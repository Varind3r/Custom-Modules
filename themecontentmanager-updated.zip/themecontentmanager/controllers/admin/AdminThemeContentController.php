<?php
/**
 * Admin Controller for Theme Content Manager
 * 
 * This controller handles the theme options sidebar and content management
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class AdminThemeContentController extends ModuleAdminController
{
    public function __construct()
    {
        // Set module for ModuleAdminController
        $this->module = Module::getInstanceByName('themecontentmanager');
        
        $this->bootstrap = true;
        $this->display = 'view';
        $this->meta_title = $this->l('Theme Content Manager');
        
        parent::__construct();
        
        if (!$this->module || !$this->module->id) {
            Tools::redirectAdmin($this->context->link->getAdminLink('AdminModules'));
        }
    }

    public function initContent()
    {
        parent::initContent();

        $this->context->smarty->assign(array(
            'content' => $this->renderView(),
        ));
    }

    public function renderView()
    {
        if (!$this->module) {
            return $this->l('Module not found');
        }
        
        $module = $this->module;
        
        // Get all pages
        $pages = $this->getAvailablePages();
        
        // Get current page identifier with validation
        $page_identifier = Tools::getValue('page', 'home');
        if (!Validate::isGenericName($page_identifier)) {
            $page_identifier = 'home';
        }
        
        // Get all content for current page
        $page_content = $module->getAllPageContent($page_identifier);
        
        // Get all fields for current page
        $fields = $this->getPageFields($page_identifier);
        
        $this->context->smarty->assign(array(
            'pages' => $pages,
            'current_page' => $page_identifier,
            'page_content' => $page_content,
            'fields' => $fields,
            'languages' => Language::getLanguages(),
            'current_lang' => $this->context->language->id,
            'ajax_url' => $this->context->link->getAdminLink('AdminThemeContent'),
            'token' => Tools::getAdminTokenLite('AdminThemeContent'),
        ));

        $template_path = _PS_MODULE_DIR_ . 'themecontentmanager/views/templates/admin/theme_options.tpl';
        
        if (!file_exists($template_path)) {
            return '<div class="alert alert-danger">Template file not found: ' . $template_path . '</div>';
        }

        return $this->context->smarty->fetch($template_path);
    }

    public function postProcess()
    {
        if (Tools::isSubmit('deleteContent')) {
            $this->deleteContent();
        }
        
        parent::postProcess();
    }

    public function ajaxProcessSaveContent()
    {
        // Security checks
        if (!Tools::getValue('ajax') || !$this->module) {
            die(json_encode(array('success' => false, 'message' => 'Invalid request')));
        }
        
        // Validate CSRF token
        if (!Tools::getValue('token') || !Validate::isCleanHtml(Tools::getValue('token'))) {
            die(json_encode(array('success' => false, 'message' => 'Invalid token')));
        }
        
        $module = $this->module;
        
        $page_identifier = Tools::getValue('page_identifier');
        $field_key = Tools::getValue('field_key');
        $field_value = Tools::getValue('field_value');
        $field_type = Tools::getValue('field_type', 'text');
        $lang_id = (int)Tools::getValue('lang_id', $this->context->language->id);
        $active = (int)Tools::getValue('active', 1);

        // Validate input
        if (empty($page_identifier) || !Validate::isGenericName($page_identifier)) {
            die(json_encode(array('success' => false, 'message' => 'Invalid page identifier')));
        }
        
        if (empty($field_key) || !Validate::isGenericName($field_key)) {
            die(json_encode(array('success' => false, 'message' => 'Invalid field key')));
        }
        
        if (!in_array($field_type, array('text', 'textarea', 'html', 'image', 'url', 'repeater'))) {
            die(json_encode(array('success' => false, 'message' => 'Invalid field type')));
        }

        // Use module's saveContent method to avoid code duplication
        $result = $module->saveContent($page_identifier, $field_key, $field_value, $field_type, $lang_id, $active);

        die(json_encode(array(
            'success' => $result,
            'message' => $result ? $this->l('Content saved successfully') : $this->l('Error saving content')
        )));
    }

    public function ajaxProcessGetContent()
    {
        // Security check
        if (!Tools::getValue('ajax') || !$this->module) {
            die(json_encode(array('success' => false, 'message' => 'Invalid request')));
        }
        
        $module = Module::getInstanceByName('themecontentmanager');
        
        $page_identifier = Tools::getValue('page_identifier');
        $field_key = Tools::getValue('field_key');
        $lang_id = (int)Tools::getValue('lang_id', $this->context->language->id);

        // Validate input
        if (empty($page_identifier) || !Validate::isGenericName($page_identifier)) {
            die(json_encode(array('success' => false, 'message' => 'Invalid page identifier')));
        }
        
        if (empty($field_key) || !Validate::isGenericName($field_key)) {
            die(json_encode(array('success' => false, 'message' => 'Invalid field key')));
        }

        $content = $module->getContentValue($page_identifier, $field_key, $lang_id);

        die(json_encode(array(
            'success' => true,
            'content' => $content
        )));
    }

    public function ajaxProcessGetPageContent()
    {
        // Security check
        if (!Tools::getValue('ajax') || !$this->module) {
            die(json_encode(array('success' => false, 'message' => 'Invalid request')));
        }
        
        $module = $this->module;
        
        $page_identifier = Tools::getValue('page_identifier');
        $lang_id = (int)Tools::getValue('lang_id', $this->context->language->id);

        // Validate input
        if (empty($page_identifier) || !Validate::isGenericName($page_identifier)) {
            die(json_encode(array('success' => false, 'message' => 'Invalid page identifier')));
        }

        $content = $module->getAllPageContent($page_identifier, $lang_id);

        die(json_encode(array(
            'success' => true,
            'content' => $content
        )));
    }


    private function deleteContent()
    {
        $id_content = (int)Tools::getValue('id_content');
        if ($id_content > 0) {
            $sql = 'DELETE FROM `' . _DB_PREFIX_ . 'theme_content` WHERE id_content = ' . (int)$id_content;
            Db::getInstance()->execute($sql);
        }
    }

    private function getAvailablePages()
    {
        return array(
            'home' => $this->l('Home Page'),
            'product' => $this->l('Product Page'),
            'category' => $this->l('Category Page'),
            'blog' => $this->l('Blog Page'),
            'contact' => $this->l('Contact Page'),
            'cms' => $this->l('CMS Pages'),
            'cart' => $this->l('Shopping Cart'),
            'checkout' => $this->l('Checkout'),
            'my-account' => $this->l('My Account'),
            'footer' => $this->l('Footer'),
            'header' => $this->l('Header'),
        );
    }

    private function getPageFields($page_identifier)
    {
        // Define default fields for each page type
        $fields = array(
            'home' => array(
                array('key' => 'hero_title', 'label' => 'Hero Title', 'type' => 'text'),
                array('key' => 'hero_subtitle', 'label' => 'Hero Subtitle', 'type' => 'textarea'),
                array('key' => 'hero_image', 'label' => 'Hero Image URL', 'type' => 'image'),
                array('key' => 'hero_button_text', 'label' => 'Hero Button Text', 'type' => 'text'),
                array('key' => 'hero_button_url', 'label' => 'Hero Button URL', 'type' => 'url'),
                array('key' => 'featured_content', 'label' => 'Featured Content', 'type' => 'html'),
            ),
            'product' => array(
                array('key' => 'product_banner', 'label' => 'Product Banner', 'type' => 'html'),
                array('key' => 'product_info', 'label' => 'Product Info', 'type' => 'html'),
            ),
            'category' => array(
                array('key' => 'category_banner', 'label' => 'Category Banner', 'type' => 'html'),
                array('key' => 'category_description', 'label' => 'Category Description', 'type' => 'html'),
            ),
            'blog' => array(
                array('key' => 'blog_banner', 'label' => 'Blog Banner', 'type' => 'html'),
                array('key' => 'blog_description', 'label' => 'Blog Description', 'type' => 'html'),
                array('key' => 'blog_sidebar_content', 'label' => 'Sidebar Content', 'type' => 'html'),
            ),
            'footer' => array(
                array('key' => 'footer_text', 'label' => 'Footer Text', 'type' => 'html'),
                array('key' => 'footer_copyright', 'label' => 'Copyright Text', 'type' => 'text'),
            ),
            'header' => array(
                array('key' => 'header_banner', 'label' => 'Header Banner', 'type' => 'html'),
                array('key' => 'header_notice', 'label' => 'Header Notice', 'type' => 'text'),
            ),
        );

        return isset($fields[$page_identifier]) ? $fields[$page_identifier] : array();
    }
}

