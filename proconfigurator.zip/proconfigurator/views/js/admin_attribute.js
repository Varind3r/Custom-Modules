/**
 * ProConfigurator - Admin JS
 */
$(function () {
    // Toggle field visibility based on field type
    var fieldType = $('#field_type_selector');
    if (fieldType.length) {
        function toggleFieldTypeSettings() {
            var type = fieldType.val();

            // Number/dimension fields
            $('.number-field, .dimension-field').closest('.form-group').hide();

            if (type === 'number') {
                $('.number-field').closest('.form-group').show();
            } else if (type === 'dimensions') {
                $('.dimension-field').closest('.form-group').show();
            }
        }

        fieldType.on('change', toggleFieldTypeSettings);
        toggleFieldTypeSettings();
    }
});
