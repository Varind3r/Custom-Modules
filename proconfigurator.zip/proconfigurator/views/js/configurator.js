/**
 * ProConfigurator - Frontend JavaScript
 */

(function () {
    'use strict';

    var ProConfig = {
        basePrice: 0,
        currency: '€',
        selections: {},

        init: function () {
            var wrapper = document.getElementById('proconfigurator');
            if (!wrapper) return;

            this.basePrice = parseFloat(wrapper.dataset.basePrice) || 0;
            this.currency = window.proconfigCurrency || '€';

            this.bindEvents();
            this.initAccordion();
        },

        bindEvents: function () {
            // Option cards (radio/checkbox)
            document.querySelectorAll('.option-card input, .option-item input').forEach(function (input) {
                input.addEventListener('change', function () {
                    ProConfig.handleOptionChange(this);
                });
            });

            // Text/Number inputs
            document.querySelectorAll('.proconfig-input, .proconfig-textarea').forEach(function (input) {
                input.addEventListener('input', function () {
                    ProConfig.handleInputChange(this);
                });
                input.addEventListener('blur', function () {
                    ProConfig.validateField(this);
                });
            });

            // Select dropdowns
            document.querySelectorAll('.proconfig-select').forEach(function (select) {
                select.addEventListener('change', function () {
                    ProConfig.handleSelectChange(this);
                });
            });

            // File uploads
            document.querySelectorAll('.proconfig-file').forEach(function (input) {
                input.addEventListener('change', function () {
                    ProConfig.handleFileChange(this);
                });
            });

            // Custom input toggle
            document.querySelectorAll('.toggle-custom-input').forEach(function (checkbox) {
                checkbox.addEventListener('change', function () {
                    var customInput = this.closest('.custom-input-toggle').querySelector('.custom-value-input');
                    var select = this.closest('.proconfig-field').querySelector('.proconfig-select');
                    if (this.checked) {
                        customInput.style.display = 'block';
                        select.disabled = true;
                    } else {
                        customInput.style.display = 'none';
                        select.disabled = false;
                    }
                });
            });

            // Add to cart
            var addBtn = document.getElementById('proconfig-add-to-cart');
            if (addBtn) {
                addBtn.addEventListener('click', function () {
                    ProConfig.addToCart();
                });
            }
        },

        initAccordion: function () {
            document.querySelectorAll('.proconfig-step-header').forEach(function (header) {
                header.addEventListener('click', function (e) {
                    if (e.target.closest('.step-toggle') || header.querySelector('.step-toggle')) {
                        var step = this.closest('.proconfig-step');
                        step.classList.toggle('collapsed');
                    }
                });
            });
        },

        handleOptionChange: function (input) {
            var field = input.closest('.proconfig-field');
            var attrId = field.dataset.attrId;
            var card = input.closest('.option-card, .option-item');

            // Update visual state for radio buttons
            if (input.type === 'radio') {
                field.querySelectorAll('.option-card, .option-item').forEach(function (c) {
                    c.classList.remove('selected');
                });
                if (input.checked) {
                    card.classList.add('selected');
                    this.selections[attrId] = input.value;
                }
            } else {
                // Checkboxes - collect all checked values
                var values = [];
                field.querySelectorAll('input:checked').forEach(function (cb) {
                    values.push(cb.value);
                });
                this.selections[attrId] = values;
            }

            // Handle dependencies
            this.processDependencies(input);

            this.updateSummary();
            this.updatePrice();
            this.validateForm();
        },

        handleInputChange: function (input) {
            var field = input.closest('.proconfig-field');
            var attrId = field.dataset.attrId;
            var fieldType = field.dataset.fieldType;

            if (fieldType === 'dimensions') {
                var widthInput = field.querySelector('[data-dimension="width"]');
                var heightInput = field.querySelector('[data-dimension="height"]');
                if (widthInput && heightInput) {
                    this.selections[attrId] = {
                        width: parseFloat(widthInput.value) || 0,
                        height: parseFloat(heightInput.value) || 0
                    };
                }
            } else {
                this.selections[attrId] = input.value;
            }

            this.updateSummary();
            this.updatePrice();
            this.validateForm();
        },

        handleSelectChange: function (select) {
            var field = select.closest('.proconfig-field');
            var attrId = field.dataset.attrId;
            this.selections[attrId] = select.value;

            this.updateSummary();
            this.updatePrice();
            this.validateForm();
        },

        handleFileChange: function (input) {
            var wrapper = input.closest('.file-upload-wrapper');
            var nameSpan = wrapper.querySelector('.file-name');
            if (input.files.length > 0) {
                nameSpan.textContent = input.files[0].name;
                var field = input.closest('.proconfig-field');
                this.selections[field.dataset.attrId] = 'file:' + input.files[0].name;
            }
            this.validateForm();
        },

        validateField: function (input) {
            var field = input.closest('.proconfig-field');
            var errorSpan = field.querySelector('.field-error');
            var isValid = true;

            if (field.dataset.required === '1' && !input.value.trim()) {
                isValid = false;
            }

            if (input.type === 'number') {
                var val = parseFloat(input.value);
                var min = parseFloat(input.min);
                var max = parseFloat(input.max);
                if (!isNaN(min) && val < min) isValid = false;
                if (!isNaN(max) && val > max) isValid = false;
            }

            if (input.pattern) {
                var regex = new RegExp(input.pattern);
                if (!regex.test(input.value)) isValid = false;
            }

            if (!isValid) {
                input.classList.add('error');
                errorSpan.style.display = 'block';
            } else {
                input.classList.remove('error');
                errorSpan.style.display = 'none';
            }

            return isValid;
        },

        validateForm: function () {
            var isValid = true;
            var requiredFields = document.querySelectorAll('.proconfig-field[data-required="1"]');

            requiredFields.forEach(function (field) {
                var fieldType = field.dataset.fieldType;
                var attrId = field.dataset.attrId;
                var hasValue = false;

                if (['radio_image', 'radio_text', 'radio_color'].indexOf(fieldType) >= 0) {
                    hasValue = field.querySelector('input:checked') !== null;
                } else if (fieldType === 'dropdown') {
                    var select = field.querySelector('select');
                    hasValue = select && select.value !== '';
                } else if (fieldType === 'dimensions') {
                    var w = field.querySelector('[data-dimension="width"]');
                    var h = field.querySelector('[data-dimension="height"]');
                    hasValue = w && h && w.value && h.value;
                } else {
                    var input = field.querySelector('.proconfig-input, .proconfig-textarea');
                    hasValue = input && input.value.trim() !== '';
                }

                if (!hasValue) isValid = false;
            });

            var addBtn = document.getElementById('proconfig-add-to-cart');
            if (addBtn) {
                addBtn.disabled = !isValid;
            }

            return isValid;
        },

        processDependencies: function (input) {
            var deps = input.dataset.dependencies;
            if (!deps) return;

            try {
                var rules = JSON.parse(deps);

                // Show groups
                if (rules.show_groups) {
                    rules.show_groups.forEach(function (groupId) {
                        var group = document.querySelector('.proconfig-step[data-step-id="' + groupId + '"]');
                        if (group) group.style.display = 'block';
                    });
                }

                // Hide groups
                if (rules.hide_groups) {
                    rules.hide_groups.forEach(function (groupId) {
                        var group = document.querySelector('.proconfig-step[data-step-id="' + groupId + '"]');
                        if (group) group.style.display = 'none';
                    });
                }

                // Show attributes
                if (rules.show_attributes) {
                    rules.show_attributes.forEach(function (attrId) {
                        var field = document.querySelector('.proconfig-field[data-attr-id="' + attrId + '"]');
                        if (field) field.style.display = 'block';
                    });
                }

                // Hide attributes
                if (rules.hide_attributes) {
                    rules.hide_attributes.forEach(function (attrId) {
                        var field = document.querySelector('.proconfig-field[data-attr-id="' + attrId + '"]');
                        if (field) field.style.display = 'none';
                    });
                }
            } catch (e) {
                console.error('Invalid dependencies JSON:', e);
            }
        },

        updateSummary: function () {
            var container = document.getElementById('proconfig-selections');
            if (!container) return;

            var html = '';
            var hasSelections = false;

            for (var attrId in this.selections) {
                var value = this.selections[attrId];
                if (!value || (Array.isArray(value) && value.length === 0)) continue;

                hasSelections = true;
                var field = document.querySelector('.proconfig-field[data-attr-id="' + attrId + '"]');
                var label = field ? field.querySelector('.field-label').textContent.replace('*', '').trim() : 'Option';
                var displayValue = this.getDisplayValue(field, value);

                html += '<div class="selection-item">' +
                    '<span class="selection-label">' + label + '</span>' +
                    '<span class="selection-value">' + displayValue + '</span>' +
                    '</div>';
            }

            container.innerHTML = hasSelections ? html : '<p class="no-selections">Select options above to see your configuration.</p>';
        },

        getDisplayValue: function (field, value) {
            if (!field) return value;

            var fieldType = field.dataset.fieldType;

            if (typeof value === 'object' && value.width !== undefined) {
                return value.width + ' × ' + value.height + ' mm';
            }

            if (['radio_image', 'radio_text', 'radio_color', 'dropdown'].indexOf(fieldType) >= 0) {
                var option = field.querySelector('[value="' + value + '"]');
                if (option) {
                    var card = option.closest('.option-card, .option-item');
                    if (card) {
                        var labelEl = card.querySelector('.option-label, .option-content strong');
                        if (labelEl) return labelEl.textContent;
                    }
                    // For select options
                    if (option.tagName === 'OPTION') return option.textContent.split('(')[0].trim();
                }
            }

            return value;
        },

        updatePrice: function () {
            var optionsTotal = 0;

            document.querySelectorAll('.proconfig-field').forEach(function (field) {
                var attrId = field.dataset.attrId;
                var selection = ProConfig.selections[attrId];
                if (!selection) return;

                // Check for dimension-based pricing
                var dimensions = null;
                for (var key in ProConfig.selections) {
                    if (typeof ProConfig.selections[key] === 'object' && ProConfig.selections[key].width) {
                        dimensions = ProConfig.selections[key];
                        break;
                    }
                }

                var widthM = dimensions ? dimensions.width / 1000 : 0;
                var heightM = dimensions ? dimensions.height / 1000 : 0;
                var area = widthM * heightM;
                var perimeter = 2 * (widthM + heightM);

                // Get price from selected option
                var input = field.querySelector('input:checked, select');
                if (input) {
                    var price = parseFloat(input.dataset.price || 0);
                    var priceType = input.dataset.priceType || 'fixed';

                    if (input.tagName === 'SELECT' && input.selectedIndex > 0) {
                        var opt = input.options[input.selectedIndex];
                        price = parseFloat(opt.dataset.price || 0);
                        priceType = opt.dataset.priceType || 'fixed';
                    }

                    switch (priceType) {
                        case 'percent':
                            optionsTotal += (ProConfig.basePrice * price / 100);
                            break;
                        case 'rate_m2':
                            optionsTotal += (price * area);
                            break;
                        case 'rate_m':
                            optionsTotal += (price * perimeter);
                            break;
                        default:
                            optionsTotal += price;
                    }
                }
            });

            var total = this.basePrice + optionsTotal;

            var optionsPriceEl = document.getElementById('proconfig-options-price');
            var totalPriceEl = document.getElementById('proconfig-total-price');
            var optionsRow = document.querySelector('.options-price');

            if (optionsTotal > 0 && optionsRow) {
                optionsRow.style.display = 'flex';
                optionsPriceEl.textContent = '+' + optionsTotal.toFixed(2) + ' ' + this.currency;
            } else if (optionsRow) {
                optionsRow.style.display = 'none';
            }

            if (totalPriceEl) {
                totalPriceEl.textContent = total.toFixed(2) + ' ' + this.currency;
            }
        },

        addToCart: function () {
            if (!this.validateForm()) return;

            var dataInput = document.getElementById('proconfig_data');
            dataInput.value = JSON.stringify(this.selections);

            // Trigger PrestaShop add to cart
            var productForm = document.querySelector('form.add-to-cart-or-refresh, form[data-product-add-to-cart]');
            if (productForm) {
                var submitBtn = productForm.querySelector('[data-button-action="add-to-cart"], .add-to-cart');
                if (submitBtn) {
                    submitBtn.click();
                }
            }
        }
    };

    // Initialize on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () {
            ProConfig.init();
        });
    } else {
        ProConfig.init();
    }

    // Expose globally
    window.ProConfig = ProConfig;
})();
