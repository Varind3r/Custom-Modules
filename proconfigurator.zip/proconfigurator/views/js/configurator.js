(function ($) {
    'use strict';

    var Configurator = {
        basePrice: typeof proconfigBasePrice !== 'undefined' ? proconfigBasePrice : 0,
        productId: typeof proconfigProductId !== 'undefined' ? proconfigProductId : 0,
        selections: {}, // groupId -> { fieldId -> value }

        init: function () {
            this.cacheElements();
            this.bindEvents();
            this.initConditions();
        },

        cacheElements: function () {
            this.$wrapper = $('#proconfigurator');
            this.$navItems = this.$wrapper.find('.nav-item');
            this.$panels = this.$wrapper.find('.proconfig-step-panel');
            this.$addToCartBtn = this.$wrapper.find('#proconfig-add-to-cart');
            this.$totalPrice = this.$wrapper.find('#proconfig-total-price');
            this.$adjustments = this.$wrapper.find('#proconfig-adjustments');
            this.$adjustmentAmount = this.$wrapper.find('#proconfig-adjustment-amount');
            this.$selections = this.$wrapper.find('#proconfig-selections');
            this.$dataInput = this.$wrapper.find('#proconfig_data');
        },

        bindEvents: function () {
            var self = this;

            // Step navigation
            this.$wrapper.on('click', '.nav-item', function () {
                self.switchStep($(this).data('target-step'));
            });

            this.$wrapper.on('click', '.next-step-btn', function () {
                self.switchStep($(this).data('next'));
            });

            this.$wrapper.on('click', '.prev-step-btn', function () {
                self.switchStep($(this).data('prev'));
            });

            this.$wrapper.on('click', '#proconfig-finish-btn', function () {
                // Focus on summary or scroll to it
                if ($(window).width() < 992) {
                    $('html, body').animate({
                        scrollTop: $(".proconfig-summary-sidebar").offset().top
                    }, 500);
                }
            });

            // Radio Card Selection
            this.$wrapper.on('click', '.proconfig-value-card:not(.checkbox-mode)', function () {
                var $card = $(this);
                var stepId = $card.data('step-id');
                var $section = $card.closest('.proconfig-section');
                var fieldId = $section.data('field-id');

                $section.find('.proconfig-value-card').removeClass('selected');
                $card.addClass('selected');

                self.updateSelection(stepId, fieldId, $card.data('value-id'), $card.data('label'), $card.data('price'), $card.data('dependencies'));
            });

            // Checkbox Card Selection
            this.$wrapper.on('click', '.proconfig-value-card.checkbox-mode', function () {
                var $card = $(this);
                var stepId = $card.data('step-id');
                var $section = $card.closest('.proconfig-section');
                var fieldId = $section.data('field-id');

                $card.toggleClass('selected');

                var selectedValues = [];
                $section.find('.proconfig-value-card.selected').each(function () {
                    selectedValues.push($(this).data('value-id'));
                });

                self.updateSelection(stepId, fieldId, selectedValues, 'Multiple', 0, $card.data('dependencies'));
            });

            // Select Dropdown
            this.$wrapper.on('change', '.proconfig-select', function () {
                var $select = $(this);
                var fieldId = $select.data('field-id');
                var stepId = $select.closest('.proconfig-step-panel').data('step-id');
                var $opt = $select.find('option:selected');

                if ($select.val()) {
                    self.updateSelection(stepId, fieldId, $select.val(), $opt.data('label'), $opt.data('price'), $opt.data('dependencies'));
                } else {
                    self.removeSelection(stepId, fieldId);
                }
            });

            // Inputs (Text, Number, etc.)
            this.$wrapper.on('input change', 'input.proconfig-text, input.proconfig-number, textarea.proconfig-textarea', function () {
                var $input = $(this);
                var fieldId = $input.data('field-id');
                var stepId = $input.closest('.proconfig-step-panel').data('step-id');
                var val = $input.val();

                // Validation for height/width
                if ($input.hasClass('proconfig-number')) {
                    var min = parseFloat($input.data('min'));
                    var max = parseFloat($input.data('max'));
                    var fVal = parseFloat(val);
                    var $msg = $input.closest('.proconfig-field-input-wrapper').find('.validation-msg');

                    if (val && (fVal < min || fVal > max)) {
                        $msg.text('Value must be between ' + min + ' and ' + max).show();
                        $input.addClass('invalid');
                    } else {
                        $msg.hide();
                        $input.removeClass('invalid');
                    }
                }

                if (val) {
                    self.updateSelection(stepId, fieldId, val, val, 0, '');
                } else {
                    self.removeSelection(stepId, fieldId);
                }
            });

            // File Upload
            this.$wrapper.on('change', '.proconfig-file', function () {
                var $input = $(this);
                var fieldId = $input.data('field-id');
                var stepId = $input.closest('.proconfig-step-panel').data('step-id');
                var file = this.files[0];

                if (file) {
                    var formData = new FormData();
                    formData.append('file', file);
                    formData.append('action', 'uploadFile');

                    $input.attr('disabled', true);

                    $.ajax({
                        url: proconfigAjaxUrl,
                        type: 'POST',
                        data: formData,
                        processData: false,
                        contentType: false,
                        dataType: 'json',
                        success: function (response) {
                            $input.attr('disabled', false);
                            if (response.success) {
                                self.updateSelection(stepId, fieldId, response.filename, response.original_name, 0, '');
                            } else {
                                alert(response.error);
                            }
                        },
                        error: function () {
                            $input.attr('disabled', false);
                            alert('File upload failed.');
                        }
                    });
                }
            });

            // Add to cart
            this.$addToCartBtn.on('click', function () {
                self.addToCart();
            });
        },

        initConditions: function () {
            // Initially hide anything that might be hidden by default if we implement complex logic
        },

        updateSelection: function (stepId, fieldId, value, label, price, dependencies) {
            if (!this.selections[stepId]) this.selections[stepId] = {};
            this.selections[stepId][fieldId] = {
                val: value,
                label: label,
                price: price
            };

            if (dependencies) {
                this.handleDependencies(dependencies);
            }

            this.updatePrice();
            this.updateSummary();
        },

        removeSelection: function (stepId, fieldId) {
            if (this.selections[stepId]) {
                delete this.selections[stepId][fieldId];
            }
            this.updatePrice();
            this.updateSummary();
        },

        handleDependencies: function (depStr) {
            var self = this;
            var rules = depStr.split(';');
            rules.forEach(function (rule) {
                var parts = rule.trim().split(':');
                if (parts.length === 2) {
                    var action = parts[0].trim();
                    var targetId = parts[1].trim();

                    if (action === 'show_field') {
                        $('.proconfig-section[data-field-id="' + targetId + '"]').fadeIn();
                    } else if (action === 'hide_field') {
                        $('.proconfig-section[data-field-id="' + targetId + '"]').fadeOut();
                        var stepId = $('.proconfig-section[data-field-id="' + targetId + '"]').closest('.proconfig-step-panel').data('step-id');
                        self.removeSelection(stepId, targetId);
                    } else if (action === 'show_value') {
                        $('.proconfig-value-card[data-value-id="' + targetId + '"]').fadeIn();
                        $('option[value="' + targetId + '"]').show();
                    } else if (action === 'hide_value') {
                        $('.proconfig-value-card[data-value-id="' + targetId + '"]').fadeOut();
                        $('option[value="' + targetId + '"]').hide();
                    } else if (action === 'show_step' || action === 'show_group') {
                        $('.nav-item[data-target-step="' + targetId + '"]').show();
                    } else if (action === 'hide_step' || action === 'hide_group') {
                        $('.nav-item[data-target-step="' + targetId + '"]').hide();
                    }
                }
            });
        },

        switchStep: function (stepIndex) {
            this.$navItems.removeClass('active').eq(stepIndex).addClass('active');
            this.$panels.removeClass('active').eq(stepIndex).addClass('active');
        },

        updatePrice: function () {
            var self = this;
            var flatSelections = {};

            // We need a way to pass this to the backend. The backend currently expects groupId -> valueId.
            // But we have groupId (stepId) -> fieldId -> value.
            // Let's adapt the JSON structure.
            $.each(this.selections, function (stepId, fields) {
                $.each(fields, function (fieldId, data) {
                    // For now, let's just send everything flat or nested.
                    // The backend needs to be updated too if it expects a specific format.
                    flatSelections[fieldId] = data.val;
                });
            });

            this.$dataInput.val(JSON.stringify(flatSelections));

            $.ajax({
                url: proconfigAjaxUrl,
                type: 'POST',
                data: {
                    action: 'updatePrice',
                    id_product: this.productId,
                    selections: flatSelections
                },
                dataType: 'json',
                success: function (response) {
                    if (response.success) {
                        self.$totalPrice.text(response.formatted_price);
                        if (response.price_impact !== 0) {
                            self.$adjustments.show();
                            self.$adjustmentAmount.text((response.price_impact > 0 ? '+' : '') + response.price_impact_formatted);
                        } else {
                            self.$adjustments.hide();
                        }
                    }
                }
            });
        },

        updateSummary: function () {
            var html = '';
            var hasSelections = false;

            $.each(this.selections, function (stepId, fields) {
                $.each(fields, function (fieldId, data) {
                    html += '<div class="summary-item">' +
                        '<strong>' + data.label + '</strong>' +
                        '</div>';
                    hasSelections = true;
                });
            });

            if (hasSelections) {
                this.$selections.html(html);
            } else {
                this.$selections.html('<p class="empty-msg">Start selecting to see details</p>');
            }
        },

        addToCart: function () {
            var self = this;

            // Basic validation
            var $invalid = this.$wrapper.find('.invalid');
            if ($invalid.length) {
                alert('Please fix validation errors before adding to cart.');
                $invalid.first().focus();
                return;
            }

            var $form = $('#add-to-cart-or-refresh');
            if (!$form.length) $form = $('form[action*="cart"]');

            if (!$form.length) {
                alert('Could not find Add to Cart form.');
                return;
            }

            // Ensure our data is in the form
            if (!this.$dataInput.closest('form').length) {
                this.$dataInput.appendTo($form);
            }

            $form.submit();
        }
    };

    $(document).ready(function () {
        if ($('#proconfigurator').length) {
            Configurator.init();
        }
    });

})(jQuery);

