<?php
/**
 * Database Installation for ProConfigurator
 * FIXED VERSION - with better error handling and upgrade support
 */

function proconfigurator_install_db()
{
    $db = Db::getInstance();
    $success = true;
    $errors = [];

    // Array of all tables to create
    $tables = [];

    // 1. Groups (Steps) - Main navigation steps
    $tables['proconfig_group'] = '
        CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_group` (
            `id_group` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
            `image` VARCHAR(255) DEFAULT NULL,
            `icon` VARCHAR(255) DEFAULT NULL,
            `color_from` VARCHAR(32) DEFAULT NULL,
            `color_to` VARCHAR(32) DEFAULT NULL,
            `is_collapsible` TINYINT(1) UNSIGNED DEFAULT 0,
            `is_repeater` TINYINT(1) UNSIGNED DEFAULT 0,
            `active` TINYINT(1) UNSIGNED DEFAULT 1,
            `sort_order` INT(11) DEFAULT 0,
            `date_add` DATETIME DEFAULT CURRENT_TIMESTAMP,
            `date_upd` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id_group`),
            KEY `active` (`active`),
            KEY `sort_order` (`sort_order`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';

    $tables['proconfig_group_lang'] = '
        CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_group_lang` (
            `id_group` INT(11) UNSIGNED NOT NULL,
            `id_lang` INT(11) UNSIGNED NOT NULL,
            `name` VARCHAR(255) NOT NULL,
            `public_title` VARCHAR(255) DEFAULT NULL,
            `description` TEXT DEFAULT NULL,
            PRIMARY KEY (`id_group`, `id_lang`),
            KEY `id_lang` (`id_lang`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';

    // 2. Fields (Sections within a Step)
    $tables['proconfig_field'] = '
        CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_field` (
            `id_field` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
            `id_group` INT(11) UNSIGNED NOT NULL,
            `field_type` VARCHAR(50) DEFAULT \'radio\',
            `min_value` DECIMAL(20,6) DEFAULT 0,
            `max_value` DECIMAL(20,6) DEFAULT 0,
            `is_required` TINYINT(1) UNSIGNED DEFAULT 0,
            `active` TINYINT(1) UNSIGNED DEFAULT 1,
            `sort_order` INT(11) DEFAULT 0,
            PRIMARY KEY (`id_field`),
            KEY `id_group` (`id_group`),
            KEY `active` (`active`),
            KEY `sort_order` (`sort_order`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';

    $tables['proconfig_field_lang'] = '
        CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_field_lang` (
            `id_field` INT(11) UNSIGNED NOT NULL,
            `id_lang` INT(11) UNSIGNED NOT NULL,
            `title` VARCHAR(255) NOT NULL,
            `description` TEXT DEFAULT NULL,
            PRIMARY KEY (`id_field`, `id_lang`),
            KEY `id_lang` (`id_lang`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';

    // 3. Values (The selectable items)
    $tables['proconfig_group_value'] = '
        CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_group_value` (
            `id_group_value` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
            `id_field` INT(11) UNSIGNED NOT NULL,
            `id_group` INT(11) UNSIGNED DEFAULT NULL,
            `image` VARCHAR(255) DEFAULT NULL,
            `color_code` VARCHAR(32) DEFAULT NULL,
            `id_manufacturer` INT(11) UNSIGNED DEFAULT 0,
            `price_impact` DECIMAL(20,6) DEFAULT 0,
            `price_impact_type` VARCHAR(20) DEFAULT \'fixed\',
            `dependencies` TEXT DEFAULT NULL,
            `active` TINYINT(1) UNSIGNED DEFAULT 1,
            `sort_order` INT(11) DEFAULT 0,
            `filter_tag` VARCHAR(255) DEFAULT NULL,
            `show_when` VARCHAR(255) DEFAULT NULL,
            PRIMARY KEY (`id_group_value`),
            KEY `id_field` (`id_field`),
            KEY `id_group` (`id_group`),
            KEY `active` (`active`),
            KEY `sort_order` (`sort_order`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';

    $tables['proconfig_group_value_lang'] = '
        CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_group_value_lang` (
            `id_group_value` INT(11) UNSIGNED NOT NULL,
            `id_lang` INT(11) UNSIGNED NOT NULL,
            `label` VARCHAR(255) NOT NULL,
            `description` TEXT DEFAULT NULL,
            PRIMARY KEY (`id_group_value`, `id_lang`),
            KEY `id_lang` (`id_lang`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';

    // 4. Product Configuration (Enable/disable per product + group order)
    $tables['proconfig_product'] = '
        CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_product` (
            `id_product` INT(11) UNSIGNED NOT NULL,
            `enabled` TINYINT(1) UNSIGNED DEFAULT 0,
            `group_order` TEXT DEFAULT NULL,
            PRIMARY KEY (`id_product`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';

    // 5. Product-specific value overrides (custom prices, labels, availability)
    $tables['proconfig_product_group_value'] = '
        CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_product_group_value` (
            `id_product` INT(11) UNSIGNED NOT NULL,
            `id_group_value` INT(11) UNSIGNED NOT NULL,
            `is_available` TINYINT(1) UNSIGNED DEFAULT 1,
            `custom_label` VARCHAR(255) DEFAULT NULL,
            `price_impact` DECIMAL(20,6) DEFAULT NULL,
            `price_impact_type` VARCHAR(20) DEFAULT NULL,
            PRIMARY KEY (`id_product`, `id_group_value`),
            KEY `id_product` (`id_product`),
            KEY `id_group_value` (`id_group_value`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';

    // 6. Cart configuration data (temporary storage before order)
    $tables['proconfig_cart_data'] = '
        CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_cart_data` (
            `id_cart` INT(11) UNSIGNED NOT NULL,
            `id_product` INT(11) UNSIGNED NOT NULL,
            `id_product_attribute` INT(11) UNSIGNED DEFAULT 0,
            `config_json` LONGTEXT NOT NULL,
            `calculated_price` DECIMAL(20,6) NOT NULL,
            `date_add` DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id_cart`, `id_product`, `id_product_attribute`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';

    // 7. Order configuration data (permanent storage after order)
    $tables['proconfig_order_data'] = '
        CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_order_data` (
            `id_proconfig_order_data` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
            `id_order` INT(11) UNSIGNED NOT NULL,
            `id_product` INT(11) UNSIGNED NOT NULL,
            `id_product_attribute` INT(11) UNSIGNED DEFAULT 0,
            `config_json` LONGTEXT NOT NULL,
            `config_summary` TEXT DEFAULT NULL,
            `calculated_price` DECIMAL(20,6) NOT NULL,
            `date_add` DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id_proconfig_order_data`),
            KEY `id_order` (`id_order`),
            KEY `id_product` (`id_product`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';

    // Execute each table creation
    foreach ($tables as $tableName => $sql) {
        try {
            $result = $db->execute($sql);
            if (!$result) {
                $errors[] = "Failed to create table: {$tableName}. Error: " . $db->getMsgError();
                $success = false;
            }
        } catch (Exception $e) {
            $errors[] = "Exception creating table {$tableName}: " . $e->getMessage();
            $success = false;
        }
    }

    // Log errors if any
    if (!empty($errors)) {
        foreach ($errors as $error) {
            PrestaShopLogger::addLog('ProConfigurator Install: ' . $error, 3);
        }
    }

    return $success;
}

/**
 * Upgrade function - run this to add missing columns to existing tables
 */
function proconfigurator_upgrade_db()
{
    $db = Db::getInstance();
    $alterations = [];

    // Check and add missing columns to proconfig_field
    $fieldColumns = $db->executeS('SHOW COLUMNS FROM `' . _DB_PREFIX_ . 'proconfig_field`');
    $existingFieldCols = array_column($fieldColumns, 'Field');

    if (!in_array('field_type', $existingFieldCols)) {
        $alterations[] = "ALTER TABLE `" . _DB_PREFIX_ . "proconfig_field` ADD COLUMN `field_type` VARCHAR(50) DEFAULT 'radio' AFTER `id_group`";
    }
    if (!in_array('min_value', $existingFieldCols)) {
        $alterations[] = "ALTER TABLE `" . _DB_PREFIX_ . "proconfig_field` ADD COLUMN `min_value` DECIMAL(20,6) DEFAULT 0 AFTER `field_type`";
    }
    if (!in_array('max_value', $existingFieldCols)) {
        $alterations[] = "ALTER TABLE `" . _DB_PREFIX_ . "proconfig_field` ADD COLUMN `max_value` DECIMAL(20,6) DEFAULT 0 AFTER `min_value`";
    }
    if (!in_array('is_required', $existingFieldCols)) {
        $alterations[] = "ALTER TABLE `" . _DB_PREFIX_ . "proconfig_field` ADD COLUMN `is_required` TINYINT(1) UNSIGNED DEFAULT 0 AFTER `max_value`";
    }

    // Check and fix price_impact_type column in proconfig_group_value (change from ENUM to VARCHAR for flexibility)
    $valueColumns = $db->executeS('SHOW COLUMNS FROM `' . _DB_PREFIX_ . 'proconfig_group_value`');
    foreach ($valueColumns as $col) {
        if ($col['Field'] === 'price_impact_type' && strpos($col['Type'], 'enum') !== false) {
            $alterations[] = "ALTER TABLE `" . _DB_PREFIX_ . "proconfig_group_value` MODIFY COLUMN `price_impact_type` VARCHAR(20) DEFAULT 'fixed'";
        }
    }

    // Execute alterations
    foreach ($alterations as $sql) {
        try {
            $db->execute($sql);
        } catch (Exception $e) {
            PrestaShopLogger::addLog('ProConfigurator Upgrade: ' . $e->getMessage(), 2);
        }
    }

    return true;
}

/**
 * Uninstall function - drops all tables
 */
function proconfigurator_uninstall_db()
{
    $db = Db::getInstance();
    $tables = [
        'proconfig_order_data',
        'proconfig_cart_data',
        'proconfig_product_group_value',
        'proconfig_product',
        'proconfig_group_value_lang',
        'proconfig_group_value',
        'proconfig_field_lang',
        'proconfig_field',
        'proconfig_group_lang',
        'proconfig_group',
    ];

    foreach ($tables as $table) {
        $db->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . $table . '`');
    }

    return true;
}
