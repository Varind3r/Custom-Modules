<?php
/**
 * Database Installation for ProConfigurator
 */

function proconfigurator_install_db()
{
    $sql = [];

    // 1. Groups (Steps)
    $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_group` (
        `id_group` INT(11) NOT NULL AUTO_INCREMENT,
        `image` VARCHAR(255) DEFAULT NULL,
        `icon` VARCHAR(255) DEFAULT NULL,
        `color_from` VARCHAR(7) DEFAULT NULL,
        `color_to` VARCHAR(7) DEFAULT NULL,
        `is_collapsible` TINYINT(1) DEFAULT 0,
        `is_repeater` TINYINT(1) DEFAULT 0,
        `active` TINYINT(1) DEFAULT 1,
        `sort_order` INT(11) DEFAULT 0,
        `date_add` DATETIME NOT NULL,
        `date_upd` DATETIME NOT NULL,
        PRIMARY KEY (`id_group`)
    ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';

    $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_group_lang` (
        `id_group` INT(11) NOT NULL,
        `id_lang` INT(11) NOT NULL,
        `name` VARCHAR(255) NOT NULL,
        `public_title` VARCHAR(255) DEFAULT NULL,
        `description` TEXT DEFAULT NULL,
        PRIMARY KEY (`id_group`, `id_lang`)
    ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';

    // 2. NEW: Fields (Sub-sections within a Step)
    $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_field` (
        `id_field` INT(11) NOT NULL AUTO_INCREMENT,
        `id_group` INT(11) NOT NULL,
        `active` TINYINT(1) DEFAULT 1,
        `sort_order` INT(11) DEFAULT 0,
        PRIMARY KEY (`id_field`)
    ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';

    $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_field_lang` (
        `id_field` INT(11) NOT NULL,
        `id_lang` INT(11) NOT NULL,
        `title` VARCHAR(255) NOT NULL,
        `description` TEXT DEFAULT NULL,
        PRIMARY KEY (`id_field`, `id_lang`)
    ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';

    // 3. Values (The Items) - NOW LINKED TO FIELD
    $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_group_value` (
        `id_group_value` INT(11) NOT NULL AUTO_INCREMENT,
        `id_field` INT(11) NOT NULL,
        `id_group` INT(11) DEFAULT NULL,
        `image` VARCHAR(255) DEFAULT NULL,
        `color_code` VARCHAR(7) DEFAULT NULL,
        `id_manufacturer` INT(11) DEFAULT 0,
        `price_impact` DECIMAL(20,6) DEFAULT 0,
        `price_impact_type` ENUM(\'fixed\', \'percent\') DEFAULT \'fixed\',
        `dependencies` TEXT DEFAULT NULL,
        `active` TINYINT(1) DEFAULT 1,
        `sort_order` INT(11) DEFAULT 0,
        PRIMARY KEY (`id_group_value`)
    ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';

    $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_group_value_lang` (
        `id_group_value` INT(11) NOT NULL,
        `id_lang` INT(11) NOT NULL,
        `label` VARCHAR(255) NOT NULL,
        `description` TEXT DEFAULT NULL,
        PRIMARY KEY (`id_group_value`, `id_lang`)
    ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';

    // Table: proconfig_product
    $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_product` (
        `id_product` int(11) NOT NULL,
        `enabled` tinyint(1) DEFAULT 0,
        `group_order` text,
        PRIMARY KEY (`id_product`)
    ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';

    // Table: proconfig_product_group_value
    $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_product_group_value` (
        `id_product` int(11) NOT NULL,
        `id_group_value` int(11) NOT NULL,
        `is_available` tinyint(1) DEFAULT 1,
        `custom_label` varchar(255) DEFAULT NULL,
        `price_impact` decimal(20,6) DEFAULT NULL,
        `price_impact_type` enum(\'fixed\', \'percent\', \'rate_m2\', \'rate_m\') DEFAULT NULL,
        PRIMARY KEY (`id_product`, `id_group_value`)
    ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';

    // Table: proconfig_cart_data
    $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_cart_data` (
        `id_cart` int(11) NOT NULL,
        `id_product` int(11) NOT NULL,
        `config_json` text NOT NULL,
        `calculated_price` decimal(20,6) NOT NULL,
        PRIMARY KEY (`id_cart`, `id_product`)
    ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';

    // Table: proconfig_order_data
    $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_order_data` (
        `id_proconfig_order_data` int(11) NOT NULL AUTO_INCREMENT,
        `id_order` int(11) NOT NULL,
        `id_product` int(11) NOT NULL,
        `config_json` text NOT NULL,
        `config_summary` text,
        `calculated_price` decimal(20,6) NOT NULL,
        PRIMARY KEY (`id_proconfig_order_data`),
        KEY `id_order` (`id_order`)
    ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';

    foreach ($sql as $query) {
        if (Db::getInstance()->execute($query) == false) {
            return false;
        }
    }

    return true;
}
