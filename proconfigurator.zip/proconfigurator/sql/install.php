<?php
/**
 * ProConfigurator - Database Installation
 */

function proconfigurator_install_db()
{
    $sql = [];

    // Groups (Steps)
    $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_group` (
        `id_group` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `icon` VARCHAR(64) DEFAULT NULL,
        `color_from` VARCHAR(32) DEFAULT "#f97316",
        `color_to` VARCHAR(32) DEFAULT "#fbbf24",
        `is_collapsible` TINYINT(1) UNSIGNED DEFAULT 1,
        `active` TINYINT(1) UNSIGNED DEFAULT 1,
        `sort_order` INT UNSIGNED DEFAULT 0,
        `date_add` DATETIME DEFAULT CURRENT_TIMESTAMP,
        `date_upd` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id_group`)
    ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

    $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_group_lang` (
        `id_group` INT UNSIGNED NOT NULL,
        `id_lang` INT UNSIGNED NOT NULL,
        `name` VARCHAR(255) NOT NULL,
        `description` TEXT,
        PRIMARY KEY (`id_group`, `id_lang`)
    ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

    // Attributes (Fields)
    $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_attribute` (
        `id_attribute` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `id_group` INT UNSIGNED DEFAULT NULL,
        `field_type` VARCHAR(50) NOT NULL DEFAULT "text",
        `is_required` TINYINT(1) UNSIGNED DEFAULT 0,
        `allow_user_input` TINYINT(1) UNSIGNED DEFAULT 0,
        `validation_regex` VARCHAR(255) DEFAULT NULL,
        `min_value` DECIMAL(10,2) DEFAULT NULL,
        `max_value` DECIMAL(10,2) DEFAULT NULL,
        `step_value` DECIMAL(10,2) DEFAULT 1,
        `min_width` DECIMAL(10,2) DEFAULT NULL,
        `max_width` DECIMAL(10,2) DEFAULT NULL,
        `min_height` DECIMAL(10,2) DEFAULT NULL,
        `max_height` DECIMAL(10,2) DEFAULT NULL,
        `price_impact` DECIMAL(20,6) DEFAULT 0,
        `price_impact_type` VARCHAR(20) DEFAULT "fixed",
        `active` TINYINT(1) UNSIGNED DEFAULT 1,
        `sort_order` INT UNSIGNED DEFAULT 0,
        `date_add` DATETIME DEFAULT CURRENT_TIMESTAMP,
        `date_upd` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id_attribute`),
        KEY `id_group` (`id_group`)
    ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

    $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_attribute_lang` (
        `id_attribute` INT UNSIGNED NOT NULL,
        `id_lang` INT UNSIGNED NOT NULL,
        `name` VARCHAR(255) NOT NULL,
        `description` TEXT,
        `placeholder` VARCHAR(255) DEFAULT NULL,
        `suffix` VARCHAR(50) DEFAULT NULL,
        `validation_error` VARCHAR(255) DEFAULT NULL,
        PRIMARY KEY (`id_attribute`, `id_lang`)
    ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

    // Group-Attribute Link (for global attributes assigned to multiple groups)
    $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_group_attribute` (
        `id_group` INT UNSIGNED NOT NULL,
        `id_attribute` INT UNSIGNED NOT NULL,
        `sort_order` INT UNSIGNED DEFAULT 0,
        PRIMARY KEY (`id_group`, `id_attribute`)
    ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

    // Options (Values)
    $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_option` (
        `id_option` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `id_attribute` INT UNSIGNED NOT NULL,
        `image` VARCHAR(255) DEFAULT NULL,
        `color_code` VARCHAR(32) DEFAULT NULL,
        `color_gradient` VARCHAR(128) DEFAULT NULL,
        `price_impact` DECIMAL(20,6) DEFAULT 0,
        `price_impact_type` VARCHAR(20) DEFAULT "fixed",
        `dependencies` TEXT,
        `active` TINYINT(1) UNSIGNED DEFAULT 1,
        `sort_order` INT UNSIGNED DEFAULT 0,
        `date_add` DATETIME DEFAULT CURRENT_TIMESTAMP,
        `date_upd` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id_option`),
        KEY `id_attribute` (`id_attribute`)
    ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

    $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_option_lang` (
        `id_option` INT UNSIGNED NOT NULL,
        `id_lang` INT UNSIGNED NOT NULL,
        `label` VARCHAR(255) NOT NULL,
        `description` TEXT,
        `badge` VARCHAR(64) DEFAULT NULL,
        `feature_list` TEXT,
        `content_field_1` VARCHAR(500) DEFAULT NULL,
        `content_field_2` VARCHAR(500) DEFAULT NULL,
        `content_field_3` VARCHAR(500) DEFAULT NULL,
        PRIMARY KEY (`id_option`, `id_lang`)
    ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

    // Product Configuration
    $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_product` (
        `id_product` INT UNSIGNED NOT NULL,
        `enabled` TINYINT(1) UNSIGNED DEFAULT 0,
        `group_order` TEXT,
        PRIMARY KEY (`id_product`)
    ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

    $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_product_attribute` (
        `id_product` INT UNSIGNED NOT NULL,
        `id_attribute` INT UNSIGNED NOT NULL,
        `is_available` TINYINT(1) UNSIGNED DEFAULT 1,
        `custom_label` VARCHAR(255) DEFAULT NULL,
        `price_impact` DECIMAL(20,6) DEFAULT NULL,
        `price_impact_type` VARCHAR(20) DEFAULT NULL,
        PRIMARY KEY (`id_product`, `id_attribute`)
    ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

    $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_product_option` (
        `id_product` INT UNSIGNED NOT NULL,
        `id_option` INT UNSIGNED NOT NULL,
        `is_available` TINYINT(1) UNSIGNED DEFAULT 1,
        `custom_label` VARCHAR(255) DEFAULT NULL,
        `image_override` VARCHAR(255) DEFAULT NULL,
        `price_impact` DECIMAL(20,6) DEFAULT NULL,
        `price_impact_type` VARCHAR(20) DEFAULT NULL,
        PRIMARY KEY (`id_product`, `id_option`)
    ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

    // Cart Data
    $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_cart_data` (
        `id_cart` INT UNSIGNED NOT NULL,
        `id_product` INT UNSIGNED NOT NULL,
        `id_product_attribute` INT UNSIGNED DEFAULT 0,
        `config_json` TEXT,
        `calculated_price` DECIMAL(20,6) DEFAULT 0,
        PRIMARY KEY (`id_cart`, `id_product`, `id_product_attribute`)
    ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

    // Order Data
    $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'proconfig_order_data` (
        `id_order` INT UNSIGNED NOT NULL,
        `id_product` INT UNSIGNED NOT NULL,
        `config_json` TEXT,
        `config_summary` TEXT,
        `calculated_price` DECIMAL(20,6) DEFAULT 0,
        PRIMARY KEY (`id_order`, `id_product`)
    ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

    foreach ($sql as $query) {
        if (!Db::getInstance()->execute($query)) {
            return false;
        }
    }

    return true;
}

function proconfigurator_uninstall_db()
{
    $tables = [
        'proconfig_group',
        'proconfig_group_lang',
        'proconfig_attribute',
        'proconfig_attribute_lang',
        'proconfig_group_attribute',
        'proconfig_option',
        'proconfig_option_lang',
        'proconfig_product',
        'proconfig_product_attribute',
        'proconfig_product_option',
        'proconfig_cart_data',
        'proconfig_order_data',
    ];

    foreach ($tables as $table) {
        Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . $table . '`');
    }

    return true;
}
