<?php
/**
 * ProConfigurator Module
 * Advanced Product Configurator for PrestaShop
 *
 * @author  Antigravity
 * @version 2.0.0
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

// Autoload classes
spl_autoload_register(function ($class) {
    $prefix = 'ProConfig';
    if (strpos($class, $prefix) === 0) {
        $file = __DIR__ . '/classes/' . $class . '.php';
        if (file_exists($file)) {
            require_once $file;
        }
    }
});

class ProConfigurator extends Module
{
    public function __construct()
    {
        $this->name = 'proconfigurator';
        $this->tab = 'front_office_features';
        $this->version = '2.0.0';
        $this->author = 'Antigravity';
        $this->need_instance = 0;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Pro Configurator');
        $this->description = $this->l('Advanced product configurator with custom attributes, conditional logic, and dynamic pricing.');
        $this->ps_versions_compliancy = ['min' => '1.7.0.0', 'max' => _PS_VERSION_];
    }

    public function install()
    {
        return parent::install()
            && $this->installDatabase()
            && $this->installTabs()
            && $this->registerHook('displayAdminProductsExtra')
            && $this->registerHook('actionProductSave')
            && $this->registerHook('displayProductExtraContent')
            && $this->registerHook('actionCartSave')
            && $this->registerHook('actionValidateOrder')
            && $this->registerHook('displayAdminOrder')
            && $this->registerHook('displayOrderConfirmation')
            && $this->registerHook('displayShoppingCart')
            && $this->registerHook('actionEmailSendBefore')
            && $this->registerHook('displayHeader');
    }

    public function uninstall()
    {
        return $this->uninstallTabs() && parent::uninstall();
    }

    private function installDatabase()
    {
        $sqlFile = dirname(__FILE__) . '/sql/install.php';
        if (file_exists($sqlFile)) {
            require_once $sqlFile;
            return proconfigurator_install_db();
        }
        return false;
    }

    private function installTabs()
    {
        $parentTab = new Tab();
        $parentTab->active = 1;
        $parentTab->class_name = 'AdminProConfigParent';
        $parentTab->name = [];
        foreach (Language::getLanguages(true) as $lang) {
            $parentTab->name[$lang['id_lang']] = 'Pro Configurator';
        }
        $parentTab->id_parent = (int)Tab::getIdFromClassName('IMPROVE');
        $parentTab->module = $this->name;
        $parentTab->icon = 'settings';
        if (!$parentTab->add()) {
            return false;
        }

        $tabs = [
            ['class' => 'AdminProConfigGroups', 'name' => 'Groups (Steps)', 'icon' => 'view_list'],
            ['class' => 'AdminProConfigAttributes', 'name' => 'Attributes (Fields)', 'icon' => 'tune'],
            ['class' => 'AdminProConfigOptions', 'name' => 'Options (Values)', 'icon' => 'list_alt'],
        ];

        foreach ($tabs as $tabData) {
            $tab = new Tab();
            $tab->active = 1;
            $tab->class_name = $tabData['class'];
            $tab->name = [];
            foreach (Language::getLanguages(true) as $lang) {
                $tab->name[$lang['id_lang']] = $tabData['name'];
            }
            $tab->id_parent = (int)Tab::getIdFromClassName('AdminProConfigParent');
            $tab->module = $this->name;
            $tab->icon = $tabData['icon'];
            if (!$tab->add()) {
                return false;
            }
        }

        return true;
    }

    private function uninstallTabs()
    {
        $tabs = ['AdminProConfigOptions', 'AdminProConfigAttributes', 'AdminProConfigGroups', 'AdminProConfigParent'];
        foreach ($tabs as $className) {
            $id = (int)Tab::getIdFromClassName($className);
            if ($id) {
                $tab = new Tab($id);
                $tab->delete();
            }
        }
        return true;
    }

    public function getContent()
    {
        Tools::redirectAdmin($this->context->link->getAdminLink('AdminProConfigGroups'));
    }

    /* =========================================================================
       HOOK: displayHeader - Add CSS/JS to front-end
       ========================================================================= */
    public function hookDisplayHeader($params)
    {
        $controller = $this->context->controller;
        if ($controller instanceof ProductController) {
            $this->context->controller->addCSS($this->_path . 'views/css/configurator.css');
            $this->context->controller->addJS($this->_path . 'views/js/configurator.js');
        }
    }

    /* =========================================================================
       HOOK: displayAdminProductsExtra - Product edit tab
       ========================================================================= */
    public function hookDisplayAdminProductsExtra($params)
    {
        $idProduct = (int)$params['id_product'];
        $idLang = (int)$this->context->language->id;

        // Get all groups with their attributes
        $groups = ProConfigGroup::getAll($idLang);
        foreach ($groups as &$group) {
            $group['attributes'] = ProConfigAttribute::getByGroup((int)$group['id_group'], $idLang);
            foreach ($group['attributes'] as &$attr) {
                $attr['options'] = ProConfigOption::getByAttribute((int)$attr['id_attribute'], $idLang);
            }
        }

        // Get product configuration
        $productConfig = Db::getInstance()->getRow(
            'SELECT * FROM `' . _DB_PREFIX_ . 'proconfig_product` WHERE id_product = ' . $idProduct
        );
        $enabled = $productConfig ? (int)$productConfig['enabled'] : 0;
        $groupOrder = $productConfig && $productConfig['group_order'] ? json_decode($productConfig['group_order'], true) : [];

        // Get product-specific overrides
        $attrOverrides = [];
        $optOverrides = [];
        
        $attrRows = Db::getInstance()->executeS(
            'SELECT * FROM `' . _DB_PREFIX_ . 'proconfig_product_attribute` WHERE id_product = ' . $idProduct
        );
        foreach ($attrRows as $row) {
            $attrOverrides[(int)$row['id_attribute']] = $row;
        }

        $optRows = Db::getInstance()->executeS(
            'SELECT * FROM `' . _DB_PREFIX_ . 'proconfig_product_option` WHERE id_product = ' . $idProduct
        );
        foreach ($optRows as $row) {
            $optOverrides[(int)$row['id_option']] = $row;
        }

        $this->context->smarty->assign([
            'product_id' => $idProduct,
            'enabled' => $enabled,
            'groups' => $groups,
            'group_order' => $groupOrder,
            'attr_overrides' => $attrOverrides,
            'opt_overrides' => $optOverrides,
            'module_path' => $this->_path,
        ]);

        return $this->display(__FILE__, 'views/templates/hook/admin_product.tpl');
    }

    /* =========================================================================
       HOOK: actionProductSave - Save product configurator settings
       ========================================================================= */
    public function hookActionProductSave($params)
    {
        $idProduct = (int)$params['id_product'];
        
        if (!Tools::isSubmit('proconfig_enabled')) {
            return;
        }

        $enabled = (int)Tools::getValue('proconfig_enabled');
        $groupOrder = Tools::getValue('proconfig_group_order');
        $groupOrderJson = is_array($groupOrder) ? json_encode($groupOrder) : '[]';

        // Upsert product config
        Db::getInstance()->execute('
            INSERT INTO `' . _DB_PREFIX_ . 'proconfig_product` (id_product, enabled, group_order)
            VALUES (' . $idProduct . ', ' . $enabled . ', \'' . pSQL($groupOrderJson) . '\')
            ON DUPLICATE KEY UPDATE enabled = ' . $enabled . ', group_order = \'' . pSQL($groupOrderJson) . '\'
        ');

        // Save attribute overrides
        $attrOverrides = Tools::getValue('attr_override');
        if (is_array($attrOverrides)) {
            foreach ($attrOverrides as $attrId => $data) {
                Db::getInstance()->execute('DELETE FROM `' . _DB_PREFIX_ . 'proconfig_product_attribute` 
                    WHERE id_product = ' . $idProduct . ' AND id_attribute = ' . (int)$attrId);
                
                Db::getInstance()->insert('proconfig_product_attribute', [
                    'id_product' => $idProduct,
                    'id_attribute' => (int)$attrId,
                    'is_available' => isset($data['available']) ? (int)$data['available'] : 1,
                    'custom_label' => pSQL($data['label'] ?? ''),
                    'price_impact' => (float)($data['price'] ?? 0),
                    'price_impact_type' => pSQL($data['price_type'] ?? 'fixed'),
                ]);
            }
        }

        // Save option overrides
        $optOverrides = Tools::getValue('opt_override');
        if (is_array($optOverrides)) {
            foreach ($optOverrides as $optId => $data) {
                Db::getInstance()->execute('DELETE FROM `' . _DB_PREFIX_ . 'proconfig_product_option` 
                    WHERE id_product = ' . $idProduct . ' AND id_option = ' . (int)$optId);
                
                Db::getInstance()->insert('proconfig_product_option', [
                    'id_product' => $idProduct,
                    'id_option' => (int)$optId,
                    'is_available' => isset($data['available']) ? (int)$data['available'] : 1,
                    'custom_label' => pSQL($data['label'] ?? ''),
                    'image_override' => pSQL($data['image'] ?? ''),
                    'price_impact' => (float)($data['price'] ?? 0),
                    'price_impact_type' => pSQL($data['price_type'] ?? 'fixed'),
                ]);
            }
        }
    }

    /* =========================================================================
       HOOK: displayProductExtraContent - Front-end configurator
       ========================================================================= */
    public function hookDisplayProductExtraContent($params)
    {
        $idProduct = (int)$params['product']->id;
        $idLang = (int)$this->context->language->id;

        // Check if configurator is enabled for this product
        $config = Db::getInstance()->getRow(
            'SELECT * FROM `' . _DB_PREFIX_ . 'proconfig_product` WHERE id_product = ' . $idProduct . ' AND enabled = 1'
        );
        
        if (!$config) {
            return [];
        }

        $groupOrder = json_decode($config['group_order'], true) ?: [];
        
        // Build configurator data
        $steps = [];
        foreach ($groupOrder as $groupId) {
            $group = new ProConfigGroup((int)$groupId, $idLang);
            if (!Validate::isLoadedObject($group) || !$group->active) {
                continue;
            }

            $stepData = [
                'id' => (int)$group->id,
                'name' => $group->name,
                'description' => $group->description,
                'icon' => $group->icon,
                'color_from' => $group->color_from,
                'color_to' => $group->color_to,
                'is_collapsible' => (int)$group->is_collapsible,
                'attributes' => [],
            ];

            $attributes = ProConfigAttribute::getByGroup((int)$group->id, $idLang);
            foreach ($attributes as $attr) {
                // Check product override availability
                $override = Db::getInstance()->getRow(
                    'SELECT * FROM `' . _DB_PREFIX_ . 'proconfig_product_attribute` 
                     WHERE id_product = ' . $idProduct . ' AND id_attribute = ' . (int)$attr['id_attribute']
                );
                
                if ($override && !$override['is_available']) {
                    continue;
                }

                $attrData = [
                    'id' => (int)$attr['id_attribute'],
                    'name' => $override && $override['custom_label'] ? $override['custom_label'] : $attr['name'],
                    'description' => $attr['description'],
                    'field_type' => $attr['field_type'],
                    'is_required' => (int)$attr['is_required'],
                    'allow_user_input' => (int)$attr['allow_user_input'],
                    'placeholder' => $attr['placeholder'],
                    'suffix' => $attr['suffix'],
                    'min_value' => $attr['min_value'],
                    'max_value' => $attr['max_value'],
                    'step_value' => $attr['step_value'],
                    'min_width' => $attr['min_width'],
                    'max_width' => $attr['max_width'],
                    'min_height' => $attr['min_height'],
                    'max_height' => $attr['max_height'],
                    'validation_regex' => $attr['validation_regex'],
                    'validation_error' => $attr['validation_error'],
                    'options' => [],
                ];

                // Get options
                $options = ProConfigOption::getByAttribute((int)$attr['id_attribute'], $idLang);
                foreach ($options as $opt) {
                    $optOverride = Db::getInstance()->getRow(
                        'SELECT * FROM `' . _DB_PREFIX_ . 'proconfig_product_option` 
                         WHERE id_product = ' . $idProduct . ' AND id_option = ' . (int)$opt['id_option']
                    );

                    if ($optOverride && !$optOverride['is_available']) {
                        continue;
                    }

                    $attrData['options'][] = [
                        'id' => (int)$opt['id_option'],
                        'label' => $optOverride && $optOverride['custom_label'] ? $optOverride['custom_label'] : $opt['label'],
                        'description' => $opt['description'],
                        'image' => $optOverride && $optOverride['image_override'] ? $optOverride['image_override'] : $opt['image'],
                        'color_code' => $opt['color_code'],
                        'color_gradient' => $opt['color_gradient'],
                        'badge' => $opt['badge'],
                        'feature_list' => $opt['feature_list'],
                        'content_field_1' => $opt['content_field_1'],
                        'content_field_2' => $opt['content_field_2'],
                        'content_field_3' => $opt['content_field_3'],
                        'price_impact' => $optOverride ? (float)$optOverride['price_impact'] : (float)$opt['price_impact'],
                        'price_impact_type' => $optOverride && $optOverride['price_impact_type'] ? $optOverride['price_impact_type'] : $opt['price_impact_type'],
                        'dependencies' => $opt['dependencies'],
                    ];
                }

                $stepData['attributes'][] = $attrData;
            }

            if (!empty($stepData['attributes'])) {
                $steps[] = $stepData;
            }
        }

        if (empty($steps)) {
            return [];
        }

        $basePrice = Product::getPriceStatic($idProduct, true);
        $currency = $this->context->currency;

        $this->context->smarty->assign([
            'proconfig_steps' => $steps,
            'proconfig_product_id' => $idProduct,
            'proconfig_base_price' => $basePrice,
            'proconfig_currency' => $currency,
            'proconfig_ajax_url' => $this->context->link->getModuleLink($this->name, 'ajax'),
        ]);

        $content = $this->display(__FILE__, 'views/templates/front/configurator.tpl');

        return [
            (new PrestaShop\PrestaShop\Core\Product\ProductExtraContent())
                ->setTitle($this->l('Configure Your Product'))
                ->setContent($content)
        ];
    }

    /* =========================================================================
       HOOK: actionCartSave - Save configuration to cart
       ========================================================================= */
    public function hookActionCartSave($params)
    {
        if (!isset($this->context->cart) || !$this->context->cart->id) {
            return;
        }

        $configJson = Tools::getValue('proconfig_data');
        $idProduct = (int)Tools::getValue('id_product');
        $idProductAttribute = (int)Tools::getValue('id_product_attribute');

        if (!$configJson || !$idProduct) {
            return;
        }

        $config = json_decode($configJson, true);
        if (!$config) {
            return;
        }

        // Calculate price
        $calculatedPrice = ProConfigPriceCalculator::calculate($idProduct, $config, $this->context);

        // Store in cart data table
        Db::getInstance()->execute('
            INSERT INTO `' . _DB_PREFIX_ . 'proconfig_cart_data` 
            (id_cart, id_product, id_product_attribute, config_json, calculated_price)
            VALUES (' . (int)$this->context->cart->id . ', ' . $idProduct . ', ' . $idProductAttribute . ', 
                    \'' . pSQL($configJson) . '\', ' . (float)$calculatedPrice . ')
            ON DUPLICATE KEY UPDATE config_json = \'' . pSQL($configJson) . '\', 
                                    calculated_price = ' . (float)$calculatedPrice
        );
    }

    /* =========================================================================
       HOOK: actionValidateOrder - Copy config to order
       ========================================================================= */
    public function hookActionValidateOrder($params)
    {
        $order = $params['order'];
        $cart = $params['cart'];

        $configs = Db::getInstance()->executeS(
            'SELECT * FROM `' . _DB_PREFIX_ . 'proconfig_cart_data` WHERE id_cart = ' . (int)$cart->id
        );

        foreach ($configs as $config) {
            $summary = $this->buildConfigSummary(json_decode($config['config_json'], true));
            
            Db::getInstance()->insert('proconfig_order_data', [
                'id_order' => (int)$order->id,
                'id_product' => (int)$config['id_product'],
                'config_json' => pSQL($config['config_json']),
                'config_summary' => pSQL($summary),
                'calculated_price' => (float)$config['calculated_price'],
            ]);
        }

        // Clean cart data
        Db::getInstance()->execute(
            'DELETE FROM `' . _DB_PREFIX_ . 'proconfig_cart_data` WHERE id_cart = ' . (int)$cart->id
        );
    }

    private function buildConfigSummary($config)
    {
        $idLang = (int)$this->context->language->id;
        $lines = [];

        foreach ($config as $attrId => $value) {
            $attr = new ProConfigAttribute((int)$attrId, $idLang);
            if (!Validate::isLoadedObject($attr)) {
                continue;
            }

            $label = $attr->name;
            $displayValue = '';

            if (is_array($value) && isset($value['width'], $value['height'])) {
                $displayValue = $value['width'] . ' x ' . $value['height'] . ' mm';
            } elseif (is_numeric($value) && $attr->requiresOptions()) {
                $opt = new ProConfigOption((int)$value, $idLang);
                $displayValue = Validate::isLoadedObject($opt) ? $opt->label : $value;
            } else {
                $displayValue = $value;
            }

            $lines[] = $label . ': ' . $displayValue;
        }

        return implode(' | ', $lines);
    }

    /* =========================================================================
       HOOK: displayAdminOrder - Show config in back-office
       ========================================================================= */
    public function hookDisplayAdminOrder($params)
    {
        $idOrder = (int)$params['id_order'];
        
        $configs = Db::getInstance()->executeS(
            'SELECT od.*, p.name as product_name FROM `' . _DB_PREFIX_ . 'proconfig_order_data` od
             LEFT JOIN `' . _DB_PREFIX_ . 'product_lang` p ON od.id_product = p.id_product 
                AND p.id_lang = ' . (int)$this->context->language->id . '
             WHERE od.id_order = ' . $idOrder
        );

        if (empty($configs)) {
            return '';
        }

        $this->context->smarty->assign(['proconfig_orders' => $configs]);
        return $this->display(__FILE__, 'views/templates/hook/admin_order.tpl');
    }

    /* =========================================================================
       HOOK: displayOrderConfirmation - Show config on thank you page
       ========================================================================= */
    public function hookDisplayOrderConfirmation($params)
    {
        $order = $params['order'];
        
        $configs = Db::getInstance()->executeS(
            'SELECT * FROM `' . _DB_PREFIX_ . 'proconfig_order_data` WHERE id_order = ' . (int)$order->id
        );

        if (empty($configs)) {
            return '';
        }

        $this->context->smarty->assign(['proconfig_orders' => $configs]);
        return $this->display(__FILE__, 'views/templates/hook/order_confirmation.tpl');
    }

    /* =========================================================================
       HOOK: displayShoppingCart - Show config summary in cart
       ========================================================================= */
    public function hookDisplayShoppingCart($params)
    {
        if (!isset($this->context->cart) || !$this->context->cart->id) {
            return '';
        }

        $configs = Db::getInstance()->executeS(
            'SELECT * FROM `' . _DB_PREFIX_ . 'proconfig_cart_data` WHERE id_cart = ' . (int)$this->context->cart->id
        );

        if (empty($configs)) {
            return '';
        }

        $configData = [];
        foreach ($configs as $config) {
            $summary = $this->buildConfigSummary(json_decode($config['config_json'], true));
            $configData[(int)$config['id_product']] = [
                'summary' => $summary,
                'price' => (float)$config['calculated_price'],
            ];
        }

        $this->context->smarty->assign(['proconfig_cart_data' => $configData]);
        return $this->display(__FILE__, 'views/templates/hook/cart_summary.tpl');
    }

    /* =========================================================================
       HOOK: actionEmailSendBefore - Add config to order emails
       ========================================================================= */
    public function hookActionEmailSendBefore($params)
    {
        if (!isset($params['templateVars']['{id_order}'])) {
            return;
        }

        $idOrder = (int)$params['templateVars']['{id_order}'];
        
        $configs = Db::getInstance()->executeS(
            'SELECT * FROM `' . _DB_PREFIX_ . 'proconfig_order_data` WHERE id_order = ' . $idOrder
        );

        if (!empty($configs)) {
            $html = '<br><strong>' . $this->l('Product Configurations') . ':</strong><br>';
            foreach ($configs as $config) {
                $html .= '<br>' . nl2br(str_replace(' | ', "\n", $config['config_summary']));
            }
            $params['templateVars']['{proconfig_summary}'] = $html;
        } else {
            $params['templateVars']['{proconfig_summary}'] = '';
        }
    }

    /* =========================================================================
       Helper: Get image upload path
       ========================================================================= */
    public function getImageUploadPath()
    {
        $themePath = _PS_THEME_DIR_ . 'assets/img/configurator/';
        if (!is_dir($themePath)) {
            @mkdir($themePath, 0755, true);
        }
        return $themePath;
    }

    public function getImageUploadUrl()
    {
        return _THEME_DIR_ . 'assets/img/configurator/';
    }
}
