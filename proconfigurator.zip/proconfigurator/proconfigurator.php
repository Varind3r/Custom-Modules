<?php
/**
 * ProConfigurator Module - Updated
 * Advanced Product Configurator for PrestaShop
 *
 * @author  Antigravity
 * @version 2.2.0
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

// Autoload classes
spl_autoload_register(function ($class) {
    $prefix = 'ProConfig';
    if (strpos($class, $prefix) === 0) {
        $file = __DIR__ . '/classes/' . $class . '.php';
        if (file_exists($file)) {
            require_once $file;
        }
    }
});

class ProConfigurator extends Module
{
    public function __construct()
    {
        $this->name = 'proconfigurator';
        $this->tab = 'front_office_features';
        $this->version = '2.2.0';
        $this->author = 'Antigravity';
        $this->need_instance = 0;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Pro Configurator');
        $this->description = $this->l('Advanced product configurator with custom groups, repeatable values, and dynamic pricing.');
        $this->ps_versions_compliancy = ['min' => '1.7.0.0', 'max' => _PS_VERSION_];
    }

    public function install()
    {
        return parent::install()
            && $this->installDatabase()
            && $this->installTabs()
            && $this->registerHook('displayAdminProductsExtra')
            && $this->registerHook('actionProductSave')
            && $this->registerHook('displayProductExtraContent')
            && $this->registerHook('actionCartSave')
            && $this->registerHook('actionValidateOrder')
            && $this->registerHook('displayAdminOrder')
            && $this->registerHook('displayOrderConfirmation')
            && $this->registerHook('displayShoppingCart')
            && $this->registerHook('actionEmailSendBefore')
            && $this->registerHook('displayHeader');
    }

    public function uninstall()
    {
        return $this->uninstallTabs() && parent::uninstall();
    }

    private function installDatabase()
    {
        $sqlFile = dirname(__FILE__) . '/sql/install.php';
        if (file_exists($sqlFile)) {
            require_once $sqlFile;
            return proconfigurator_install_db();
        }
        return false;
    }

    private function installTabs()
    {
        $parentTab = new Tab();
        $parentTab->active = 1;
        $parentTab->class_name = 'AdminProConfigParent';
        $parentTab->name = [];
        foreach (Language::getLanguages(true) as $lang) {
            $parentTab->name[$lang['id_lang']] = 'Pro Configurator';
        }
        $parentTab->id_parent = (int) Tab::getIdFromClassName('IMPROVE');
        $parentTab->module = $this->name;
        $parentTab->icon = 'settings';
        if (!$parentTab->add()) {
            return false;
        }

        // UPDATED: Only 2 tabs now (Groups and GroupValues)
        $tabs = [
            ['class' => 'AdminProConfigGroups', 'name' => 'Groups (Steps)', 'icon' => 'view_list'],
            ['class' => 'AdminProConfigGroupValue', 'name' => 'Group Values', 'icon' => 'list_alt'],
        ];

        foreach ($tabs as $tabData) {
            $tab = new Tab();
            $tab->active = 1;
            $tab->class_name = $tabData['class'];
            $tab->name = [];
            foreach (Language::getLanguages(true) as $lang) {
                $tab->name[$lang['id_lang']] = $tabData['name'];
            }
            $tab->id_parent = (int) Tab::getIdFromClassName('AdminProConfigParent');
            $tab->module = $this->name;
            $tab->icon = $tabData['icon'];
            if (!$tab->add()) {
                return false;
            }
        }

        return true;
    }

    private function uninstallTabs()
    {
        $tabs = ['AdminProConfigGroupValue', 'AdminProConfigGroups', 'AdminProConfigParent'];
        foreach ($tabs as $className) {
            $id = (int) Tab::getIdFromClassName($className);
            if ($id) {
                $tab = new Tab($id);
                $tab->delete();
            }
        }
        return true;
    }

    public function getContent()
    {
        Tools::redirectAdmin($this->context->link->getAdminLink('AdminProConfigGroups'));
    }

    /* =========================================================================
       HOOK: displayHeader - Add CSS/JS to front-end
       ========================================================================= */
    public function hookDisplayHeader($params)
    {
        $controller = $this->context->controller;
        if ($controller instanceof ProductController) {
            $this->context->controller->addCSS($this->_path . 'views/css/configurator.css');
            $this->context->controller->addJS($this->_path . 'views/js/configurator.js');
        }
    }

    /* =========================================================================
       HOOK: displayProductExtraContent - Front-end configurator
       ========================================================================= */
    public function hookDisplayProductExtraContent($params)
    {
        $idProduct = (int) $params['product']->id;
        $idLang = (int) $this->context->language->id;

        $config = Db::getInstance()->getRow(
            'SELECT * FROM `' . _DB_PREFIX_ . 'proconfig_product` WHERE id_product = ' . $idProduct . ' AND enabled = 1'
        );

        if (!$config) return [];

        $groupOrder = json_decode($config['group_order'], true) ?: [];
        $steps = [];

        foreach ($groupOrder as $groupId) {
            $group = ProConfigGroup::getWithFieldsAndValues((int) $groupId, $idLang);
            
            if (!$group || !$group['active']) continue;

            $stepData = [
                'id' => (int) $group['id_group'],
                'name' => $group['name'],
                'public_title' => $group['public_title'],
                'image' => $group['image'],
                'color_from' => $group['color_from'],
                'color_to' => $group['color_to'],
                'sections' => [],
            ];

            foreach ($group['fields'] as $field) {
                if (!$field['active']) continue;

                $sectionData = [
                    'id' => (int) $field['id_field'],
                    'title' => $field['title'],
                    'description' => $field['description'],
                    'field_type' => $field['field_type'],
                    'min_value' => (float) $field['min_value'],
                    'max_value' => (float) $field['max_value'],
                    'is_required' => (int) $field['is_required'],
                    'values' => [],
                ];

                foreach ($field['values'] as $value) {
                    if (!$value['active']) continue;

                    // Check product override
                    $override = Db::getInstance()->getRow(
                        'SELECT * FROM `' . _DB_PREFIX_ . 'proconfig_product_group_value` 
                         WHERE id_product = ' . $idProduct . ' AND id_group_value = ' . (int) $value['id_group_value']
                    );

                    if ($override && !$override['is_available']) continue;

                    $sectionData['values'][] = [
                        'id' => (int) $value['id_group_value'],
                        'label' => $override && $override['custom_label'] ? $override['custom_label'] : $value['label'],
                        'description' => $value['description'],
                        'image' => $value['image'],
                        'price_impact' => $override ? (float) $override['price_impact'] : (float) $value['price_impact'],
                        'price_impact_type' => $override && $override['price_impact_type'] ? $override['price_impact_type'] : $value['price_impact_type'],
                        'dependencies' => $value['dependencies'],
                    ];
                }

                if (!empty($sectionData['values'])) {
                    $stepData['sections'][] = $sectionData;
                }
            }

            if (!empty($stepData['sections'])) {
                $steps[] = $stepData;
            }
        }

        if (empty($steps)) return [];

        $this->context->smarty->assign([
            'proconfig_steps' => $steps,
            'proconfig_product_id' => $idProduct,
            'proconfig_base_price' => Product::getPriceStatic($idProduct, true),
            'proconfig_currency' => $this->context->currency,
            'proconfig_ajax_url' => $this->context->link->getModuleLink($this->name, 'ajax'),
            'proconfig_img_path' => _PS_BASE_URL_.__PS_BASE_URI__.'themes/child_classic/assets/img/configurator/',
        ]);

        return [
            (new PrestaShop\PrestaShop\Core\Product\ProductExtraContent())
                ->setTitle($this->l('Configure Your Product'))
                ->setContent($this->display(__FILE__, 'views/templates/front/configurator.tpl'))
        ];
    }


    /* =========================================================================
       HOOK: displayAdminProductsExtra - Product edit tab
       ========================================================================= */
    public function hookDisplayAdminProductsExtra($params)
    {
        $idProduct = (int) $params['id_product'];
        $idLang = (int) $this->context->language->id;

        // Get all groups
        $groups = ProConfigGroup::getAll($idLang);

        // Get product configuration
        $productConfig = Db::getInstance()->getRow(
            'SELECT * FROM `' . _DB_PREFIX_ . 'proconfig_product` WHERE id_product = ' . $idProduct
        );
        $enabled = $productConfig ? (int) $productConfig['enabled'] : 0;
        $groupOrder = $productConfig && $productConfig['group_order'] ? json_decode($productConfig['group_order'], true) : [];

        // Get product-specific value overrides
        $valueOverrides = [];
        $valueRows = Db::getInstance()->executeS(
            'SELECT * FROM `' . _DB_PREFIX_ . 'proconfig_product_group_value` WHERE id_product = ' . $idProduct
        );
        if ($valueRows) {
            foreach ($valueRows as $row) {
                $valueOverrides[(int) $row['id_group_value']] = $row;
            }
        }

        $this->context->smarty->assign([
            'product_id' => $idProduct,
            'enabled' => $enabled,
            'groups' => $groups,
            'group_order' => $groupOrder,
            'value_overrides' => $valueOverrides,
            'module_path' => $this->_path,
        ]);

        return $this->display(__FILE__, 'views/templates/hook/admin_product.tpl');
    }

    /* =========================================================================
       HOOK: actionProductSave - Save product configurator settings
       ========================================================================= */
    public function hookActionProductSave($params)
    {
        $idProduct = (int) $params['id_product'];

        if (!Tools::isSubmit('proconfig_enabled')) {
            return;
        }

        $enabled = (int) Tools::getValue('proconfig_enabled');
        $groupOrder = Tools::getValue('proconfig_group_order');
        $groupOrderJson = is_array($groupOrder) ? json_encode($groupOrder) : '[]';

        // Upsert product config
        Db::getInstance()->execute('
            INSERT INTO `' . _DB_PREFIX_ . 'proconfig_product` (id_product, enabled, group_order)
            VALUES (' . $idProduct . ', ' . $enabled . ', \'' . pSQL($groupOrderJson) . '\')
            ON DUPLICATE KEY UPDATE enabled = ' . $enabled . ', group_order = \'' . pSQL($groupOrderJson) . '\'
        ');

        // Save value overrides
        $valueOverrides = Tools::getValue('value_override');
        if (is_array($valueOverrides)) {
            foreach ($valueOverrides as $valueId => $data) {
                Db::getInstance()->execute('DELETE FROM `' . _DB_PREFIX_ . 'proconfig_product_group_value` 
                    WHERE id_product = ' . $idProduct . ' AND id_group_value = ' . (int) $valueId);

                Db::getInstance()->insert('proconfig_product_group_value', [
                    'id_product' => $idProduct,
                    'id_group_value' => (int) $valueId,
                    'is_available' => isset($data['available']) ? (int) $data['available'] : 1,
                    'custom_label' => pSQL($data['label'] ?? ''),
                    'price_impact' => (float) ($data['price'] ?? 0),
                    'price_impact_type' => pSQL($data['price_type'] ?? 'fixed'),
                ]);
            }
        }
    }

    /* =========================================================================
       HOOK: actionCartSave - Save configuration to cart
       ========================================================================= */
    public function hookActionCartSave($params)
    {
        if (!isset($this->context->cart) || !$this->context->cart->id) {
            return;
        }

        $configJson = Tools::getValue('proconfig_data');
        $idProduct = (int) Tools::getValue('id_product');

        if (!$configJson || !$idProduct) {
            return;
        }

        $config = json_decode($configJson, true);
        if (!$config) {
            return;
        }

        // Calculate price
        $calculatedPrice = ProConfigPriceCalculator::calculate($idProduct, $config, $this->context);

        // Store in cart data table
        Db::getInstance()->execute('
            INSERT INTO `' . _DB_PREFIX_ . 'proconfig_cart_data` 
            (id_cart, id_product, config_json, calculated_price)
            VALUES (' . (int) $this->context->cart->id . ', ' . $idProduct . ', 
                    \'' . pSQL($configJson) . '\', ' . (float) $calculatedPrice . ')
            ON DUPLICATE KEY UPDATE config_json = \'' . pSQL($configJson) . '\', 
                                    calculated_price = ' . (float) $calculatedPrice
        );
    }

    /* =========================================================================
       HOOK: actionValidateOrder - Copy config to order
       ========================================================================= */
    public function hookActionValidateOrder($params)
    {
        $order = $params['order'];
        $cart = $params['cart'];

        $configs = Db::getInstance()->executeS(
            'SELECT * FROM `' . _DB_PREFIX_ . 'proconfig_cart_data` WHERE id_cart = ' . (int) $cart->id
        );

        if ($configs) {
            foreach ($configs as $config) {
                $summary = $this->buildConfigSummary(json_decode($config['config_json'], true));

                Db::getInstance()->insert('proconfig_order_data', [
                    'id_order' => (int) $order->id,
                    'id_product' => (int) $config['id_product'],
                    'config_json' => pSQL($config['config_json']),
                    'config_summary' => pSQL($summary),
                    'calculated_price' => (float) $config['calculated_price'],
                ]);
            }

            // Clean cart data
            Db::getInstance()->execute(
                'DELETE FROM `' . _DB_PREFIX_ . 'proconfig_cart_data` WHERE id_cart = ' . (int) $cart->id
            );
        }
    }

    private function buildConfigSummary($config)
    {
        $idLang = (int) $this->context->language->id;
        $lines = [];

        foreach ($config as $groupId => $valueIds) {
            $group = new ProConfigGroup((int) $groupId, $idLang);
            if (!Validate::isLoadedObject($group)) {
                continue;
            }

            $values = [];
            if (is_array($valueIds)) {
                foreach ($valueIds as $vid) {
                    $val = ProConfigGroupValue::getComplete((int) $vid, $idLang);
                    if ($val) {
                        $values[] = $val['label'];
                    }
                }
            } else {
                $val = ProConfigGroupValue::getComplete((int) $valueIds, $idLang);
                if ($val) {
                    $values[] = $val['label'];
                }
            }

            if (!empty($values)) {
                $lines[] = $group->name . ': ' . implode(', ', $values);
            }
        }

        return implode(' | ', $lines);
    }

    /* =========================================================================
       HOOK: displayAdminOrder - Show config in back-office
       ========================================================================= */
    public function hookDisplayAdminOrder($params)
    {
        $idOrder = (int) $params['id_order'];

        $configs = Db::getInstance()->executeS(
            'SELECT od.*, p.name as product_name FROM `' . _DB_PREFIX_ . 'proconfig_order_data` od
             LEFT JOIN `' . _DB_PREFIX_ . 'product_lang` p ON od.id_product = p.id_product 
                AND p.id_lang = ' . (int) $this->context->language->id . '
             WHERE od.id_order = ' . $idOrder
        );

        if (empty($configs)) {
            return '';
        }

        $this->context->smarty->assign(['proconfig_orders' => $configs]);
        return $this->display(__FILE__, 'views/templates/hook/admin_order.tpl');
    }

    /* =========================================================================
       HOOK: displayOrderConfirmation - Show config on thank you page
       ========================================================================= */
    public function hookDisplayOrderConfirmation($params)
    {
        $order = $params['order'];

        $configs = Db::getInstance()->executeS(
            'SELECT * FROM `' . _DB_PREFIX_ . 'proconfig_order_data` WHERE id_order = ' . (int) $order->id
        );

        if (empty($configs)) {
            return '';
        }

        $this->context->smarty->assign(['proconfig_orders' => $configs]);
        return $this->display(__FILE__, 'views/templates/hook/order_confirmation.tpl');
    }

    /* =========================================================================
       HOOK: displayShoppingCart - Show config summary in cart
       ========================================================================= */
    public function hookDisplayShoppingCart($params)
    {
        if (!isset($this->context->cart) || !$this->context->cart->id) {
            return '';
        }

        $configs = Db::getInstance()->executeS(
            'SELECT * FROM `' . _DB_PREFIX_ . 'proconfig_cart_data` WHERE id_cart = ' . (int) $this->context->cart->id
        );

        if (empty($configs)) {
            return '';
        }

        $configData = [];
        foreach ($configs as $config) {
            $summary = $this->buildConfigSummary(json_decode($config['config_json'], true));
            $configData[(int) $config['id_product']] = [
                'summary' => $summary,
                'price' => (float) $config['calculated_price'],
            ];
        }

        $this->context->smarty->assign(['proconfig_cart_data' => $configData]);
        return $this->display(__FILE__, 'views/templates/hook/cart_summary.tpl');
    }

    /* =========================================================================
       HOOK: actionEmailSendBefore - Add config to order emails
       ========================================================================= */
    public function hookActionEmailSendBefore($params)
    {
        if (!isset($params['templateVars']['{id_order}'])) {
            return;
        }

        $idOrder = (int) $params['templateVars']['{id_order}'];

        $configs = Db::getInstance()->executeS(
            'SELECT * FROM `' . _DB_PREFIX_ . 'proconfig_order_data` WHERE id_order = ' . $idOrder
        );

        if (!empty($configs)) {
            $html = '<br><strong>' . $this->l('Product Configurations') . ':</strong><br>';
            foreach ($configs as $config) {
                $html .= '<br>' . nl2br(str_replace(' | ', "\n", $config['config_summary']));
            }
            $params['templateVars']['{proconfig_summary}'] = $html;
        } else {
            $params['templateVars']['{proconfig_summary}'] = '';
        }
    }

    /* =========================================================================
       Helper: Get image upload path
       ========================================================================= */
    public function getImageUploadPath()
    {
        $themePath = _PS_THEME_DIR_ . 'assets/img/configurator/';
        if (!is_dir($themePath)) {
            @mkdir($themePath, 0755, true);
        }
        return $themePath;
    }

    public function getImageUploadUrl()
    {
        return _THEME_DIR_ . 'assets/img/configurator/';
    }
}
