# ProConfigurator Module - Complete Documentation

## 📋 Overview

ProConfigurator is a PrestaShop 1.7.x module that allows you to create custom product configurators with:

- **Multi-step wizard interface**
- **Multiple field types** (radio cards, checkboxes, dropdowns, text, number, dimensions, file upload)
- **Dynamic pricing** (fixed, percentage, per m², per linear meter)
- **Conditional logic** (show/hide fields, values, or steps based on selections)
- **Per-product customization** (enable/disable options, override prices)

---

## 🏗️ Architecture - How Products Get Different Options

### Step 1: Create Global Library

In the admin panel under **Pro Configurator > Groups**, you create ALL possible options:

```
Group: "Frame Type"
├── Section: "Window Style"
│   ├── Value: "Single Casement" - €0
│   ├── Value: "Double Casement" - €75
│   ├── Value: "Tilt & Turn" - €120
│   └── Value: "Sliding" - €150

Group: "Glass"
├── Section: "Glazing Type"
│   ├── Value: "Double Glazing" - €0
│   ├── Value: "Triple Glazing" - €85
│   └── Value: "Security Glass" - €120

Group: "Dimensions"
├── Section: "Width (mm)" - type: width, min: 500, max: 3000
└── Section: "Height (mm)" - type: height, min: 400, max: 2500

Group: "Color"
├── Section: "Frame Color"
│   ├── Value: "White RAL 9016" - €0
│   ├── Value: "Anthracite Grey" - €45
│   └── Value: "Oak Effect" - €65
```

### Step 2: Enable Per Product

On each product's edit page, you'll see a "Product Configurator" tab where you can:

1. **Enable/Disable** the configurator for this product
2. **Select which groups** to show (drag to reorder)
3. **Override values** per product:
   - Hide specific values
   - Change prices
   - Change labels

**Example for 3 different products:**

| Setting | Window Product | Door Product | Skylight Product |
|---------|---------------|--------------|------------------|
| Frame Type | ✓ Enabled | ✓ Enabled | ✗ Disabled |
| Glass | ✓ Enabled | ✓ Enabled | ✓ Enabled |
| Dimensions | ✓ Enabled | ✗ Disabled | ✓ Enabled |
| Color | ✓ Enabled | ✓ Enabled | ✗ Disabled |
| Triple Glazing Price | €85 (default) | €85 (default) | €200 (override) |
| Grey Color Available | Yes | Yes | No (hidden) |

---

## ⚡ Conditional Logic System

### Where It's Implemented

- **Frontend JavaScript**: `views/js/configurator.js` - `handleDependencies()` function (line 197)
- **Storage**: Each value has a `dependencies` field where you enter logic rules

### How to Use Conditional Logic

In the admin, when creating/editing a value, there's a "Logic" field. Enter rules separated by semicolons:

```
action:target_id; action:target_id;
```

### Available Actions

| Action | Description | Example |
|--------|-------------|---------|
| `show_field:ID` | Show a section/field | `show_field:5` |
| `hide_field:ID` | Hide a section/field | `hide_field:5` |
| `show_value:ID` | Show a specific value option | `show_value:12` |
| `hide_value:ID` | Hide a specific value option | `hide_value:12` |
| `show_step:INDEX` | Show a navigation step | `show_step:3` |
| `hide_step:INDEX` | Hide a navigation step | `hide_step:3` |
| `show_group:ID` | Same as show_step | `show_group:2` |
| `hide_group:ID` | Same as hide_step | `hide_group:2` |

### Example Use Cases

**1. Material dependency:**
If user selects "Wooden Frame", show "Wood Treatment" field:
```
In "Wooden Frame" value: show_field:7
In "Aluminum Frame" value: hide_field:7
In "PVC Frame" value: hide_field:7
```

**2. Size restrictions:**
If user selects "Standard Size", hide custom dimensions:
```
In "Standard Size" value: hide_field:3; hide_field:4
In "Custom Size" value: show_field:3; show_field:4
```

**3. Premium options:**
If user selects "Premium Package", show additional options:
```
In "Premium Package" value: show_step:4; show_value:15; show_value:16
```

---

## 💰 Pricing System

### Price Impact Types

| Type | Code | Description | Example |
|------|------|-------------|---------|
| Fixed | `fixed` | Adds fixed amount to price | +€50 |
| Percentage | `percent` | Adds % of base price | +10% of €299 = +€29.90 |
| Per m² | `rate_m2` | Rate × Width × Height | €25/m² × 1.5m × 1.2m = €45 |
| Per meter | `rate_m` | Rate × Perimeter | €10/m × (1.5+1.2)×2 = €54 |

### Price Calculation Order

1. Get base product price
2. For each selected value:
   - Check for product-specific override
   - If override exists, use override price
   - Otherwise, use default value price
3. Sum all fixed amounts
4. Calculate percentage additions on base
5. For m² / m rates, use dimensions from height/width fields
6. Total = Base + Fixed + Percentages + Dimensional rates

---

## 📁 File Structure

```
proconfigurator/
├── proconfigurator.php              # Main module file
├── classes/
│   ├── ProConfigGroup.php           # Group (Step) model
│   ├── ProConfigField.php           # Field (Section) model  
│   ├── ProConfigGroupValue.php      # Value (Option) model
│   └── ProConfigPriceCalculator.php # Price calculation logic
├── controllers/
│   ├── admin/
│   │   ├── AdminProConfigGroupsController.php      # Manage groups
│   │   └── AdminProConfigGroupValueController.php  # Manage values
│   └── front/
│       └── ajax.php                 # AJAX endpoints
├── sql/
│   └── install.php                  # Database schema
└── views/
    ├── css/configurator.css         # Frontend styles
    ├── js/configurator.js           # Frontend logic + conditional logic
    └── templates/
        ├── admin/                   # Admin templates
        ├── front/configurator.tpl   # Frontend configurator UI
        └── hook/
            ├── admin_product.tpl    # Product edit tab
            ├── admin_order.tpl      # Order view config
            ├── cart_summary.tpl     # Cart display
            └── order_confirmation.tpl # Thank you page
```

---

## 🗄️ Database Tables

| Table | Purpose |
|-------|---------|
| `proconfig_group` | Configuration steps/groups |
| `proconfig_group_lang` | Multi-language names for groups |
| `proconfig_field` | Sections within groups |
| `proconfig_field_lang` | Multi-language titles for fields |
| `proconfig_group_value` | Selectable values/options |
| `proconfig_group_value_lang` | Multi-language labels |
| `proconfig_product` | Per-product enable + group order |
| `proconfig_product_group_value` | Per-product value overrides |
| `proconfig_cart_data` | Temp config storage in cart |
| `proconfig_order_data` | Permanent config storage for orders |

---

## 🔧 Troubleshooting

### SQL Installation Issues

If module installation fails, run this SQL manually to see errors:

```sql
-- Check if tables exist
SHOW TABLES LIKE 'ps_proconfig%';

-- If tables exist but have issues, check structure
DESCRIBE ps_proconfig_field;
DESCRIBE ps_proconfig_group_value;
```

To fix missing columns on existing installation:
```sql
ALTER TABLE `ps_proconfig_field` 
    ADD COLUMN IF NOT EXISTS `field_type` VARCHAR(50) DEFAULT 'radio',
    ADD COLUMN IF NOT EXISTS `min_value` DECIMAL(20,6) DEFAULT 0,
    ADD COLUMN IF NOT EXISTS `max_value` DECIMAL(20,6) DEFAULT 0,
    ADD COLUMN IF NOT EXISTS `is_required` TINYINT(1) DEFAULT 0;
```

### Module not showing on product page

1. Check if configurator is **enabled** for the product
2. Check if at least one **group is selected** for the product
3. Check if the groups have **active fields with active values**
4. Clear PrestaShop cache

---

## 📝 Quick Start Guide

1. **Install the module** in PrestaShop
2. Go to **Improve > Pro Configurator > Groups**
3. Create your first group (e.g., "Material Selection")
4. Add sections and values within the group
5. Repeat for all configuration options you need
6. Go to **Products > Edit any product**
7. Click the **Product Configurator** tab
8. Enable configurator and select which groups to show
9. Save the product
10. Visit the product on frontend - configurator appears!
