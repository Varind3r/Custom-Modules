<?php
/**
 * ProConfigField Class - Sections within a Step
 */

class ProConfigField extends ObjectModel
{
    public $id_field;
    public $id_group;
    public $field_type = 'radio';
    public $min_value = 0;
    public $max_value = 0;
    public $is_required = 0;
    public $active = 1;
    public $sort_order = 0;

    // Multilang
    public $title;
    public $description;

    public static $definition = [
        'table' => 'proconfig_field',
        'primary' => 'id_field',
        'multilang' => true,
        'fields' => [
            'id_group' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true],
            'field_type' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'size' => 50],
            'min_value' => ['type' => self::TYPE_FLOAT, 'validate' => 'isFloat'],
            'max_value' => ['type' => self::TYPE_FLOAT, 'validate' => 'isFloat'],
            'is_required' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'active' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'sort_order' => ['type' => self::TYPE_INT, 'validate' => 'isInt'],
            
            // Multilang
            'title' => ['type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isCleanHtml', 'required' => true, 'size' => 255],
            'description' => ['type' => self::TYPE_HTML, 'lang' => true, 'validate' => 'isCleanHtml'],
        ],
    ];

    public static function getByGroup($idGroup, $idLang)
    {
        $sql = 'SELECT f.*, fl.* 
                FROM `' . _DB_PREFIX_ . 'proconfig_field` f
                LEFT JOIN `' . _DB_PREFIX_ . 'proconfig_field_lang` fl ON (f.id_field = fl.id_field AND fl.id_lang = ' . (int) $idLang . ')
                WHERE f.id_group = ' . (int) $idGroup . ' 
                ORDER BY f.sort_order ASC';
        
        $fields = Db::getInstance()->executeS($sql);

        if ($fields) {
            foreach ($fields as &$field) {
                $field['values'] = ProConfigGroupValue::getByField($field['id_field'], $idLang);
            }
        }

        return $fields;
    }

    public function delete()
    {
        // Delete child values
        $values = ProConfigGroupValue::getByField($this->id, (int)Context::getContext()->language->id);
        foreach ($values as $v) {
            $valueObj = new ProConfigGroupValue($v['id_group_value']);
            $valueObj->delete();
        }
        return parent::delete();
    }
}
