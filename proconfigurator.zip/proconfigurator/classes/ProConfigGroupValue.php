<?php
/**
 * ProConfigGroupValue Class
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class ProConfigGroupValue extends ObjectModel
{
    public $id_group_value;
    public $id_field;
    public $id_group; // Keeping as optional fallback
    public $image;
    public $id_manufacturer;
    public $color_code;
    public $price_impact;
    public $price_impact_type;
    public $dependencies;
    public $active = 1;
    public $sort_order = 0;

    // Multilang
    public $label;
    public $description;

    public static $definition = [
        'table' => 'proconfig_group_value',
        'primary' => 'id_group_value',
        'multilang' => true,
        'fields' => [
            'id_field' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true],
            'id_group' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId'],
            'image' => ['type' => self::TYPE_STRING, 'validate' => 'isString', 'size' => 255],
            'id_manufacturer' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId'],
            'color_code' => ['type' => self::TYPE_STRING, 'validate' => 'isColor', 'size' => 7],
            'price_impact' => ['type' => self::TYPE_FLOAT, 'validate' => 'isFloat'],
            'price_impact_type' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'values' => ['fixed', 'percent']],
            'dependencies' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'active' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'sort_order' => ['type' => self::TYPE_INT, 'validate' => 'isInt'],
            
            // Multilang
            'label' => ['type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isCleanHtml', 'required' => true, 'size' => 255],
            'description' => ['type' => self::TYPE_HTML, 'lang' => true, 'validate' => 'isCleanHtml'],
        ],
    ];

    public static function getByField($idField, $idLang)
    {
        return Db::getInstance()->executeS('
            SELECT v.*, vl.* 
            FROM `' . _DB_PREFIX_ . 'proconfig_group_value` v
            LEFT JOIN `' . _DB_PREFIX_ . 'proconfig_group_value_lang` vl ON (v.id_group_value = vl.id_group_value AND vl.id_lang = ' . (int) $idLang . ')
            WHERE v.id_field = ' . (int) $idField . '
            ORDER BY v.sort_order ASC'
        );
    }

    public static function getPriceTypes()
    {
        return [
            ['id' => 'fixed', 'name' => 'Fixed Amount'],
            ['id' => 'percent', 'name' => 'Percentage of Base Price'],
            ['id' => 'rate_m2', 'name' => 'Per Square Meter (Total Width x Total Height)'],
            ['id' => 'rate_m', 'name' => 'Per Linear Meter (Total Width)'],
        ];
    }

    public static function getComplete($idGroupValue, $idLang)
    {
        return Db::getInstance()->getRow('
            SELECT v.*, vl.*
            FROM `' . _DB_PREFIX_ . 'proconfig_group_value` v
            LEFT JOIN `' . _DB_PREFIX_ . 'proconfig_group_value_lang` vl ON (v.id_group_value = vl.id_group_value AND vl.id_lang = ' . (int) $idLang . ')
            WHERE v.id_group_value = ' . (int) $idGroupValue
        );
    }
}
