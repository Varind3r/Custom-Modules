<?php
/**
 * ProConfigPriceCalculator Class
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class ProConfigPriceCalculator
{
    public static function calculate($idProduct, array $selections, $context = null)
    {
        if (!$context) {
            $context = Context::getContext();
        }

        $basePrice = Product::getPriceStatic($idProduct, true, null, 6, null, false, false);
        $impacts = self::getImpacts($selections, $idProduct);

        $totalImpact = $impacts['fixed'];
        if ($impacts['percent'] != 0) {
            $totalImpact += ($basePrice * ($impacts['percent'] / 100));
        }

        return $basePrice + $totalImpact;
    }

    public static function getImpacts(array $selections, $idProduct = null)
    {
        $fixed = 0.0;
        $percent = 0.0;
        $dimensions = ['height' => 0, 'width' => 0];

        // First pass: extract dimensions
        foreach ($selections as $fieldId => $val) {
            $field = new ProConfigField((int)$fieldId);
            if (Validate::isLoadedObject($field)) {
                if ($field->field_type === 'height') $dimensions['height'] = (float)$val / 1000; // convert mm to m
                if ($field->field_type === 'width') $dimensions['width'] = (float)$val / 1000; // convert mm to m
            }
        }

        foreach ($selections as $fieldId => $valueId) {
            if (empty($valueId)) continue;

            if (is_array($valueId)) {
                foreach ($valueId as $vid) {
                    self::applyImpactById($vid, $idProduct, $fixed, $percent, $dimensions);
                }
            } else {
                self::applyImpactById($valueId, $idProduct, $fixed, $percent, $dimensions);
            }
        }

        return ['fixed' => $fixed, 'percent' => $percent];
    }

    private static function applyImpactById($valueId, $idProduct, &$fixed, &$percent, $dimensions = [])
    {
        if (!is_numeric($valueId)) return;

        $groupValue = new ProConfigGroupValue((int) $valueId);
        if (!Validate::isLoadedObject($groupValue)) return;

        $price = (float) $groupValue->price_impact;
        $type = $groupValue->price_impact_type;

        if ($idProduct) {
            $override = Db::getInstance()->getRow(
                'SELECT price_impact, price_impact_type FROM `' . _DB_PREFIX_ . 'proconfig_product_group_value`
                 WHERE id_product = ' . (int) $idProduct . ' AND id_group_value = ' . (int) $valueId
            );
            if ($override && $override['price_impact'] !== null) {
                $price = (float) $override['price_impact'];
                $type = $override['price_impact_type'] ?: 'fixed';
            }
        }

        if ($type === 'rate_m2') {
            $fixed += $price * $dimensions['height'] * $dimensions['width'];
        } elseif ($type === 'rate_m') {
            $fixed += $price * ($dimensions['height'] + $dimensions['width']) * 2;
        } else {
            self::applyPriceImpact($price, $type, $fixed, $percent);
        }
    }

    private static function applyPriceImpact($price, $type, &$fixed, &$percent)
    {
        switch ($type) {
            case 'percent':
                $percent += $price;
                break;
            case 'fixed':
            default:
                $fixed += $price;
                break;
        }
    }
}
