<?php
/**
 * ProConfigPriceCalculator - Calculates final price based on configuration
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class ProConfigPriceCalculator
{
    /**
     * Calculate final price
     *
     * @param int $idProduct Product ID
     * @param array $selections Map of attribute_id => value (option_id, input value, or dimensions array)
     * @param Context $context PrestaShop context
     * @return float Final price rounded to shop precision
     */
    public static function calculate($idProduct, array $selections, Context $context = null)
    {
        $context = $context ?: Context::getContext();

        // Get base product price (tax excl)
        $basePrice = Product::getPriceStatic(
            $idProduct,
            false,
            null,
            6,
            null,
            false,
            true,
            1,
            false,
            null,
            null,
            null,
            $context->shop->id
        );

        $impacts = self::getImpacts($selections, $idProduct);

        // Calculate: (Base + Fixed) + (Base * Percent / 100)
        $finalPrice = $basePrice + $impacts['fixed'] + ($basePrice * $impacts['percent'] / 100);

        return Tools::ps_round($finalPrice, (int) Configuration::get('PS_PRICE_DISPLAY_PRECISION'));
    }

    /**
     * Calculate price impacts from selections
     *
     * @param array $selections Map of attribute_id => value
     * @param int $idProduct Product ID for overrides
     * @return array ['fixed' => float, 'percent' => float]
     */
    public static function getImpacts(array $selections, $idProduct = null)
    {
        $fixed = 0.0;
        $percent = 0.0;
        $width = 0.0;
        $height = 0.0;

        // First pass: Extract dimensions
        foreach ($selections as $attrId => $value) {
            // Check for composite dimensions (array with width/height)
            if (is_array($value) && isset($value['width'], $value['height'])) {
                $width = (float) $value['width'];
                $height = (float) $value['height'];
            }
        }

        // Convert mm to meters for rate calculations
        $widthM = $width / 1000;
        $heightM = $height / 1000;
        $area = $widthM * $heightM;
        $perimeter = 2 * ($widthM + $heightM);

        // Second pass: Calculate price impacts
        foreach ($selections as $attrId => $value) {
            // Skip dimension arrays (already processed)
            if (is_array($value) && isset($value['width'], $value['height'])) {
                continue;
            }

            $attribute = new ProConfigAttribute((int) $attrId);
            if (!Validate::isLoadedObject($attribute)) {
                continue;
            }

            // Apply attribute-level price impact (from product override or base)
            $attrPrice = (float) $attribute->price_impact;
            $attrPriceType = $attribute->price_impact_type;

            if ($idProduct) {
                $override = Db::getInstance()->getRow(
                    'SELECT price_impact, price_impact_type FROM `' . _DB_PREFIX_ . 'proconfig_product_attribute`
                     WHERE id_product = ' . (int) $idProduct . ' AND id_attribute = ' . (int) $attrId
                );
                if ($override && $override['price_impact'] !== null) {
                    $attrPrice = (float) $override['price_impact'];
                    $attrPriceType = $override['price_impact_type'] ?: 'fixed';
                }
            }

            if ($attrPrice != 0) {
                self::applyPriceImpact($attrPrice, $attrPriceType, $fixed, $percent, $area, $perimeter);
            }

            // Apply option price impact
            if ($attribute->requiresOptions() && is_numeric($value)) {
                $optionId = (int) $value;
                $option = new ProConfigOption($optionId);

                if (Validate::isLoadedObject($option) && $option->active) {
                    $optPrice = (float) $option->price_impact;
                    $optPriceType = $option->price_impact_type;

                    // Check product override
                    if ($idProduct) {
                        $optOverride = Db::getInstance()->getRow(
                            'SELECT price_impact, price_impact_type FROM `' . _DB_PREFIX_ . 'proconfig_product_option`
                             WHERE id_product = ' . (int) $idProduct . ' AND id_option = ' . $optionId
                        );
                        if ($optOverride && $optOverride['price_impact'] !== null) {
                            $optPrice = (float) $optOverride['price_impact'];
                            $optPriceType = $optOverride['price_impact_type'] ?: 'fixed';
                        }
                    }

                    self::applyPriceImpact($optPrice, $optPriceType, $fixed, $percent, $area, $perimeter);
                }
            }
        }

        return ['fixed' => $fixed, 'percent' => $percent];
    }

    /**
     * Apply a single price impact to the running totals
     */
    private static function applyPriceImpact($price, $type, &$fixed, &$percent, $area, $perimeter)
    {
        switch ($type) {
            case 'percent':
                $percent += $price;
                break;
            case 'rate_m2':
                $fixed += ($price * $area);
                break;
            case 'rate_m':
                $fixed += ($price * $perimeter);
                break;
            case 'fixed':
            default:
                $fixed += $price;
                break;
        }
    }

    /**
     * Format price for display
     */
    public static function formatPrice($price, Context $context = null)
    {
        $context = $context ?: Context::getContext();
        return Tools::displayPrice($price, $context->currency);
    }

    /**
     * Get price breakdown for display
     */
    public static function getBreakdown($idProduct, array $selections, Context $context = null)
    {
        $context = $context ?: Context::getContext();
        $idLang = (int) $context->language->id;

        $basePrice = Product::getPriceStatic($idProduct, false);
        $breakdown = [
            'base' => [
                'label' => 'Base Price',
                'value' => $basePrice,
                'formatted' => self::formatPrice($basePrice, $context),
            ],
            'options' => [],
            'total' => 0,
        ];

        foreach ($selections as $attrId => $value) {
            if (is_array($value) && isset($value['width'], $value['height'])) {
                $breakdown['dimensions'] = [
                    'width' => (float) $value['width'],
                    'height' => (float) $value['height'],
                ];
                continue;
            }

            $attribute = new ProConfigAttribute((int) $attrId, $idLang);
            if (!Validate::isLoadedObject($attribute)) {
                continue;
            }

            if ($attribute->requiresOptions() && is_numeric($value)) {
                $option = new ProConfigOption((int) $value, $idLang);
                if (Validate::isLoadedObject($option) && $option->price_impact != 0) {
                    $breakdown['options'][] = [
                        'attribute' => $attribute->name,
                        'option' => $option->label,
                        'price' => (float) $option->price_impact,
                        'type' => $option->price_impact_type,
                        'formatted' => self::formatPrice($option->price_impact, $context),
                    ];
                }
            }
        }

        $breakdown['total'] = self::calculate($idProduct, $selections, $context);
        $breakdown['total_formatted'] = self::formatPrice($breakdown['total'], $context);

        return $breakdown;
    }
}
