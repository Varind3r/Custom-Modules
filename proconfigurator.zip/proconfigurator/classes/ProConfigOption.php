<?php
/**
 * ProConfigOption - Option/Value ObjectModel
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class ProConfigOption extends ObjectModel
{
    public $id_attribute;
    public $image;
    public $color_code;
    public $color_gradient;
    public $price_impact = 0;
    public $price_impact_type = 'fixed';
    public $dependencies;
    public $active = 1;
    public $sort_order = 0;
    public $date_add;
    public $date_upd;

    // Multilang
    public $label;
    public $description;
    public $badge;
    public $feature_list;
    public $content_field_1;
    public $content_field_2;
    public $content_field_3;

    public static $definition = [
        'table' => 'proconfig_option',
        'primary' => 'id_option',
        'multilang' => true,
        'fields' => [
            'id_attribute' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true],
            'image' => ['type' => self::TYPE_STRING, 'validate' => 'isCleanHtml', 'size' => 255],
            'color_code' => ['type' => self::TYPE_STRING, 'validate' => 'isColor', 'size' => 32],
            'color_gradient' => ['type' => self::TYPE_STRING, 'validate' => 'isAnything', 'size' => 128],
            'price_impact' => ['type' => self::TYPE_FLOAT, 'validate' => 'isFloat'],
            'price_impact_type' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'size' => 20],
            'dependencies' => ['type' => self::TYPE_STRING, 'validate' => 'isAnything'],
            'active' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool', 'required' => true],
            'sort_order' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'],
            'date_add' => ['type' => self::TYPE_DATE, 'validate' => 'isDate'],
            'date_upd' => ['type' => self::TYPE_DATE, 'validate' => 'isDate'],
            // Multilang
            'label' => ['type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isGenericName', 'required' => true, 'size' => 255],
            'description' => ['type' => self::TYPE_HTML, 'lang' => true, 'validate' => 'isCleanHtml'],
            'badge' => ['type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isGenericName', 'size' => 64],
            'feature_list' => ['type' => self::TYPE_HTML, 'lang' => true, 'validate' => 'isCleanHtml'],
            'content_field_1' => ['type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isCleanHtml', 'size' => 500],
            'content_field_2' => ['type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isCleanHtml', 'size' => 500],
            'content_field_3' => ['type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isCleanHtml', 'size' => 500],
        ],
    ];

    /**
     * Price impact types
     */
    public static function getPriceTypes()
    {
        return [
            ['id' => 'fixed', 'name' => 'Fixed Amount'],
            ['id' => 'percent', 'name' => 'Percentage of Base Price'],
            ['id' => 'rate_m2', 'name' => 'Rate per m² (Area)'],
            ['id' => 'rate_m', 'name' => 'Rate per m (Linear/Perimeter)'],
        ];
    }

    /**
     * Get options by attribute
     */
    public static function getByAttribute($idAttribute, $idLang = null, $activeOnly = true)
    {
        $idLang = $idLang ?: (int) Context::getContext()->language->id;

        $sql = new DbQuery();
        $sql->select('o.*, ol.label, ol.description, ol.badge, ol.feature_list, ol.content_field_1, ol.content_field_2, ol.content_field_3')
            ->from('proconfig_option', 'o')
            ->leftJoin('proconfig_option_lang', 'ol', 'o.id_option = ol.id_option AND ol.id_lang = ' . (int) $idLang)
            ->where('o.id_attribute = ' . (int) $idAttribute);

        if ($activeOnly) {
            $sql->where('o.active = 1');
        }

        $sql->orderBy('o.sort_order ASC');

        return Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
    }

    /**
     * Get parsed dependencies
     */
    public function getDependencies()
    {
        if (empty($this->dependencies)) {
            return [];
        }
        return json_decode($this->dependencies, true) ?: [];
    }

    /**
     * Set dependencies from array
     */
    public function setDependencies(array $deps)
    {
        $this->dependencies = json_encode($deps);
    }

    /**
     * Get gradient CSS value
     */
    public function getGradientCss()
    {
        if (!empty($this->color_gradient)) {
            $gradient = json_decode($this->color_gradient, true);
            if ($gradient && isset($gradient['from'], $gradient['to'])) {
                $direction = $gradient['direction'] ?? 'to right';
                return "linear-gradient({$direction}, {$gradient['from']}, {$gradient['to']})";
            }
        }
        return $this->color_code ? $this->color_code : '#cccccc';
    }
}
