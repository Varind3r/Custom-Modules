<?php
/**
 * ProConfigGroup Class
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class ProConfigGroup extends ObjectModel
{
    public $id_group;
    public $image;
    public $icon;
    public $color_from;
    public $color_to;
    public $is_collapsible;
    public $is_repeater;
    public $active;
    public $sort_order;

    // Multilang
    public $name;
    public $public_title;
    public $description;

    public static $definition = [
        'table' => 'proconfig_group',
        'primary' => 'id_group',
        'multilang' => true,
        'fields' => [
            'image' => ['type' => self::TYPE_STRING, 'validate' => 'isString', 'size' => 255],
            'icon' => ['type' => self::TYPE_STRING, 'validate' => 'isString', 'size' => 64],
            'color_from' => ['type' => self::TYPE_STRING, 'validate' => 'isString', 'size' => 32],
            'color_to' => ['type' => self::TYPE_STRING, 'validate' => 'isString', 'size' => 32],
            'is_collapsible' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'is_repeater' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'active' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'sort_order' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'],

            // Multilang
            'name' => ['type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isString', 'required' => true, 'size' => 255],
            'public_title' => ['type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isString', 'size' => 255],
            'description' => ['type' => self::TYPE_HTML, 'lang' => true, 'validate' => 'isCleanHtml'],
        ],
    ];

    public static function getWithFieldsAndValues($idGroup, $idLang)
    {
        $group = Db::getInstance()->getRow('
            SELECT g.*, gl.* 
            FROM `' . _DB_PREFIX_ . 'proconfig_group` g
            LEFT JOIN `' . _DB_PREFIX_ . 'proconfig_group_lang` gl ON (g.id_group = gl.id_group AND gl.id_lang = ' . (int) $idLang . ')
            WHERE g.id_group = ' . (int) $idGroup
        );

        if ($group) {
            $group['fields'] = ProConfigField::getByGroup($group['id_group'], $idLang);
        }

        return $group;
    }

    public static function getAll($idLang)
    {
        return Db::getInstance()->executeS('
            SELECT g.*, gl.* 
            FROM `' . _DB_PREFIX_ . 'proconfig_group` g
            LEFT JOIN `' . _DB_PREFIX_ . 'proconfig_group_lang` gl ON (g.id_group = gl.id_group AND gl.id_lang = ' . (int) $idLang . ')
            WHERE g.active = 1
            ORDER BY g.sort_order ASC'
        );
    }

    public function delete()
    {
        // Delete child fields
        $fields = ProConfigField::getByGroup($this->id, (int)Context::getContext()->language->id);
        foreach ($fields as $f) {
            $fieldObj = new ProConfigField($f['id_field']);
            $fieldObj->delete();
        }
        return parent::delete();
    }
}
