<?php
/**
 * ProConfigGroup - Step/Group ObjectModel
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class ProConfigGroup extends ObjectModel
{
    public $icon;
    public $color_from = '#f97316';
    public $color_to = '#fbbf24';
    public $is_collapsible = 1;
    public $active = 1;
    public $sort_order = 0;
    public $date_add;
    public $date_upd;

    // Multilang
    public $name;
    public $description;

    public static $definition = [
        'table' => 'proconfig_group',
        'primary' => 'id_group',
        'multilang' => true,
        'fields' => [
            'icon' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'size' => 64],
            'color_from' => ['type' => self::TYPE_STRING, 'validate' => 'isColor', 'size' => 32],
            'color_to' => ['type' => self::TYPE_STRING, 'validate' => 'isColor', 'size' => 32],
            'is_collapsible' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'active' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool', 'required' => true],
            'sort_order' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'],
            'date_add' => ['type' => self::TYPE_DATE, 'validate' => 'isDate'],
            'date_upd' => ['type' => self::TYPE_DATE, 'validate' => 'isDate'],
            // Multilang
            'name' => ['type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isGenericName', 'required' => true, 'size' => 255],
            'description' => ['type' => self::TYPE_HTML, 'lang' => true, 'validate' => 'isCleanHtml'],
        ],
    ];

    /**
     * Get all groups
     */
    public static function getAll($idLang = null, $activeOnly = true)
    {
        $idLang = $idLang ?: (int) Context::getContext()->language->id;

        $sql = new DbQuery();
        $sql->select('g.*, gl.name, gl.description')
            ->from('proconfig_group', 'g')
            ->leftJoin('proconfig_group_lang', 'gl', 'g.id_group = gl.id_group AND gl.id_lang = ' . (int) $idLang);

        if ($activeOnly) {
            $sql->where('g.active = 1');
        }

        $sql->orderBy('g.sort_order ASC');

        return Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
    }

    /**
     * Get groups for dropdown
     */
    public static function getDropdown($idLang = null)
    {
        $groups = self::getAll($idLang, false);
        $result = [];
        foreach ($groups as $group) {
            $result[] = [
                'id' => (int) $group['id_group'],
                'name' => $group['name'],
            ];
        }
        return $result;
    }
}
