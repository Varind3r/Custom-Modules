<?php
/**
 * ProConfigAttribute - Field/Attribute ObjectModel
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class ProConfigAttribute extends ObjectModel
{
    public $id_group;
    public $field_type = 'text';
    public $is_required = 0;
    public $allow_user_input = 0;
    public $validation_regex;
    public $min_value;
    public $max_value;
    public $step_value = 1;
    public $min_width;
    public $max_width;
    public $min_height;
    public $max_height;
    public $price_impact = 0;
    public $price_impact_type = 'fixed';
    public $active = 1;
    public $sort_order = 0;
    public $date_add;
    public $date_upd;

    // Multilang
    public $name;
    public $description;
    public $placeholder;
    public $suffix;
    public $validation_error;

    public static $definition = [
        'table' => 'proconfig_attribute',
        'primary' => 'id_attribute',
        'multilang' => true,
        'fields' => [
            'id_group' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId'],
            'field_type' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'required' => true, 'size' => 50],
            'is_required' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'allow_user_input' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'validation_regex' => ['type' => self::TYPE_STRING, 'validate' => 'isString', 'size' => 255],
            'min_value' => ['type' => self::TYPE_FLOAT, 'validate' => 'isFloat'],
            'max_value' => ['type' => self::TYPE_FLOAT, 'validate' => 'isFloat'],
            'step_value' => ['type' => self::TYPE_FLOAT, 'validate' => 'isFloat'],
            'min_width' => ['type' => self::TYPE_FLOAT, 'validate' => 'isFloat'],
            'max_width' => ['type' => self::TYPE_FLOAT, 'validate' => 'isFloat'],
            'min_height' => ['type' => self::TYPE_FLOAT, 'validate' => 'isFloat'],
            'max_height' => ['type' => self::TYPE_FLOAT, 'validate' => 'isFloat'],
            'price_impact' => ['type' => self::TYPE_FLOAT, 'validate' => 'isFloat'],
            'price_impact_type' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'size' => 20],
            'active' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool', 'required' => true],
            'sort_order' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'],
            'date_add' => ['type' => self::TYPE_DATE, 'validate' => 'isDate'],
            'date_upd' => ['type' => self::TYPE_DATE, 'validate' => 'isDate'],
            // Multilang
            'name' => ['type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isGenericName', 'required' => true, 'size' => 255],
            'description' => ['type' => self::TYPE_HTML, 'lang' => true, 'validate' => 'isCleanHtml'],
            'placeholder' => ['type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isGenericName', 'size' => 255],
            'suffix' => ['type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isGenericName', 'size' => 50],
            'validation_error' => ['type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isGenericName', 'size' => 255],
        ],
    ];

    /**
     * Field types available
     */
    public static function getFieldTypes()
    {
        return [
            ['id' => 'text', 'name' => 'Text Input'],
            ['id' => 'textarea', 'name' => 'Text Area'],
            ['id' => 'number', 'name' => 'Number Input'],
            ['id' => 'dropdown', 'name' => 'Dropdown Select'],
            ['id' => 'radio_text', 'name' => 'Radio Buttons (Text)'],
            ['id' => 'radio_image', 'name' => 'Image Selection (Grid)'],
            ['id' => 'radio_color', 'name' => 'Color Selection (Palette)'],
            ['id' => 'checkbox', 'name' => 'Checkboxes'],
            ['id' => 'file', 'name' => 'File Upload'],
            ['id' => 'dimensions', 'name' => 'Dimensions (Width × Height)'],
            ['id' => 'date', 'name' => 'Date Picker'],
        ];
    }

    /**
     * Get attributes by group
     */
    public static function getByGroup($idGroup, $idLang = null, $activeOnly = true)
    {
        $idLang = $idLang ?: (int) Context::getContext()->language->id;

        $sql = new DbQuery();
        $sql->select('a.*, al.name, al.description, al.placeholder, al.suffix, al.validation_error')
            ->from('proconfig_attribute', 'a')
            ->leftJoin('proconfig_attribute_lang', 'al', 'a.id_attribute = al.id_attribute AND al.id_lang = ' . (int) $idLang)
            ->where('a.id_group = ' . (int) $idGroup);

        if ($activeOnly) {
            $sql->where('a.active = 1');
        }

        $sql->orderBy('a.sort_order ASC');

        return Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
    }

    /**
     * Get all attributes
     */
    public static function getAll($idLang = null, $activeOnly = true)
    {
        $idLang = $idLang ?: (int) Context::getContext()->language->id;

        $sql = new DbQuery();
        $sql->select('a.*, al.name, al.description, al.placeholder, al.suffix, al.validation_error, g.name as group_name')
            ->from('proconfig_attribute', 'a')
            ->leftJoin('proconfig_attribute_lang', 'al', 'a.id_attribute = al.id_attribute AND al.id_lang = ' . (int) $idLang)
            ->leftJoin('proconfig_group', 'g', 'a.id_group = g.id_group')
            ->leftJoin('proconfig_group_lang', 'gl', 'g.id_group = gl.id_group AND gl.id_lang = ' . (int) $idLang);

        if ($activeOnly) {
            $sql->where('a.active = 1');
        }

        $sql->orderBy('a.id_group ASC, a.sort_order ASC');

        return Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
    }

    /**
     * Check if field type requires options
     */
    public function requiresOptions()
    {
        $optionTypes = ['dropdown', 'radio_text', 'radio_image', 'radio_color', 'checkbox'];
        return in_array($this->field_type, $optionTypes);
    }

    /**
     * Check if field type is dimension-based
     */
    public function isDimensionType()
    {
        return $this->field_type === 'dimensions';
    }
}
