<?php
/**
 * Admin Controller for ProConfigurator Groups (Steps)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class AdminProConfigGroupsController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        $this->table = 'proconfig_group';
        // Explicit primary key so PS doesn't guess id_proconfig_group
        $this->identifier = 'id_group';
        $this->className = 'ProConfigGroup';
        $this->lang = true;
        $this->addRowAction('edit');
        $this->addRowAction('delete');
        $this->addRowAction('viewAttributes');

        parent::__construct();

        // Ensure module is loaded for PS 1.7.9 compatibility
        if (!$this->module) {
            $this->module = Module::getInstanceByName('proconfigurator');
        }

        $this->fields_list = [
            'id_group' => [
                'title' => $this->trans('ID', [], 'Admin.Global'),
                'align' => 'center',
                'class' => 'fixed-width-xs',
            ],
            'name' => [
                'title' => $this->trans('Name', [], 'Admin.Global'),
                'filter_key' => 'b!name',
            ],
            'color_from' => [
                'title' => $this->trans('Color', [], 'Admin.Global'),
                'callback' => 'displayColorPreview',
                'search' => false,
            ],
            'active' => [
                'title' => $this->trans('Active', [], 'Admin.Global'),
                'type' => 'bool',
                'active' => 'status',
                'filter_key' => 'a!active',
            ],
            'sort_order' => [
                'title' => $this->trans('Position', [], 'Admin.Global'),
                'type' => 'int',
                'filter_key' => 'a!sort_order',
            ],
        ];

        $this->bulk_actions = [
            'delete' => [
                'text' => $this->trans('Delete selected', [], 'Admin.Actions'),
                'confirm' => $this->trans('Delete selected items?', [], 'Admin.Notifications.Warning'),
                'icon' => 'icon-trash',
            ],
        ];
    }

    public function displayColorPreview($value, $row)
    {
        $from = $row['color_from'] ?: '#f97316';
        $to = $row['color_to'] ?: '#fbbf24';
        return '<div style="width:80px;height:25px;border-radius:4px;background:linear-gradient(to right,' . $from . ',' . $to . ');border:1px solid #ddd;"></div>';
    }

    public function displayViewAttributesLink($token, $id)
    {
        $href = $this->context->link->getAdminLink('AdminProConfigAttributes') . '&id_group=' . (int) $id;
        return '<a class="btn btn-default" href="' . $href . '" title="View Attributes">
            <i class="icon-list"></i> Attributes
        </a>';
    }

    public function renderForm()
    {
        $this->fields_form = [
            'legend' => [
                'title' => $this->trans('Configurator Group (Step)', [], 'Modules.Proconfigurator.Admin'),
                'icon' => 'icon-folder-open',
            ],
            'input' => [
                [
                    'type' => 'text',
                    'label' => $this->trans('Name', [], 'Admin.Global'),
                    'name' => 'name',
                    'lang' => true,
                    'required' => true,
                    'hint' => $this->trans('Group name shown in the configurator accordion', [], 'Modules.Proconfigurator.Admin'),
                ],
                [
                    'type' => 'textarea',
                    'label' => $this->trans('Description', [], 'Admin.Global'),
                    'name' => 'description',
                    'lang' => true,
                    'autoload_rte' => true,
                ],
                [
                    'type' => 'text',
                    'label' => $this->trans('Icon Class', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'icon',
                    'hint' => $this->trans('Material icon name (e.g., "category", "settings")', [], 'Modules.Proconfigurator.Admin'),
                    'class' => 'fixed-width-lg',
                ],
                [
                    'type' => 'color',
                    'label' => $this->trans('Gradient Start Color', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'color_from',
                    'hint' => $this->trans('Left/top color of the gradient', [], 'Modules.Proconfigurator.Admin'),
                ],
                [
                    'type' => 'color',
                    'label' => $this->trans('Gradient End Color', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'color_to',
                    'hint' => $this->trans('Right/bottom color of the gradient', [], 'Modules.Proconfigurator.Admin'),
                ],
                [
                    'type' => 'switch',
                    'label' => $this->trans('Collapsible', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'is_collapsible',
                    'is_bool' => true,
                    'values' => [
                        ['id' => 'is_collapsible_on', 'value' => 1, 'label' => $this->trans('Yes', [], 'Admin.Global')],
                        ['id' => 'is_collapsible_off', 'value' => 0, 'label' => $this->trans('No', [], 'Admin.Global')],
                    ],
                    'hint' => $this->trans('Allow users to collapse/expand this step', [], 'Modules.Proconfigurator.Admin'),
                ],
                [
                    'type' => 'switch',
                    'label' => $this->trans('Active', [], 'Admin.Global'),
                    'name' => 'active',
                    'is_bool' => true,
                    'values' => [
                        ['id' => 'active_on', 'value' => 1, 'label' => $this->trans('Yes', [], 'Admin.Global')],
                        ['id' => 'active_off', 'value' => 0, 'label' => $this->trans('No', [], 'Admin.Global')],
                    ],
                ],
                [
                    'type' => 'text',
                    'label' => $this->trans('Position', [], 'Admin.Global'),
                    'name' => 'sort_order',
                    'class' => 'fixed-width-sm',
                    'hint' => $this->trans('Display order (lower = first)', [], 'Modules.Proconfigurator.Admin'),
                ],
            ],
            'submit' => [
                'title' => $this->trans('Save', [], 'Admin.Actions'),
            ],
        ];

        // Add CSS for color preview
        if ($this->module) {
            $this->addCSS(_PS_MODULE_DIR_ . $this->module->name . '/views/css/admin.css');
        }

        return parent::renderForm();
    }

    public function postProcess()
    {
        if (Tools::isSubmit('submitAdd' . $this->table)) {
            // Set default values if not provided
            if (!Tools::getValue('color_from')) {
                $_POST['color_from'] = '#f97316';
            }
            if (!Tools::getValue('color_to')) {
                $_POST['color_to'] = '#fbbf24';
            }
            if (Tools::getValue('sort_order') === '') {
                $_POST['sort_order'] = 0;
            }
        }

        return parent::postProcess();
    }

    public function initContent()
    {
        parent::initContent();

        // Add custom header with stats
        if ($this->display != 'add' && $this->display != 'edit') {
            $totalGroups = Db::getInstance()->getValue('SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'proconfig_group`');
            $activeGroups = Db::getInstance()->getValue('SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'proconfig_group` WHERE active = 1');

            $this->context->smarty->assign([
                'total_groups' => (int) $totalGroups,
                'active_groups' => (int) $activeGroups,
            ]);
        }
    }

    /**
     * Override _getSelect to fix JOIN queries with correct column names
     */
    protected function _getSelect()
    {
        return $this->fixJoinColumns(parent::_getSelect());
    }
    
    /**
     * Override _getFrom to ensure correct JOINs
     */
    protected function _getFrom()
    {
        return $this->fixJoinColumns(parent::_getFrom());
    }
    
    /**
     * Override _getJoin to prevent incorrect auto-joins
     */
    protected function _getJoin()
    {
        return $this->fixJoinColumns(parent::_getJoin());
    }

    /**
     * Normalize any wrong auto-joined column names (handles backticks too)
     */
    private function fixJoinColumns($sql)
    {
        $replacements = [
            '/`?(b|g|c)`?\.`?id_proconfig_group`?/i' => 'a.id_group',
            '/`?(b|g|c)`?\.`?id_proconfig_attribute`?/i' => 'a.id_attribute',
            '/`?(b|g|c)`?\.`?id_proconfig_option`?/i' => 'a.id_option',
            '/ON\s+`?(b|g|c)`?\.`?id_proconfig_group`?\s*=\s*/i' => 'ON a.id_group = ',
            '/ON\s+`?(b|g|c)`?\.`?id_proconfig_attribute`?\s*=\s*/i' => 'ON a.id_attribute = ',
            '/ON\s+`?(b|g|c)`?\.`?id_proconfig_option`?\s*=\s*/i' => 'ON a.id_option = ',
            '/\s+`?(b|g|c)`?\.`?id_proconfig_group`?\s*=\s*/i' => ' a.id_group = ',
            '/\s+`?(b|g|c)`?\.`?id_proconfig_attribute`?\s*=\s*/i' => ' a.id_attribute = ',
            '/\s+`?(b|g|c)`?\.`?id_proconfig_option`?\s*=\s*/i' => ' a.id_option = ',
        ];

        foreach ($replacements as $pattern => $replacement) {
            $sql = preg_replace($pattern, $replacement, $sql);
        }

        return $sql;
    }
}
