<?php
/**
 * Admin Controller for ProConfigurator Groups (Steps)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class AdminProConfigGroupsController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        $this->table = 'proconfig_group';
        $this->identifier = 'id_group';
        $this->className = 'ProConfigGroup';
        $this->lang = true;
        $this->addRowAction('edit');
        $this->addRowAction('delete');
        $this->addRowAction('viewValues');

        parent::__construct();
        // Enable toolbar with Save and Back buttons
        $this->show_toolbar = true;
        $this->toolbar_scroll = true;
        $this->toolbar_btn['save'] = [
            'href' => '#',
            'desc' => $this->trans('Save', [], 'Admin.Actions'),
            'icon' => 'process-icon-save',
        ];
        $this->toolbar_btn['back'] = [
            'href' => $this->context->link->getAdminLink('AdminProConfigGroups'),
            'desc' => $this->trans('Back to list', [], 'Admin.Actions'),
            'icon' => 'process-icon-back',
        ];

        $this->fields_list = [
            'id_group' => [
                'title' => $this->trans('ID', [], 'Admin.Global'),
                'align' => 'center',
                'class' => 'fixed-width-xs',
            ],
            'name' => [
                'title' => $this->trans('Group Name (Steps)', [], 'Modules.Proconfigurator.Admin'),
            ],
            'public_title' => [
                'title' => $this->trans('Public Title', [], 'Modules.Proconfigurator.Admin'),
            ],
            'is_repeater' => [
                'title' => $this->trans('Repeater?', [], 'Modules.Proconfigurator.Admin'),
                'type' => 'bool',
                'active' => 'repeater',
            ],
            'active' => [
                'title' => $this->trans('Active', [], 'Admin.Global'),
                'type' => 'bool',
                'active' => 'status',
            ],
            'sort_order' => [
                'title' => $this->trans('Position', [], 'Admin.Global'),
                'type' => 'int',
            ],
        ];
    }

    /**
     * Custom link to manage values
     */
    public function displayViewValuesLink($token = null, $id = null, $name = null)
    {
        $href = $this->context->link->getAdminLink('AdminProConfigGroupValue') . '&id_group=' . $id;
        
        $this->context->smarty->assign([
            'href' => $href,
            'action' => $this->trans('Manage Values', [], 'Modules.Proconfigurator.Admin'),
            'icon' => 'icon-list-ul',
        ]);

        return $this->context->smarty->fetch('helpers/list/list_action_view.tpl');
    }

    public function renderForm()
    {
        if (!($obj = $this->loadObject(true))) {
            return;
        }

        $idLang = (int) $this->context->language->id;
        $fields = [];
        if ($obj->id) {
            $fields = ProConfigField::getByGroup($obj->id, $idLang);
        }

        $this->fields_form = [
            'legend' => [
                'title' => $this->trans('Configurator Group (Step)', [], 'Modules.Proconfigurator.Admin'),
                'icon' => 'icon-tags',
            ],
            'input' => [
                [
                    'type' => 'text',
                    'label' => $this->trans('Group Name (Internal)', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'name',
                    'lang' => true,
                    'required' => true,
                ],
                [
                    'type' => 'text',
                    'label' => $this->trans('Public Title (Sidebar)', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'public_title',
                    'lang' => true,
                ],
                [
                    'type' => 'file',
                    'label' => $this->trans('Sidebar Image', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'image',
                ],
                [
                    'type' => 'color',
                    'label' => $this->trans('Gradient From', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'color_from',
                ],
                [
                    'type' => 'color',
                    'label' => $this->trans('Gradient To', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'color_to',
                ],
                [
                    'type' => 'switch',
                    'label' => $this->trans('Active', [], 'Admin.Global'),
                    'name' => 'active',
                    'is_bool' => true,
                    'values' => [
                        ['id' => 'active_on', 'value' => 1, 'label' => $this->trans('Yes', [], 'Admin.Global')],
                        ['id' => 'active_off', 'value' => 0, 'label' => $this->trans('No', [], 'Admin.Global')],
                    ],
                ],
                // THE NESTED REPEATER
                [
                    'type' => 'free',
                    'name' => 'nested_fields_repeater',
                    'label' => $this->trans('Step Content (Sections)', [], 'Modules.Proconfigurator.Admin'),
                ]
            ],
            'submit' => [
                'title' => $this->trans('Save', [], 'Admin.Actions'),
            ],
        ];

        $this->fields_value['nested_fields_repeater'] = $this->renderNestedFieldsRepeater($fields);

        return parent::renderForm();
    }

    private function renderNestedFieldsRepeater($fields)
    {
        $this->context->smarty->assign([
            'step_fields' => $fields,
            'id_group' => $this->object->id,
            'is_edit' => (bool)$this->object->id,
            'image_base_url' => _PS_BASE_URL_.__PS_BASE_URI__.'themes/child_classic/assets/img/configurator/',
        ]);
        return $this->context->smarty->fetch($this->module->getLocalPath() . 'views/templates/admin/pro_config_groups/helpers/form/form.tpl');
    }

    public function processAdd()
    {
        $res = parent::processAdd();
        if ($res && $this->object->id) {
            $this->saveNestedRepeater($this->object->id);
        }
        return $res;
    }

    public function processUpdate()
    {
        $res = parent::processUpdate();
        if ($res && $this->object->id) {
            $this->saveNestedRepeater($this->object->id);
        }
        return $res;
    }

    private function saveNestedRepeater($id_group)
    {
        $languages = Language::getLanguages(false);
        $sections = Tools::getValue('section');
        
        if (!is_array($sections)) {
            return;
        }

        // Ensure id_group is set correctly if it was missing from post
        if (!$id_group) $id_group = (int)Tools::getValue('id_group');

        // 1. Cleanup old sections
        $submitted_section_ids = array_filter(array_column($sections, 'id_field'));
        $existing_fields = ProConfigField::getByGroup($id_group, (int)$this->context->language->id);
        foreach ($existing_fields as $ef) {
            if (!in_array($ef['id_field'], $submitted_section_ids)) {
                $obj = new ProConfigField($ef['id_field']);
                $obj->delete();
            }
        }

        // 2. Process Sections
        foreach ($sections as $s_idx => $s_data) {
            if ($s_idx === 'S_INDEX') continue;

            $field = new ProConfigField((int)$s_data['id_field']);
            $field->id_group = $id_group;
            
            // Populate all languages to satisfy 'required' validation
            foreach ($languages as $lang) {
                $field->title[(int)$lang['id_lang']] = $s_data['title'];
                $field->description[(int)$lang['id_lang']] = $s_data['description'];
            }
            
            $field->field_type = $s_data['field_type'] ?? 'radio';
            $field->min_value = (float)($s_data['min_value'] ?? 0);
            $field->max_value = (float)($s_data['max_value'] ?? 0);
            $field->is_required = (int)($s_data['is_required'] ?? 0);
            $field->sort_order = (int)$s_idx;
            $field->active = 1;
            
            if (!$field->save()) {
                // If field fails to save, we might want to know why, but for now continue
                continue;
            }

            $id_field = $field->id;

            // 3. Process Values within this Section
            $values = $s_data['val'] ?? [];
            $submitted_val_ids = array_filter(array_column($values, 'id_group_value'));
            $existing_vals = ProConfigGroupValue::getByField($id_field, (int)$this->context->language->id);
            foreach ($existing_vals as $ev) {
                if (!in_array($ev['id_group_value'], $submitted_val_ids)) {
                    $obj = new ProConfigGroupValue($ev['id_group_value']);
                    $obj->delete();
                }
            }

            foreach ($values as $v_idx => $v_data) {
                if ($v_idx === 'V_INDEX') continue;

                $val = new ProConfigGroupValue((int)$v_data['id_group_value']);
                $val->id_field = $id_field;
                $val->id_group = $id_group;
                
                // Populate all languages
                foreach ($languages as $lang) {
                    $val->label[(int)$lang['id_lang']] = $v_data['label'];
                    $val->description[(int)$lang['id_lang']] = $v_data['description'] ?? '';
                }
                
                $val->price_impact = (float)$v_data['price'];
                $val->price_impact_type = $v_data['price_type'];
                $val->dependencies = $v_data['dependencies'] ?? '';
                $val->sort_order = (int)$v_idx;
                $val->active = 1;

                // Nested Image Upload
                if (isset($_FILES['section']['tmp_name'][$s_idx]['val'][$v_idx]['image_upload']) 
                    && !empty($_FILES['section']['tmp_name'][$s_idx]['val'][$v_idx]['image_upload'])) {
                    
                    $file = [
                        'name' => $_FILES['section']['name'][$s_idx]['val'][$v_idx]['image_upload'],
                        'tmp_name' => $_FILES['section']['tmp_name'][$s_idx]['val'][$v_idx]['image_upload'],
                    ];
                    
                    $upload_dir = _PS_THEME_DIR_ . 'assets/img/configurator/';
                    if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
                    
                    $filename = time() . '_' . preg_replace('/[^a-zA-Z0-9.-]/', '', $file['name']);
                    if (move_uploaded_file($file['tmp_name'], $upload_dir . $filename)) {
                        $val->image = $filename;
                    }
                } else {
                    $val->image = $v_data['image_prev'] ?? '';
                }

                $val->save();
            }
        }
    }


}
