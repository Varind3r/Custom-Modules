<?php
/**
 * Admin Controller for ProConfigurator Options (Values)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class AdminProConfigOptionsController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        $this->table = 'proconfig_option';
        $this->className = 'ProConfigOption';
        $this->lang = true;
        $this->addRowAction('edit');
        $this->addRowAction('delete');

        parent::__construct();

        // Ensure module is loaded for PS 1.7.9 compatibility
        if (!$this->module) {
            $this->module = Module::getInstanceByName('proconfigurator');
        }

        // Filter by attribute if provided
        if ($idAttribute = (int) Tools::getValue('id_attribute')) {
            $this->_where .= ' AND a.id_attribute = ' . $idAttribute;
        }

        $this->fields_list = [
            'id_option' => [
                'title' => $this->trans('ID', [], 'Admin.Global'),
                'align' => 'center',
                'class' => 'fixed-width-xs',
            ],
            'label' => [
                'title' => $this->trans('Label', [], 'Admin.Global'),
                'filter_key' => 'b!label',
            ],
            'image' => [
                'title' => $this->trans('Image', [], 'Admin.Global'),
                'callback' => 'displayImagePreview',
                'search' => false,
            ],
            'color_code' => [
                'title' => $this->trans('Color', [], 'Admin.Global'),
                'callback' => 'displayColorSwatch',
                'search' => false,
            ],
            'price_impact' => [
                'title' => $this->trans('Price', [], 'Admin.Global'),
                'type' => 'price',
                'currency' => true,
            ],
            'active' => [
                'title' => $this->trans('Active', [], 'Admin.Global'),
                'type' => 'bool',
                'active' => 'status',
            ],
            'sort_order' => [
                'title' => $this->trans('Position', [], 'Admin.Global'),
                'type' => 'int',
            ],
        ];

        $this->bulk_actions = [
            'delete' => [
                'text' => $this->trans('Delete selected', [], 'Admin.Actions'),
                'confirm' => $this->trans('Delete selected items?', [], 'Admin.Notifications.Warning'),
                'icon' => 'icon-trash',
            ],
        ];
    }

    public function displayImagePreview($value, $row)
    {
        if (empty($value)) {
            return '-';
        }
        $url = strpos($value, 'http') === 0 ? $value : _THEME_DIR_ . 'assets/img/configurator/' . $value;
        return '<img src="' . $url . '" style="max-width:60px;max-height:40px;border-radius:4px;border:1px solid #ddd;" />';
    }

    public function displayColorSwatch($value, $row)
    {
        if (empty($value)) {
            return '-';
        }
        return '<div style="width:30px;height:30px;border-radius:50%;background:' . $value . ';border:2px solid #fff;box-shadow:0 1px 3px rgba(0,0,0,0.2);"></div>';
    }

    public function renderForm()
    {
        // Get attributes for dropdown
        $attributes = Db::getInstance()->executeS('
            SELECT a.id_attribute as id, al.name 
            FROM `' . _DB_PREFIX_ . 'proconfig_attribute` a
            LEFT JOIN `' . _DB_PREFIX_ . 'proconfig_attribute_lang` al 
                ON a.id_attribute = al.id_attribute AND al.id_lang = ' . (int) $this->context->language->id . '
            WHERE a.active = 1
            ORDER BY al.name ASC
        ');

        $this->fields_form = [
            'legend' => [
                'title' => $this->trans('Configurator Option (Value)', [], 'Modules.Proconfigurator.Admin'),
                'icon' => 'icon-check-square-o',
            ],
            'input' => [
                [
                    'type' => 'select',
                    'label' => $this->trans('Attribute (Field)', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'id_attribute',
                    'required' => true,
                    'options' => [
                        'query' => $attributes,
                        'id' => 'id',
                        'name' => 'name',
                    ],
                ],
                [
                    'type' => 'text',
                    'label' => $this->trans('Label', [], 'Admin.Global'),
                    'name' => 'label',
                    'lang' => true,
                    'required' => true,
                ],
                [
                    'type' => 'textarea',
                    'label' => $this->trans('Description', [], 'Admin.Global'),
                    'name' => 'description',
                    'lang' => true,
                    'autoload_rte' => true,
                ],
                [
                    'type' => 'text',
                    'label' => $this->trans('Badge', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'badge',
                    'lang' => true,
                    'class' => 'fixed-width-lg',
                    'hint' => $this->trans('Short text like "Promo", "Best Seller", "New"', [], 'Modules.Proconfigurator.Admin'),
                ],
                [
                    'type' => 'textarea',
                    'label' => $this->trans('Feature List', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'feature_list',
                    'lang' => true,
                    'autoload_rte' => true,
                    'hint' => $this->trans('Bullet points or HTML list of features', [], 'Modules.Proconfigurator.Admin'),
                ],
                // Multiple Content Fields
                [
                    'type' => 'text',
                    'label' => $this->trans('Content Field 1', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'content_field_1',
                    'lang' => true,
                    'hint' => $this->trans('Additional content field for rich option data', [], 'Modules.Proconfigurator.Admin'),
                ],
                [
                    'type' => 'text',
                    'label' => $this->trans('Content Field 2', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'content_field_2',
                    'lang' => true,
                ],
                [
                    'type' => 'text',
                    'label' => $this->trans('Content Field 3', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'content_field_3',
                    'lang' => true,
                ],
                // Visual
                [
                    'type' => 'file',
                    'label' => $this->trans('Image', [], 'Admin.Global'),
                    'name' => 'image_file',
                    'hint' => $this->trans('Upload image (saved to theme assets folder)', [], 'Modules.Proconfigurator.Admin'),
                ],
                [
                    'type' => 'text',
                    'label' => $this->trans('Image Path', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'image',
                    'hint' => $this->trans('Or enter image filename/URL directly', [], 'Modules.Proconfigurator.Admin'),
                ],
                [
                    'type' => 'color',
                    'label' => $this->trans('Color Code', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'color_code',
                ],
                [
                    'type' => 'text',
                    'label' => $this->trans('Color Gradient', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'color_gradient',
                    'hint' => $this->trans('JSON: {"from":"#color1","to":"#color2","direction":"to right"}', [], 'Modules.Proconfigurator.Admin'),
                ],
                // Pricing
                [
                    'type' => 'text',
                    'label' => $this->trans('Price Impact', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'price_impact',
                    'prefix' => $this->context->currency->sign,
                    'class' => 'fixed-width-md',
                ],
                [
                    'type' => 'select',
                    'label' => $this->trans('Price Type', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'price_impact_type',
                    'options' => [
                        'query' => ProConfigOption::getPriceTypes(),
                        'id' => 'id',
                        'name' => 'name',
                    ],
                ],
                // Conditional Logic
                [
                    'type' => 'textarea',
                    'label' => $this->trans('Dependencies (JSON)', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'dependencies',
                    'rows' => 4,
                    'hint' => $this->trans('Conditional logic in JSON format. Example: {"show_groups":[2],"hide_attributes":[5,6],"require_attributes":[3]}', [], 'Modules.Proconfigurator.Admin'),
                ],
                // Status
                [
                    'type' => 'switch',
                    'label' => $this->trans('Active', [], 'Admin.Global'),
                    'name' => 'active',
                    'is_bool' => true,
                    'values' => [
                        ['id' => 'active_on', 'value' => 1, 'label' => $this->trans('Yes', [], 'Admin.Global')],
                        ['id' => 'active_off', 'value' => 0, 'label' => $this->trans('No', [], 'Admin.Global')],
                    ],
                ],
                [
                    'type' => 'text',
                    'label' => $this->trans('Position', [], 'Admin.Global'),
                    'name' => 'sort_order',
                    'class' => 'fixed-width-sm',
                ],
            ],
            'submit' => [
                'title' => $this->trans('Save', [], 'Admin.Actions'),
            ],
        ];

        // Pre-fill attribute if in URL
        if ($idAttribute = (int) Tools::getValue('id_attribute')) {
            $this->fields_value['id_attribute'] = $idAttribute;
        }

        return parent::renderForm();
    }

    public function postProcess()
    {
        // Handle image upload
        if (Tools::isSubmit('submitAdd' . $this->table) && isset($_FILES['image_file']) && $_FILES['image_file']['error'] === 0) {
            if ($this->module) {
                $uploadPath = $this->module->getImageUploadPath();

                $filename = time() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '', $_FILES['image_file']['name']);
                $destination = $uploadPath . $filename;

                if (move_uploaded_file($_FILES['image_file']['tmp_name'], $destination)) {
                    $_POST['image'] = $filename;
                }
            }
        }

        // Set defaults
        if (Tools::isSubmit('submitAdd' . $this->table)) {
            if (Tools::getValue('sort_order') === '') {
                $_POST['sort_order'] = 0;
            }
            if (Tools::getValue('price_impact') === '') {
                $_POST['price_impact'] = 0;
            }
        }

        return parent::postProcess();
    }

    public function initToolbar()
    {
        parent::initToolbar();

        // Add link back to attributes if filtered
        if ($idAttribute = (int) Tools::getValue('id_attribute')) {
            $this->page_header_toolbar_btn['back_to_attributes'] = [
                'href' => $this->context->link->getAdminLink('AdminProConfigAttributes'),
                'desc' => $this->trans('Back to Attributes', [], 'Modules.Proconfigurator.Admin'),
                'icon' => 'process-icon-back',
            ];
        }
    }
}
