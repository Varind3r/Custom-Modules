<?php
/**
 * Admin Controller for ProConfigurator Attributes (Fields)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class AdminProConfigAttributesController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        $this->table = 'proconfig_attribute';
        // Explicit primary key so PS doesn't guess id_proconfig_attribute
        $this->identifier = 'id_attribute';
        $this->className = 'ProConfigAttribute';
        $this->lang = true;
        $this->addRowAction('edit');
        $this->addRowAction('delete');
        $this->addRowAction('viewOptions');

        parent::__construct();

        // Ensure module is loaded for PS 1.7.9 compatibility
        if (!$this->module) {
            $this->module = Module::getInstanceByName('proconfigurator');
        }

        // Filter by group if provided
        if ($idGroup = (int) Tools::getValue('id_group')) {
            $this->_where .= ' AND a.id_group = ' . $idGroup;
        }

        $this->fields_list = [
            'id_attribute' => [
                'title' => $this->trans('ID', [], 'Admin.Global'),
                'align' => 'center',
                'class' => 'fixed-width-xs',
            ],
            'name' => [
                'title' => $this->trans('Name', [], 'Admin.Global'),
                'filter_key' => 'b!name',
            ],
            'field_type' => [
                'title' => $this->trans('Type', [], 'Admin.Global'),
                'callback' => 'displayFieldTypeBadge',
            ],
            'is_required' => [
                'title' => $this->trans('Required', [], 'Admin.Global'),
                'type' => 'bool',
                'align' => 'center',
            ],
            'allow_user_input' => [
                'title' => $this->trans('User Input', [], 'Modules.Proconfigurator.Admin'),
                'type' => 'bool',
                'align' => 'center',
            ],
            'active' => [
                'title' => $this->trans('Active', [], 'Admin.Global'),
                'type' => 'bool',
                'active' => 'status',
            ],
            'sort_order' => [
                'title' => $this->trans('Position', [], 'Admin.Global'),
                'type' => 'int',
            ],
        ];

        $this->bulk_actions = [
            'delete' => [
                'text' => $this->trans('Delete selected', [], 'Admin.Actions'),
                'confirm' => $this->trans('Delete selected items?', [], 'Admin.Notifications.Warning'),
                'icon' => 'icon-trash',
            ],
        ];
    }

    public function displayFieldTypeBadge($value, $row)
    {
        $colors = [
            'text' => '#3498db',
            'textarea' => '#3498db',
            'number' => '#9b59b6',
            'dropdown' => '#e67e22',
            'radio_text' => '#2ecc71',
            'radio_image' => '#1abc9c',
            'radio_color' => '#e74c3c',
            'checkbox' => '#f39c12',
            'file' => '#34495e',
            'dimensions' => '#16a085',
            'date' => '#8e44ad',
        ];
        $color = $colors[$value] ?? '#95a5a6';
        $label = ucwords(str_replace('_', ' ', $value));
        return '<span class="badge" style="background:' . $color . ';color:#fff;">' . $label . '</span>';
    }

    public function displayViewOptionsLink($token, $id)
    {
        $href = $this->context->link->getAdminLink('AdminProConfigOptions') . '&id_attribute=' . (int) $id;
        return '<a class="btn btn-default btn-xs" href="' . $href . '" title="Manage Options">
            <i class="icon-list-alt"></i> Options
        </a>';
    }

    public function renderForm()
    {
        $groups = ProConfigGroup::getDropdown($this->context->language->id);
        array_unshift($groups, ['id' => 0, 'name' => '-- No Group (Global) --']);

        $this->fields_form = [
            'legend' => [
                'title' => $this->trans('Configurator Attribute (Field)', [], 'Modules.Proconfigurator.Admin'),
                'icon' => 'icon-puzzle-piece',
            ],
            'input' => [
                [
                    'type' => 'text',
                    'label' => $this->trans('Name', [], 'Admin.Global'),
                    'name' => 'name',
                    'lang' => true,
                    'required' => true,
                ],
                [
                    'type' => 'select',
                    'label' => $this->trans('Group', [], 'Admin.Global'),
                    'name' => 'id_group',
                    'options' => [
                        'query' => $groups,
                        'id' => 'id',
                        'name' => 'name',
                    ],
                    'hint' => $this->trans('Assign to a specific group or leave as global', [], 'Modules.Proconfigurator.Admin'),
                ],
                [
                    'type' => 'select',
                    'label' => $this->trans('Field Type', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'field_type',
                    'id' => 'field_type_selector',
                    'required' => true,
                    'options' => [
                        'query' => ProConfigAttribute::getFieldTypes(),
                        'id' => 'id',
                        'name' => 'name',
                    ],
                ],
                [
                    'type' => 'textarea',
                    'label' => $this->trans('Description', [], 'Admin.Global'),
                    'name' => 'description',
                    'lang' => true,
                    'autoload_rte' => true,
                ],
                [
                    'type' => 'text',
                    'label' => $this->trans('Placeholder', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'placeholder',
                    'lang' => true,
                    'hint' => $this->trans('Placeholder text for input fields', [], 'Modules.Proconfigurator.Admin'),
                ],
                [
                    'type' => 'text',
                    'label' => $this->trans('Suffix', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'suffix',
                    'lang' => true,
                    'class' => 'fixed-width-sm',
                    'hint' => $this->trans('Unit suffix (e.g., "mm", "cm", "€")', [], 'Modules.Proconfigurator.Admin'),
                ],
                // Validation Section
                [
                    'type' => 'switch',
                    'label' => $this->trans('Required', [], 'Admin.Global'),
                    'name' => 'is_required',
                    'is_bool' => true,
                    'values' => [
                        ['id' => 'is_required_on', 'value' => 1, 'label' => $this->trans('Yes', [], 'Admin.Global')],
                        ['id' => 'is_required_off', 'value' => 0, 'label' => $this->trans('No', [], 'Admin.Global')],
                    ],
                ],
                [
                    'type' => 'switch',
                    'label' => $this->trans('Allow User Custom Input', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'allow_user_input',
                    'is_bool' => true,
                    'values' => [
                        ['id' => 'allow_user_input_on', 'value' => 1, 'label' => $this->trans('Yes', [], 'Admin.Global')],
                        ['id' => 'allow_user_input_off', 'value' => 0, 'label' => $this->trans('No', [], 'Admin.Global')],
                    ],
                    'hint' => $this->trans('Allow customers to enter custom values in addition to predefined options', [], 'Modules.Proconfigurator.Admin'),
                ],
                [
                    'type' => 'text',
                    'label' => $this->trans('Validation Regex', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'validation_regex',
                    'hint' => $this->trans('Regular expression for validation (advanced)', [], 'Modules.Proconfigurator.Admin'),
                ],
                [
                    'type' => 'text',
                    'label' => $this->trans('Validation Error Message', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'validation_error',
                    'lang' => true,
                    'hint' => $this->trans('Custom error message when validation fails', [], 'Modules.Proconfigurator.Admin'),
                ],
                // Number/Dimension Limits
                [
                    'type' => 'text',
                    'label' => $this->trans('Min Value', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'min_value',
                    'class' => 'fixed-width-sm',
                    'form_group_class' => 'number-field',
                ],
                [
                    'type' => 'text',
                    'label' => $this->trans('Max Value', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'max_value',
                    'class' => 'fixed-width-sm',
                    'form_group_class' => 'number-field',
                ],
                [
                    'type' => 'text',
                    'label' => $this->trans('Step', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'step_value',
                    'class' => 'fixed-width-sm',
                    'form_group_class' => 'number-field',
                ],
                // Dimension Limits
                [
                    'type' => 'text',
                    'label' => $this->trans('Min Width (mm)', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'min_width',
                    'class' => 'fixed-width-sm',
                    'form_group_class' => 'dimension-field',
                ],
                [
                    'type' => 'text',
                    'label' => $this->trans('Max Width (mm)', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'max_width',
                    'class' => 'fixed-width-sm',
                    'form_group_class' => 'dimension-field',
                ],
                [
                    'type' => 'text',
                    'label' => $this->trans('Min Height (mm)', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'min_height',
                    'class' => 'fixed-width-sm',
                    'form_group_class' => 'dimension-field',
                ],
                [
                    'type' => 'text',
                    'label' => $this->trans('Max Height (mm)', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'max_height',
                    'class' => 'fixed-width-sm',
                    'form_group_class' => 'dimension-field',
                ],
                // Status
                [
                    'type' => 'switch',
                    'label' => $this->trans('Active', [], 'Admin.Global'),
                    'name' => 'active',
                    'is_bool' => true,
                    'values' => [
                        ['id' => 'active_on', 'value' => 1, 'label' => $this->trans('Yes', [], 'Admin.Global')],
                        ['id' => 'active_off', 'value' => 0, 'label' => $this->trans('No', [], 'Admin.Global')],
                    ],
                ],
                [
                    'type' => 'text',
                    'label' => $this->trans('Position', [], 'Admin.Global'),
                    'name' => 'sort_order',
                    'class' => 'fixed-width-sm',
                ],
            ],
            'submit' => [
                'title' => $this->trans('Save', [], 'Admin.Actions'),
            ],
        ];

        // Pre-fill group if in URL
        if ($idGroup = (int) Tools::getValue('id_group')) {
            $this->fields_value['id_group'] = $idGroup;
        }

        // Add JS for conditional field visibility
        if ($this->module) {
            $this->addJS(_PS_MODULE_DIR_ . $this->module->name . '/views/js/admin_attribute.js');
        }

        return parent::renderForm();
    }

    public function postProcess()
    {
        if (Tools::isSubmit('submitAdd' . $this->table)) {
            // Set defaults
            if (Tools::getValue('sort_order') === '') {
                $_POST['sort_order'] = 0;
            }
            if (Tools::getValue('step_value') === '') {
                $_POST['step_value'] = 1;
            }
        }

        return parent::postProcess();
    }

    /**
     * Override renderList to ensure correct JOINs
     * PrestaShop automatically handles language JOIN when lang=true,
     * but we need to prevent incorrect auto-joins with group table
     */
    public function renderList()
    {
        // Let PrestaShop handle the language JOIN automatically (lang=true)
        // The _getSelect and _getFrom overrides will fix any incorrect column references
        return parent::renderList();
    }

    /**
     * Override _getSelect to fix JOIN queries with correct column names
     */
    protected function _getSelect()
    {
        return $this->fixJoinColumns(parent::_getSelect());
    }

    /**
     * Override _getFrom to ensure correct JOINs
     */
    protected function _getFrom()
    {
        return $this->fixJoinColumns(parent::_getFrom());
    }

    /**
     * Override _getJoin to prevent incorrect auto-joins
     */
    protected function _getJoin()
    {
        return $this->fixJoinColumns(parent::_getJoin());
    }

    /**
     * Normalize any wrong auto-joined column names (handles backticks too)
     */
    private function fixJoinColumns($sql)
    {
        // First, check what's actually in your SQL
        error_log("Original SQL: " . $sql);

        $replacements = [
            // Match with or without backticks, with or without table prefix
            '/(`?(?:b|g|c)`?\.`?(?:ps_)?id_proconfig_group`?)/i' => 'a.id_group',
            '/(`?(?:b|g|c)`?\.`?(?:ps_)?id_proconfig_attribute`?)/i' => 'a.id_attribute',
            '/(`?(?:b|g|c)`?\.`?(?:ps_)?id_proconfig_option`?)/i' => 'a.id_option',

            // For ON clauses
            '/(ON\s+`?(?:b|g|c)`?\.`?(?:ps_)?id_proconfig_group`?\s*=\s*)/i' => 'ON a.id_group = ',
            '/(ON\s+`?(?:b|g|c)`?\.`?(?:ps_)?id_proconfig_attribute`?\s*=\s*)/i' => 'ON a.id_attribute = ',
            '/(ON\s+`?(?:b|g|c)`?\.`?(?:ps_)?id_proconfig_option`?\s*=\s*)/i' => 'ON a.id_option = ',

            // For WHERE clauses
            '/(\s+`?(?:b|g|c)`?\.`?(?:ps_)?id_proconfig_group`?\s*=\s*)/i' => ' a.id_group = ',
            '/(\s+`?(?:b|g|c)`?\.`?(?:ps_)?id_proconfig_attribute`?\s*=\s*)/i' => ' a.id_attribute = ',
            '/(\s+`?(?:b|g|c)`?\.`?(?:ps_)?id_proconfig_option`?\s*=\s*)/i' => ' a.id_option = ',
        ];

        foreach ($replacements as $pattern => $replacement) {
            $count = 0;
            $sql = preg_replace($pattern, $replacement, $sql, -1, $count);
            if ($count > 0) {
                error_log("Applied pattern: $pattern -> $replacement ($count times)");
            }
        }

        error_log("Modified SQL: " . $sql);
        return $sql;
    }

    public function initToolbar()
    {
        parent::initToolbar();

        // Add link back to groups if filtered
        if ($idGroup = (int) Tools::getValue('id_group')) {
            $this->page_header_toolbar_btn['back_to_groups'] = [
                'href' => $this->context->link->getAdminLink('AdminProConfigGroups'),
                'desc' => $this->trans('Back to Groups', [], 'Modules.Proconfigurator.Admin'),
                'icon' => 'process-icon-back',
            ];
        }
    }
}
