<?php
/**
 * Admin Controller for ProConfigurator Group Values (Repeatable Items)
 * 
 * Like ACF Repeater - manage values for each group
 * Each value = selectable option with image, label, price
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class AdminProConfigGroupValueController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        $this->table = 'proconfig_group_value';
        $this->identifier = 'id_group_value';
        $this->className = 'ProConfigGroupValue';
        $this->lang = true;
        $this->addRowAction('edit');
        $this->addRowAction('delete');

        parent::__construct();

        // Ensure module is loaded
        if (!$this->module) {
            $this->module = Module::getInstanceByName('proconfigurator');
        }

        // IMPORTANT: Filter by group from URL
        if ($idGroup = (int) Tools::getValue('id_group')) {
            $this->_where .= ' AND a.id_group = ' . $idGroup;
        } else {
            // If processing a specific object, we need to know its group
            $idObj = (int) Tools::getValue('id_group_value');
            if ($idObj) {
                $obj = new ProConfigGroupValue($idObj);
                if (Validate::isLoadedObject($obj)) {
                    $this->_where .= ' AND a.id_group = ' . (int) $obj->id_group;
                    $_GET['id_group'] = $obj->id_group; // Inject for renderForm
                }
            } else {
                // Redirect back to groups if no group specified
                Tools::redirect($this->context->link->getAdminLink('AdminProConfigGroups'));
            }
        }

        $this->fields_list = [
            'id_group_value' => [
                'title' => $this->trans('ID', [], 'Admin.Global'),
                'align' => 'center',
                'class' => 'fixed-width-xs',
            ],
            'label' => [
                'title' => $this->trans('Value Label', [], 'Modules.Proconfigurator.Admin'),
                'filter_key' => 'b!label',
            ],
            'image' => [
                'title' => $this->trans('Image', [], 'Admin.Global'),
                'callback' => 'displayImagePreview',
                'search' => false,
            ],
            'color_code' => [
                'title' => $this->trans('Color', [], 'Admin.Global'),
                'callback' => 'displayColorSwatch',
                'search' => false,
            ],
            'price_impact' => [
                'title' => $this->trans('Price Impact', [], 'Modules.Proconfigurator.Admin'),
                'type' => 'price',
                'currency' => true,
            ],
            'price_impact_type' => [
                'title' => $this->trans('Price Type', [], 'Modules.Proconfigurator.Admin'),
                'callback' => 'displayPriceType',
            ],
            'active' => [
                'title' => $this->trans('Active', [], 'Admin.Global'),
                'type' => 'bool',
                'active' => 'status',
            ],
            'sort_order' => [
                'title' => $this->trans('Position', [], 'Admin.Global'),
                'type' => 'int',
            ],
        ];

        $this->bulk_actions = [
            'delete' => [
                'text' => $this->trans('Delete selected', [], 'Admin.Actions'),
                'confirm' => $this->trans('Delete selected items?', [], 'Admin.Notifications.Warning'),
                'icon' => 'icon-trash',
            ],
        ];
    }

    /**
     * Display image preview callback
     */
    public function displayImagePreview($value, $row)
    {
        if (empty($value)) {
            return '-';
        }
        $url = strpos($value, 'http') === 0 ? $value : _THEME_DIR_ . 'assets/img/configurator/' . $value;
        return '<img src="' . $url . '" style="max-width:60px;max-height:40px;border-radius:4px;border:1px solid #ddd;" />';
    }

    /**
     * Display color swatch callback
     */
    public function displayColorSwatch($value, $row)
    {
        if (empty($value)) {
            return '-';
        }
        return '<div style="width:30px;height:30px;border-radius:50%;background:' . $value . ';border:2px solid #fff;box-shadow:0 1px 3px rgba(0,0,0,0.2);"></div>';
    }

    /**
     * Display price type badge
     */
    public function displayPriceType($value, $row)
    {
        $colors = [
            'fixed' => '#3498db',
            'percent' => '#e67e22',
            'rate_m2' => '#16a085',
            'rate_m' => '#8e44ad',
        ];
        $labels = [
            'fixed' => 'Fixed',
            'percent' => 'Percentage',
            'rate_m2' => 'Per m²',
            'rate_m' => 'Per m',
        ];
        $color = $colors[$value] ?? '#95a5a6';
        $label = $labels[$value] ?? $value;
        return '<span class="badge" style="background:' . $color . ';color:#fff;">' . $label . '</span>';
    }

    /**
     * Render form for add/edit
     */
    public function renderForm()
    {
        // Get group info
        $idGroup = (int) Tools::getValue('id_group');
        if (!$idGroup) {
            $this->errors[] = $this->trans('No group specified', [], 'Modules.Proconfigurator.Admin');
            return '';
        }

        $group = new ProConfigGroup($idGroup, $this->context->language->id);
        if (!Validate::isLoadedObject($group)) {
            $this->errors[] = $this->trans('Invalid group', [], 'Modules.Proconfigurator.Admin');
            return '';
        }

        // Get manufacturers for dropdown
        $manufacturers = Manufacturer::getManufacturers(false, (int) $this->context->language->id);
        array_unshift($manufacturers, ['id_manufacturer' => 0, 'name' => '-- No Brand --']);

        // Price type options
        $priceTypes = ProConfigGroupValue::getPriceTypes();

        $this->fields_form = [
            'legend' => [
                'title' => $this->trans('Add Value to: ', [], 'Modules.Proconfigurator.Admin') . $group->name,
                'icon' => 'icon-puzzle-piece',
            ],
            'input' => [
                // Hidden ID Group
                [
                    'type' => 'hidden',
                    'name' => 'id_group',
                ],
                // Basic Info
                [
                    'type' => 'text',
                    'label' => $this->trans('Value Label', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'label',
                    'lang' => true,
                    'required' => true,
                    'hint' => $this->trans('Display name for this value (e.g., "Oak Wood", "36mm")', [], 'Modules.Proconfigurator.Admin'),
                ],
                [
                    'type' => 'textarea',
                    'label' => $this->trans('Description', [], 'Admin.Global'),
                    'name' => 'description',
                    'lang' => true,
                    'autoload_rte' => true,
                    'hint' => $this->trans('Optional detailed description shown to customers', [], 'Modules.Proconfigurator.Admin'),
                ],

                // Brand/Manufacturer
                [
                    'type' => 'select',
                    'label' => $this->trans('Brand / Manufacturer', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'id_manufacturer',
                    'options' => [
                        'query' => $manufacturers,
                        'id' => 'id_manufacturer',
                        'name' => 'name',
                    ],
                    'hint' => $this->trans('Optionally link to a brand/manufacturer', [], 'Modules.Proconfigurator.Admin'),
                ],

                // Visual - Image
                [
                    'type' => 'file',
                    'label' => $this->trans('Image', [], 'Admin.Global'),
                    'name' => 'image_file',
                    'hint' => $this->trans('Upload image to show for this value (e.g., material swatch, size preview)', [], 'Modules.Proconfigurator.Admin'),
                ],
                [
                    'type' => 'text',
                    'label' => $this->trans('Image Path (URL or Filename)', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'image',
                    'hint' => $this->trans('Or enter image filename/URL directly if already uploaded', [], 'Modules.Proconfigurator.Admin'),
                ],

                // Visual - Color
                [
                    'type' => 'color',
                    'label' => $this->trans('Color Code', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'color_code',
                    'hint' => $this->trans('Optional color swatch (hex code)', [], 'Modules.Proconfigurator.Admin'),
                ],

                // Pricing
                [
                    'type' => 'text',
                    'label' => $this->trans('Price Impact', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'price_impact',
                    'prefix' => $this->context->currency->sign,
                    'class' => 'fixed-width-md',
                    'required' => true,
                    'hint' => $this->trans('Amount to add to base price (0 for no change)', [], 'Modules.Proconfigurator.Admin'),
                ],
                [
                    'type' => 'select',
                    'label' => $this->trans('Price Type', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'price_impact_type',
                    'options' => [
                        'query' => $priceTypes,
                        'id' => 'id',
                        'name' => 'name',
                    ],
                    'hint' => $this->trans('How to calculate price: fixed amount, percentage, or rate per unit', [], 'Modules.Proconfigurator.Admin'),
                ],

                // Conditional Logic (Advanced)
                [
                    'type' => 'textarea',
                    'label' => $this->trans('Conditional Logic (JSON)', [], 'Modules.Proconfigurator.Admin'),
                    'name' => 'dependencies',
                    'hint' => $this->trans('Advanced: JSON rules for when this value should be shown/hidden (optional)', [], 'Modules.Proconfigurator.Admin'),
                    'class' => 'fixed-width-lg',
                ],

                // Status
                [
                    'type' => 'switch',
                    'label' => $this->trans('Active', [], 'Admin.Global'),
                    'name' => 'active',
                    'is_bool' => true,
                    'values' => [
                        ['id' => 'active_on', 'value' => 1, 'label' => $this->trans('Yes', [], 'Admin.Global')],
                        ['id' => 'active_off', 'value' => 0, 'label' => $this->trans('No', [], 'Admin.Global')],
                    ],
                ],
                [
                    'type' => 'text',
                    'label' => $this->trans('Position', [], 'Admin.Global'),
                    'name' => 'sort_order',
                    'class' => 'fixed-width-sm',
                    'hint' => $this->trans('Display order (lower = first)', [], 'Modules.Proconfigurator.Admin'),
                ],
            ],
            'submit' => [
                'title' => $this->trans('Save', [], 'Admin.Actions'),
            ],
        ];

        // Set hidden group ID
        $this->fields_value['id_group'] = $idGroup;

        return parent::renderForm();
    }

    /**
     * Process form submission
     */
    public function postProcess()
    {
        // Handle image upload
        if (
            (Tools::isSubmit('submitAdd' . $this->table) || Tools::isSubmit('submitUpdate' . $this->table))
            && isset($_FILES['image_file']) && $_FILES['image_file']['error'] === 0
        ) {
            if ($this->module) {
                $uploadPath = $this->module->getImageUploadPath();
                $filename = time() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '', $_FILES['image_file']['name']);
                $destination = $uploadPath . $filename;

                if (move_uploaded_file($_FILES['image_file']['tmp_name'], $destination)) {
                    $_POST['image'] = $filename;
                }
            }
        }

        // Set defaults
        if (Tools::isSubmit('submitAdd' . $this->table)) {
            if (Tools::getValue('sort_order') === '') {
                $_POST['sort_order'] = 0;
            }
            if (Tools::getValue('price_impact') === '') {
                $_POST['price_impact'] = 0;
            }
            if (!Tools::getValue('price_impact_type')) {
                $_POST['price_impact_type'] = 'fixed';
            }
        }

        // After processing the form, redirect back to the values list for the same group
        if (Tools::isSubmit('submitAdd' . $this->table) || Tools::isSubmit('submitUpdate' . $this->table)) {
            $idGroup = (int) Tools::getValue('id_group');
            if ($idGroup) {
                $this->redirect_after = $this->context->link->getAdminLink('AdminProConfigGroupValue') . '&id_group=' . $idGroup;
            }
        }
        return parent::postProcess();
    }

    /**
     * Initialize toolbar with back button
     */
    public function initToolbar()
    {
        parent::initToolbar();

        $idGroup = (int) Tools::getValue('id_group');
        if ($idGroup) {
            $this->page_header_toolbar_btn['back_to_group'] = [
                'href' => $this->context->link->getAdminLink('AdminProConfigGroups') . '&updateid_group=' . $idGroup,
                'desc' => $this->trans('Back to Group', [], 'Modules.Proconfigurator.Admin'),
                'icon' => 'process-icon-back',
            ];
        }
    }

    /**
     * Override getList to join group info
     */
    public function getList($id_lang, $order_by = null, $order_way = null, $start = 0, $limit = null, $id_lang_shop = false)
    {
        // Add JOIN for group names
        $this->_select .= ', gl.name as group_name';
        $this->_join .= ' LEFT JOIN `' . _DB_PREFIX_ . 'proconfig_group_lang` gl ON (a.id_group = gl.id_group AND gl.id_lang = ' . (int) $id_lang . ')';

        return parent::getList($id_lang, $order_by, $order_way, $start, $limit, $id_lang_shop);
    }

    /**
     * AJAX: Get values for a group with product-specific overrides
     * Used by admin product page to load value customization options
     */
    public function ajaxProcessGetValuesForProduct()
    {
        $idGroup = (int) Tools::getValue('id_group');
        $idProduct = (int) Tools::getValue('id_product');
        $idLang = (int) $this->context->language->id;

        if (!$idGroup) {
            die(json_encode(['error' => 'No group specified', 'values' => []]));
        }

        // Get all fields and values for this group
        $fields = ProConfigField::getByGroup($idGroup, $idLang);
        $values = [];

        foreach ($fields as $field) {
            if (!empty($field['values'])) {
                foreach ($field['values'] as $value) {
                    // Get product-specific override if exists
                    $override = null;
                    if ($idProduct) {
                        $override = Db::getInstance()->getRow(
                            'SELECT * FROM `' . _DB_PREFIX_ . 'proconfig_product_group_value`
                             WHERE id_product = ' . $idProduct . ' AND id_group_value = ' . (int) $value['id_group_value']
                        );
                    }

                    $values[] = [
                        'id_group_value' => (int) $value['id_group_value'],
                        'id_field' => (int) $value['id_field'],
                        'label' => $value['label'],
                        'image' => $value['image'],
                        'price_impact' => (float) $value['price_impact'],
                        'price_impact_type' => $value['price_impact_type'],
                        'active' => (int) $value['active'],
                        'override' => $override ? [
                            'is_available' => (int) $override['is_available'],
                            'custom_label' => $override['custom_label'],
                            'price_impact' => $override['price_impact'] !== null ? (float) $override['price_impact'] : null,
                            'price_impact_type' => $override['price_impact_type'],
                        ] : null,
                    ];
                }
            }
        }

        die(json_encode([
            'success' => true,
            'id_group' => $idGroup,
            'id_product' => $idProduct,
            'values' => $values,
        ]));
    }

    /**
     * Handle AJAX requests
     */
    public function displayAjax()
    {
        $action = Tools::getValue('action');

        if ($action === 'getValuesForProduct') {
            $this->ajaxProcessGetValuesForProduct();
        }
    }
}
