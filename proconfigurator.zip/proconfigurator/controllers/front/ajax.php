<?php
/**
 * ProConfigurator - AJAX Controller
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class ProConfiguratorAjaxModuleFrontController extends ModuleFrontController
{
    public $ajax = true;
    public $display_column_left = false;
    public $display_column_right = false;

    public function postProcess()
    {
        $action = Tools::getValue('action');

        if ($action === 'updatePrice') {
            return $this->updatePrice();
        } elseif ($action === 'getGroupValues') {
            return $this->getGroupValues();
        } elseif ($action === 'uploadFile') {
            return $this->uploadFile();
        }

        exit(json_encode(['error' => 'Invalid action']));
    }

    /**
     * Calculate price based on selections
     */
    private function updatePrice()
    {
        $idProduct = (int) Tools::getValue('id_product');
        $selections = Tools::getValue('selections');

        if (!$idProduct || !is_array($selections)) {
            exit(json_encode(['error' => 'Invalid data']));
        }

        $calculatedPrice = ProConfigPriceCalculator::calculate($idProduct, $selections, $this->context);
        $basePrice = Product::getPriceStatic($idProduct, true);

        exit(json_encode([
            'success' => true,
            'total_price' => $calculatedPrice,
            'formatted_price' => Tools::displayPrice($calculatedPrice, $this->context->currency),
            'price_impact' => $calculatedPrice - $basePrice,
        ]));
    }

    /**
     * Get values for a group
     */
    private function getGroupValues()
    {
        $idGroup = (int) Tools::getValue('id_group');
        $idLang = (int) $this->context->language->id;

        if (!$idGroup) {
            exit(json_encode(['error' => 'Invalid group']));
        }

        // Use the correct method - get the full group structure with fields and values
        $group = ProConfigGroup::getWithFieldsAndValues($idGroup, $idLang);

        if (!$group) {
            exit(json_encode(['error' => 'Group not found']));
        }

        exit(json_encode([
            'success' => true,
            'group' => $group,
            'fields' => $group['fields'] ?? [],
        ]));
    }
    /**
     * Upload file
     */
    private function uploadFile()
    {
        if (!isset($_FILES['file']) || $_FILES['file']['error'] !== 0) {
            exit(json_encode(['error' => 'No file uploaded']));
        }

        $file = $_FILES['file'];
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx', 'zip', 'dwg'];

        if (!in_array(strtolower($extension), $allowedExtensions)) {
            exit(json_encode(['error' => 'File type not allowed']));
        }

        $uploadDir = _PS_THEME_DIR_ . 'assets/img/configurator/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        $filename = 'upload_' . time() . '_' . uniqid() . '.' . $extension;
        if (move_uploaded_file($file['tmp_name'], $uploadDir . $filename)) {
            exit(json_encode([
                'success' => true,
                'filename' => $filename,
                'original_name' => $file['name'],
            ]));
        }

        exit(json_encode(['error' => 'Failed to move file']));
    }
}
