<?php

class AdminThemeContentManagerController extends ModuleAdminController
{
    public function __construct()
    {
        parent::__construct();
        $this->bootstrap = true;
    }

    public function initContent()
    {
        parent::initContent();

        $page_identifier = Tools::getValue('page_identifier', 'home');
        $category_id = (int) Tools::getValue('category_id', 0);

        if ($page_identifier == 'category' && $category_id > 0) {
            $storage_identifier = 'category_' . $category_id;
        } else {
            $storage_identifier = $page_identifier;
        }

        $lang_id = (int) Tools::getValue('lang_id', $this->context->language->id);

        // Save Action
        if (Tools::isSubmit('save_content')) {
            $this->processThemeContentSave($storage_identifier, $lang_id);
            Tools::redirectAdmin($this->context->link->getAdminLink('AdminThemeContentManager') . '&page_identifier=' . $page_identifier . '&category_id=' . $category_id . '&lang_id=' . $lang_id . '&conf=4');
        }

        $fields_def = $this->getFieldsDefinition($storage_identifier);
        $content_data = $this->module->getAllPageContent($storage_identifier, $lang_id);

        $html = $this->renderHeader($page_identifier, $lang_id, $category_id);
        $html .= '<form method="post" action="" class="form-horizontal" enctype="multipart/form-data">';
        $html .= '<input type="hidden" name="page_identifier" value="' . $page_identifier . '">';
        $html .= '<input type="hidden" name="lang_id" value="' . $lang_id . '">';

        foreach ($fields_def as $section_key => $section) {
            $html .= '<div class="panel">';
            $html .= '<div class="panel-heading">' . $section['label'] . '</div>';
            $html .= '<div class="panel-body">';

            foreach ($section['fields'] as $key => $field) {
                $value = isset($content_data[$key]) ? $content_data[$key] : (isset($field['default']) ? $field['default'] : '');
                $html .= $this->renderField($key, $field, $value);
            }

            $html .= '</div></div>';
        }

        $html .= '<div class="panel-footer">
                <button type="submit" name="save_content" class="btn btn-default pull-right">
                    <i class="process-icon-save"></i> Save
                </button>
            </div>';
        $html .= '</form>';

        $html .= $this->getCustomJs();

        $this->context->smarty->assign('content', $html);
    }

    private function renderHeader($current_page, $current_lang, $current_category = 0)
    {
        $pages = array(
            'home' => 'Homepage',
            'header' => 'Header',
            'footer' => 'Footer',
            'category' => 'Category Page',
            'blog' => 'Blog Page',
            'contact' => 'Contact Page',
            'about' => 'About Us Page'
        );
        $languages = Language::getLanguages(true);

        $html = '<div class="panel"><div class="panel-body"><form class="form-inline">';

        // Page Selector
        $html .= '<div class="form-group" style="margin-right: 10px;"><label>Page: </label> <select class="form-control" onchange="location.href=\'' . $this->context->link->getAdminLink('AdminThemeContentManager') . '&page_identifier=\'+this.value+\'&lang_id=' . $current_lang . '\'">';
        foreach ($pages as $k => $l) {
            $selected = ($k == $current_page) ? 'selected' : '';
            $html .= '<option value="' . $k . '" ' . $selected . '>' . $l . '</option>';
        }
        $html .= '</select></div>';

        // Category Selector (only if Category Page is selected)
        if ($current_page == 'category') {
            $categories = Category::getCategories($current_lang, true, false);
            $html .= '<div class="form-group" style="margin-right: 10px;"><label>Specific Category: </label> <select class="form-control" onchange="location.href=\'' . $this->context->link->getAdminLink('AdminThemeContentManager') . '&page_identifier=category&category_id=\'+this.value+\'&lang_id=' . $current_lang . '\'">';
            $html .= '<option value="0">-- All Categories (Default) --</option>';
            foreach ($categories as $cat) {
                $selected = ($cat['id_category'] == $current_category) ? 'selected' : '';
                $indent = max(0, ($cat['level_depth'] - 1) * 2);
                $html .= '<option value="' . $cat['id_category'] . '" ' . $selected . '>' . str_repeat('&nbsp;', $indent) . $cat['name'] . '</option>';
            }
            $html .= '</select></div>';
        }

        // Language Selector
        $html .= '<div class="form-group"><label>Language: </label> <select class="form-control" onchange="location.href=\'' . $this->context->link->getAdminLink('AdminThemeContentManager') . '&page_identifier=' . $current_page . '&category_id=' . $current_category . '&lang_id=\'+this.value">';
        foreach ($languages as $l) {
            $selected = ($l['id_lang'] == $current_lang) ? 'selected' : '';
            $html .= '<option value="' . $l['id_lang'] . '" ' . $selected . '>' . $l['name'] . '</option>';
        }
        $html .= '</select></div>';
        $html .= '</form></div></div>';
        return $html;
    }

    private function renderField($key, $field, $value)
    {
        $html = '<div class="form-group">';
        $html .= '<label class="control-label col-lg-3">' . $field['label'] . '</label>';
        $html .= '<div class="col-lg-9">';

        switch ($field['type']) {
            case 'text':
                $html .= '<input type="text" name="' . $key . '" value="' . htmlspecialchars($value, ENT_QUOTES) . '" class="form-control">';
                break;
            case 'textarea':
                $html .= '<textarea name="' . $key . '" rows="5" class="form-control">' . htmlspecialchars($value, ENT_QUOTES) . '</textarea>';
                break;
            case 'image':
                $preview_url = $value;
                if ($value && strpos($value, 'http') !== 0) {
                    $baseUrl = $this->context->link->getBaseLink();
                    $baseUri = __PS_BASE_URI__;
                    if ($baseUri != '/' && strpos($value, $baseUri) === 0) {
                        $preview_url = rtrim($baseUrl, $baseUri) . $value;
                    } else {
                        $preview_url = rtrim($baseUrl, '/') . '/' . ltrim($value, '/');
                    }
                }
                $html .= '<div class="image-field-wrapper" style="border: 1px solid #ddd; padding: 15px; border-radius: 5px; background: #f9f9f9;">';
                $html .= '<div class="input-group" style="margin-bottom: 10px;">
                            <span class="input-group-addon">URL</span>
                            <input type="text" name="' . $key . '" value="' . htmlspecialchars($value, ENT_QUOTES) . '" class="form-control" placeholder="http://...">
                          </div>';
                if ($value) {
                    $html .= '<div class="image-preview" style="margin-bottom: 10px;">
                                <label style="display:block;">Current Preview:</label>
                                <img src="' . htmlspecialchars($preview_url, ENT_QUOTES) . '" style="max-height: 150px; border: 2px solid #fff; box-shadow: 0 0 5px rgba(0,0,0,0.1); padding: 2px; background: #fff;">
                              </div>';
                }
                $html .= '<div class="upload-group">
                            <label><i class="icon-upload"></i> Upload New Image (Overwrites URL above):</label>
                            <input type="file" name="' . $key . '_upload" class="form-control">
                          </div>';
                $html .= '</div>';
                break;
            case 'repeater':
                $html .= $this->renderRepeater($key, $field, $value);
                break;
            case 'multiselect':
                if (is_string($value)) {
                    $decoded = json_decode($value, true);
                    if (json_last_error() === JSON_ERROR_NONE) {
                        $value = $decoded;
                    }
                }
                $html .= '<select name="' . $key . '[]" class="form-control" multiple style="height: 200px;">';
                if (isset($field['options'])) {
                    foreach ($field['options'] as $opt_val => $opt_label) {
                        $selected = (is_array($value) && in_array($opt_val, $value)) ? 'selected' : '';
                        $html .= '<option value="' . $opt_val . '" ' . $selected . '>' . $opt_label . '</option>';
                    }
                }
                $html .= '</select>';
                break;
        }

        if (isset($field['desc'])) {
            $html .= '<p class="help-block">' . $field['desc'] . '</p>';
        }
        $html .= '</div></div>';
        return $html;
    }

    private function renderRepeater($key, $field, $value)
    {
        $items = json_decode($value, true);
        if (!is_array($items))
            $items = [];

        $html = '<div class="repeater-container" data-key="' . $key . '">';
        $html .= '<div class="repeater-items">';

        // Template for new items
        $html .= '<div class="repeater-template" style="display:none">';
        $html .= $this->renderRepeaterItem($key, $field['subfields'], [], 'TEMPLATE_INDEX');
        $html .= '</div>';

        // Existing items
        foreach ($items as $index => $item) {
            $html .= $this->renderRepeaterItem($key, $field['subfields'], $item, $index);
        }

        $html .= '</div>';
        $html .= '<button type="button" class="btn btn-success add-repeater-item"><i class="icon-plus"></i> Add Item</button>';
        $html .= '</div>';
        return $html;
    }

    private function renderRepeaterItem($parentKey, $subfields, $itemData, $index)
    {
        $html = '<div class="repeater-item panel" style="margin-bottom: 10px; border: 1px solid #ddd; padding: 10px;">';
        $html .= '<button type="button" class="btn btn-danger btn-xs pull-right remove-repeater-item"><i class="icon-trash"></i></button>';
        $html .= '<div class="clearfix"></div>';

        foreach ($subfields as $subKey => $subField) {
            $fieldName = $parentKey . '[' . $index . '][' . $subKey . ']';
            $val = isset($itemData[$subKey]) ? $itemData[$subKey] : '';

            $html .= '<div class="form-group" style="margin-bottom: 5px;">';
            $html .= '<label class="control-label col-lg-3">' . $subField['label'] . '</label>';
            $html .= '<div class="col-lg-9">';

            if ($subField['type'] == 'textarea') {
                $html .= '<textarea name="' . $fieldName . '" class="form-control">' . htmlspecialchars($val, ENT_QUOTES) . '</textarea>';
            } elseif ($subField['type'] == 'image') {
                $preview_url = $val;
                if ($val && strpos($val, 'http') !== 0) {
                    $baseUrl = $this->context->link->getBaseLink();
                    $baseUri = __PS_BASE_URI__;
                    if ($baseUri != '/' && strpos($val, $baseUri) === 0) {
                        $preview_url = rtrim($baseUrl, $baseUri) . $val;
                    } else {
                        $preview_url = rtrim($baseUrl, '/') . '/' . ltrim($val, '/');
                    }
                }
                $html .= '<div class="image-field-wrapper" style="border: 1px solid #eee; padding: 10px; margin-bottom: 5px;">';
                $html .= '<div class="input-group" style="margin-bottom: 5px;">
                            <input type="text" name="' . $fieldName . '" value="' . htmlspecialchars($val, ENT_QUOTES) . '" class="form-control" placeholder="Image URL">
                            <span class="input-group-addon"><i class="icon-image"></i></span>
                          </div>';
                if ($val) {
                    $html .= '<div style="margin-bottom: 5px;"><img src="' . htmlspecialchars($preview_url, ENT_QUOTES) . '" style="max-height: 80px; border: 1px solid #ddd;"></div>';
                }
                $uploadFieldName = $parentKey . '[' . $index . '][' . $subKey . '_upload]';
                $html .= '<div class="upload-group">
                            <small>Or upload:</small>
                            <input type="file" name="' . $uploadFieldName . '" class="form-control input-sm">
                          </div>';
                $html .= '</div>';
            } else {
                $html .= '<input type="text" name="' . $fieldName . '" value="' . htmlspecialchars($val, ENT_QUOTES) . '" class="form-control">';
            }

            $html .= '</div></div>';
        }
        $html .= '</div>';
        return $html;
    }

    private function processThemeContentSave($page, $lang_id)
    {
        $def = $this->getFieldsDefinition($page);
        foreach ($def as $section) {
            foreach ($section['fields'] as $key => $field) {
                if ($field['type'] == 'repeater') {
                    $val = Tools::getValue($key); // This might be an array
                    // If Tools::getValue doesn't return array, check $_POST
                    if (!is_array($val) && isset($_POST[$key])) {
                        $val = $_POST[$key];
                    }
                    // Filter out template index if present (though JS should handle it, just in case)
                    if (is_array($val)) {
                        if (isset($val['TEMPLATE_INDEX']))
                            unset($val['TEMPLATE_INDEX']);

                        // Handle uploads for repeater items
                        foreach ($val as $idx => &$item) {
                            foreach ($field['subfields'] as $subKey => $subField) {
                                if ($subField['type'] == 'image') {
                                    // Check $_FILES[$key]['name'][$idx][$subKey . '_upload']
                                    if (isset($_FILES[$key]['name'][$idx][$subKey . '_upload']) && !empty($_FILES[$key]['tmp_name'][$idx][$subKey . '_upload'])) {
                                        $fileData = [
                                            'name' => $_FILES[$key]['name'][$idx][$subKey . '_upload'],
                                            'type' => $_FILES[$key]['type'][$idx][$subKey . '_upload'],
                                            'tmp_name' => $_FILES[$key]['tmp_name'][$idx][$subKey . '_upload'],
                                            'error' => $_FILES[$key]['error'][$idx][$subKey . '_upload'],
                                            'size' => $_FILES[$key]['size'][$idx][$subKey . '_upload'],
                                        ];
                                        $res = $this->uploadThemeContentImage($fileData);
                                        if ($res) {
                                            $item[$subKey] = $res;
                                        }
                                    }
                                }
                            }
                        }

                        $val = array_values($val); // Reindex
                        $this->module->saveContentValue($page, $key, json_encode($val), $lang_id);
                    } else {
                        $this->module->saveContentValue($page, $key, json_encode([]), $lang_id);
                    }
                } else {
                    $val = Tools::getValue($key);

                    // Handle single image upload
                    if ($field['type'] == 'image') {
                        if (isset($_FILES[$key . '_upload']) && !empty($_FILES[$key . '_upload']['tmp_name'])) {
                            $res = $this->uploadThemeContentImage($_FILES[$key . '_upload']);
                            if ($res) {
                                $val = $res;
                            }
                        }
                    }

                    if (is_array($val)) {
                        $val = json_encode($val);
                    }

                    $this->module->saveContentValue($page, $key, $val, $lang_id);
                }
            }
        }
        $this->confirmations[] = 'Content saved successfully';
    }

    private function uploadThemeContentImage($file)
    {
        $uploadDir = _PS_ROOT_DIR_ . '/themes/child_classic/assets/img/';
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = uniqid() . '.' . $ext;
        $targetFile = $uploadDir . $filename;

        if (move_uploaded_file($file['tmp_name'], $targetFile)) {
            // Return root-relative path including subdirectory
            return __PS_BASE_URI__ . 'themes/child_classic/assets/img/' . $filename;
        }
        return false;
    }

    private function getFieldsDefinition($page)
    {
        if ($page == 'home') {
            return [
                'hero' => [
                    'label' => 'Hero Section',
                    'fields' => [
                        'hero_slides' => [
                            'type' => 'repeater',
                            'label' => 'Slides',
                            'subfields' => [
                                'image' => ['type' => 'image', 'label' => 'Image URL'],
                                'title' => ['type' => 'text', 'label' => 'Title'],
                                'btn_text' => ['type' => 'text', 'label' => 'Button Text'],
                                'btn_link' => ['type' => 'text', 'label' => 'Button Link'],
                            ]
                        ]
                    ]
                ],
                'quality' => [
                    'label' => 'Quality Section',
                    'fields' => [
                        'quality_title' => ['type' => 'text', 'label' => 'Section Title'],
                        'quality_products' => [
                            'type' => 'repeater',
                            'label' => 'Manual Products (Fallback)',
                            'subfields' => [
                                'image' => ['type' => 'image', 'label' => 'Image'],
                                'title' => ['type' => 'text', 'label' => 'Title'],
                                'subtitle' => ['type' => 'text', 'label' => 'Subtitle'],
                                'desc' => ['type' => 'textarea', 'label' => 'Description'],
                                'btn_text' => ['type' => 'text', 'label' => 'Button Text'],
                                'btn_link' => ['type' => 'text', 'label' => 'Button Link'],
                            ]
                        ],
                        'selected_products' => [
                            'type' => 'multiselect',
                            'label' => 'Select Products',
                            'desc' => 'Select products to display in the Quality section. If selected, these will override the manual products above.',
                            'options' => $this->getProductsOptions((int) Tools::getValue('lang_id', $this->context->language->id))
                        ],
                    ]
                ],
                'ideas' => [
                    'label' => 'Ideas Section',
                    'fields' => [
                        'ideas_title' => ['type' => 'text', 'label' => 'Title'],
                        'ideas_subtitle' => ['type' => 'textarea', 'label' => 'Subtitle'],
                        'ideas_articles' => [
                            'type' => 'repeater',
                            'label' => 'Manual Articles (Fallback)',
                            'subfields' => [
                                'image' => ['type' => 'image', 'label' => 'Image'],
                                'tag' => ['type' => 'text', 'label' => 'Tag'],
                                'date' => ['type' => 'text', 'label' => 'Date'],
                                'title' => ['type' => 'text', 'label' => 'Title'],
                                'link' => ['type' => 'text', 'label' => 'Link'],
                            ]
                        ],
                        'selected_blog_posts' => [
                            'type' => 'multiselect',
                            'label' => 'Select Blog Posts',
                            'desc' => 'Select blog posts to display in the Ideas section. If selected, these will override the manual articles above.',
                            'options' => $this->getBlogPostsOptions((int) Tools::getValue('lang_id', $this->context->language->id))
                        ],
                        'ideas_btn_text' => ['type' => 'text', 'label' => 'Bottom Button Text'],
                        'ideas_btn_link' => ['type' => 'text', 'label' => 'Bottom Button Link'],
                    ]
                ],
                'project' => [
                    'label' => 'Project Section',
                    'fields' => [
                        'project_title' => ['type' => 'text', 'label' => 'Title'],
                        'project_text_1' => ['type' => 'textarea', 'label' => 'Text Paragraph 1'],
                        'project_text_2' => ['type' => 'textarea', 'label' => 'Text Paragraph 2'],
                        'project_btn_text' => ['type' => 'text', 'label' => 'Button Text'],
                        'project_btn_link' => ['type' => 'text', 'label' => 'Button Link'],
                        'project_mascot' => ['type' => 'image', 'label' => 'Mascot Image'],
                    ]
                ],
                'reviews' => [
                    'label' => 'Reviews Section',
                    'fields' => [
                        'reviews_title' => ['type' => 'text', 'label' => 'Title'],
                        'reviews_list' => [
                            'type' => 'repeater',
                            'label' => 'Testimonials',
                            'subfields' => [
                                'quote' => ['type' => 'textarea', 'label' => 'Quote'],
                                'image' => ['type' => 'image', 'label' => 'User Image'],
                                'name' => ['type' => 'text', 'label' => 'Name'],
                                'stars' => ['type' => 'text', 'label' => 'Stars (e.g. ★★★★★)'],
                            ]
                        ]
                    ]
                ],
                'features' => [
                    'label' => 'Features Section',
                    'fields' => [
                        'features_list' => [
                            'type' => 'repeater',
                            'label' => 'Features',
                            'subfields' => [
                                'icon' => ['type' => 'image', 'label' => 'Icon Image'],
                                'title' => ['type' => 'text', 'label' => 'Title'],
                                'text' => ['type' => 'textarea', 'label' => 'Text'],
                                'link' => ['type' => 'text', 'label' => 'Link URL'],
                            ]
                        ]
                    ]
                ],
                'gallery' => [
                    'label' => 'Gallery Section',
                    'fields' => [
                        'gallery_title' => ['type' => 'text', 'label' => 'Title'],
                        'gallery_items' => [
                            'type' => 'repeater',
                            'label' => 'Manual Gallery Items (Fallback)',
                            'subfields' => [
                                'icon' => ['type' => 'text', 'label' => 'Icon Class'],
                                'title' => ['type' => 'text', 'label' => 'Title'],
                                'subtitle' => ['type' => 'text', 'label' => 'Subtitle'],
                                'link' => ['type' => 'text', 'label' => 'Link'],
                                'gradient' => ['type' => 'text', 'label' => 'Gradient CSS (optional)'],
                            ]
                        ],
                        'selected_gallery_products' => [
                            'type' => 'multiselect',
                            'label' => 'Select Products for Gallery',
                            'desc' => 'If selected, these products will be shown in the gallery.',
                            'options' => $this->getProductsOptions((int) Tools::getValue('lang_id', $this->context->language->id))
                        ],
                        'selected_gallery_categories' => [
                            'type' => 'multiselect',
                            'label' => 'Select Categories for Gallery',
                            'desc' => 'If selected, these categories will be shown in the gallery.',
                            'options' => $this->getCategoriesOptions((int) Tools::getValue('lang_id', $this->context->language->id))
                        ],
                    ]
                ],
                'partners' => [
                    'label' => 'Partners Section',
                    'fields' => [
                        'partners_title' => ['type' => 'text', 'label' => 'Title'],
                        'partners_list' => [
                            'type' => 'repeater',
                            'label' => 'Manual Partners (Fallback)',
                            'subfields' => [
                                'name' => ['type' => 'text', 'label' => 'Name/Logo Text'],
                                'link' => ['type' => 'text', 'label' => 'Link URL'],
                            ]
                        ],
                        'selected_brands' => [
                            'type' => 'multiselect',
                            'label' => 'Select Brands',
                            'desc' => 'Select brands to display in the Partners section. If selected, these will override the manual partners above.',
                            'options' => $this->getBrandsOptions((int) Tools::getValue('lang_id', $this->context->language->id))
                        ],
                    ]
                ]
            ];
        } elseif ($page == 'header') {
            return [
                'topbar' => [
                    'label' => 'Top Bar',
                    'fields' => [
                        'phone_number' => ['type' => 'text', 'label' => 'Phone Number'],
                        'email' => ['type' => 'text', 'label' => 'Email'],
                    ]
                ]
            ];
        } elseif ($page == 'footer') {
            return [
                'info' => [
                    'label' => 'Footer Info',
                    'fields' => [
                        'footer_logo' => ['type' => 'image', 'label' => 'Footer Logo'],
                        'footer_desc' => ['type' => 'textarea', 'label' => 'Description'],
                        'footer_address' => ['type' => 'textarea', 'label' => 'Address/Contact HTML'],
                        'footer_copyright' => ['type' => 'text', 'label' => 'Copyright Text'],
                    ]
                ],
                'column_1' => [
                    'label' => 'Footer Column 1 (Links)',
                    'fields' => [
                        'footer_col_1_title' => ['type' => 'text', 'label' => 'Column Title'],
                        'footer_col_1_links' => [
                            'type' => 'repeater',
                            'label' => 'Links',
                            'subfields' => [
                                'text' => ['type' => 'text', 'label' => 'Link Text'],
                                'url' => ['type' => 'text', 'label' => 'Link URL'],
                            ]
                        ]
                    ]
                ],
                'column_2' => [
                    'label' => 'Footer Column 2 (Links)',
                    'fields' => [
                        'footer_col_2_title' => ['type' => 'text', 'label' => 'Column Title'],
                        'footer_col_2_links' => [
                            'type' => 'repeater',
                            'label' => 'Links',
                            'subfields' => [
                                'text' => ['type' => 'text', 'label' => 'Link Text'],
                                'url' => ['type' => 'text', 'label' => 'Link URL'],
                            ]
                        ]
                    ]
                ],
                'column_3' => [
                    'label' => 'Footer Column 3 (Service & Social)',
                    'fields' => [
                        'footer_col_3_title' => ['type' => 'text', 'label' => 'Service Title (e.g. A Votre Service)'],
                        'footer_col_3_desc' => ['type' => 'textarea', 'label' => 'Service Description (e.g. Opening Hours)'],
                        'footer_social_title' => ['type' => 'text', 'label' => 'Social Title (e.g. Suivez Nous...)'],
                        'footer_social_links' => [
                            'type' => 'repeater',
                            'label' => 'Social Icons',
                            'subfields' => [
                                'icon_class' => ['type' => 'text', 'label' => 'Icon Class (e.g., fab fa-whatsapp)'],
                                'url' => ['type' => 'text', 'label' => 'Link URL'],
                            ]
                        ]
                    ]
                ]
            ];
        } elseif ($page == 'category' || strpos($page, 'category_') === 0) {
            return [
                'banner' => [
                    'label' => 'Category Banner',
                    'fields' => [
                        'banner_image' => ['type' => 'image', 'label' => 'Custom Banner Image', 'desc' => 'Leave empty to use category cover image'],
                    ]
                ]
            ];
        } elseif ($page == 'blog') {
            return [
                'banner' => [
                    'label' => 'Blog Banner',
                    'fields' => [
                        'blog_banner_title' => ['type' => 'text', 'label' => 'Banner Title'],
                        'blog_banner_image' => ['type' => 'image', 'label' => 'Banner Image'],
                    ]
                ]
            ];
        } elseif ($page == 'contact') {
            return [
                'banner' => [
                    'label' => 'Contact Banner',
                    'fields' => [
                        'contact_banner_title' => ['type' => 'text', 'label' => 'Banner Title'],
                        'contact_banner_image' => ['type' => 'image', 'label' => 'Banner Image'],
                    ]
                ],
                'info' => [
                    'label' => 'Contact Information',
                    'fields' => [
                        'contact_title' => ['type' => 'text', 'label' => 'Contact Title'],
                        'contact_phone_1' => ['type' => 'text', 'label' => 'Phone 1'],
                        'contact_phone_2' => ['type' => 'text', 'label' => 'Phone 2'],
                        'contact_email' => ['type' => 'text', 'label' => 'Email'],
                        'contact_address_1' => ['type' => 'textarea', 'label' => 'Address 1'],
                        'contact_address_2' => ['type' => 'textarea', 'label' => 'Address 2'],
                    ]
                ],
                'social' => [
                    'label' => 'Social Media',
                    'fields' => [
                        'social_title' => ['type' => 'text', 'label' => 'Social Title'],
                        'social_facebook' => ['type' => 'text', 'label' => 'Facebook Link'],
                        'social_instagram' => ['type' => 'text', 'label' => 'Instagram Link'],
                        'social_youtube' => ['type' => 'text', 'label' => 'Youtube Link'],
                        'social_tiktok' => ['type' => 'text', 'label' => 'Tiktok Link'],
                    ]
                ],
                'maps' => [
                    'label' => 'Maps',
                    'fields' => [
                        'map_1_url' => ['type' => 'text', 'label' => 'Map 1 URL (Iframe src)'],
                        'map_1_link' => ['type' => 'text', 'label' => 'Map 1 View Larger Link'],
                        'map_2_url' => ['type' => 'text', 'label' => 'Map 2 URL (Iframe src)'],
                        'map_2_link' => ['type' => 'text', 'label' => 'Map 2 View Larger Link'],
                    ]
                ],
            ];
        } elseif ($page == 'about') {
            return [
                'banner' => [
                    'label' => 'Banner Section',
                    'fields' => [
                        'about_banner_image' => ['type' => 'image', 'label' => 'Banner Background Image'],
                        'about_banner_title' => ['type' => 'text', 'label' => 'Banner Title'],
                    ]
                ],
                'main_content' => [
                    'label' => 'Main Content (About Block)',
                    'fields' => [
                        'about_main_title' => ['type' => 'text', 'label' => 'Main Title'],
                        'about_main_image' => ['type' => 'image', 'label' => 'Main Image'],
                        'about_main_desc_1' => ['type' => 'textarea', 'label' => 'Description Paragraph 1'],
                        'about_main_desc_2' => ['type' => 'textarea', 'label' => 'Description Paragraph 2'],
                    ]
                ],
                'counters' => [
                    'label' => 'Counters Section',
                    'fields' => [
                        'about_counters' => [
                            'type' => 'repeater',
                            'label' => 'Counters',
                            'subfields' => [
                                'image' => ['type' => 'image', 'label' => 'Icon/Image'],
                                'number' => ['type' => 'text', 'label' => 'Number (e.g. 1997)'],
                                'text' => ['type' => 'text', 'label' => 'Label'],
                            ]
                        ]
                    ]
                ],
                'solutions' => [
                    'label' => 'Solutions Section',
                    'fields' => [
                        'about_solutions' => [
                            'type' => 'repeater',
                            'label' => 'Solutions List',
                            'subfields' => [
                                'image' => ['type' => 'image', 'label' => 'Image'],
                                'title' => ['type' => 'text', 'label' => 'Title'],
                                'desc' => ['type' => 'textarea', 'label' => 'Description'],
                            ]
                        ]
                    ]
                ],
                'mission' => [
                    'label' => 'Mission Section',
                    'fields' => [
                        'about_mission_image' => ['type' => 'image', 'label' => 'Mission Image'],
                        'about_mission_title' => ['type' => 'text', 'label' => 'Mission Title'],
                        'about_mission_desc' => ['type' => 'textarea', 'label' => 'Mission Description'],
                    ]
                ],
                'features' => [
                    'label' => 'Features Section',
                    'fields' => [
                        'about_features' => [
                            'type' => 'repeater',
                            'label' => 'Features Checkmarks',
                            'subfields' => [
                                'icon' => ['type' => 'image', 'label' => 'Icon Image'],
                                'title' => ['type' => 'text', 'label' => 'Title'],
                                'desc' => ['type' => 'textarea', 'label' => 'Description'],
                                'note' => ['type' => 'text', 'label' => 'Note (Optional, e.g. for Warranty)'],
                            ]
                        ]
                    ]
                ],
                // ADD THIS NEW PARTNERS SECTION FOR ABOUT PAGE
                'partners' => [
                    'label' => 'Partners Section',
                    'fields' => [
                        'about_partners_title' => ['type' => 'text', 'label' => 'Title', 'default' => 'Our Partners'],
                        'about_partners_list' => [
                            'type' => 'repeater',
                            'label' => 'Partners List',
                            'subfields' => [
                                'image' => ['type' => 'image', 'label' => 'Logo Image'],
                                'name' => ['type' => 'text', 'label' => 'Partner Name'],
                                'link' => ['type' => 'text', 'label' => 'Link URL'],
                            ]
                        ],
                        'about_selected_brands' => [
                            'type' => 'multiselect',
                            'label' => 'Select Brands (Override)',
                            'desc' => 'Select brands to display instead of manual partners above.',
                            'options' => $this->getBrandsOptions((int) Tools::getValue('lang_id', $this->context->language->id))
                        ],
                    ]
                ]
            ];
        }
        return [];
    }

    private function getBlogPostsOptions($id_lang)
    {
        $options = [];
        if (Module::isEnabled('ets_blog')) {
            $sql = 'SELECT p.id_post, pl.title 
                    FROM ' . _DB_PREFIX_ . 'ets_blog_post p 
                    LEFT JOIN ' . _DB_PREFIX_ . 'ets_blog_post_lang pl ON (p.id_post = pl.id_post AND pl.id_lang = ' . (int) $id_lang . ')
                    WHERE p.enabled = 1
                    ORDER BY p.id_post DESC';
            $posts = Db::getInstance()->executeS($sql);
            if ($posts) {
                foreach ($posts as $post) {
                    $options[$post['id_post']] = '#' . $post['id_post'] . ' - ' . $post['title'];
                }
            }
        }
        return $options;
    }

    private function getBrandsOptions($id_lang)
    {
        $options = [];
        $brands = Manufacturer::getManufacturers(false, $id_lang, true);
        if ($brands) {
            foreach ($brands as $brand) {
                $options[$brand['id_manufacturer']] = '#' . $brand['id_manufacturer'] . ' - ' . $brand['name'];
            }
        }
        return $options;
    }

    private function getProductsOptions($id_lang)
    {
        $options = [];
        $products = Product::getProducts($id_lang, 0, 0, 'id_product', 'DESC');
        if ($products) {
            foreach ($products as $product) {
                $options[$product['id_product']] = '#' . $product['id_product'] . ' - ' . $product['name'];
            }
        }
        return $options;
    }

    private function getCategoriesOptions($id_lang)
    {
        $options = [];
        $categories = Category::getCategories($id_lang, true, false);
        if ($categories) {
            foreach ($categories as $cat) {
                $indent = max(0, ($cat['level_depth'] - 1) * 2);
                $options[$cat['id_category']] = str_repeat('-', $indent) . ' #' . $cat['id_category'] . ' - ' . $cat['name'];
            }
        }
        return $options;
    }

    private function getCustomJs()
    {
        return '<script>
        $(document).ready(function() {
            $(".add-repeater-item").click(function() {
                var container = $(this).closest(".repeater-container");
                var key = container.data("key");
                var template = container.find(".repeater-template").html();
                var newIndex = container.find(".repeater-items .repeater-item").length; // This counts template too if not careful, but template is hidden
                // Better index calculation
                newIndex = new Date().getTime(); // Unique ID
                
                var newItem = template.replace(/TEMPLATE_INDEX/g, newIndex);
                container.find(".repeater-items").append(newItem);
            });

            $(document).on("click", ".remove-repeater-item", function() {
                $(this).closest(".repeater-item").remove();
            });
        });
        </script>';
    }
}