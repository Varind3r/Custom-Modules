<?php
/**
 * Admin Controller for Theme Content Manager
 * 
 * This controller handles the theme options sidebar and content management
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class AdminThemeContentController extends ModuleAdminController
{
    public function __construct()
    {
        // Set module for ModuleAdminController
        $this->module = Module::getInstanceByName('themecontentmanager');
        
        $this->bootstrap = true;
        $this->display = 'view';
        $this->meta_title = $this->l('Theme Content Manager');
        
        parent::__construct();
        
        if (!$this->module || !$this->module->id) {
            Tools::redirectAdmin($this->context->link->getAdminLink('AdminModules'));
        }
    }

    public function initContent()
    {
        parent::initContent();

        $this->context->smarty->assign(array(
            'content' => $this->renderView(),
        ));
    }

    public function renderView()
    {
        if (!$this->module) {
            return $this->l('Module not found');
        }
        
        $module = $this->module;
        
        // Get all pages
        $pages = $this->getAvailablePages();
        
        // Get current page identifier
        $page_identifier = Tools::getValue('page', 'home');
        
        // Get all content for current page
        $page_content = $module->getAllPageContent($page_identifier);
        
        // Get all fields for current page
        $fields = $this->getPageFields($page_identifier);
        
        $this->context->smarty->assign(array(
            'pages' => $pages,
            'current_page' => $page_identifier,
            'page_content' => $page_content,
            'fields' => $fields,
            'languages' => Language::getLanguages(),
            'current_lang' => $this->context->language->id,
            'ajax_url' => $this->context->link->getAdminLink('AdminThemeContent'),
            'token' => Tools::getAdminTokenLite('AdminThemeContent'),
        ));

        $template_path = _PS_MODULE_DIR_ . 'themecontentmanager/views/templates/admin/theme_options.tpl';
        
        if (!file_exists($template_path)) {
            return '<div class="alert alert-danger">Template file not found: ' . $template_path . '</div>';
        }

        return $this->context->smarty->fetch($template_path);
    }

    public function postProcess()
    {
        if (Tools::isSubmit('deleteContent')) {
            $this->deleteContent();
        }
        
        parent::postProcess();
    }

    public function ajaxProcessSaveContent()
    {
        // Security check
        if (!Tools::getValue('ajax') || !$this->module) {
            die(json_encode(array('success' => false, 'message' => 'Invalid request')));
        }
        
        $module = $this->module;
        
        $page_identifier = Tools::getValue('page_identifier');
        $field_key = Tools::getValue('field_key');
        $field_value = Tools::getValue('field_value');
        $field_type = Tools::getValue('field_type', 'text');
        $lang_id = Tools::getValue('lang_id', $this->context->language->id);
        $active = Tools::getValue('active', 1);

        // Use module's saveContent method to avoid code duplication
        $result = $module->saveContent($page_identifier, $field_key, $field_value, $field_type, $lang_id, $active);

        die(json_encode(array(
            'success' => $result,
            'message' => $result ? $this->l('Content saved successfully') : $this->l('Error saving content')
        )));
    }

    public function ajaxProcessGetContent()
    {
        $module = Module::getInstanceByName('themecontentmanager');
        
        $page_identifier = Tools::getValue('page_identifier');
        $field_key = Tools::getValue('field_key');
        $lang_id = Tools::getValue('lang_id', $this->context->language->id);

        $content = $module->getContentValue($page_identifier, $field_key, $lang_id);

        die(json_encode(array(
            'success' => true,
            'content' => $content
        )));
    }

    public function ajaxProcessGetPageContent()
    {
        // Security check
        if (!Tools::getValue('ajax') || !$this->module) {
            die(json_encode(array('success' => false, 'message' => 'Invalid request')));
        }
        
        $module = $this->module;
        
        $page_identifier = Tools::getValue('page_identifier');
        $lang_id = Tools::getValue('lang_id', $this->context->language->id);

        $content = $module->getAllPageContent($page_identifier, $lang_id);

        die(json_encode(array(
            'success' => true,
            'content' => $content
        )));
    }


    private function deleteContent()
    {
        $id_content = Tools::getValue('id_content');
        if ($id_content) {
            $sql = 'DELETE FROM `' . _DB_PREFIX_ . 'theme_content` WHERE id_content = ' . (int)$id_content;
            Db::getInstance()->execute($sql);
        }
    }

    private function getAvailablePages()
    {
        return array(
            'home' => $this->l('Home Page'),
            'product' => $this->l('Product Page'),
            'category' => $this->l('Category Page'),
            'contact' => $this->l('Contact Page'),
            'cms' => $this->l('CMS Pages'),
            'cart' => $this->l('Shopping Cart'),
            'checkout' => $this->l('Checkout'),
            'my-account' => $this->l('My Account'),
            'footer' => $this->l('Footer'),
            'header' => $this->l('Header'),
        );
    }

    private function getPageFields($page_identifier)
    {
        // Define default fields for each page type
        $fields = array(
            'home' => array(
                array('key' => 'hero_title', 'label' => 'Hero Title', 'type' => 'text'),
                array('key' => 'hero_subtitle', 'label' => 'Hero Subtitle', 'type' => 'textarea'),
                array('key' => 'hero_image', 'label' => 'Hero Image URL', 'type' => 'image'),
                array('key' => 'hero_button_text', 'label' => 'Hero Button Text', 'type' => 'text'),
                array('key' => 'hero_button_url', 'label' => 'Hero Button URL', 'type' => 'url'),
                array('key' => 'featured_content', 'label' => 'Featured Content', 'type' => 'html'),
            ),
            'product' => array(
                array('key' => 'product_banner', 'label' => 'Product Banner', 'type' => 'html'),
                array('key' => 'product_info', 'label' => 'Product Info', 'type' => 'html'),
            ),
            'category' => array(
                array('key' => 'category_banner', 'label' => 'Category Banner', 'type' => 'html'),
                array('key' => 'category_description', 'label' => 'Category Description', 'type' => 'html'),
            ),
            'footer' => array(
                array('key' => 'footer_text', 'label' => 'Footer Text', 'type' => 'html'),
                array('key' => 'footer_copyright', 'label' => 'Copyright Text', 'type' => 'text'),
            ),
            'header' => array(
                array('key' => 'header_banner', 'label' => 'Header Banner', 'type' => 'html'),
                array('key' => 'header_notice', 'label' => 'Header Notice', 'type' => 'text'),
            ),
        );

        return isset($fields[$page_identifier]) ? $fields[$page_identifier] : array();
    }
}

