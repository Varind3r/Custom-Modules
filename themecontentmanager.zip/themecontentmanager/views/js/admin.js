/**
 * Theme Content Manager - Admin JavaScript
 */

$(document).ready(function() {
    var currentPage = $('#page_identifier').val();
    var currentLang = $('#lang_id').val();
    var ajaxUrl = $('#ajax_url').val() || window.location.href;

    // Page navigation
    $('.page-link').on('click', function(e) {
        e.preventDefault();
        var page = $(this).data('page');
        loadPageContent(page);
    });

    // Language change
    $('#lang_id').on('change', function() {
        currentLang = $(this).val();
        loadPageContent(currentPage);
    });

    // Auto-save on field change (with debounce)
    var saveTimeout;
    $('.content-field').on('input change', function() {
        clearTimeout(saveTimeout);
        var $field = $(this);
        
        saveTimeout = setTimeout(function() {
            saveField($field);
        }, 1000); // Save after 1 second of inactivity
    });

    // Save all button
    $('#save-all-content').on('click', function() {
        saveAllFields();
    });

    // Add custom field
    $('#add-custom-field').on('click', function() {
        addCustomField();
    });

    // Repeater field handlers
    $(document).on('click', '.repeater-add-row', function() {
        var $repeater = $(this).closest('.repeater-field');
        addRepeaterRow($repeater);
    });

    $(document).on('click', '.repeater-remove-row', function() {
        var $row = $(this).closest('.repeater-row');
        $row.fadeOut(300, function() {
            $(this).remove();
            updateRepeaterData($row.closest('.repeater-field'));
        });
    });

    // Image preview for image fields
    $(document).on('input', '.content-field[data-field-type="image"]', function() {
        var url = $(this).val();
        var $preview = $(this).siblings('.image-preview');
        
        if (url && isValidUrl(url)) {
            if ($preview.length === 0) {
                $preview = $('<div class="image-preview"></div>');
                $(this).after($preview);
            }
            $preview.html('<img src="' + url + '" alt="Preview" style="max-width: 200px; max-height: 200px;">');
        } else {
            $preview.remove();
        }
    });

    /**
     * Load content for a specific page
     */
    function loadPageContent(page) {
        currentPage = page;
        
        // Update active nav item
        $('.page-link').closest('li').removeClass('active');
        $('.page-link[data-page="' + page + '"]').closest('li').addClass('active');
        
        // Update page identifier
        $('#page_identifier').val(page);
        
        // Update page name
        var pageName = $('.page-link[data-page="' + page + '"]').text();
        $('#current-page-name').text(pageName);
        
        // Reload page content via AJAX
        $.ajax({
            url: ajaxUrl,
            type: 'POST',
            data: {
                ajax: true,
                action: 'getPageContent',
                page_identifier: page,
                lang_id: currentLang,
                token: getToken()
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    // Update fields with loaded content
                    if (response.content) {
                        $.each(response.content, function(key, value) {
                            var fieldValue = value.value || value;
                            var fieldType = value.type || 'text';
                            var $field = $('.content-field[data-field-key="' + key + '"]');
                            
                            if ($field.length) {
                                if (fieldType === 'repeater') {
                                    // Handle repeater field
                                    var $repeater = $('.repeater-field[data-field-key="' + key + '"]');
                                    if ($repeater.length) {
                                        try {
                                            var repeaterData = JSON.parse(fieldValue);
                                            $repeater.find('.repeater-rows').empty();
                                            repeaterData.forEach(function(row, index) {
                                                var rowHtml = createRepeaterRow(key, index, row);
                                                $repeater.find('.repeater-rows').append(rowHtml);
                                            });
                                            updateRepeaterData($repeater);
                                        } catch(e) {
                                            console.error('Error parsing repeater data:', e);
                                        }
                                    }
                                } else {
                                    $field.val(fieldValue);
                                }
                            }
                        });
                    }
                }
            },
            error: function() {
                showStatus('Error loading content', 'error');
            }
        });
    }

    /**
     * Save a single field
     */
    function saveField($field) {
        var fieldKey = $field.data('field-key');
        var fieldType = $field.data('field-type');
        var fieldValue = $field.val();
        
        if (!fieldKey) {
            return;
        }

        // For repeater fields, get the JSON data
        if (fieldType === 'repeater') {
            var $repeater = $field.closest('.repeater-field');
            var rows = [];
            $repeater.find('.repeater-row').each(function() {
                var rowData = {};
                $(this).find('.repeater-sub-field').each(function() {
                    var subKey = $(this).data('sub-key');
                    rowData[subKey] = $(this).val();
                });
                rows.push(rowData);
            });
            fieldValue = JSON.stringify(rows);
        }

        $.ajax({
            url: ajaxUrl,
            type: 'POST',
            data: {
                ajax: true,
                action: 'saveContent',
                page_identifier: currentPage,
                field_key: fieldKey,
                field_value: fieldValue,
                field_type: fieldType,
                lang_id: currentLang,
                active: 1,
                token: getToken()
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    showFieldStatus($field, 'saved');
                } else {
                    showFieldStatus($field, 'error');
                }
            },
            error: function() {
                showFieldStatus($field, 'error');
            }
        });
    }

    /**
     * Save all fields
     */
    function saveAllFields() {
        var $button = $('#save-all-content');
        var $status = $('#save-status');
        
        $button.prop('disabled', true);
        $status.html('<span class="loading"></span> Saving...').removeClass('success error');
        
        var fieldsToSave = [];
        $('.content-field').each(function() {
            var $field = $(this);
            var fieldKey = $field.data('field-key');
            
            if (fieldKey) {
                fieldsToSave.push({
                    key: fieldKey,
                    value: $field.val(),
                    type: $field.data('field-type')
                });
            }
        });

        var saved = 0;
        var total = fieldsToSave.length;
        
        if (total === 0) {
            $status.html('No fields to save').addClass('error');
            $button.prop('disabled', false);
            return;
        }

        fieldsToSave.forEach(function(field) {
            $.ajax({
                url: ajaxUrl,
                type: 'POST',
                data: {
                    ajax: true,
                    action: 'saveContent',
                    page_identifier: currentPage,
                    field_key: field.key,
                    field_value: field.value,
                    field_type: field.type,
                    lang_id: currentLang,
                    active: 1,
                    token: getToken()
                },
                dataType: 'json',
                success: function(response) {
                    saved++;
                    if (saved === total) {
                        $status.html('All content saved successfully!').addClass('success');
                        $button.prop('disabled', false);
                        
                        setTimeout(function() {
                            $status.fadeOut(function() {
                                $status.html('').show();
                            });
                        }, 3000);
                    }
                },
                error: function() {
                    saved++;
                    if (saved === total) {
                        $status.html('Error saving some content').addClass('error');
                        $button.prop('disabled', false);
                    }
                }
            });
        });
    }

    /**
     * Add custom field
     */
    function addCustomField() {
        var fieldKey = $('#custom_field_key').val().trim();
        var fieldLabel = $('#custom_field_label').val().trim();
        var fieldType = $('#custom_field_type').val();
        
        if (!fieldKey || !fieldLabel) {
            alert('Please enter both field key and label');
            return;
        }

        // Validate field key format
        if (!/^[a-z0-9_]+$/.test(fieldKey)) {
            alert('Field key must contain only lowercase letters, numbers, and underscores');
            return;
        }

        // Check if field already exists
        if ($('.content-field[data-field-key="' + fieldKey + '"]').length > 0) {
            alert('Field with this key already exists');
            return;
        }

        // Create field HTML
        var fieldHtml = createFieldHtml(fieldKey, fieldLabel, fieldType, '');
        
        // Add to fields container
        $('#content-fields').append(fieldHtml);
        
        // Initialize rich text editor if HTML type
        if (fieldType === 'html') {
            var $textarea = $('#field_' + fieldKey);
            if (typeof tinyMCE !== 'undefined') {
                tinyMCE.execCommand('mceAddControl', false, 'field_' + fieldKey);
            }
        }
        
        // For repeater fields, initialize the data
        if (fieldType === 'repeater') {
            var $repeater = $('.repeater-field[data-field-key="' + fieldKey + '"]');
            updateRepeaterData($repeater);
        }
        
        // Clear form
        $('#custom_field_key').val('');
        $('#custom_field_label').val('');
    }

    /**
     * Create field HTML
     */
    function createFieldHtml(key, label, type, value) {
        var inputHtml = '';
        
        if (type === 'text') {
            inputHtml = '<input type="text" class="form-control content-field" id="field_' + key + 
                       '" name="field_' + key + '" data-field-key="' + key + 
                       '" data-field-type="' + type + '" value="' + escapeHtml(value) + '">';
        } else if (type === 'textarea') {
            inputHtml = '<textarea class="form-control content-field" id="field_' + key + 
                       '" name="field_' + key + '" data-field-key="' + key + 
                       '" data-field-type="' + type + '" rows="5">' + escapeHtml(value) + '</textarea>';
        } else if (type === 'html') {
            inputHtml = '<textarea class="form-control content-field rte" id="field_' + key + 
                       '" name="field_' + key + '" data-field-key="' + key + 
                       '" data-field-type="' + type + '" rows="10">' + escapeHtml(value) + '</textarea>';
        } else if (type === 'image' || type === 'url') {
            inputHtml = '<input type="url" class="form-control content-field" id="field_' + key + 
                       '" name="field_' + key + '" data-field-key="' + key + 
                       '" data-field-type="' + type + '" value="' + escapeHtml(value) + 
                       '" placeholder="https://example.com/' + (type === 'image' ? 'image.jpg' : 'page') + '">';
        } else if (type === 'repeater') {
            // Repeater field structure
            var repeaterData = value ? JSON.parse(value) : [];
            inputHtml = createRepeaterFieldHtml(key, repeaterData);
        }

        var fieldClass = type === 'repeater' ? 'field-group repeater-field' : 'field-group';
        return '<div class="' + fieldClass + '" data-field-key="' + key + '" data-field-type="' + type + '">' +
               '<label for="field_' + key + '">' + escapeHtml(label) + 
               ' <span class="field-type-badge">' + type + '</span></label>' +
               inputHtml +
               '<small class="help-block">Field Key: <code>' + key + '</code></small>' +
               '</div>';
    }

    /**
     * Create repeater field HTML
     */
    function createRepeaterFieldHtml(key, repeaterData) {
        var html = '<div class="repeater-container" data-repeater-key="' + key + '">';
        html += '<div class="repeater-rows">';
        
        if (repeaterData && repeaterData.length > 0) {
            repeaterData.forEach(function(row, index) {
                html += createRepeaterRow(key, index, row);
            });
        } else {
            // Add one empty row by default
            html += createRepeaterRow(key, 0, {});
        }
        
        html += '</div>';
        html += '<button type="button" class="btn btn-success btn-sm repeater-add-row" style="margin-top: 10px;">';
        html += '<i class="icon-plus"></i> Add Row</button>';
        html += '</div>';
        
        return html;
    }

    /**
     * Create a single repeater row
     */
    function createRepeaterRow(repeaterKey, rowIndex, rowData) {
        var html = '<div class="repeater-row" data-row-index="' + rowIndex + '">';
        html += '<div class="panel panel-default" style="margin-bottom: 10px;">';
        html += '<div class="panel-heading" style="background: #f5f5f5;">';
        html += '<span class="repeater-row-label">Row ' + (rowIndex + 1) + '</span>';
        html += '<button type="button" class="btn btn-danger btn-xs pull-right repeater-remove-row">';
        html += '<i class="icon-trash"></i> Remove</button>';
        html += '</div>';
        html += '<div class="panel-body">';
        
        // Default sub-fields for repeater (can be customized)
        var subFields = [
            {key: 'title', label: 'Title', type: 'text'},
            {key: 'description', label: 'Description', type: 'textarea'},
            {key: 'image', label: 'Image URL', type: 'image'},
            {key: 'link', label: 'Link URL', type: 'url'}
        ];
        
        subFields.forEach(function(subField) {
            var subValue = rowData[subField.key] || '';
            html += '<div class="form-group" style="margin-bottom: 15px;">';
            html += '<label style="font-weight: normal; font-size: 12px;">' + subField.label + '</label>';
            
            if (subField.type === 'text' || subField.type === 'url' || subField.type === 'image') {
                html += '<input type="' + (subField.type === 'url' || subField.type === 'image' ? 'url' : 'text') + 
                       '" class="form-control repeater-sub-field" data-sub-key="' + subField.key + 
                       '" value="' + escapeHtml(subValue) + '" style="font-size: 13px;">';
            } else if (subField.type === 'textarea') {
                html += '<textarea class="form-control repeater-sub-field" data-sub-key="' + subField.key + 
                       '" rows="3" style="font-size: 13px;">' + escapeHtml(subValue) + '</textarea>';
            }
            
            html += '</div>';
        });
        
        html += '</div>';
        html += '</div>';
        html += '</div>';
        
        return html;
    }

    /**
     * Add a new row to repeater
     */
    function addRepeaterRow($repeater) {
        var repeaterKey = $repeater.data('field-key');
        var $rows = $repeater.find('.repeater-rows');
        var rowCount = $rows.find('.repeater-row').length;
        var newRow = createRepeaterRow(repeaterKey, rowCount, {});
        $rows.append(newRow);
        updateRepeaterData($repeater);
    }

    /**
     * Update repeater data (convert to JSON)
     */
    function updateRepeaterData($repeater) {
        var repeaterKey = $repeater.data('field-key');
        var rows = [];
        
        $repeater.find('.repeater-row').each(function() {
            var rowData = {};
            $(this).find('.repeater-sub-field').each(function() {
                var subKey = $(this).data('sub-key');
                rowData[subKey] = $(this).val();
            });
            rows.push(rowData);
        });
        
        // Store as hidden field or update the field value
        var jsonData = JSON.stringify(rows);
        var $hiddenField = $repeater.find('input[type="hidden"].repeater-data');
        if ($hiddenField.length === 0) {
            $repeater.append('<input type="hidden" class="repeater-data content-field" data-field-key="' + repeaterKey + 
                           '" data-field-type="repeater" value="' + escapeHtml(jsonData) + '">');
        } else {
            $hiddenField.val(jsonData);
        }
        
        // Auto-save
        var $field = $repeater.find('.repeater-data');
        if ($field.length) {
            saveField($field);
        }
    }

    // Auto-save repeater sub-fields
    $(document).on('input change', '.repeater-sub-field', function() {
        var $repeater = $(this).closest('.repeater-field');
        updateRepeaterData($repeater);
    });

    /**
     * Show field status
     */
    function showFieldStatus($field, status) {
        var $group = $field.closest('.field-group');
        $group.removeClass('saved error');
        
        if (status === 'saved') {
            $group.addClass('saved');
            setTimeout(function() {
                $group.removeClass('saved');
            }, 2000);
        } else {
            $group.addClass('error');
        }
    }

    /**
     * Show status message
     */
    function showStatus(message, type) {
        var $status = $('#save-status');
        $status.html(message).addClass(type);
        
        setTimeout(function() {
            $status.fadeOut(function() {
                $status.html('').show();
            });
        }, 3000);
    }

    /**
     * Get CSRF token
     */
    function getToken() {
        // Try to get token from hidden input field
        var token = $('#admin_token').val();
        if (!token) {
            // Fallback to form token
            token = $('input[name="token"]').val();
        }
        if (!token) {
            // Fallback to URL parameter
            var urlParams = new URLSearchParams(window.location.search);
            token = urlParams.get('token');
        }
        return token || '';
    }

    /**
     * Validate URL
     */
    function isValidUrl(string) {
        try {
            new URL(string);
            return true;
        } catch (_) {
            return false;
        }
    }

    /**
     * Escape HTML
     */
    function escapeHtml(text) {
        var map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, function(m) { return map[m]; });
    }
});

