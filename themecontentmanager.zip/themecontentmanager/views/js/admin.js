/**
 * Theme Content Manager - Admin JavaScript
 */

$(document).ready(function() {
    var currentPage = $('#page_identifier').val();
    var currentLang = $('#lang_id').val();
    var ajaxUrl = $('#ajax_url').val() || window.location.href;

    // Page navigation
    $('.page-link').on('click', function(e) {
        e.preventDefault();
        var page = $(this).data('page');
        loadPageContent(page);
    });

    // Language change
    $('#lang_id').on('change', function() {
        currentLang = $(this).val();
        loadPageContent(currentPage);
    });

    // Auto-save on field change (with debounce)
    var saveTimeout;
    $('.content-field').on('input change', function() {
        clearTimeout(saveTimeout);
        var $field = $(this);
        
        saveTimeout = setTimeout(function() {
            saveField($field);
        }, 1000); // Save after 1 second of inactivity
    });

    // Save all button
    $('#save-all-content').on('click', function() {
        saveAllFields();
    });

    // Add custom field
    $('#add-custom-field').on('click', function() {
        addCustomField();
    });

    // Image preview for image fields
    $(document).on('input', '.content-field[data-field-type="image"]', function() {
        var url = $(this).val();
        var $preview = $(this).siblings('.image-preview');
        
        if (url && isValidUrl(url)) {
            if ($preview.length === 0) {
                $preview = $('<div class="image-preview"></div>');
                $(this).after($preview);
            }
            $preview.html('<img src="' + url + '" alt="Preview" style="max-width: 200px; max-height: 200px;">');
        } else {
            $preview.remove();
        }
    });

    /**
     * Load content for a specific page
     */
    function loadPageContent(page) {
        currentPage = page;
        
        // Update active nav item
        $('.page-link').closest('li').removeClass('active');
        $('.page-link[data-page="' + page + '"]').closest('li').addClass('active');
        
        // Update page identifier
        $('#page_identifier').val(page);
        
        // Update page name
        var pageName = $('.page-link[data-page="' + page + '"]').text();
        $('#current-page-name').text(pageName);
        
        // Reload page content via AJAX
        $.ajax({
            url: ajaxUrl,
            type: 'POST',
            data: {
                ajax: true,
                action: 'getPageContent',
                page_identifier: page,
                lang_id: currentLang,
                token: getToken()
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    // Update fields with loaded content
                    if (response.content) {
                        $.each(response.content, function(key, value) {
                            var $field = $('.content-field[data-field-key="' + key + '"]');
                            if ($field.length) {
                                $field.val(value.value || value);
                            }
                        });
                    }
                }
            },
            error: function() {
                showStatus('Error loading content', 'error');
            }
        });
    }

    /**
     * Save a single field
     */
    function saveField($field) {
        var fieldKey = $field.data('field-key');
        var fieldType = $field.data('field-type');
        var fieldValue = $field.val();
        
        if (!fieldKey) {
            return;
        }

        $.ajax({
            url: ajaxUrl,
            type: 'POST',
            data: {
                ajax: true,
                action: 'saveContent',
                page_identifier: currentPage,
                field_key: fieldKey,
                field_value: fieldValue,
                field_type: fieldType,
                lang_id: currentLang,
                active: 1,
                token: getToken()
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    showFieldStatus($field, 'saved');
                } else {
                    showFieldStatus($field, 'error');
                }
            },
            error: function() {
                showFieldStatus($field, 'error');
            }
        });
    }

    /**
     * Save all fields
     */
    function saveAllFields() {
        var $button = $('#save-all-content');
        var $status = $('#save-status');
        
        $button.prop('disabled', true);
        $status.html('<span class="loading"></span> Saving...').removeClass('success error');
        
        var fieldsToSave = [];
        $('.content-field').each(function() {
            var $field = $(this);
            var fieldKey = $field.data('field-key');
            
            if (fieldKey) {
                fieldsToSave.push({
                    key: fieldKey,
                    value: $field.val(),
                    type: $field.data('field-type')
                });
            }
        });

        var saved = 0;
        var total = fieldsToSave.length;
        
        if (total === 0) {
            $status.html('No fields to save').addClass('error');
            $button.prop('disabled', false);
            return;
        }

        fieldsToSave.forEach(function(field) {
            $.ajax({
                url: ajaxUrl,
                type: 'POST',
                data: {
                    ajax: true,
                    action: 'saveContent',
                    page_identifier: currentPage,
                    field_key: field.key,
                    field_value: field.value,
                    field_type: field.type,
                    lang_id: currentLang,
                    active: 1,
                    token: getToken()
                },
                dataType: 'json',
                success: function(response) {
                    saved++;
                    if (saved === total) {
                        $status.html('All content saved successfully!').addClass('success');
                        $button.prop('disabled', false);
                        
                        setTimeout(function() {
                            $status.fadeOut(function() {
                                $status.html('').show();
                            });
                        }, 3000);
                    }
                },
                error: function() {
                    saved++;
                    if (saved === total) {
                        $status.html('Error saving some content').addClass('error');
                        $button.prop('disabled', false);
                    }
                }
            });
        });
    }

    /**
     * Add custom field
     */
    function addCustomField() {
        var fieldKey = $('#custom_field_key').val().trim();
        var fieldLabel = $('#custom_field_label').val().trim();
        var fieldType = $('#custom_field_type').val();
        
        if (!fieldKey || !fieldLabel) {
            alert('Please enter both field key and label');
            return;
        }

        // Validate field key format
        if (!/^[a-z0-9_]+$/.test(fieldKey)) {
            alert('Field key must contain only lowercase letters, numbers, and underscores');
            return;
        }

        // Check if field already exists
        if ($('.content-field[data-field-key="' + fieldKey + '"]').length > 0) {
            alert('Field with this key already exists');
            return;
        }

        // Create field HTML
        var fieldHtml = createFieldHtml(fieldKey, fieldLabel, fieldType, '');
        
        // Add to fields container
        $('#content-fields').append(fieldHtml);
        
        // Initialize rich text editor if HTML type
        if (fieldType === 'html') {
            var $textarea = $('#field_' + fieldKey);
            if (typeof tinyMCE !== 'undefined') {
                tinyMCE.execCommand('mceAddControl', false, 'field_' + fieldKey);
            }
        }
        
        // Clear form
        $('#custom_field_key').val('');
        $('#custom_field_label').val('');
    }

    /**
     * Create field HTML
     */
    function createFieldHtml(key, label, type, value) {
        var inputHtml = '';
        
        if (type === 'text') {
            inputHtml = '<input type="text" class="form-control content-field" id="field_' + key + 
                       '" name="field_' + key + '" data-field-key="' + key + 
                       '" data-field-type="' + type + '" value="' + escapeHtml(value) + '">';
        } else if (type === 'textarea') {
            inputHtml = '<textarea class="form-control content-field" id="field_' + key + 
                       '" name="field_' + key + '" data-field-key="' + key + 
                       '" data-field-type="' + type + '" rows="5">' + escapeHtml(value) + '</textarea>';
        } else if (type === 'html') {
            inputHtml = '<textarea class="form-control content-field rte" id="field_' + key + 
                       '" name="field_' + key + '" data-field-key="' + key + 
                       '" data-field-type="' + type + '" rows="10">' + escapeHtml(value) + '</textarea>';
        } else if (type === 'image' || type === 'url') {
            inputHtml = '<input type="url" class="form-control content-field" id="field_' + key + 
                       '" name="field_' + key + '" data-field-key="' + key + 
                       '" data-field-type="' + type + '" value="' + escapeHtml(value) + 
                       '" placeholder="https://example.com/' + (type === 'image' ? 'image.jpg' : 'page') + '">';
        }

        return '<div class="form-group field-group" data-field-key="' + key + '">' +
               '<label for="field_' + key + '">' + escapeHtml(label) + 
               ' <span class="field-type-badge">' + type + '</span></label>' +
               inputHtml +
               '<small class="help-block">Field Key: <code>' + key + '</code></small>' +
               '</div>';
    }

    /**
     * Show field status
     */
    function showFieldStatus($field, status) {
        var $group = $field.closest('.field-group');
        $group.removeClass('saved error');
        
        if (status === 'saved') {
            $group.addClass('saved');
            setTimeout(function() {
                $group.removeClass('saved');
            }, 2000);
        } else {
            $group.addClass('error');
        }
    }

    /**
     * Show status message
     */
    function showStatus(message, type) {
        var $status = $('#save-status');
        $status.html(message).addClass(type);
        
        setTimeout(function() {
            $status.fadeOut(function() {
                $status.html('').show();
            });
        }, 3000);
    }

    /**
     * Get CSRF token
     */
    function getToken() {
        // Try to get token from hidden input field
        var token = $('#admin_token').val();
        if (!token) {
            // Fallback to form token
            token = $('input[name="token"]').val();
        }
        if (!token) {
            // Fallback to URL parameter
            var urlParams = new URLSearchParams(window.location.search);
            token = urlParams.get('token');
        }
        return token || '';
    }

    /**
     * Validate URL
     */
    function isValidUrl(string) {
        try {
            new URL(string);
            return true;
        } catch (_) {
            return false;
        }
    }

    /**
     * Escape HTML
     */
    function escapeHtml(text) {
        var map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, function(m) { return map[m]; });
    }
});

