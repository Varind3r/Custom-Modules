# PrestaShop Module ZIP Creator
# This script renames the folder and creates a proper ZIP file

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "PrestaShop Module ZIP Creator" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

$currentDir = Get-Location
$parentDir = Split-Path -Parent $currentDir
$moduleName = "themecontentmanager"
$zipFileName = "$moduleName.zip"

Write-Host "Current folder: $currentDir" -ForegroundColor Yellow
Write-Host "Module name: $moduleName" -ForegroundColor Yellow
Write-Host ""

# Check if we're in the right folder
if (Test-Path "themecontentmanager.php") {
    Write-Host "✓ Found module files" -ForegroundColor Green
    
    # Create temporary folder structure
    $tempPath = Join-Path $parentDir "temp_$moduleName"
    $modulePath = Join-Path $tempPath $moduleName
    
    if (Test-Path $tempPath) {
        Remove-Item $tempPath -Recurse -Force
    }
    
    Write-Host "Creating proper folder structure..." -ForegroundColor Yellow
    New-Item -ItemType Directory -Path $modulePath -Force | Out-Null
    
    # Copy all files except this script
    Write-Host "Copying files..." -ForegroundColor Yellow
    Get-ChildItem -Path $currentDir -Exclude "*.ps1","*.bat","*.md","*.txt" | 
        Copy-Item -Destination $modulePath -Recurse -Force
    
    # Also copy important docs
    Copy-Item "README.md" -Destination $modulePath -ErrorAction SilentlyContinue
    Copy-Item "INSTALLATION.txt" -Destination $modulePath -ErrorAction SilentlyContinue
    
    # Create ZIP file
    Write-Host "Creating ZIP file..." -ForegroundColor Yellow
    $zipPath = Join-Path $parentDir $zipFileName
    
    if (Test-Path $zipPath) {
        Remove-Item $zipPath -Force
    }
    
    Compress-Archive -Path $modulePath -DestinationPath $zipPath -Force
    
    # Clean up temp folder
    Remove-Item $tempPath -Recurse -Force
    
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Green
    Write-Host "SUCCESS! ZIP file created!" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "ZIP Location: $zipPath" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Next steps:" -ForegroundColor Yellow
    Write-Host "1. Go to PrestaShop Back Office" -ForegroundColor White
    Write-Host "2. Navigate to: Modules > Module Manager" -ForegroundColor White
    Write-Host "3. Click: 'Upload a module'" -ForegroundColor White
    Write-Host "4. Select: $zipFileName" -ForegroundColor White
    Write-Host "5. Click: 'Upload this module'" -ForegroundColor White
    Write-Host ""
    
} else {
    Write-Host "ERROR: themecontentmanager.php not found!" -ForegroundColor Red
    Write-Host "Make sure you're running this script from the module folder." -ForegroundColor Red
}

Write-Host "Press any key to exit..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

