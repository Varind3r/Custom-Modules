<?php
/**
 * Theme Content Manager Module for PrestaShop 1.7+
 * 
 * File location: modules/themecontentmanager/themecontentmanager.php
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class ThemeContentManager extends Module
{
    public function __construct()
    {
        $this->name = 'themecontentmanager';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'Merlin';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = array('min' => '1.7', 'max' => _PS_VERSION_);
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Theme Content Manager');
        $this->description = $this->l('Manage dynamic content for all pages');
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
    }

    /**
     * Install the module
     */
    public function install()
    {
        return parent::install() &&
            $this->installDB() &&
            $this->registerHook('displayHeader') &&
            $this->registerHook('displayHome') &&
            $this->registerHook('actionAdminControllerSetMedia');
    }

    /**
     * Uninstall the module
     */
    public function uninstall()
    {
        return $this->uninstallDB() &&
            parent::uninstall();
    }

    /**
     * Install database tables
     */
    private function installDB()
    {
        $sql = '
        
        CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'theme_content` (
            `id_content` int(11) NOT NULL AUTO_INCREMENT,
            `page_identifier` varchar(255) NOT NULL,
            `field_key` varchar(255) NOT NULL,
            `field_value` longtext,
            `field_type` varchar(50) DEFAULT "text",
            `lang_id` int(11) DEFAULT NULL,
            `shop_id` int(11) DEFAULT NULL,
            `active` tinyint(1) DEFAULT 1,
            `date_add` datetime NOT NULL,
            `date_upd` datetime NOT NULL,
            PRIMARY KEY (`id_content`),
            UNIQUE KEY `unique_content` (`page_identifier`, `field_key`, `lang_id`, `shop_id`),
            KEY `page_identifier` (`page_identifier`),
            KEY `field_key` (`field_key`),
            KEY `lang_id` (`lang_id`),
            KEY `shop_id` (`shop_id`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';

        return Db::getInstance()->execute($sql);
    }

    /**
     * Uninstall database tables
     */
    private function uninstallDB()
    {
        $sql = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'theme_content`';
        return Db::getInstance()->execute($sql);
    }

    /**
     * Module configuration page - Redirects to admin controller
     */
    public function getContent()
    {
        Tools::redirectAdmin($this->context->link->getAdminLink('AdminThemeContent'));
    }

    /**
     * Save content to database
     */
    public function saveContent($page_identifier, $field_key, $field_value, $field_type, $lang_id = null, $active = 1)
    {
        // Validate inputs
        if (empty($page_identifier) || !Validate::isGenericName($page_identifier)) {
            return false;
        }
        
        if (empty($field_key) || !Validate::isGenericName($field_key)) {
            return false;
        }
        
        if (!in_array($field_type, array('text', 'textarea', 'html', 'image', 'url', 'repeater'))) {
            return false;
        }
        
        $shop_id = $this->context->shop->id;
        $lang_id = $lang_id ? (int)$lang_id : $this->context->language->id;
        $active = (int)$active;

        // Check if content already exists
        $sql = 'SELECT id_content FROM `' . _DB_PREFIX_ . 'theme_content`
                WHERE page_identifier = "' . pSQL($page_identifier) . '"
                AND field_key = "' . pSQL($field_key) . '"
                AND lang_id = ' . (int)$lang_id . '
                AND shop_id = ' . (int)$shop_id;

        $existing = Db::getInstance()->getRow($sql);

        if ($existing) {
            // Update existing
            $sql = 'UPDATE `' . _DB_PREFIX_ . 'theme_content`
                    SET field_value = "' . pSQL($field_value, true) . '",
                        field_type = "' . pSQL($field_type) . '",
                        active = ' . (int)$active . ',
                        date_upd = NOW()
                    WHERE id_content = ' . (int)$existing['id_content'];
        } else {
            // Insert new
            $sql = 'INSERT INTO `' . _DB_PREFIX_ . 'theme_content`
                    (page_identifier, field_key, field_value, field_type, lang_id, shop_id, active, date_add, date_upd)
                    VALUES ("' . pSQL($page_identifier) . '",
                            "' . pSQL($field_key) . '",
                            "' . pSQL($field_value, true) . '",
                            "' . pSQL($field_type) . '",
                            ' . (int)$lang_id . ',
                            ' . (int)$shop_id . ',
                            ' . (int)$active . ',
                            NOW(),
                            NOW())';
        }

        return Db::getInstance()->execute($sql);
    }

    /**
     * Get content value by page identifier and field key
     */
    public function getContentValue($page_identifier, $field_key, $lang_id = null, $shop_id = null)
    {
        $lang_id = $lang_id ? $lang_id : $this->context->language->id;
        $shop_id = $shop_id ? $shop_id : $this->context->shop->id;

        $sql = 'SELECT field_value, field_type
                FROM `' . _DB_PREFIX_ . 'theme_content`
                WHERE page_identifier = "' . pSQL($page_identifier) . '"
                AND field_key = "' . pSQL($field_key) . '"
                AND lang_id = ' . (int)$lang_id . '
                AND shop_id = ' . (int)$shop_id . '
                AND active = 1';

        $result = Db::getInstance()->getRow($sql);

        return $result ? $result['field_value'] : '';
    }

    /**
     * Get all content for a page
     */
    public function getAllPageContent($page_identifier, $lang_id = null, $shop_id = null)
    {
        $lang_id = $lang_id ? $lang_id : $this->context->language->id;
        $shop_id = $shop_id ? $shop_id : $this->context->shop->id;

        $sql = 'SELECT field_key, field_value, field_type
                FROM `' . _DB_PREFIX_ . 'theme_content`
                WHERE page_identifier = "' . pSQL($page_identifier) . '"
                AND lang_id = ' . (int)$lang_id . '
                AND shop_id = ' . (int)$shop_id . '
                AND active = 1';

        $results = Db::getInstance()->executeS($sql);
        $content = array();

        if ($results) {
            foreach ($results as $row) {
                $content[$row['field_key']] = array(
                    'value' => $row['field_value'],
                    'type' => $row['field_type']
                );
            }
        }

        return $content;
    }

    /**
     * Hook: Add CSS/JS to header
     */
    public function hookDisplayHeader()
    {
        $this->context->controller->addCSS($this->_path . 'views/css/themecontentmanager.css');
        $this->context->controller->addJS($this->_path . 'views/js/themecontentmanager.js');
    }

    /**
     * Hook: Display content in home page
     */
    public function hookDisplayHome($params)
    {
        if (!$this->active) {
            return '';
        }
        
        $content = $this->getAllPageContent('home');
        if (empty($content)) {
            return '';
        }
        
        $this->context->smarty->assign('theme_content', $content);
        return $this->display(__FILE__, 'views/templates/hook/home.tpl');
    }

    /**
     * Hook: Action Admin Controller Set Media
     */
    public function hookActionAdminControllerSetMedia()
    {
        $controller = Tools::getValue('controller');
        if ($controller == 'AdminThemeContent' || 
            ($controller == 'AdminModules' && Tools::getValue('configure') == $this->name)) {
            $this->context->controller->addCSS($this->_path . 'views/css/admin.css');
            $this->context->controller->addJS($this->_path . 'views/js/admin.js');
        }
    }
}