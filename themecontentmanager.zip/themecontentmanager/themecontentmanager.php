<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

class ThemeContentManager extends Module
{
    public function getContent()
    {
        Tools::redirectAdmin(
            $this->context->link->getAdminLink('AdminThemeContentManager')
        );
    }
    public function __construct()
    {
        $this->name = 'themecontentmanager';
        $this->tab = 'administration';
        $this->version = '1.0.0';
        $this->author = 'DEV';
        $this->need_instance = 0;

        parent::__construct();

        $this->displayName = $this->l('Theme Content Manager');
        $this->description = $this->l('Manage theme content');
    }

    public function install()
    {
        return parent::install() 
            && $this->installSidebarTab()
            && $this->installDb()
            && $this->registerHook('displayHeader')
            && $this->registerHook('displayLeftColumn')
            && $this->registerHook('displayRightColumn');
    }

    public function uninstall()
    {
        $this->uninstallSidebarTab();
        $this->uninstallDb();
        return parent::uninstall();
    }

    // ... (installDb, uninstallDb, installSidebarTab, uninstallSidebarTab methods remain same)

    public function hookDisplayHeader()
    {
        $id_lang = (int)$this->context->language->id;
        $id_shop = (int)$this->context->shop->id;

        // Initialize variables to avoid Smarty errors
        $this->context->smarty->assign([
            'theme_content_header' => [],
            'theme_content_footer' => [],
            'theme_content_home' => [],
            'theme_content_category' => [],
            'theme_content_blog' => [],
            'theme_content_contact' => [],
        ]);

        // Header Content
        $header_content = $this->getAllPageContent('header', $id_lang, $id_shop);
        if ($header_content) {
            $this->context->smarty->assign('theme_content_header', $header_content);
        }

        // Footer Content
        $footer_content = $this->getAllPageContent('footer', $id_lang, $id_shop);
        if ($footer_content) {
            $this->context->smarty->assign('theme_content_footer', $this->decodeJsonFields($footer_content));
        }

        // Homepage Content
        if ($this->context->controller->php_self == 'index') {
            $home_content = $this->getAllPageContent('home', $id_lang, $id_shop);
            $home_content = $this->decodeJsonFields($home_content);
            
            $selected_posts = isset($home_content['selected_blog_posts']) ? $home_content['selected_blog_posts'] : [];
            if (!is_array($selected_posts) && !empty($selected_posts)) {
                $selected_posts = json_decode($selected_posts, true);
            }
            
            $blog_posts = $this->getBlogPostsData($selected_posts, $id_lang);
            
            if (!empty($blog_posts)) {
                $home_content['ideas_articles'] = $blog_posts;
                
                // Set default button link if empty
                if (empty($home_content['ideas_btn_link'])) {
                    $module = Module::getInstanceByName('ets_blog');
                    $home_content['ideas_btn_link'] = $module->getLink('blog');
                }
                if (empty($home_content['ideas_btn_text'])) {
                    $home_content['ideas_btn_text'] = 'Tous nos conseils';
                }
            }

            // Fetch selected brands if any
            $selected_brands = isset($home_content['selected_brands']) ? $home_content['selected_brands'] : [];
            if (!is_array($selected_brands) && !empty($selected_brands)) {
                $selected_brands = json_decode($selected_brands, true);
            }
            
            // If no brands selected, fetch all active brands as fallback
            if (empty($selected_brands)) {
                $all_brands = Manufacturer::getManufacturers(false, $id_lang, true);
                if ($all_brands) {
                    $selected_brands = array_column($all_brands, 'id_manufacturer');
                }
            }

            if (!empty($selected_brands)) {
                $home_content['partners_list'] = $this->getBrandsData($selected_brands, $id_lang);
            }

            // Fetch selected products if any
            $selected_products = isset($home_content['selected_products']) ? $home_content['selected_products'] : [];
            if (!is_array($selected_products) && !empty($selected_products)) {
                $selected_products = json_decode($selected_products, true);
            }

            if (!empty($selected_products)) {
                $home_content['quality_products'] = $this->getProductsData($selected_products, $id_lang);
            }

            // Fetch gallery items (products or categories)
            $selected_gallery_products = isset($home_content['selected_gallery_products']) ? $home_content['selected_gallery_products'] : [];
            if (!is_array($selected_gallery_products) && !empty($selected_gallery_products)) {
                $selected_gallery_products = json_decode($selected_gallery_products, true);
            }

            $selected_gallery_categories = isset($home_content['selected_gallery_categories']) ? $home_content['selected_gallery_categories'] : [];
            if (!is_array($selected_gallery_categories) && !empty($selected_gallery_categories)) {
                $selected_gallery_categories = json_decode($selected_gallery_categories, true);
            }

            $gallery_items = [];
            if (!empty($selected_gallery_products)) {
                $gallery_items = array_merge($gallery_items, $this->getProductsData($selected_gallery_products, $id_lang));
            }
            if (!empty($selected_gallery_categories)) {
                $gallery_items = array_merge($gallery_items, $this->getCategoriesData($selected_gallery_categories, $id_lang));
            }

            if (!empty($gallery_items)) {
                $home_content['gallery_items'] = $gallery_items;
            }
            
            $this->context->smarty->assign('theme_content_home', $home_content);
        }

        // Category Content
        if ($this->context->controller->php_self == 'category') {
            $id_category = (int)Tools::getValue('id_category');
            $category_content = $this->getAllPageContent('category_' . $id_category, $id_lang, $id_shop);
            
            // Fallback to global category content if specific one is empty
            if (empty($category_content)) {
                $category_content = $this->getAllPageContent('category', $id_lang, $id_shop);
            }
            
            $this->context->smarty->assign('theme_content_category', $this->decodeJsonFields($category_content));
        }

        // Blog Content - More robust detection
        $controller = $this->context->controller;
        $is_blog = false;
        
        if (isset($controller->module) && $controller->module->name == 'ets_blog') {
            $is_blog = true;
        } elseif (strpos(strtolower(get_class($controller)), 'blog') !== false) {
            $is_blog = true;
        } elseif (isset($controller->php_self) && strpos($controller->php_self, 'blog') !== false) {
            $is_blog = true;
        }

        if ($is_blog) {
            $blog_content = $this->getAllPageContent('blog', $id_lang, $id_shop);
            $this->context->smarty->assign('theme_content_blog', $this->decodeJsonFields($blog_content));
        }

        // Contact Content
        $controller = $this->context->controller;
        if ($controller->php_self == 'contact' || (isset($controller->module) && $controller->module->name == 'contactform') || Tools::getValue('controller') == 'contact') {
            $contact_content = $this->getAllPageContent('contact', $id_lang, $id_shop);
            $this->context->smarty->assign('theme_content_contact', $this->decodeJsonFields($contact_content));
        }

        // About Us Content (CMS ID 4)
        if ($this->context->controller->php_self == 'cms' && (int)Tools::getValue('id_cms') == 4) {
            $about_content = $this->getAllPageContent('about', $id_lang, $id_shop);
            $about_content = $this->decodeJsonFields($about_content);

            // Fetch selected brands if any
            $selected_brands = isset($about_content['about_selected_brands']) ? $about_content['about_selected_brands'] : [];
            if (!is_array($selected_brands) && !empty($selected_brands)) {
                $selected_brands = json_decode($selected_brands, true);
            }
            
            // If no brands selected, fetch all active brands as fallback
            if (empty($selected_brands)) {
                $all_brands = Manufacturer::getManufacturers(false, $id_lang, true);
                if ($all_brands) {
                    $selected_brands = array_column($all_brands, 'id_manufacturer');
                }
            }

            if (!empty($selected_brands)) {
                $about_content['about_partners_list'] = $this->getBrandsData($selected_brands, $id_lang);
            }

            $this->context->smarty->assign('theme_content_about', $about_content);
        }
    }

    public function hookDisplayLeftColumn($params)
    {
        return $this->displaySidebarBrands();
    }

    private function displaySidebarBrands()
    {
        if ($this->context->controller->php_self == 'category') {
            return '';
        }

        $id_lang = (int)$this->context->language->id;
        $id_shop = (int)$this->context->shop->id;
        
        $home_content = $this->getAllPageContent('home', $id_lang, $id_shop);
        $home_content = $this->decodeJsonFields($home_content);
        
        $selected_brands = isset($home_content['selected_brands']) ? $home_content['selected_brands'] : [];
        if (!is_array($selected_brands) && !empty($selected_brands)) {
            $selected_brands = json_decode($selected_brands, true);
        }
        
        if (empty($selected_brands)) {
            $all_brands = Manufacturer::getManufacturers(false, $id_lang, true);
            if ($all_brands) {
                $selected_brands = array_column($all_brands, 'id_manufacturer');
            }
        }

        if (!empty($selected_brands)) {
            $brands = $this->getBrandsData($selected_brands, $id_lang);
            $this->context->smarty->assign('brands', $brands);
            return $this->display(__FILE__, 'views/templates/hook/sidebar_brands.tpl');
        }
        
        return '';
    }

    public function hookDisplayRightColumn($params)
    {
        return $this->displaySidebarBrands();
    }

    private function decodeJsonFields($content)
    {
        foreach ($content as $key => $value) {
            $decoded = json_decode($value, true);
            if (json_last_error() === JSON_ERROR_NONE) {
                $content[$key] = $decoded;
            }
        }
        return $content;
    }

    public function getBlogPostsData($post_ids, $id_lang)
    {
        if (!Module::isEnabled('ets_blog')) {
            return [];
        }

        if (!class_exists('Ets_blog_post')) {
            require_once(_PS_MODULE_DIR_ . 'ets_blog/ets_blog.php');
        }
        
        $posts_data = [];
        $module = Module::getInstanceByName('ets_blog');

        // If no posts selected, fetch latest 3
        if (empty($post_ids)) {
            $latest_posts = Ets_blog_post::getPostsWithFilter(' AND p.enabled=1', 'p.date_add DESC,', 0, 3);
            if ($latest_posts) {
                $post_ids = array_column($latest_posts, 'id_post');
            }
        }

        if (empty($post_ids)) {
            return [];
        }
        
        foreach ($post_ids as $id_post) {
            $post = new Ets_blog_post((int)$id_post, $id_lang);
            if (Validate::isLoadedObject($post)) {
                $image = '';
                if ($post->thumb) {
                    $image = $this->context->link->getMediaLink(_PS_ETS_BLOG_IMG_ . 'post/' . $post->thumb);
                } elseif ($post->image) {
                    $image = $this->context->link->getMediaLink(_PS_ETS_BLOG_IMG_ . 'post/' . $post->image);
                }

                $categories = $post->getCategories($id_lang, true);
                $tag = '';
                if ($categories) {
                    $tag = $categories[0]['title'];
                }

                $desc = $post->short_description;
                if (empty(trim(strip_tags($desc)))) {
                    $desc = $post->description;
                }

                $posts_data[] = [
                    'id' => $post->id,
                    'title' => $post->title,
                    'image' => $image,
                    'tag' => $tag,
                    'date' => date('d M Y', strtotime($post->date_add)),
                    'link' => $module->getLink('blog', ['id_post' => $post->id], $id_lang),
                    'short_description' => $desc
                ];
            }
        }
        return $posts_data;
    }

    public function getBrandsData($brand_ids, $id_lang)
    {
        $brands_data = [];
        foreach ($brand_ids as $id_manufacturer) {
            $manufacturer = new Manufacturer((int)$id_manufacturer, $id_lang);
            if (Validate::isLoadedObject($manufacturer)) {
                $image = $this->context->link->getManufacturerImageLink($manufacturer->id);
                $brands_data[] = [
                    'id' => $manufacturer->id,
                    'name' => $manufacturer->name,
                    'image' => $image,
                    'link' => $this->context->link->getManufacturerLink($manufacturer->id, $manufacturer->link_rewrite, $id_lang)
                ];
            }
        }
        return $brands_data;
    }

    public function getProductsData($product_ids, $id_lang)
    {
        $products_data = [];
        foreach ($product_ids as $id_product) {
            $product = new Product((int)$id_product, true, $id_lang);
            if (Validate::isLoadedObject($product)) {
                $image_id = Product::getCover($product->id);
                $image_url = '';
                if ($image_id) {
                    $image_url = $this->context->link->getImageLink($product->link_rewrite, $image_id['id_image'], 'dev_figma');
                }

                $category = new Category($product->id_category_default, $id_lang);
                
                $products_data[] = [
                    'id' => $product->id,
                    'title' => $product->name,
                    'subtitle' => Validate::isLoadedObject($category) ? $category->name : '',
                    'desc' => $product->description_short,
                    'image' => $image_url,
                    'btn_text' => 'VOIR LE PRODUIT',
                    'btn_link' => $this->context->link->getProductLink($product)
                ];
            }
        }
        return $products_data;
    }

    public function getCategoriesData($category_ids, $id_lang)
    {
        $categories_data = [];
        foreach ($category_ids as $id_category) {
            $category = new Category((int)$id_category, $id_lang);
            if (Validate::isLoadedObject($category)) {
                $image_url = '';
                if (file_exists(_PS_CAT_IMG_DIR_ . $category->id . '.jpg')) {
                    $image_url = $this->context->link->getCatImageLink($category->link_rewrite, $category->id, 'dev_figma');
                }

                $categories_data[] = [
                    'id' => $category->id,
                    'title' => $category->name,
                    'subtitle' => $category->description ? strip_tags($category->description) : '',
                    'image' => $image_url,
                    'btn_text' => 'VOIR LA CATÉGORIE',
                    'btn_link' => $this->context->link->getCategoryLink($category)
                ];
            }
        }
        return $categories_data;
    }


    // ... (getContentValue, getAllPageContent, saveContentValue methods remain same)

    private function installDb()
    {
        $sql = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'theme_content` (
            `id_theme_content` int(11) NOT NULL AUTO_INCREMENT,
            `page` varchar(64) NOT NULL,
            `field_key` varchar(64) NOT NULL,
            `id_lang` int(11) NOT NULL DEFAULT 0,
            `id_shop` int(11) NOT NULL DEFAULT 1,
            `content` longtext,
            PRIMARY KEY (`id_theme_content`),
            UNIQUE KEY `idx_content` (`page`, `field_key`, `id_lang`, `id_shop`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';

        return Db::getInstance()->execute($sql);
    }

    private function uninstallDb()
    {
        return Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'theme_content`');
    }

    private function installSidebarTab()
    {
        // Always remove old tab first
        $this->uninstallSidebarTab();

        $parentId = (int) Tab::getIdFromClassName('AdminParentModulesSf');

        if (!$parentId) {
            return false;
        }

        $tab = new Tab();
        $tab->active = 1;
        $tab->class_name = 'AdminThemeContentManager';
        $tab->id_parent = $parentId;
        $tab->module = $this->name;

        foreach (Language::getLanguages(true) as $lang) {
            $tab->name[$lang['id_lang']] = 'Theme Content Manager';
        }

        return $tab->add();
    }

    private function uninstallSidebarTab()
    {
        $id = (int) Tab::getIdFromClassName('AdminThemeContentManager');
        if ($id) {
            $tab = new Tab($id);
            $tab->delete();
        }
    }

    public function getContentValue($page, $key, $id_lang = null, $id_shop = null)
    {
        if ($id_lang === null) {
            $id_lang = $this->context->language->id;
        }
        if ($id_shop === null) {
            $id_shop = $this->context->shop->id;
        }

        $sql = new DbQuery();
        $sql->select('content');
        $sql->from('theme_content');
        $sql->where('page = \'' . pSQL($page) . '\'');
        $sql->where('field_key = \'' . pSQL($key) . '\'');
        $sql->where('id_lang = ' . (int)$id_lang);
        $sql->where('id_shop = ' . (int)$id_shop);

        return Db::getInstance()->getValue($sql);
    }

    public function getAllPageContent($page, $id_lang = null, $id_shop = null)
    {
        if ($id_lang === null) {
            $id_lang = $this->context->language->id;
        }
        if ($id_shop === null) {
            $id_shop = $this->context->shop->id;
        }

        $sql = new DbQuery();
        $sql->select('field_key, content');
        $sql->from('theme_content');
        
        if (strpos($page, 'category_') === 0) {
            $sql->where('page = \'' . pSQL($page) . '\'');
        } else {
            $sql->where('page = \'' . pSQL($page) . '\'');
        }
        
        $sql->where('id_lang = ' . (int)$id_lang);
        $sql->where('id_shop = ' . (int)$id_shop);

        $results = Db::getInstance()->executeS($sql);
        $content = array();
        
        if ($results) {
            foreach ($results as $row) {
                $content[$row['field_key']] = $row['content'];
            }
        }
        
        return $content;
    }

    public function saveContentValue($page, $key, $value, $id_lang, $id_shop = null)
    {
        if ($id_shop === null) {
            $id_shop = $this->context->shop->id;
        }

        // Check if exists
        $sql = 'SELECT id_theme_content FROM ' . _DB_PREFIX_ . 'theme_content 
                WHERE page = \'' . pSQL($page) . '\' 
                AND field_key = \'' . pSQL($key) . '\' 
                AND id_lang = ' . (int)$id_lang . ' 
                AND id_shop = ' . (int)$id_shop;
        
        $id = Db::getInstance()->getValue($sql);

        if ($id) {
            return Db::getInstance()->update('theme_content', array(
                'content' => pSQL($value, true)
            ), 'id_theme_content = ' . (int)$id);
        } else {
            return Db::getInstance()->insert('theme_content', array(
                'page' => pSQL($page),
                'field_key' => pSQL($key),
                'id_lang' => (int)$id_lang,
                'id_shop' => (int)$id_shop,
                'content' => pSQL($value, true)
            ));
        }
    }
}
