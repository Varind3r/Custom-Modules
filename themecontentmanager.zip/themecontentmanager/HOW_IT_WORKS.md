# 🎨 Theme Content Manager - How It Works (Visual Guide)

## 📊 Visual Flow Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                    PRESTASHOP ADMIN PANEL                       │
│                                                                 │
│  Modules → Theme Content Manager → Configure                  │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│              THEME OPTIONS SIDEBAR INTERFACE                     │
│                                                                 │
│  ┌──────────────┐  ┌─────────────────────────────────────────┐  │
│  │   SIDEBAR    │  │         CONTENT AREA                   │  │
│  │              │  │                                         │  │
│  │ • Home Page  │  │  ┌─────────────────────────────────┐   │  │
│  │ • Product    │  │  │  Hero Title: [___________]      │   │  │
│  │ • Category   │  │  │  Hero Subtitle: [________]      │   │  │
│  │ • Blog       │  │  │  Hero Image: [___________]      │   │  │
│  │ • Contact    │  │  │                                 │   │  │
│  │ • Footer     │  │  │  ┌─ Repeater Field ─────────┐  │   │  │
│  │ • Header     │  │  │  │ Row 1                    │  │   │  │
│  │              │  │  │  │  Title: [________]        │  │   │  │
│  │              │  │  │  │  Image: [________]        │  │   │  │
│  │              │  │  │  │  Link: [________]         │  │   │  │
│  │              │  │  │  │  [Remove]                 │  │   │  │
│  │              │  │  │  └──────────────────────────┘  │   │  │
│  │              │  │  │  [+ Add Row]                   │   │  │
│  │              │  │  └─────────────────────────────────┘   │  │
│  │              │  │                                         │  │
│  │              │  │  [Save All Content]                    │  │
│  │              │  │                                         │  │
│  │              │  │  ┌─ Add Custom Field ───────────────┐   │  │
│  │              │  │  │ Key: [________] Type: [Select▼] │   │  │
│  │              │  │  │ [+ Add Field]                    │   │  │
│  │              │  │  └──────────────────────────────────┘   │  │
│  └──────────────┘  └─────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
                              │
                              │ Auto-saves after 1 second
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                        DATABASE                                 │
│                                                                 │
│  Table: ps_theme_content                                       │
│  ┌─────────────┬──────────────┬───────────┬──────────────┐   │
│  │ page_id     │ field_key    │ value     │ field_type   │   │
│  ├─────────────┼──────────────┼───────────┼──────────────┤   │
│  │ home        │ hero_title   │ "Welcome" │ text         │   │
│  │ home        │ hero_image   │ "url..."  │ image        │   │
│  │ home        │ features     │ "[{...}]" │ repeater     │   │
│  └─────────────┴──────────────┴───────────┴──────────────┘   │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    FRONTEND TEMPLATES                            │
│                                                                 │
│  home.tpl / product.tpl / category.tpl                         │
│                                                                 │
│  {assign var='title' value=ThemeContentHelper::get('home',      │
│                                                    'hero_title')}│
│  <h1>{$title}</h1>                                              │
│                                                                 │
│  {assign var='features' value=ThemeContentHelper::getAll('home')}│
│  {foreach from=$features item=feature}                          │
│    <div>{$feature.title}</div>                                 │
│  {/foreach}                                                     │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      VISITOR SEES                                │
│                                                                 │
│  ┌─────────────────────────────────────────┐                   │
│  │  Welcome to Our Store                   │                   │
│  │  [Hero Image]                           │                   │
│  │                                         │                   │
│  │  Feature 1 | Feature 2 | Feature 3     │                   │
│  └─────────────────────────────────────────┘                   │
└─────────────────────────────────────────────────────────────────┘
```

## 🔄 Complete Workflow

### Step 1: Admin Adds Content
```
Admin Panel
    ↓
Select Page (e.g., "Home Page")
    ↓
Fill Fields:
  - Hero Title: "Welcome"
  - Hero Image: "https://..."
  - Add Repeater Field: "Features"
    ↓
Add Rows to Repeater:
  Row 1: Title="Fast Shipping", Image="...", Link="..."
  Row 2: Title="24/7 Support", Image="...", Link="..."
    ↓
Auto-saves to Database (after 1 second)
```

### Step 2: Data Storage
```
Database stores:
- Simple fields: Direct value
- Repeater fields: JSON array
  [
    {title: "Fast Shipping", image: "...", link: "..."},
    {title: "24/7 Support", image: "...", link: "..."}
  ]
```

### Step 3: Template Usage
```smarty
{* Get simple field *}
{assign var='title' value=ThemeContentHelper::get('home', 'hero_title')}
<h1>{$title}</h1>

{* Get repeater field *}
{assign var='features' value=ThemeContentHelper::getRepeater('home', 'features')}
{foreach from=$features item=feature}
  <div class="feature">
    <h3>{$feature.title}</h3>
    <img src="{$feature.image}">
    <a href="{$feature.link}">Learn More</a>
  </div>
{/foreach}
```

## 📋 Field Types Available

### 1. Text Field
```
┌─────────────────────────┐
│ Hero Title             │
│ [Enter title here...]  │
└─────────────────────────┘
```

### 2. Textarea Field
```
┌─────────────────────────┐
│ Description            │
│ ┌───────────────────┐  │
│ │ Enter description │  │
│ │ (multiple lines)  │  │
│ └───────────────────┘  │
└─────────────────────────┘
```

### 3. HTML Field (Rich Text Editor)
```
┌─────────────────────────┐
│ Featured Content        │
│ ┌───────────────────┐  │
│ │ [B] [I] [U] [Link]│  │
│ │ ───────────────── │  │
│ │ Enter HTML content │  │
│ └───────────────────┘  │
└─────────────────────────┘
```

### 4. Image URL Field
```
┌─────────────────────────┐
│ Hero Image URL          │
│ [https://example.com/..]│
│ ┌──────────────┐        │
│ │  [Preview]   │        │
│ └──────────────┘        │
└─────────────────────────┘
```

### 5. URL Field
```
┌─────────────────────────┐
│ Button Link             │
│ [https://example.com/..]│
└─────────────────────────┘
```

### 6. Repeater Field (NEW! 🎉)
```
┌─────────────────────────────────────────┐
│ Features (Repeater)                     │
│                                         │
│ ┌─ Row 1 ───────────────────────────┐ │
│ │ Title: [Fast Shipping]             │ │
│ │ Description: [We ship fast...]     │ │
│ │ Image: [https://...]                │ │
│ │ Link: [https://...]                 │ │
│ │ [Remove]                            │ │
│ └────────────────────────────────────┘ │
│                                         │
│ ┌─ Row 2 ───────────────────────────┐ │
│ │ Title: [24/7 Support]             │ │
│ │ Description: [Always here...]       │ │
│ │ Image: [https://...]                │ │
│ │ Link: [https://...]                 │ │
│ │ [Remove]                            │ │
│ └────────────────────────────────────┘ │
│                                         │
│ [+ Add Row]                              │
└─────────────────────────────────────────┘
```

## 🎯 Real-World Example

### Scenario: Homepage Hero Section with Features

**In Admin:**
1. Select "Home Page"
2. Fill "Hero Title": "Welcome to Our Store"
3. Fill "Hero Image": "https://example.com/hero.jpg"
4. Add Repeater Field: "homepage_features"
5. Add 3 rows:
   - Row 1: Fast Shipping, Image, Link
   - Row 2: Secure Payment, Image, Link
   - Row 3: Easy Returns, Image, Link

**In Template:**
```smarty
<section class="hero">
  {assign var='hero_title' value=ThemeContentHelper::get('home', 'hero_title')}
  {assign var='hero_image' value=ThemeContentHelper::get('home', 'hero_image')}
  
  <h1>{$hero_title}</h1>
  <img src="{$hero_image}">
  
  {assign var='features' value=ThemeContentHelper::getRepeater('home', 'homepage_features')}
  <div class="features">
    {foreach from=$features item=feature}
      <div class="feature-item">
        <img src="{$feature.image}">
        <h3>{$feature.title}</h3>
        <p>{$feature.description}</p>
        <a href="{$feature.link}">Learn More</a>
      </div>
    {/foreach}
  </div>
</section>
```

**Result on Frontend:**
```
┌─────────────────────────────────────┐
│  Welcome to Our Store               │
│  [Large Hero Image]                  │
│                                     │
│  ┌──────────┐ ┌──────────┐ ┌──────┐│
│  │ [Icon]   │ │ [Icon]   │ │[Icon]││
│  │ Fast     │ │ Secure   │ │ Easy ││
│  │ Shipping │ │ Payment │ │Return││
│  └──────────┘ └──────────┘ └──────┘│
└─────────────────────────────────────┘
```

## 🔑 Key Features

✅ **No Coding Required** - Add fields from admin panel
✅ **Auto-Save** - Saves automatically after 1 second
✅ **Repeater Fields** - Create repeatable content blocks
✅ **Multi-Language** - Manage content per language
✅ **Organized** - Fields grouped by page
✅ **Visual** - See changes immediately

## 📝 Quick Reference

**Add Field:**
1. Enter Field Key (e.g., `custom_banner`)
2. Enter Field Label (e.g., `Custom Banner`)
3. Select Field Type
4. Click "+" button

**Add Repeater:**
1. Select "Repeater" as field type
2. Field automatically creates with default sub-fields
3. Click "Add Row" to add more items
4. Each row has: Title, Description, Image, Link

**Use in Templates:**
- Simple: `ThemeContentHelper::get('page', 'field_key')`
- Repeater: `ThemeContentHelper::getRepeater('page', 'field_key')`

