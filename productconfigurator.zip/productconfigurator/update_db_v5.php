<?php
/**
 * DB Update V5 - Add Attribute Overrides table
 */
require_once(dirname(__FILE__).'/../../config/config.inc.php');

$queries = [
    "CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "configurator_product_attribute_value` (
        `id_product` INT(11) UNSIGNED NOT NULL,
        `id_configurator_attribute` INT(11) UNSIGNED NOT NULL,
        `price_impact` DECIMAL(20, 6) DEFAULT 0.000000,
        `price_impact_type` VARCHAR(20) DEFAULT 'fixed',
        `custom_label` VARCHAR(255) DEFAULT NULL,
        `is_available` TINYINT(1) DEFAULT 1,
        PRIMARY KEY (`id_product`, `id_configurator_attribute`)
    ) ENGINE=" . _MYSQL_ENGINE_ . " DEFAULT CHARSET=utf8;"
];

foreach ($queries as $query) {
    if (Db::getInstance()->execute($query)) {
        echo "Success: " . substr($query, 0, 50) . "...<br>";
    } else {
        echo "Error: " . Db::getInstance()->getMsgError() . "<br>";
    }
}
echo "Done.";
