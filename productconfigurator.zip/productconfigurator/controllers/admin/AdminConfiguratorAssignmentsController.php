<?php
/**
 * Admin Controller for managing Category Assignments
 */

class AdminConfiguratorAssignmentsController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        $this->context = Context::getContext();

        parent::__construct();
    }

    public function initContent()
    {
        parent::initContent();

        $this->processAssignmentSave();

        $idLang = (int) $this->context->language->id;

        // Get all groups
        $groups = Db::getInstance()->executeS(
            'SELECT g.id_configurator_group, gl.name
             FROM `' . _DB_PREFIX_ . 'configurator_group` g
             LEFT JOIN `' . _DB_PREFIX_ . 'configurator_group_lang` gl ON gl.id_configurator_group = g.id_configurator_group AND gl.id_lang = ' . $idLang . '
             WHERE g.active = 1
             ORDER BY g.sort_order ASC'
        ) ?: [];

        // Get all categories
        $categories = Category::getCategories($idLang, true, false);

        // Get current assignments
        $assignments = Db::getInstance()->executeS(
            'SELECT * FROM `' . _DB_PREFIX_ . 'configurator_category`'
        ) ?: [];

        $assignmentMap = [];
        if ($assignments) {
            foreach ($assignments as $a) {
                if (!isset($assignmentMap[$a['id_category']])) {
                    $assignmentMap[$a['id_category']] = [];
                }
                $assignmentMap[$a['id_category']][] = (int) $a['id_configurator_group'];
            }
        }

        $this->context->smarty->assign([
            'groups' => $groups,
            'categories' => $categories,
            'assignments' => $assignmentMap,
            'save_url' => $this->context->link->getAdminLink('AdminConfiguratorAssignments'),
        ]);

        $this->setTemplate('assignments.tpl');
    }

    private function processAssignmentSave()
    {
        if (!Tools::isSubmit('save_assignments')) {
            return;
        }

        $categoryAssignments = Tools::getValue('category_assignment', []);

        // Clear all existing assignments
        Db::getInstance()->execute('TRUNCATE TABLE `' . _DB_PREFIX_ . 'configurator_category`');

        // Save new assignments
        foreach ($categoryAssignments as $idCategory => $groupIds) {
            if (is_array($groupIds)) {
                foreach ($groupIds as $idGroup) {
                    if ($idGroup > 0) {
                        Db::getInstance()->insert('configurator_category', [
                            'id_category' => (int) $idCategory,
                            'id_configurator_group' => (int) $idGroup,
                        ], false, true, Db::INSERT_IGNORE);
                    }
                }
            }
        }

        $this->confirmations[] = $this->trans('Assignments saved successfully.', [], 'Modules.Productconfigurator.Admin');
    }

    public function setMedia($isNewTheme = false)
    {
        parent::setMedia($isNewTheme);
        $this->addCSS(_PS_MODULE_DIR_ . 'productconfigurator/views/css/admin.css');
    }

    public function createTemplate($tpl_name)
    {
        if (file_exists($this->getTemplatePath() . $tpl_name) && $this->viewAccess()) {
            return $this->context->smarty->createTemplate($this->getTemplatePath() . $tpl_name, $this->context->smarty);
        }

        return parent::createTemplate($tpl_name);
    }

    public function getTemplatePath()
    {
        return _PS_MODULE_DIR_ . 'productconfigurator/views/templates/admin/';
    }
}
