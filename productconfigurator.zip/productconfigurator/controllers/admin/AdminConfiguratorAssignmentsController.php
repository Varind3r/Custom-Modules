<?php
/**
 * Admin controller for Configurator Product Assignments
 * Located at: modules/productconfigurator/controllers/admin/
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class AdminConfiguratorAssignmentsController extends ModuleAdminController
{
    protected function l($string, $specific = false, $class = null, $addslashes = false, $htmlentities = true)
    {
        if ($this->module) {
            return $this->module->l($string, $specific);
        }
        return Translate::getModuleTranslation('productconfigurator', $string, 'AdminConfiguratorAssignmentsController');
    }

    public function __construct()
    {
        $this->bootstrap = true;
        $this->table      = 'configurator_product_group';
        $this->identifier = 'id_product';
        $this->lang       = false;
        $this->addRowAction('delete');
        $this->list_no_link = true;

        parent::__construct();

        $this->fields_list = [
            'id_product' => [
                'title' => $this->l('Product ID'),
                'align' => 'center',
                'class' => 'fixed-width-xs',
            ],
            'id_configurator_group' => [
                'title' => $this->l('Configurator Group ID'),
                'align' => 'center',
                'class' => 'fixed-width-xs',
            ],
            'sort_order' => [
                'title' => $this->l('Position'),
                'type'  => 'int',
                'filter_key' => 'a!sort_order',
            ],
        ];
    }

    public function initContent()
    {
        parent::initContent();
        $this->content = $this->renderList();
        $this->context->smarty->assign('content', $this->content);
    }
}
?>

