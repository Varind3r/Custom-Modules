<?php
/**
 * Admin controller for Configurator Steps (Groups)
 * Located at: modules/productconfigurator/controllers/admin/
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class AdminConfiguratorGroupsController extends ModuleAdminController
{
    protected function l($string, $specific = false, $class = null, $addslashes = false, $htmlentities = true)
    {
        if ($this->module) {
            return $this->module->l($string, $specific);
        }
        return Translate::getModuleTranslation('productconfigurator', $string, 'AdminConfiguratorGroupsController');
    }

    public function __construct()
    {
        $this->bootstrap = true;
        $this->table      = 'configurator_group';
        $this->className  = 'ConfiguratorStep'; // ObjectModel we created earlier
        $this->lang       = true; // multilang support
        $this->addRowAction('edit');
        $this->addRowAction('delete');
        $this->addRowAction('fields');

        parent::__construct();

        $this->fields_list = [
            'id_configurator_group' => [
                'title' => $this->l('ID'),
                'align' => 'center',
                'class' => 'fixed-width-xs',
            ],
            'name' => [
                'title' => $this->l('Name'),
                'filter_key' => 'b!name',
                'type' => 'text',
            ],
            'active' => [
                'title' => $this->l('Enabled'),
                'type'  => 'bool',
                'active' => 'status',
                'filter_key' => 'a!active',
            ],
            'sort_order' => [
                'title' => $this->l('Position'),
                'type'  => 'int',
                'filter_key' => 'a!sort_order',
            ],
        ];
    }

    /** Render the form for adding / editing a step */
    public function renderForm()
    {
        $this->fields_form = [
            'legend' => [
                'title' => $this->l('Configurator Step'),
                'icon'  => 'icon-cogs',
            ],
            'input'  => [
                [
                    'type'  => 'text',
                    'label' => $this->l('Name'),
                    'name'  => 'name',
                    'lang'  => true,
                    'required' => true,
                ],
                [
                    'type'  => 'textarea',
                    'label' => $this->l('Description'),
                    'name'  => 'description',
                    'lang'  => true,
                    'autoload_rte' => true,
                ],
                [
                    'type'  => 'switch',
                    'label' => $this->l('Enabled'),
                    'name'  => 'active',
                    'is_bool'=> true,
                    'values'=> [
                        ['id' => 'active_on',  'value' => 1, 'label' => $this->l('Yes')],
                        ['id' => 'active_off', 'value' => 0, 'label' => $this->l('No')],
                    ],
                ],
                [
                    'type' => 'html',
                    'label' => $this->l('Manage Fields'),
                    'name' => 'inline_fields',
                    'html_content' => $this->renderInlineFields(),
                ],
                [
                    'type'  => 'text',
                    'label' => $this->l('Position'),
                    'name'  => 'sort_order',
                    'required' => true,
                    'class' => 'fixed-width-sm',
                ],
            ],
            'submit' => [
                'title' => $this->l('Save'),
            ],
        ];

        return parent::renderForm();
    }

    protected function renderInlineFields()
    {
        $assignedFields = [];
        if ($this->object->id) {
            $assignedFields = ConfiguratorField::getByStep((int)$this->object->id, (int)$this->context->language->id);
            // Load full object data for each field to get multilang values
            foreach ($assignedFields as &$field) {
                $fieldObj = new ConfiguratorField((int)$field['id_configurator_attribute']);
                $field['name'] = $fieldObj->name;
                $field['description'] = $fieldObj->description;
            }
        }

        $this->context->smarty->assign([
            'assigned_fields' => $assignedFields,
            'languages' => Language::getLanguages(true),
            'default_lang' => (int)Configuration::get('PS_LANG_DEFAULT'),
        ]);

        return $this->context->smarty->fetch(_PS_MODULE_DIR_.'productconfigurator/views/templates/admin/fields_repeater.tpl');
    }

    public function postProcess()
    {
        if (Tools::isSubmit('submitAddconfigurator_group')) {
            $res = parent::postProcess();
            if ($res && $this->object->id) {
                $groupId = (int)$this->object->id;
                
                // 1. Clear existing assignments
                Db::getInstance()->execute('DELETE FROM '._DB_PREFIX_.'configurator_group_attribute WHERE id_configurator_group = '.$groupId);

                // 2. Process Existing Fields (Updates)
                $existingFields = Tools::getValue('fields');
                $sortOrder = 0;
                if (is_array($existingFields)) {
                    foreach ($existingFields as $fieldId => $data) {
                        $fieldObj = new ConfiguratorField((int)$fieldId);
                        if (Validate::isLoadedObject($fieldObj)) {
                            $fieldObj->name = $data['name'];
                            $fieldObj->description = $data['description'];
                            $fieldObj->field_type = $data['field_type'];
                            $fieldObj->is_required = isset($data['is_required']) ? 1 : 0;
                            $fieldObj->save();

                            Db::getInstance()->insert('configurator_group_attribute', [
                                'id_configurator_group' => $groupId,
                                'id_configurator_attribute' => (int)$fieldId,
                                'sort_order' => $sortOrder++
                            ]);
                        }
                    }
                }

                // 3. Process New Fields (Creation)
                $newFields = Tools::getValue('new_fields');
                if (is_array($newFields)) {
                    foreach ($newFields as $data) {
                        if (empty($data['name'][(int)Configuration::get('PS_LANG_DEFAULT')])) {
                            continue;
                        }

                        $fieldObj = new ConfiguratorField();
                        $fieldObj->name = $data['name'];
                        $fieldObj->description = $data['description'];
                        $fieldObj->field_type = $data['field_type'];
                        $fieldObj->is_required = isset($data['is_required']) ? 1 : 0;
                        $fieldObj->active = 1;
                        $fieldObj->sort_order = 0;
                        
                        if ($fieldObj->add()) {
                            Db::getInstance()->insert('configurator_group_attribute', [
                                'id_configurator_group' => $groupId,
                                'id_configurator_attribute' => (int)$fieldObj->id,
                                'sort_order' => $sortOrder++
                            ]);
                        }
                    }
                }
            }
            return $res;
        }
        return parent::postProcess();
    }

    public function displayFieldsLink($token, $id)
    {
        // This link will filter the attributes list by group
        $href = $this->context->link->getAdminLink('AdminConfiguratorAttributes') . '&id_group=' . (int)$id;
        
        return '<a class="edit btn btn-default" href="' . $href . '" title="' . $this->l('Manage Fields') . '">
            <i class="icon-list"></i> ' . $this->l('Manage Fields') . '
        </a>';
    }
}
?>
