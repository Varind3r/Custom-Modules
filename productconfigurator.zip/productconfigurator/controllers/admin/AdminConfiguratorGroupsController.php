<?php
/**
 * Admin Controller for managing Configurator Groups
 */

class AdminConfiguratorGroupsController extends ModuleAdminController
{
    public function __construct()
    {
        $this->table = 'configurator_group';
        $this->identifier = 'id_configurator_group';
        $this->className = 'ConfiguratorGroup';
        $this->lang = true;
        $this->bootstrap = true;
        $this->context = Context::getContext();

        parent::__construct();

        $this->fields_list = [
            'id_configurator_group' => [
                'title' => $this->trans('ID', [], 'Admin.Global'),
                'align' => 'center',
                'class' => 'fixed-width-xs',
            ],
            'name' => [
                'title' => $this->trans('Name', [], 'Admin.Global'),
                'filter_key' => 'gl!name',
            ],
            'sort_order' => [
                'title' => $this->trans('Position', [], 'Admin.Global'),
                'align' => 'center',
                'class' => 'fixed-width-sm',
            ],
            'active' => [
                'title' => $this->trans('Active', [], 'Admin.Global'),
                'active' => 'status',
                'type' => 'bool',
                'align' => 'center',
            ],
        ];

        $this->bulk_actions = [
            'delete' => [
                'text' => $this->trans('Delete selected', [], 'Admin.Actions'),
                'confirm' => $this->trans('Delete selected items?', [], 'Admin.Notifications.Warning'),
                'icon' => 'icon-trash',
            ],
        ];

        $this->_select = 'gl.name';
        $this->_join = 'LEFT JOIN `' . _DB_PREFIX_ . 'configurator_group_lang` gl ON (gl.id_configurator_group = a.id_configurator_group AND gl.id_lang = ' . (int) $this->context->language->id . ')';
    }

    public function renderForm()
    {
        // Get all attributes for selection
        $attributes = Db::getInstance()->executeS(
            'SELECT a.id_configurator_attribute, al.name, a.field_type
             FROM `' . _DB_PREFIX_ . 'configurator_attribute` a
             LEFT JOIN `' . _DB_PREFIX_ . 'configurator_attribute_lang` al 
                ON al.id_configurator_attribute = a.id_configurator_attribute 
                AND al.id_lang = ' . (int) $this->context->language->id . '
             WHERE a.active = 1
             ORDER BY a.sort_order ASC'
        ) ?: [];

        $attributeOptions = [];
        if ($attributes) { // Check return value of executeS
            foreach ($attributes as $attr) {
                $attributeOptions[] = [
                    'id' => $attr['id_configurator_attribute'],
                    'name' => $attr['name'] . ' (' . $attr['field_type'] . ')',
                ];
            }
        }

        // Get currently selected attributes for this group
        $selectedAttributes = [];
        if ($this->object && $this->object->id) {
            $selected = Db::getInstance()->executeS(
                'SELECT id_configurator_attribute FROM `' . _DB_PREFIX_ . 'configurator_group_attribute`
                 WHERE id_configurator_group = ' . (int) $this->object->id . '
                 ORDER BY sort_order ASC'
            ) ?: [];
            if ($selected) {
                $selectedAttributes = array_column($selected, 'id_configurator_attribute');
            }
        }

        $this->fields_form = [
            'legend' => [
                'title' => $this->trans('Attribute Group', [], 'Modules.Productconfigurator.Admin'),
                'icon' => 'icon-folder-open',
            ],
            'input' => [
                [
                    'type' => 'text',
                    'label' => $this->trans('Group Name', [], 'Modules.Productconfigurator.Admin'),
                    'name' => 'name',
                    'lang' => true,
                    'required' => true,
                    'hint' => $this->trans('Name of the attribute group', [], 'Modules.Productconfigurator.Admin'),
                ],
                [
                    'type' => 'textarea',
                    'label' => $this->trans('Description', [], 'Admin.Global'),
                    'name' => 'description',
                    'lang' => true,
                    'hint' => $this->trans('Description shown on product page', [], 'Modules.Productconfigurator.Admin'),
                ],
                [
                    'type' => 'file',
                    'label' => $this->trans('Group Image', [], 'Modules.Productconfigurator.Admin'),
                    'name' => 'image',
                    'hint' => $this->trans('Optional image for the group header', [], 'Modules.Productconfigurator.Admin'),
                ],
                [
                    'type' => 'swap',
                    'label' => $this->trans('Attributes in Group', [], 'Modules.Productconfigurator.Admin'),
                    'name' => 'group_attributes',
                    'multiple' => true,
                    'options' => [
                        'query' => $attributeOptions,
                        'id' => 'id',
                        'name' => 'name',
                    ],
                    'hint' => $this->trans('Select and order attributes for this group', [], 'Modules.Productconfigurator.Admin'),
                ],
                [
                    'type' => 'text',
                    'label' => $this->trans('Sort Order', [], 'Modules.Productconfigurator.Admin'),
                    'name' => 'sort_order',
                    'class' => 'fixed-width-sm',
                ],
                [
                    'type' => 'switch',
                    'label' => $this->trans('Active', [], 'Admin.Global'),
                    'name' => 'active',
                    'values' => [
                        ['id' => 'active_on', 'value' => 1, 'label' => $this->trans('Yes', [], 'Admin.Global')],
                        ['id' => 'active_off', 'value' => 0, 'label' => $this->trans('No', [], 'Admin.Global')],
                    ],
                ],
            ],
            'submit' => [
                'title' => $this->trans('Save', [], 'Admin.Actions'),
            ],
        ];

        // Set default value for swap field
        $this->fields_value['group_attributes'] = $selectedAttributes;

        // Show current image if exists
        if ($this->object && $this->object->image) {
            $this->fields_form['input'][2]['image'] = $this->object->image;
        }

        return parent::renderForm();
    }

    public function postProcess()
    {
        if (Tools::isSubmit('submitAdd' . $this->table)) {
            parent::postProcess();
            
            if (empty($this->errors) && $this->object && $this->object->id) {
                $this->saveGroupAttributes($this->object->id);
            }
            
            return;
        }

        return parent::postProcess();
    }

    private function saveGroupAttributes($idGroup)
    {
        $attributeIds = Tools::getValue('group_attributes', []);

        // Clear existing mappings
        Db::getInstance()->delete('configurator_group_attribute', 'id_configurator_group = ' . (int) $idGroup);

        // Save new mappings
        if (is_array($attributeIds) && !empty($attributeIds)) {
            $sortOrder = 0;
            foreach ($attributeIds as $attrId) {
                Db::getInstance()->insert('configurator_group_attribute', [
                    'id_configurator_group' => (int) $idGroup,
                    'id_configurator_attribute' => (int) $attrId,
                    'sort_order' => $sortOrder++,
                ]);
            }
        }
    }

    public function processAdd()
    {
        $object = parent::processAdd();
        
        // Handle image upload
        if ($object && $object->id) {
            $this->handleImageUpload($object->id);
        }
        
        return $object;
    }

    public function processUpdate()
    {
        $object = parent::processUpdate();
        
        // Handle image upload
        if ($object && $object->id) {
            $this->handleImageUpload($object->id);
        }
        
        return $object;
    }

    private function handleImageUpload($idGroup)
    {
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = _PS_MODULE_DIR_ . 'productconfigurator/views/img/groups/';
            if (!file_exists($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }

            $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $filename = 'group_' . $idGroup . '.' . $ext;
            $targetPath = $uploadDir . $filename;

            if (move_uploaded_file($_FILES['image']['tmp_name'], $targetPath)) {
                Db::getInstance()->update('configurator_group', [
                    'image' => 'modules/productconfigurator/views/img/groups/' . $filename,
                ], 'id_configurator_group = ' . (int) $idGroup);
            }
        }
    }
}
