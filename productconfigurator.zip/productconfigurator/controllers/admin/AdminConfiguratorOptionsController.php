<?php
/**
 * Admin controller for Configurator Options
 * Located at: modules/productconfigurator/controllers/admin/
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class AdminConfiguratorOptionsController extends ModuleAdminController
{
    protected function l($string, $specific = false, $class = null, $addslashes = false, $htmlentities = true)
    {
        if ($this->module) {
            return $this->module->l($string, $specific);
        }
        return Translate::getModuleTranslation('productconfigurator', $string, 'AdminConfiguratorOptionsController');
    }

    public function __construct()
    {
        $this->bootstrap = true;
        $this->table      = 'configurator_attribute_option';
        $this->className  = 'ConfiguratorOption';
        $this->lang       = true;
        $this->addRowAction('edit');
        $this->addRowAction('delete');

        parent::__construct();

        if ($id_attribute = (int)Tools::getValue('id_attribute')) {
            $this->_where .= ' AND a.id_configurator_attribute = '.$id_attribute;
        }

        $this->fields_list = [
            'id_configurator_option' => [
                'title' => $this->l('ID'),
                'align' => 'center',
                'class' => 'fixed-width-xs',
            ],
            'label' => [
                'title' => $this->l('Label'),
                'filter_key' => 'b!label',
                'type' => 'text',
            ],
            'id_configurator_attribute' => [
                'title' => $this->l('Field ID'),
                'align' => 'center',
                'type' => 'int',
            ],
            'price_impact' => [
                'title' => $this->l('Price'),
                'type' => 'price',
            ],
            'active' => [
                'title' => $this->l('Enabled'),
                'type'  => 'bool',
                'active' => 'status',
                'filter_key' => 'a!active',
            ],
            'sort_order' => [
                'title' => $this->l('Position'),
                'type'  => 'int',
                'filter_key' => 'a!sort_order',
            ],
        ];
    }

    public function renderForm()
    {
        // Get available fields (attributes) for the parent selector
        $fields = Db::getInstance()->executeS('
            SELECT a.id_configurator_attribute as id, al.name 
            FROM '._DB_PREFIX_.'configurator_attribute a
            LEFT JOIN '._DB_PREFIX_.'configurator_attribute_lang al ON (a.id_configurator_attribute = al.id_configurator_attribute AND al.id_lang = '.(int)$this->context->language->id.')
            WHERE a.active = 1
        ');

        $this->fields_form = [
            'legend' => [
                'title' => $this->l('Configurator Option'),
                'icon'  => 'icon-cogs',
            ],
            'input'  => [
                [
                    'type'  => 'select',
                    'label' => $this->l('Field (Attribute)'),
                    'name'  => 'id_configurator_attribute',
                    'required' => true,
                    'options' => [
                        'query' => $fields,
                        'id' => 'id',
                        'name' => 'name',
                    ],
                ],
                [
                    'type'  => 'text',
                    'label' => $this->l('Label'),
                    'name'  => 'label',
                    'lang'  => true,
                    'required' => true,
                ],
                [
                    'type'  => 'textarea',
                    'label' => $this->l('Description'),
                    'name'  => 'description',
                    'lang'  => true,
                    'autoload_rte' => true,
                ],
                [
                    'type'  => 'text',
                    'label' => $this->l('Badge Text'),
                    'name'  => 'badge',
                    'lang'  => true,
                    'desc'  => $this->l('Short text like "Promotion" or "Best Seller".'),
                    'size'  => 64,
                ],
                [
                    'type'  => 'textarea',
                    'label' => $this->l('Features List'),
                    'name'  => 'features',
                    'lang'  => true,
                    'autoload_rte' => true,
                    'desc'  => $this->l('List of key features. Use BULLET POINTS or simple HTML.'),
                    'rows'  => 5,
                ],
                [
                    'type'  => 'text',
                    'label' => $this->l('Price Impact'),
                    'name'  => 'price_impact',
                    'prefix' => $this->context->currency->sign,
                ],
                [
                    'type'  => 'select',
                    'label' => $this->l('Price Type'),
                    'name'  => 'price_impact_type',
                    'options' => [
                        'query' => [
                            ['id' => 'fixed', 'name' => $this->l('Fixed Amount')],
                            ['id' => 'percent', 'name' => $this->l('Percentage of Base Price')],
                            ['id' => 'rate_m2', 'name' => $this->l('Rate per m² (Area)')],
                            ['id' => 'rate_m', 'name' => $this->l('Rate per m (Linear)')],
                        ],
                        'id' => 'id',
                        'name' => 'name',
                    ],
                ],
                [
                    'type'  => 'switch',
                    'label' => $this->l('Enabled'),
                    'name'  => 'active',
                    'is_bool'=> true,
                    'values'=> [
                        ['id' => 'active_on',  'value' => 1, 'label' => $this->l('Yes')],
                        ['id' => 'active_off', 'value' => 0, 'label' => $this->l('No')],
                    ],
                ],
                [
                    'type'  => 'text',
                    'label' => $this->l('Image URL'),
                    'name'  => 'image',
                    'desc'  => $this->l('URL of the preview image (e.g. /img/windows/pvc.png)'),
                ],
                [
                    'type'  => 'color',
                    'label' => $this->l('Color Code'),
                    'name'  => 'color_code',
                ],
                [
                    'type'  => 'textarea',
                    'label' => $this->l('Dependencies (JSON)'),
                    'name'  => 'dependencies',
                    'desc'  => $this->l('Example: {"show_steps": [2], "hide_fields": [10]}'),
                ],
                [
                    'type'  => 'text',
                    'label' => $this->l('Position'),
                    'name'  => 'sort_order',
                    'required' => true,
                    'class' => 'fixed-width-sm',
                ],
            ],
            'submit' => [
                'title' => $this->l('Save'),
            ],
        ];

        return parent::renderForm();
    }
}
