<?php
/**
 * Admin controller for Configurator Attributes (Fields)
 * Located at: modules/productconfigurator/controllers/admin/
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class AdminConfiguratorAttributesController extends ModuleAdminController
{
    protected function l($string, $specific = false, $class = null, $addslashes = false, $htmlentities = true)
    {
        if ($this->module) {
            return $this->module->l($string, $specific);
        }
        return Translate::getModuleTranslation('productconfigurator', $string, 'AdminConfiguratorAttributesController');
    }

    public function __construct()
    {
        $this->bootstrap = true;
        $this->table      = 'configurator_attribute';
        $this->className  = 'ConfiguratorField';
        $this->lang       = true;
        $this->addRowAction('edit');
        $this->addRowAction('delete');
        $this->addRowAction('options');

        parent::__construct();

        if ($id_group = (int)Tools::getValue('id_group')) {
            $this->_join .= ' INNER JOIN '._DB_PREFIX_.'configurator_group_attribute ga ON (ga.id_configurator_attribute = a.id_configurator_attribute AND ga.id_configurator_group = '.$id_group.')';
        }

        $this->fields_list = [
            'id_configurator_attribute' => [
                'title' => $this->l('ID'),
                'align' => 'center',
                'class' => 'fixed-width-xs',
            ],
            'name' => [
                'title' => $this->l('Name'),
                'filter_key' => 'b!name',
                'type' => 'text',
            ],
            'field_type' => [
                'title' => $this->l('Field Type'),
                'type' => 'text',
                'filter_key' => 'a!field_type',
            ],
            'active' => [
                'title' => $this->l('Enabled'),
                'type'  => 'bool',
                'active' => 'status',
                'filter_key' => 'a!active',
            ],
            'sort_order' => [
                'title' => $this->l('Position'),
                'type'  => 'int',
                'filter_key' => 'a!sort_order',
            ],
        ];
    }

    /** Render the form for adding / editing an attribute */
    public function renderForm()
    {
        $this->fields_form = [
            'legend' => [
                'title' => $this->l('Configurator Attribute'),
                'icon'  => 'icon-cogs',
            ],
            'input'  => [
                [
                    'type'  => 'text',
                    'label' => $this->l('Name'),
                    'name'  => 'name',
                    'lang'  => true,
                    'required' => true,
                ],
                [
                    'type'  => 'select',
                    'label' => $this->l('Parent Step (Group)'),
                    'name'  => 'id_configurator_group',
                    'required' => false,
                    'desc'  => $this->l('Optional. If left empty, this field is "Global" and can be reused in multiple steps.'),
                    'options' => [
                        'query' => Db::getInstance()->executeS('SELECT g.id_configurator_group as id, gl.name FROM '._DB_PREFIX_.'configurator_group g LEFT JOIN '._DB_PREFIX_.'configurator_group_lang gl ON g.id_configurator_group = gl.id_configurator_group WHERE gl.id_lang = '.(int)$this->context->language->id),
                        'id' => 'id',
                        'name' => 'name',
                        'default' => ['value' => 0, 'label' => $this->l('-- Global (No specific group) --')]
                    ],
                ],
                [
                    'type'  => 'select',
                    'label' => $this->l('Field Type'),
                    'name'  => 'field_type',
                    'id'    => 'field_type_selector',
                    'required' => true,
                    'options' => [
                        'query' => [
                            ['id' => 'text', 'name' => $this->l('Text Input')],
                            ['id' => 'number', 'name' => $this->l('Number Input')],
                            ['id' => 'dropdown', 'name' => $this->l('Dropdown (Select)')],
                            ['id' => 'radio_text', 'name' => $this->l('Radio Buttons (Text)')],
                            ['id' => 'radio_image', 'name' => $this->l('Image Selection (Grid)')],
                            ['id' => 'radio_color', 'name' => $this->l('Color Selection (Palette)')],
                            ['id' => 'checkbox', 'name' => $this->l('Checkbox')],
                            ['id' => 'file', 'name' => $this->l('File Upload')],
                            ['id' => 'dimensions', 'name' => $this->l('Dimensions Input (Width & Height)')],
                        ],
                        'id' => 'id',
                        'name' => 'name',
                    ],
                ],
                // Dimension Limits (Only if Type = dimensions)
                [
                    'type'  => 'text',
                    'label' => $this->l('Min Width (mm)'),
                    'name'  => 'min_width',
                    'col'   => 3,
                    'form_group_class' => 'hide_unless_dimensions',
                ],
                [
                    'type'  => 'text',
                    'label' => $this->l('Max Width (mm)'),
                    'name'  => 'max_width',
                    'col'   => 3,
                    'form_group_class' => 'hide_unless_dimensions',
                ],
                [
                    'type'  => 'text',
                    'label' => $this->l('Min Height (mm)'),
                    'name'  => 'min_height',
                    'col'   => 3,
                    'form_group_class' => 'hide_unless_dimensions',
                ],
                [
                    'type'  => 'text',
                    'label' => $this->l('Max Height (mm)'),
                    'name'  => 'max_height',
                    'col'   => 3,
                    'form_group_class' => 'hide_unless_dimensions',
                ],
                [
                    'type'  => 'textarea',
                    'label' => $this->l('Description'),
                    'name'  => 'description',
                    'lang'  => true,
                    'autoload_rte' => true,
                ],
                [
                    'type'  => 'switch',
                    'label' => $this->l('Required'),
                    'name'  => 'is_required',
                    'is_bool'=> true,
                    'values'=> [
                        ['id' => 'is_required_on',  'value' => 1, 'label' => $this->l('Yes')],
                        ['id' => 'is_required_off', 'value' => 0, 'label' => $this->l('No')],
                    ],
                ],
                [
                    'type'  => 'switch',
                    'label' => $this->l('Enabled'),
                    'name'  => 'active',
                    'is_bool'=> true,
                    'values'=> [
                        ['id' => 'active_on',  'value' => 1, 'label' => $this->l('Yes')],
                        ['id' => 'active_off', 'value' => 0, 'label' => $this->l('No')],
                    ],
                ],
                [
                    'type'  => 'text',
                    'label' => $this->l('Position'),
                    'name'  => 'sort_order',
                    'required' => true,
                    'class' => 'fixed-width-sm',
                ],
                [
                    'type' => 'html',
                    'name' => 'inline_options',
                    'html_content' => $this->renderInlineOptions(),
                ]
            ],
            'submit' => [
                'title' => $this->l('Save'),
            ],
        ];

        // Pre-fill the group if we have it in the URL
        if ($id_group = (int)Tools::getValue('id_group')) {
            $this->fields_value['id_configurator_group'] = $id_group;
        } elseif ($this->object->id) {
            $this->fields_value['id_configurator_group'] = Db::getInstance()->getValue('SELECT id_configurator_group FROM '._DB_PREFIX_.'configurator_group_attribute WHERE id_configurator_attribute = '.(int)$this->object->id);
        }

        // JS for conditional visibility
        $this->context->controller->addJS(_PS_MODULE_DIR_.$this->module->name.'/views/js/admin_attribute.js');

        return parent::renderForm();
    }

    protected function renderInlineOptions()
    {
        $options = [];
        if ($this->object->id) {
            $optionsRows = ConfiguratorOption::getByField((int)$this->object->id, (int)$this->context->language->id);
            foreach ($optionsRows as $row) {
                $optObj = new ConfiguratorOption((int)$row['id_configurator_option']);
                $row['label'] = $optObj->label;
                $row['description'] = $optObj->description;
                $options[] = $row;
            }
        }

        $this->context->smarty->assign([
            'field_options' => $options,
            'languages' => Language::getLanguages(true),
            'default_lang' => (int)Configuration::get('PS_LANG_DEFAULT'),
            'fields_value' => $this->fields_value,
        ]);

        return $this->context->smarty->fetch(_PS_MODULE_DIR_.'productconfigurator/views/templates/admin/options_repeater.tpl');
    }

    public function postProcess()
    {
        if (Tools::isSubmit('submitAddconfigurator_attribute')) {
            $res = parent::postProcess();
            if ($res && $this->object->id) {
                $attrId = (int)$this->object->id;
                
                // 1. Process Metadata
                $id_group = (int)Tools::getValue('id_configurator_group');
                if ($id_group) {
                    Db::getInstance()->execute('DELETE FROM '._DB_PREFIX_.'configurator_group_attribute WHERE id_configurator_attribute = '.$attrId);
                    Db::getInstance()->insert('configurator_group_attribute', [
                        'id_configurator_group' => $id_group,
                        'id_configurator_attribute' => $attrId
                    ]);
                }

                // 2. Process Existing Options
                $existingOptions = Tools::getValue('options');
                $keepIds = [];
                $sort = 0;
                if (is_array($existingOptions)) {
                    foreach ($existingOptions as $optId => $data) {
                        $optObj = new ConfiguratorOption((int)$optId);
                        if (Validate::isLoadedObject($optObj)) {
                            $optObj->label = $data['label'];
                            $optObj->description = $data['description'];
                            $optObj->price_impact = (float)$data['price'];
                            $optObj->price_impact_type = $data['price_type'];
                            $optObj->active = isset($data['active']) ? 1 : 0;
                            $optObj->image = $data['image'];
                            $optObj->color_code = $data['color_code'];
                            $optObj->sort_order = $sort++;
                            $optObj->save();
                            $keepIds[] = (int)$optId;
                        }
                    }
                }

                // 3. Process New Options
                $newOptions = Tools::getValue('new_options');
                if (is_array($newOptions)) {
                    foreach ($newOptions as $data) {
                        if (empty($data['label'][(int)Configuration::get('PS_LANG_DEFAULT')])) {
                            continue;
                        }
                        $optObj = new ConfiguratorOption();
                        $optObj->id_configurator_attribute = $attrId;
                        $optObj->label = $data['label'];
                        $optObj->description = $data['description'];
                        $optObj->price_impact = (float)$data['price'];
                        $optObj->price_impact_type = $data['price_type'];
                        $optObj->active = isset($data['active']) ? 1 : 0;
                        $optObj->image = $data['image'];
                        $optObj->color_code = $data['color_code'];
                        $optObj->sort_order = $sort++;
                        if ($optObj->add()) {
                            $keepIds[] = (int)$optObj->id;
                        }
                    }
                }

                // 4. Cleanup removed options
                $sql = 'DELETE FROM '._DB_PREFIX_.'configurator_attribute_option WHERE id_configurator_attribute = '.$attrId;
                if (!empty($keepIds)) {
                    $sql .= ' AND id_configurator_option NOT IN ('.implode(',', $keepIds).')';
                }
                Db::getInstance()->execute($sql);
            }
            return $res;
        }
        return parent::postProcess();
    }

    public function displayOptionsLink($token, $id)
    {
        $href = $this->context->link->getAdminLink('AdminConfiguratorOptions') . '&id_attribute=' . (int)$id;
        
        return '<a class="edit btn btn-default" href="' . $href . '" title="' . $this->l('Manage Options') . '">
            <i class="icon-list"></i> ' . $this->l('Manage Options') . '
        </a>';
    }
}
?>

