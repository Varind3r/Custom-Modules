<?php
/**
 * Admin Controller for managing Configurator Attributes
 */

class AdminConfiguratorAttributesController extends ModuleAdminController
{
    public function __construct()
    {
        $this->table = 'configurator_attribute';
        $this->identifier = 'id_configurator_attribute';
        $this->className = 'ConfiguratorAttribute';
        $this->lang = true;
        $this->bootstrap = true;
        $this->context = Context::getContext();

        parent::__construct();

        $this->fields_list = [
            'id_configurator_attribute' => [
                'title' => $this->trans('ID', [], 'Admin.Global'),
                'align' => 'center',
                'class' => 'fixed-width-xs',
            ],
            'name' => [
                'title' => $this->trans('Name', [], 'Admin.Global'),
                'filter_key' => 'al!name',
            ],
            'field_type' => [
                'title' => $this->trans('Field Type', [], 'Modules.Productconfigurator.Admin'),
                'type' => 'select',
                'list' => ProductConfigurator::getFieldTypes(),
                'filter_key' => 'a!field_type',
            ],
            'is_required' => [
                'title' => $this->trans('Required', [], 'Admin.Global'),
                'active' => 'status',
                'type' => 'bool',
                'align' => 'center',
            ],
            'sort_order' => [
                'title' => $this->trans('Position', [], 'Admin.Global'),
                'align' => 'center',
                'class' => 'fixed-width-sm',
            ],
            'active' => [
                'title' => $this->trans('Active', [], 'Admin.Global'),
                'active' => 'status',
                'type' => 'bool',
                'align' => 'center',
            ],
        ];

        $this->bulk_actions = [
            'delete' => [
                'text' => $this->trans('Delete selected', [], 'Admin.Actions'),
                'confirm' => $this->trans('Delete selected items?', [], 'Admin.Notifications.Warning'),
                'icon' => 'icon-trash',
            ],
        ];

        $this->_select = 'al.name';
        $this->_join = 'LEFT JOIN `' . _DB_PREFIX_ . 'configurator_attribute_lang` al ON (al.id_configurator_attribute = a.id_configurator_attribute AND al.id_lang = ' . (int) $this->context->language->id . ')';
    }

    public function initContent()
    {
        parent::initContent();
    }

    public function renderForm()
    {
        $fieldTypes = [];
        foreach (ProductConfigurator::getFieldTypes() as $key => $label) {
            $fieldTypes[] = [
                'id' => $key,
                'name' => $label,
            ];
        }

        $priceTypes = [
            ['id' => 'fixed', 'name' => $this->trans('Fixed Amount', [], 'Modules.Productconfigurator.Admin')],
            ['id' => 'percent', 'name' => $this->trans('Percentage', [], 'Modules.Productconfigurator.Admin')],
        ];

        $this->fields_form = [
            'legend' => [
                'title' => $this->trans('Attribute Type', [], 'Modules.Productconfigurator.Admin'),
                'icon' => 'icon-cogs',
            ],
            'input' => [
                [
                    'type' => 'text',
                    'label' => $this->trans('Name', [], 'Admin.Global'),
                    'name' => 'name',
                    'lang' => true,
                    'required' => true,
                    'hint' => $this->trans('Attribute name displayed to users', [], 'Modules.Productconfigurator.Admin'),
                ],
                [
                    'type' => 'textarea',
                    'label' => $this->trans('Description', [], 'Admin.Global'),
                    'name' => 'description',
                    'lang' => true,
                    'hint' => $this->trans('Help text shown below the field', [], 'Modules.Productconfigurator.Admin'),
                ],
                [
                    'type' => 'select',
                    'label' => $this->trans('Field Type', [], 'Modules.Productconfigurator.Admin'),
                    'name' => 'field_type',
                    'required' => true,
                    'options' => [
                        'query' => $fieldTypes,
                        'id' => 'id',
                        'name' => 'name',
                    ],
                ],
                [
                    'type' => 'text',
                    'label' => $this->trans('Placeholder', [], 'Modules.Productconfigurator.Admin'),
                    'name' => 'placeholder',
                    'lang' => true,
                    'hint' => $this->trans('Placeholder text for input fields', [], 'Modules.Productconfigurator.Admin'),
                ],
                [
                    'type' => 'text',
                    'label' => $this->trans('Suffix', [], 'Modules.Productconfigurator.Admin'),
                    'name' => 'suffix',
                    'lang' => true,
                    'hint' => $this->trans('Suffix displayed after the input (e.g., cm, kg)', [], 'Modules.Productconfigurator.Admin'),
                    'class' => 'fixed-width-lg',
                ],
                [
                    'type' => 'switch',
                    'label' => $this->trans('Required Field', [], 'Modules.Productconfigurator.Admin'),
                    'name' => 'is_required',
                    'values' => [
                        ['id' => 'is_required_on', 'value' => 1, 'label' => $this->trans('Yes', [], 'Admin.Global')],
                        ['id' => 'is_required_off', 'value' => 0, 'label' => $this->trans('No', [], 'Admin.Global')],
                    ],
                ],
                [
                    'type' => 'switch',
                    'label' => $this->trans('Show on Product Page', [], 'Modules.Productconfigurator.Admin'),
                    'name' => 'show_on_product',
                    'values' => [
                        ['id' => 'show_on_product_on', 'value' => 1, 'label' => $this->trans('Yes', [], 'Admin.Global')],
                        ['id' => 'show_on_product_off', 'value' => 0, 'label' => $this->trans('No', [], 'Admin.Global')],
                    ],
                ],
                [
                    'type' => 'switch',
                    'label' => $this->trans('Show on Cart/Order', [], 'Modules.Productconfigurator.Admin'),
                    'name' => 'show_on_cart',
                    'values' => [
                        ['id' => 'show_on_cart_on', 'value' => 1, 'label' => $this->trans('Yes', [], 'Admin.Global')],
                        ['id' => 'show_on_cart_off', 'value' => 0, 'label' => $this->trans('No', [], 'Admin.Global')],
                    ],
                ],
                [
                    'type' => 'html',
                    'name' => 'validation_section',
                    'html_content' => '<hr><h4>' . $this->trans('Validation Settings (for Number/Range fields)', [], 'Modules.Productconfigurator.Admin') . '</h4>',
                ],
                [
                    'type' => 'text',
                    'label' => $this->trans('Minimum Value', [], 'Modules.Productconfigurator.Admin'),
                    'name' => 'min_value',
                    'class' => 'fixed-width-lg',
                    'hint' => $this->trans('Minimum allowed value', [], 'Modules.Productconfigurator.Admin'),
                ],
                [
                    'type' => 'text',
                    'label' => $this->trans('Maximum Value', [], 'Modules.Productconfigurator.Admin'),
                    'name' => 'max_value',
                    'class' => 'fixed-width-lg',
                    'hint' => $this->trans('Maximum allowed value', [], 'Modules.Productconfigurator.Admin'),
                ],
                [
                    'type' => 'text',
                    'label' => $this->trans('Step Value', [], 'Modules.Productconfigurator.Admin'),
                    'name' => 'step_value',
                    'class' => 'fixed-width-lg',
                    'hint' => $this->trans('Increment step for range sliders', [], 'Modules.Productconfigurator.Admin'),
                ],
                [
                    'type' => 'html',
                    'name' => 'price_section',
                    'html_content' => '<hr><h4>' . $this->trans('Price Settings (Optional)', [], 'Modules.Productconfigurator.Admin') . '</h4>',
                ],
                [
                    'type' => 'text',
                    'label' => $this->trans('Price Impact', [], 'Modules.Productconfigurator.Admin'),
                    'name' => 'price_impact',
                    'class' => 'fixed-width-lg',
                    'hint' => $this->trans('Leave empty if no price impact. For options with individual prices, set them in Options below.', [], 'Modules.Productconfigurator.Admin'),
                    'suffix' => Configuration::get('PS_CURRENCY_DEFAULT') ? Currency::getDefaultCurrency()->sign : '€',
                ],
                [
                    'type' => 'select',
                    'label' => $this->trans('Price Impact Type', [], 'Modules.Productconfigurator.Admin'),
                    'name' => 'price_impact_type',
                    'options' => [
                        'query' => $priceTypes,
                        'id' => 'id',
                        'name' => 'name',
                    ],
                ],
                [
                    'type' => 'text',
                    'label' => $this->trans('Sort Order', [], 'Modules.Productconfigurator.Admin'),
                    'name' => 'sort_order',
                    'class' => 'fixed-width-sm',
                ],
                [
                    'type' => 'switch',
                    'label' => $this->trans('Active', [], 'Admin.Global'),
                    'name' => 'active',
                    'values' => [
                        ['id' => 'active_on', 'value' => 1, 'label' => $this->trans('Yes', [], 'Admin.Global')],
                        ['id' => 'active_off', 'value' => 0, 'label' => $this->trans('No', [], 'Admin.Global')],
                    ],
                ],
            ],
            'submit' => [
                'title' => $this->trans('Save', [], 'Admin.Actions'),
            ],
        ];

        // Add options management for attributes that have options
        if ($this->object && $this->object->id) {
            $this->fields_form['input'][] = [
                'type' => 'html',
                'name' => 'options_section',
                'html_content' => '<hr><h4>' . $this->trans('Attribute Options', [], 'Modules.Productconfigurator.Admin') . '</h4><p class="help-block">' . $this->trans('For Dropdown, Radio, Checkbox, Color Picker, and Image Selector field types', [], 'Modules.Productconfigurator.Admin') . '</p>' . $this->renderOptionsManager(),
            ];
        }

        return parent::renderForm();
    }

    private function renderOptionsManager()
    {
        $idAttribute = (int) Tools::getValue('id_configurator_attribute');
        if (!$idAttribute) {
            return '<div class="alert alert-info">' . $this->trans('Save the attribute first, then you can add options.', [], 'Modules.Productconfigurator.Admin') . '</div>';
        }

        $options = Db::getInstance()->executeS(
            'SELECT o.*, ol.label, ol.description
             FROM `' . _DB_PREFIX_ . 'configurator_attribute_option` o
             LEFT JOIN `' . _DB_PREFIX_ . 'configurator_attribute_option_lang` ol 
                ON ol.id_configurator_option = o.id_configurator_option 
                AND ol.id_lang = ' . (int) $this->context->language->id . '
             WHERE o.id_configurator_attribute = ' . $idAttribute . '
             ORDER BY o.sort_order ASC'
        ) ?: [];

        $html = '<div class="options-manager" id="options-manager">';
        $html .= '<table class="table table-bordered">';
        $html .= '<thead><tr>';
        $html .= '<th>' . $this->trans('Label', [], 'Admin.Global') . '</th>';
        $html .= '<th>' . $this->trans('Color Code', [], 'Modules.Productconfigurator.Admin') . '</th>';
        $html .= '<th>' . $this->trans('Image', [], 'Admin.Global') . '</th>';
        $html .= '<th>' . $this->trans('Price Impact', [], 'Modules.Productconfigurator.Admin') . '</th>';
        $html .= '<th>' . $this->trans('Default', [], 'Admin.Global') . '</th>';
        $html .= '<th>' . $this->trans('Order', [], 'Admin.Global') . '</th>';
        $html .= '<th>' . $this->trans('Active', [], 'Admin.Global') . '</th>';
        $html .= '<th>' . $this->trans('Actions', [], 'Admin.Global') . '</th>';
        $html .= '</tr></thead>';
        $html .= '<tbody id="options-list">';

        foreach ($options as $opt) {
            $html .= $this->renderOptionRow($opt);
        }

        $html .= '</tbody></table>';
        
        $html .= '<button type="button" class="btn btn-success" id="add-option-btn">';
        $html .= '<i class="icon-plus"></i> ' . $this->trans('Add Option', [], 'Modules.Productconfigurator.Admin');
        $html .= '</button>';
        
        $html .= '</div>';

        // Add JavaScript for option management
        $html .= $this->getOptionsJs($idAttribute);

        return $html;
    }

    private function renderOptionRow($opt, $isNew = false)
    {
        $id = $isNew ? 'new_' . time() : $opt['id_configurator_option'];
        $prefix = 'option[' . $id . ']';

        $html = '<tr class="option-row" data-id="' . $id . '">';
        $html .= '<td><input type="text" name="' . $prefix . '[label]" value="' . htmlspecialchars($opt['label'] ?? '') . '" class="form-control" required></td>';
        $html .= '<td><input type="color" name="' . $prefix . '[color_code]" value="' . htmlspecialchars($opt['color_code'] ?? '#ffffff') . '" class="form-control" style="width:60px;"></td>';
        $html .= '<td><input type="text" name="' . $prefix . '[image]" value="' . htmlspecialchars($opt['image'] ?? '') . '" class="form-control" placeholder="URL or upload"></td>';
        $html .= '<td><input type="number" name="' . $prefix . '[price_impact]" value="' . htmlspecialchars($opt['price_impact'] ?? '') . '" class="form-control" step="0.01"></td>';
        $html .= '<td class="text-center"><input type="radio" name="default_option" value="' . $id . '" ' . (!empty($opt['is_default']) ? 'checked' : '') . '></td>';
        $html .= '<td><input type="number" name="' . $prefix . '[sort_order]" value="' . htmlspecialchars($opt['sort_order'] ?? 0) . '" class="form-control" style="width:60px;"></td>';
        $html .= '<td class="text-center"><input type="checkbox" name="' . $prefix . '[active]" value="1" ' . (!isset($opt['active']) || $opt['active'] ? 'checked' : '') . '></td>';
        $html .= '<td><button type="button" class="btn btn-danger btn-xs remove-option"><i class="icon-trash"></i></button></td>';
        $html .= '</tr>';

        return $html;
    }

    private function getOptionsJs($idAttribute)
    {
        return '<script>
        $(document).ready(function() {
            var optionCounter = 0;
            
            $("#add-option-btn").click(function() {
                optionCounter++;
                var newId = "new_" + optionCounter;
                var row = \'<tr class="option-row" data-id="\' + newId + \'">\' +
                    \'<td><input type="text" name="option[\' + newId + \'][label]" value="" class="form-control" required></td>\' +
                    \'<td><input type="color" name="option[\' + newId + \'][color_code]" value="#ffffff" class="form-control" style="width:60px;"></td>\' +
                    \'<td><input type="text" name="option[\' + newId + \'][image]" value="" class="form-control" placeholder="URL"></td>\' +
                    \'<td><input type="number" name="option[\' + newId + \'][price_impact]" value="" class="form-control" step="0.01"></td>\' +
                    \'<td class="text-center"><input type="radio" name="default_option" value="\' + newId + \'"></td>\' +
                    \'<td><input type="number" name="option[\' + newId + \'][sort_order]" value="0" class="form-control" style="width:60px;"></td>\' +
                    \'<td class="text-center"><input type="checkbox" name="option[\' + newId + \'][active]" value="1" checked></td>\' +
                    \'<td><button type="button" class="btn btn-danger btn-xs remove-option"><i class="icon-trash"></i></button></td>\' +
                    \'</tr>\';
                $("#options-list").append(row);
            });

            $(document).on("click", ".remove-option", function() {
                var row = $(this).closest("tr");
                var id = row.data("id");
                if (id && !String(id).startsWith("new_")) {
                    // Mark existing option for deletion
                    row.hide();
                    row.append(\'<input type="hidden" name="delete_option[]" value="\' + id + \'">\');
                } else {
                    row.remove();
                }
            });
        });
        </script>';
    }

    public function postProcess()
    {
        if (Tools::isSubmit('submitAdd' . $this->table)) {
            // Handle options save after parent processes
            $result = parent::postProcess();
            
            if ($result && $this->object && $this->object->id) {
                $this->saveOptions($this->object->id);
            }
            
            return $result;
        }

        return parent::postProcess();
    }

    private function saveOptions($idAttribute)
    {
        $options = (array) Tools::getValue('option', []);
        $deleteOptions = (array) Tools::getValue('delete_option', []);
        $defaultOption = Tools::getValue('default_option');
        $idLang = (int) $this->context->language->id;

        // Delete marked options
        foreach ($deleteOptions as $optId) {
            Db::getInstance()->delete('configurator_attribute_option', 'id_configurator_option = ' . (int) $optId);
            Db::getInstance()->delete('configurator_attribute_option_lang', 'id_configurator_option = ' . (int) $optId);
        }

        // Save/update options
        foreach ($options as $optId => $optData) {
            $isNew = strpos($optId, 'new_') === 0;
            $isDefault = ($defaultOption == $optId) ? 1 : 0;

            $data = [
                'id_configurator_attribute' => (int) $idAttribute,
                'color_code' => pSQL($optData['color_code'] ?? ''),
                'image' => pSQL($optData['image'] ?? ''),
                'price_impact' => !empty($optData['price_impact']) ? (float) $optData['price_impact'] : null,
                'price_impact_type' => 'fixed',
                'is_default' => $isDefault,
                'sort_order' => (int) ($optData['sort_order'] ?? 0),
                'active' => isset($optData['active']) ? 1 : 0,
            ];

            if ($isNew) {
                // Insert new option
                Db::getInstance()->insert('configurator_attribute_option', $data);
                $newOptId = Db::getInstance()->Insert_ID();

                // Insert lang
                Db::getInstance()->insert('configurator_attribute_option_lang', [
                    'id_configurator_option' => (int) $newOptId,
                    'id_lang' => $idLang,
                    'label' => pSQL($optData['label'] ?? ''),
                    'description' => pSQL($optData['description'] ?? ''),
                ]);
            } else {
                // Update existing option
                Db::getInstance()->update('configurator_attribute_option', $data, 'id_configurator_option = ' . (int) $optId);

                // Update lang
                $langExists = Db::getInstance()->getRow(
                    'SELECT * FROM `' . _DB_PREFIX_ . 'configurator_attribute_option_lang` 
                     WHERE id_configurator_option = ' . (int) $optId . ' AND id_lang = ' . $idLang
                );

                if ($langExists) {
                    Db::getInstance()->update('configurator_attribute_option_lang', [
                        'label' => pSQL($optData['label'] ?? ''),
                        'description' => pSQL($optData['description'] ?? ''),
                    ], 'id_configurator_option = ' . (int) $optId . ' AND id_lang = ' . $idLang);
                } else {
                    Db::getInstance()->insert('configurator_attribute_option_lang', [
                        'id_configurator_option' => (int) $optId,
                        'id_lang' => $idLang,
                        'label' => pSQL($optData['label'] ?? ''),
                        'description' => pSQL($optData['description'] ?? ''),
                    ]);
                }
            }
        }
    }

    public function setMedia($isNewTheme = false)
    {
        parent::setMedia($isNewTheme);
        
        $this->addCSS(_PS_MODULE_DIR_ . 'productconfigurator/views/css/admin.css');
    }
}
