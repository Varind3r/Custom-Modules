<?php
/**
 * Frontend controller for Product Configurator
 * Provides JSON endpoint for configurator data
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class ProductConfiguratorConfiguratorModuleFrontController extends ModuleFrontController
{
    public function init()
    {
        parent::init();
        $this->ajax = true;
    }

    public function initContent()
    {
        parent::initContent();
        
        $idProduct = (int)Tools::getValue('id_product');
        
        if (!$idProduct) {
            $this->ajaxDie(json_encode(['error' => 'Product ID required']));
        }

        // Build configurator JSON
        $config = ConfiguratorJsonBuilder::buildForProduct($idProduct, $this->context->language->id);
        
        header('Content-Type: application/json');
        $this->ajaxDie(json_encode($config));
    }
}
?>
