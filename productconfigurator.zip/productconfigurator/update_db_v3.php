<?php
require_once dirname(__FILE__).'/../../config/config.inc.php';
require_once dirname(__FILE__).'/../../init.php';

$db = Db::getInstance();

echo "Updating database schema for Phase 3 (Pricing Logic)...\n";

// Add dimension_type to ps_configurator_attribute
// values: 'none', 'width', 'height', 'depth'
$check = $db->getValue("SELECT count(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = '"._DB_NAME_."' AND TABLE_NAME = '"._DB_PREFIX_."configurator_attribute' AND COLUMN_NAME = 'dimension_type'");

if (!$check) {
    if ($db->execute("ALTER TABLE `"._DB_PREFIX_."configurator_attribute` ADD COLUMN `dimension_type` VARCHAR(20) DEFAULT 'none'")) {
        echo "[OK] Added 'dimension_type' to attribute table.\n";
    } else {
        echo "[ERROR] Failed to add 'dimension_type': " . $db->getMsgError() . "\n";
    }
} else {
    echo "[SKIP] 'dimension_type' already exists.\n";
}

echo "Database update complete.\n";
