# Product Configurator Module - Architecture & Relationships

## 📐 HIERARCHY EXPLANATION

```
Product (e.g., "Custom Window")
 └─ Configurator (enabled = true/false per product)
     └─ Steps/Groups (e.g., "Material", "Dimensions", "Installation")
         └─ Fields/Attributes (e.g., "Material Type", "Width", "Height")
             └─ Options/Choices (e.g., "PVC", "Wood", "Aluminum")
```

## 🔗 RELATIONSHIP DIAGRAM

### Global Content (CMS-like, reusable across products)

```
configurator_group (Steps)
    ├─ id_configurator_group
    ├─ name (multilang)
    └─ description (multilang)
         │
         │ (1 → N via configurator_group_attribute)
         │
         ▼
configurator_attribute (Fields)
    ├─ id_configurator_attribute
    ├─ field_type (radio_image, radio_text, dropdown, text, number, file)
    ├─ name (multilang)
    └─ description (multilang)
         │
         │ (1 → N via configurator_attribute_option)
         │
         ▼
configurator_attribute_option (Options)
    ├─ id_configurator_option
    ├─ id_configurator_attribute (FK)
    ├─ label (multilang)
    ├─ image
    ├─ price_impact
    └─ dependencies (JSON)
```

### Product Assignment (Product-specific)

```
Product
    │
    │ (1 → N via configurator_product_group)
    │
    ▼
configurator_product_group
    ├─ id_product
    ├─ id_configurator_group (which Step to show)
    └─ sort_order (step order for this product)
         │
         │ (Product can override option prices)
         │
         ▼
configurator_product_option_value
    ├─ id_product
    ├─ id_configurator_option
    ├─ price_impact (override)
    └─ is_available
```

## 🎯 KEY CONCEPTS

### 1. Steps (Groups) = Wizard Pages
- **Purpose**: Organize fields into logical steps
- **Example**: "Step 1: Choose Material", "Step 2: Enter Dimensions"
- **Global**: Created once, reused across products
- **Product Assignment**: Products select which steps to show and in what order

### 2. Fields (Attributes) = Input Controls
- **Purpose**: The actual form fields users interact with
- **Types**:
  - `radio_image`: Radio buttons with images
  - `radio_text`: Radio buttons with text labels
  - `dropdown`: Select dropdown
  - `text`: Text input
  - `number`: Number input
  - `file`: File upload
- **Belongs to**: One Step (via `configurator_group_attribute`)
- **Global**: Created once, assigned to steps

### 3. Options (Choices) = Field Values
- **Purpose**: Predefined choices for fields that need them
- **Only for**: `radio_*`, `dropdown`, `checkbox` field types
- **Not needed for**: `text`, `number`, `file` (user enters value)
- **Belongs to**: One Field (via `id_configurator_attribute`)
- **Can have**: Images, prices, dependencies

## 🔄 DATA FLOW

### Back Office Flow:
1. **Admin creates Steps** (e.g., "Material", "Dimensions")
2. **Admin creates Fields** (e.g., "Material Type", "Width")
3. **Admin assigns Fields to Steps** (via `configurator_group_attribute`)
4. **Admin creates Options** for Fields that need them (e.g., "PVC", "Wood" for "Material Type")
5. **Admin edits Product** → Assigns Steps to Product → Sets step order

### Front Office Flow:
1. **Product page loads** → Check if configurator enabled
2. **Build JSON structure**:
   - Get product's assigned steps (from `configurator_product_group`)
   - For each step, get its fields (from `configurator_group_attribute`)
   - For each field, get its options (from `configurator_attribute_option`)
   - Apply product-specific price overrides (from `configurator_product_option_value`)
3. **Render wizard** → One step at a time
4. **User selects options** → Validate → Calculate price → Show next step
5. **Add to cart** → Store full configuration JSON

## 📊 EXAMPLE STRUCTURE

### Database Example:

**Step 1: "Material"**
- Field 1: "Material Type" (radio_image)
  - Option 1: "PVC" (image: pvc.jpg, price: +10)
  - Option 2: "Wood" (image: wood.jpg, price: +20)
  - Option 3: "Aluminum" (image: aluminum.jpg, price: +30)

**Step 2: "Dimensions"**
- Field 2: "Width" (number, required, min: 10, max: 200)
- Field 3: "Height" (number, required, min: 10, max: 200)

**Product Assignment:**
- Product #14 assigns Step 1 (sort_order: 0) and Step 2 (sort_order: 1)
- Product #14 overrides "Wood" option price to +25 (instead of default +20)

### Frontend JSON Output:

```json
{
  "steps": [
    {
      "id": 1,
      "name": "Material",
      "fields": [
        {
          "id": 10,
          "type": "radio_image",
          "name": "Material Type",
          "is_required": true,
          "options": [
            {
              "id": 100,
              "label": "PVC",
              "image": "/img/pvc.jpg",
              "price": 10,
              "dependencies": {}
            },
            {
              "id": 101,
              "label": "Wood",
              "image": "/img/wood.jpg",
              "price": 25,
              "dependencies": {}
            }
          ]
        }
      ]
    },
    {
      "id": 2,
      "name": "Dimensions",
      "fields": [
        {
          "id": 20,
          "type": "number",
          "name": "Width",
          "is_required": true,
          "min_value": 10,
          "max_value": 200
        }
      ]
    }
  ]
}
```

## ⚠️ IMPORTANT RULES

1. **Products assign Steps, NOT Fields directly**
   - Use `configurator_product_group` table
   - Fields come automatically via the Step → Field relationship

2. **Field Types determine if Options are needed:**
   - **Need Options**: `radio_image`, `radio_text`, `dropdown`, `checkbox`
   - **No Options**: `text`, `number`, `file` (user enters value)

3. **Price Calculation:**
   - Base product price
   + Sum of selected option prices (with product overrides)
   + Formula pricing (if enabled)

4. **Dependencies:**
   - Stored as JSON in `configurator_attribute_option.dependencies`
   - Format: `{"show_steps": [2, 3], "hide_fields": [5]}`

