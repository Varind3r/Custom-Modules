/**
 * Product Configurator - Frontend JavaScript
 * Handles live price calculation, form validation, and Step Navigation
 */

(function () {
    'use strict';

    var ProductConfigurator = {
        container: null,
        basePrice: 0,
        currencySign: '€',
        pricingMode: 'additive',

        init: function () {
            this.container = document.getElementById('product-configurator');
            if (!this.container) return;

            this.getBasePrice();
            this.bindEvents();
            this.bindNavigation(); // NEW
            this.calculatePrice();
        },

        getBasePrice: function () {
            // Get base price from PrestaShop's product price element
            var priceElement = document.querySelector('.current-price .price, .product-price .price');
            if (priceElement) {
                var priceText = priceElement.textContent || priceElement.innerText;
                this.basePrice = parseFloat(priceText.replace(/[^0-9.,]/g, '').replace(',', '.')) || 0;
            }

            // Get currency sign
            var currencyElement = document.querySelector('[itemprop="priceCurrency"]');
            if (currencyElement) {
                this.currencySign = currencyElement.getAttribute('content') || '€';
            }

            // Update base price display
            var basePriceEl = document.getElementById('configurator-base-price');
            if (basePriceEl) {
                basePriceEl.textContent = this.formatPrice(this.basePrice);
            }
        },

        bindEvents: function () {
            var self = this;

            // Bind to all configurator inputs
            // Note: selector finds inputs no matter where they are nested
            var inputs = this.container.querySelectorAll('input, select, textarea');
            inputs.forEach(function (input) {
                input.addEventListener('change', function () {
                    self.calculatePrice();
                    self.updateDataField();
                });
                input.addEventListener('input', function () {
                    self.calculatePrice();
                    self.updateDataField();
                });
            });

            // Range slider value display
            var ranges = this.container.querySelectorAll('.configurator-range');
            ranges.forEach(function (range) {
                var valueDisplay = range.parentElement.querySelector('.range-value');
                range.addEventListener('input', function () {
                    if (valueDisplay) {
                        valueDisplay.textContent = this.value;
                    }
                });
            });

            // Form submission validation
            var addToCartForm = document.querySelector('#add-to-cart-or-refresh, .add-to-cart');
            if (addToCartForm) {
                addToCartForm.addEventListener('submit', function (e) {
                    if (!self.validateForm()) {
                        e.preventDefault();
                        self.showValidationErrors();
                    }
                });
            }
        },

        // NEW: Sidebar Navigation Logic
        bindNavigation: function () {
            var self = this;
            var navLinks = this.container.querySelectorAll('.step-link');
            var sections = this.container.querySelectorAll('.configurator-step-section');

            // Smooth Scroll on Click
            navLinks.forEach(function (link) {
                link.addEventListener('click', function (e) {
                    e.preventDefault();
                    var targetId = this.getAttribute('data-target');
                    var targetSection = document.querySelector(targetId);

                    if (targetSection) {
                        // Offset for sticky headers if any (adjust 100 as needed)
                        var offsetTop = targetSection.getBoundingClientRect().top + window.pageYOffset - 100;
                        window.scrollTo({
                            top: offsetTop,
                            behavior: 'smooth'
                        });
                    }
                });
            });

            // Scroll Spy (Highlight active section)
            window.addEventListener('scroll', function () {
                var scrollPosition = window.scrollY + 200; // Offset

                sections.forEach(function (section) {
                    var sectionTop = section.offsetTop;
                    var sectionHeight = section.offsetHeight;
                    var sectionId = '#' + section.id;

                    if (scrollPosition >= sectionTop && scrollPosition < (sectionTop + sectionHeight)) {
                        navLinks.forEach(function (link) {
                            link.parentElement.classList.remove('active');
                            if (link.getAttribute('data-target') === sectionId) {
                                link.parentElement.classList.add('active');
                            }
                        });
                    }
                });
            });
        },

        calculatePrice: function () {
            var optionsTotal = 0;
            var fields = this.container.querySelectorAll('.configurator-field');

            fields.forEach(function (field) {
                var fieldType = field.dataset.fieldType;
                var basePriceImpact = parseFloat(field.dataset.priceImpact) || 0; // Field level price

                // Add base field price impact if value is present
                // Simplify: If it's a field that holds a value, and it has a value, add base price
                var hasValue = false;
                var input = field.querySelector('input, select, textarea');
                if (input) {
                    if (fieldType === 'checkbox' || fieldType === 'radio') {
                        if (field.querySelector('input:checked')) hasValue = true;
                    } else if (input.value) {
                        hasValue = true;
                    }
                }

                if (hasValue && basePriceImpact !== 0) {
                    optionsTotal += basePriceImpact;
                }


                // Calculate based on selected options (Option level price)
                if (fieldType === 'dropdown') {
                    var select = field.querySelector('select');
                    if (select && select.selectedIndex > 0) {
                        var selectedOption = select.options[select.selectedIndex];
                        optionsTotal += parseFloat(selectedOption.dataset.price) || 0;
                    }
                } else if (fieldType === 'radio' || fieldType === 'color_picker' || fieldType === 'image_selector') {
                    var checked = field.querySelector('input:checked');
                    if (checked) {
                        optionsTotal += parseFloat(checked.dataset.price) || 0;
                    }
                } else if (fieldType === 'checkbox') {
                    var checkboxes = field.querySelectorAll('input:checked');
                    checkboxes.forEach(function (cb) {
                        optionsTotal += parseFloat(cb.dataset.price) || 0;
                    });
                }
            });

            // Update price display
            var optionsPriceEl = document.getElementById('configurator-options-price');
            var totalPriceEl = document.getElementById('configurator-total-price');
            // Also update any other total price display in sidebar
            var sidebarTotalEl = document.querySelector('.sidebar-price-summary .total-price .price-value');

            var totalPrice = this.basePrice + optionsTotal;

            if (optionsPriceEl) {
                optionsPriceEl.textContent = '+' + this.formatPrice(optionsTotal);
            }
            if (totalPriceEl) {
                totalPriceEl.textContent = this.formatPrice(totalPrice);
            }
            if (sidebarTotalEl) {
                sidebarTotalEl.textContent = this.formatPrice(totalPrice);
            }

            // Update main product price (optional, works if theme uses standard selectors)
            this.updateMainPrice(totalPrice);

            return totalPrice;
        },

        updateMainPrice: function (newPrice) {
            // Update the main product price display
            var priceElement = document.querySelector('.current-price .price');
            // Try fallback selectors for different themes
            if (!priceElement) priceElement = document.querySelector('.product-price .price');
            if (!priceElement) priceElement = document.querySelector('#our_price_display'); // classic 1.6 style

            if (priceElement) {
                priceElement.textContent = this.formatPrice(newPrice);
            }
        },

        formatPrice: function (price) {
            // Basic formatting - ideally should use PrestaShop's formatCurrency if available globally
            return price.toFixed(2) + ' ' + this.currencySign;
        },

        validateForm: function () {
            var valid = true;
            var requiredFields = this.container.querySelectorAll('.configurator-field[data-required="1"]');

            requiredFields.forEach(function (field) {
                var fieldType = field.dataset.fieldType;
                var hasValue = false;

                if (fieldType === 'dropdown') {
                    var select = field.querySelector('select');
                    hasValue = select && select.value !== '';
                } else if (fieldType === 'radio' || fieldType === 'color_picker' || fieldType === 'image_selector') {
                    hasValue = field.querySelector('input:checked') !== null;
                } else if (fieldType === 'checkbox') {
                    hasValue = field.querySelector('input:checked') !== null;
                } else {
                    var input = field.querySelector('input, textarea');
                    hasValue = input && input.value.trim() !== '';
                }

                if (!hasValue) {
                    valid = false;
                    field.classList.add('has-error');
                    // Add visual error cue
                    field.style.border = "1px solid red";
                } else {
                    field.classList.remove('has-error');
                    field.style.border = "none";
                }
            });

            return valid;
        },

        showValidationErrors: function () {
            var errorField = this.container.querySelector('.has-error');
            if (errorField) {
                errorField.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }

            // Show alert
            // alert('Please fill in all required fields.'); // Use less intrusive notification or existing one
        },

        updateDataField: function () {
            var data = this.collectFormData();
            var dataField = document.getElementById('configurator-data-field');
            if (dataField) {
                dataField.value = JSON.stringify(data);
            }
        },

        collectFormData: function () {
            var data = {};
            // Simplified collection logic
            var inputs = this.container.querySelectorAll('input, select, textarea');
            inputs.forEach(function (input) {
                // Determine attribute ID from name "configurator[ID]"
                var match = input.name.match(/configurator\[(\d+)\]/);
                if (match) {
                    var attrId = match[1];
                    var val = null;

                    if (input.type === 'radio' || input.type === 'checkbox') {
                        if (input.checked) val = input.value;
                    } else {
                        val = input.value;
                    }

                    if (val) {
                        if (input.type === 'checkbox') {
                            if (!data[attrId]) data[attrId] = [];
                            data[attrId].push(val);
                        } else {
                            data[attrId] = val;
                        }
                    }
                }
            });
            return data;
        }
    };

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () {
            ProductConfigurator.init();
        });
    } else {
        ProductConfigurator.init();
    }

    // Expose for external use
    window.ProductConfigurator = ProductConfigurator;

})();
