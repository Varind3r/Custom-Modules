/**
 * Admin Attribute Form JS
 */
$(document).ready(function () {
    function toggleDimensions() {
        var type = $('#field_type_selector').val();
        if (type === 'dimensions') {
            $('.hide_unless_dimensions').closest('.form-group').show();
        } else {
            $('.hide_unless_dimensions').closest('.form-group').hide();
        }
    }

    // Initial check
    toggleDimensions();

    // On change
    $(document).on('change', '#field_type_selector', function () {
        toggleDimensions();
    });
});
