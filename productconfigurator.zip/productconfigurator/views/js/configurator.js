/**
 * Product Configurator - Frontend JavaScript
 * Handles wizard display, validation, dependencies, and price calculation
 */

(function () {
    'use strict';

    class ProductConfigurator {
        constructor(container) {
            this.container = container;
            this.productId = container.dataset.productId;
            this.config = JSON.parse(container.querySelector('#configurator-steps').dataset.config);
            this.currentStep = 0;
            this.selections = {};
            this.price = 0;

            this.init();
        }

        init() {
            this.renderSteps();
            this.attachEvents();
            this.updatePrice();
            this.updatePreviewImage();
        }

        renderSteps() {
            const stepsContainer = this.container.querySelector('#configurator-steps');
            stepsContainer.innerHTML = '';

            this.config.steps.forEach((step, index) => {
                const stepEl = this.createStepElement(step, index);
                stepsContainer.appendChild(stepEl);
            });

            this.showStep(0);
        }

        createStepElement(step, index) {
            const stepDiv = document.createElement('div');
            stepDiv.className = 'configurator-step';
            stepDiv.dataset.stepId = step.id;
            stepDiv.dataset.stepIndex = index;
            if (index > 0) {
                stepDiv.style.display = 'none';
            }

            let html = `
                <div class="step-header">
                    <h3>${this.escapeHtml(step.name)}</h3>
                    ${step.description ? `<p>${this.escapeHtml(step.description)}</p>` : ''}
                </div>
                <div class="step-fields">
            `;

            step.fields.forEach(field => {
                html += this.renderField(field);
            });

            html += `
                </div>
                <div class="step-actions">
                    ${index > 0 ? '<button type="button" class="btn btn-secondary step-prev">Previous</button>' : ''}
                    ${index < this.config.steps.length - 1 ? '<button type="button" class="btn btn-primary step-next" disabled>Next</button>' : ''}
                    ${index === this.config.steps.length - 1 ? '<button type="button" class="btn btn-success add-to-cart" disabled>Add to Cart</button>' : ''}
                </div>
            `;

            stepDiv.innerHTML = html;
            return stepDiv;
        }

        renderField(field) {
            let html = `<div class="configurator-field" data-field-id="${field.id}" data-field-type="${field.type}">`;
            html += `<label>${this.escapeHtml(field.name)}${field.is_required ? ' <span class="required">*</span>' : ''}</label>`;

            if (field.type === 'radio_image' || field.type === 'radio_text' || field.type === 'radio_color') {
                html += this.renderRadioField(field);
            } else if (field.type === 'dropdown') {
                html += this.renderDropdownField(field);
            } else if (field.type === 'text' || field.type === 'number') {
                html += this.renderInputField(field);
            } else if (field.type === 'file') {
                html += this.renderFileField(field);
            } else if (field.type === 'dimensions') {
                html += this.renderDimensionsField(field);
            }

            html += `</div>`;
            return html;
        }

        renderRadioField(field) {
            let html = '<div class="field-options card-grid">'; // Added card-grid class
            field.options.forEach(option => {
                const isImage = field.type === 'radio_image' && option.image;
                const isColor = field.type === 'radio_color' && option.color_code;

                // Parse features
                let featuresHtml = '';
                if (option.features) {
                    let features = [];
                    try {
                        // Try parsing as JSON first
                        features = JSON.parse(option.features);
                    } catch (e) {
                        // Fallback to newline split
                        features = option.features.split('\n');
                    }

                    if (Array.isArray(features) && features.length > 0) {
                        featuresHtml = '<ul class="option-features">';
                        features.forEach(feat => {
                            if (feat && feat.trim()) featuresHtml += `<li><i class="icon-check"></i> ${this.escapeHtml(feat)}</li>`;
                        });
                        featuresHtml += '</ul>';
                    } else {
                        // If it's just a string string (HTML likely)
                        featuresHtml = `<div class="option-features-text">${option.features}</div>`;
                    }
                }

                let extraClass = '';
                if (isImage) extraClass = 'option-image';
                if (isColor) extraClass = 'option-color';
                if (option.badge) extraClass += ' has-badge';

                html += `
                    <label class="option-card ${extraClass}">
                        <input type="radio" name="field_${field.id}" value="${option.id}" data-option-id="${option.id}">
                        
                        ${option.badge ? `<span class="option-badge">${this.escapeHtml(option.badge)}</span>` : ''}

                        ${isImage ? `<div class="option-img-wrapper"><img src="${this.escapeHtml(option.image)}" alt="${this.escapeHtml(option.label)}"></div>` : ''}
                        
                        ${isColor ? `<span class="color-preview" style="background-color: ${this.escapeHtml(option.color_code)}"></span>` : ''}

                        <div class="option-details">
                            <span class="option-label">${this.escapeHtml(option.label)}</span>
                            ${option.description ? `<div class="option-desc">${this.escapeHtml(option.description)}</div>` : ''}
                            ${featuresHtml}
                            ${option.price ? `<span class="option-price">+${this.formatPrice(option.price)}</span>` : ''}
                        </div>
                    </label>
                `;
            });
            html += '</div>';
            return html;
        }

        renderDropdownField(field) {
            let html = `<select name="field_${field.id}" class="form-control">`;
            html += '<option value="">-- Select --</option>';
            field.options.forEach(option => {
                html += `<option value="${option.id}" data-option-id="${option.id}">${this.escapeHtml(option.label)}${option.price ? ` (+${this.formatPrice(option.price)})` : ''}</option>`;
            });
            html += '</select>';
            return html;
        }

        renderInputField(field) {
            const inputType = field.type === 'number' ? 'number' : 'text';
            let attrs = `type="${inputType}" name="field_${field.id}" class="form-control"`;
            if (field.is_required) attrs += ' required';
            if (field.min_value !== undefined) attrs += ` min="${field.min_value}"`;
            if (field.max_value !== undefined) attrs += ` max="${field.max_value}"`;
            if (field.step_value !== undefined) attrs += ` step="${field.step_value}"`;
            if (field.placeholder) attrs += ` placeholder="${this.escapeHtml(field.placeholder)}"`;
            if (field.suffix) {
                return `<div class="input-group"><input ${attrs}><span class="input-group-text">${this.escapeHtml(field.suffix)}</span></div>`;
            }
            return `<input ${attrs}>`;
        }

        renderFileField(field) {
            return `<input type="file" name="field_${field.id}" class="form-control" ${field.is_required ? 'required' : ''}>`;
        }

        renderDimensionsField(field) {
            let html = '<div class="row dimensions-container">';
            // Width Input
            html += `
                <div class="col-md-6 form-group">
                    <label class="small text-muted">Width (mm)</label>
                    <input type="number" 
                           class="form-control dimension-part" 
                           data-parent-field="${field.id}" 
                           data-dim-type="width"
                           min="${field.min_width || 0}" 
                           max="${field.max_width || 99999}" 
                           placeholder="${field.min_width ? 'Min: ' + field.min_width : ''}"
                           ${field.is_required ? 'required' : ''}>
                </div>`;

            // Height Input
            html += `
                <div class="col-md-6 form-group">
                    <label class="small text-muted">Height (mm)</label>
                    <input type="number" 
                           class="form-control dimension-part" 
                           data-parent-field="${field.id}" 
                           data-dim-type="height"
                           min="${field.min_height || 0}" 
                           max="${field.max_height || 99999}" 
                           placeholder="${field.min_height ? 'Min: ' + field.min_height : ''}"
                           ${field.is_required ? 'required' : ''}>
                </div>`;

            html += '</div>';
            return html;
        }

        attachEvents() {
            this.container.addEventListener('change', (e) => {
                if (e.target.matches('input[type="radio"], select, input[type="text"], input[type="number"]')) {
                    this.handleFieldChange(e.target);
                }
            });

            this.container.addEventListener('click', (e) => {
                if (e.target.matches('.step-next')) {
                    this.nextStep();
                } else if (e.target.matches('.step-prev')) {
                    this.prevStep();
                } else if (e.target.matches('.add-to-cart')) {
                    this.addToCart();
                }
            });
        }

        handleFieldChange(input) {
            const fieldId = input.name.replace('field_', '');
            const field = this.getFieldById(parseInt(fieldId));

            if (!field) return;

            let value = input.value;
            if (input.classList.contains('dimension-part')) {
                // Handle composite dimension logic
                const parentId = input.dataset.parentField;
                const container = this.container.querySelector(`.configurator-field[data-field-id="${parentId}"]`);
                const wInput = container.querySelector('[data-dim-type="width"]');
                const hInput = container.querySelector('[data-dim-type="height"]');

                const w = parseFloat(wInput.value) || 0;
                const h = parseFloat(hInput.value) || 0;

                // Only store if valid or partial? Valid stores objects.
                if (w > 0 && h > 0) {
                    this.selections[parentId] = { width: w, height: h };
                } else {
                    delete this.selections[parentId]; // Incomplete
                }

                // Trigger update
                this.validateCurrentStep();
                this.updatePrice();
                this.updateSummary();
                return; // Special case handled
            }

            if (input.type === 'radio') {
                value = input.checked ? parseInt(input.value) : null;
            } else if (input.type === 'number') {
                value = parseFloat(value) || null;
            }

            if (value) {
                this.selections[fieldId] = value;

                // Handle dependencies
                if (input.type === 'radio' && input.checked) {
                    const optionId = parseInt(input.value);
                    this.handleDependencies(optionId);
                }
            } else {
                delete this.selections[fieldId];
            }

            this.validateCurrentStep();
            this.updatePrice();
            this.updateSummary();
            this.updatePreviewImage();
        }

        updatePreviewImage() {
            const imgEl = this.container.querySelector('#preview-image');
            const placeholderEl = this.container.querySelector('#preview-placeholder');
            if (!imgEl) return;

            let lastImage = null;

            // Iterate through assigned steps to find the last selected option with an image
            this.config.steps.forEach(step => {
                step.fields.forEach(field => {
                    const selection = this.selections[field.id];
                    if (selection && field.options) {
                        const option = field.options.find(opt => opt.id === selection);
                        if (option && option.image) {
                            lastImage = option.image;
                        }
                    }
                });
            });

            if (lastImage) {
                imgEl.src = lastImage;
                imgEl.style.display = 'inline-block';
                if (placeholderEl) placeholderEl.style.display = 'none';
            } else {
                imgEl.style.display = 'none';
                if (placeholderEl) placeholderEl.style.display = 'block';
            }
        }

        handleDependencies(optionId) {
            const option = this.getOptionById(optionId);
            if (!option || !option.dependencies) return;

            const deps = option.dependencies;

            // Show/hide steps
            if (deps.show_steps) {
                deps.show_steps.forEach(stepId => {
                    const stepEl = this.container.querySelector(`[data-step-id="${stepId}"]`);
                    if (stepEl) stepEl.style.display = '';
                });
            }
            if (deps.hide_steps) {
                deps.hide_steps.forEach(stepId => {
                    const stepEl = this.container.querySelector(`[data-step-id="${stepId}"]`);
                    if (stepEl) stepEl.style.display = 'none';
                });
            }

            // Show/hide fields
            if (deps.show_fields) {
                deps.show_fields.forEach(fieldId => {
                    const fieldEl = this.container.querySelector(`[data-field-id="${fieldId}"]`);
                    if (fieldEl) fieldEl.style.display = '';
                });
            }
            if (deps.hide_fields) {
                deps.hide_fields.forEach(fieldId => {
                    const fieldEl = this.container.querySelector(`[data-field-id="${fieldId}"]`);
                    if (fieldEl) fieldEl.style.display = 'none';
                });
            }
        }

        validateCurrentStep() {
            const step = this.config.steps[this.currentStep];
            let isValid = true;

            step.fields.forEach(field => {
                if (field.is_required && !this.selections[field.id]) {
                    isValid = false;
                }
            });

            const nextBtn = this.container.querySelector('.step-next');
            const addBtn = this.container.querySelector('.add-to-cart');

            if (nextBtn) nextBtn.disabled = !isValid;
            if (addBtn && this.currentStep === this.config.steps.length - 1) {
                addBtn.disabled = !isValid;
            }
        }

        showStep(index) {
            const steps = this.container.querySelectorAll('.configurator-step');
            steps.forEach((step, i) => {
                step.style.display = i === index ? 'block' : 'none';
            });
            this.currentStep = index;
            this.validateCurrentStep();
        }

        nextStep() {
            if (this.currentStep < this.config.steps.length - 1) {
                this.showStep(this.currentStep + 1);
            }
        }

        prevStep() {
            if (this.currentStep > 0) {
                this.showStep(this.currentStep - 1);
            }
        }

        updatePrice() {
            // 1. Calculate Dimensions (Area / Perimeter)
            let width = 0;
            let height = 0;

            // Check old style (separate fields)
            this.config.steps.forEach(step => {
                step.fields.forEach(field => {
                    if (this.selections[field.id]) {
                        if (field.dimension_type === 'width') width = parseFloat(this.selections[field.id]) || 0;
                        if (field.dimension_type === 'height') height = parseFloat(this.selections[field.id]) || 0;
                    }
                });
            });

            // Iterate selections to find composite dimensions (New V4 Logic)
            Object.keys(this.selections).forEach(fieldId => {
                const val = this.selections[fieldId];
                if (val && typeof val === 'object' && val.width && val.height) {
                    width = val.width;
                    height = val.height;
                }
            });

            // Convert mm to m
            const widthM = width / 1000;
            const heightM = height / 1000;
            const area = widthM * heightM;
            const perimeter = 2 * (widthM + heightM);

            console.log(`Dimensions: ${width}x${height} mm. Area: ${area.toFixed(2)} m2`);

            // 2. Calculate Total Price (Options + Fields)
            let totalPrice = 0;

            Object.keys(this.selections).forEach(fieldId => {
                const field = this.getFieldById(parseInt(fieldId));
                if (!field) return;

                // 2a. Field-level Price Impact
                if (field.price && field.price !== 0) {
                    totalPrice += parseFloat(field.price);
                }

                // 2b. Option Price Impacts
                if (field.options) {
                    const val = this.selections[fieldId];
                    if (typeof val === 'object') return; // Skip composite values for standard pricing

                    const option = field.options.find(opt => opt.id === val);
                    if (option && option.price) {
                        let impact = parseFloat(option.price);

                        if (option.price_type === 'rate_m2') {
                            impact = impact * area;
                        } else if (option.price_type === 'rate_m') {
                            impact = impact * perimeter;
                        }
                        totalPrice += impact;
                    }
                }
            });

            this.price = totalPrice;
            const priceEl = this.container.querySelector('#configurator-price');
            if (priceEl) {
                priceEl.textContent = `Additional: ${this.formatPrice(totalPrice)}`;
            }
        }

        updateSummary() {
            const summaryEl = this.container.querySelector('#configurator-selections');
            if (!summaryEl) return;

            // Check if there are any selections
            if (Object.keys(this.selections).length === 0) {
                summaryEl.innerHTML = '<p class="text-muted small">No options selected</p>';
                return;
            }

            let html = '<ul class="list-unstyled mb-0">';
            Object.keys(this.selections).forEach(fieldId => {
                const field = this.getFieldById(parseInt(fieldId));
                if (!field) return;

                let label = field.name;
                let value = this.selections[fieldId];

                if (field.options) {
                    const option = field.options.find(opt => opt.id === value);
                    if (option) value = option.label;
                }

                if (field.type === 'dimensions' && typeof value === 'object') {
                    value = `${value.width} x ${value.height} mm`;
                }

                html += `<li><strong>${this.escapeHtml(label)}:</strong> ${this.escapeHtml(value)}</li>`;
            });
            html += '</ul>';

            this.container.querySelector('#configurator-selections').innerHTML = html;
        }

        addToCart() {
            const formData = new FormData();
            formData.append('id_product', this.productId);
            formData.append('qty', 1);
            formData.append('configurator_selection', JSON.stringify(this.selections));

            fetch(prestashop.urls.pages.cart, {
                method: 'POST',
                body: formData
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        prestashop.emit('updateCart', { reason: { linkAction: 'add-to-cart' } });
                    } else {
                        alert('Error adding to cart');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error adding to cart');
                });
        }

        getFieldById(fieldId) {
            for (const step of this.config.steps) {
                const field = step.fields.find(f => f.id === fieldId);
                if (field) return field;
            }
            return null;
        }

        getOptionById(optionId) {
            for (const step of this.config.steps) {
                for (const field of step.fields) {
                    if (field.options) {
                        const option = field.options.find(opt => opt.id === optionId);
                        if (option) return option;
                    }
                }
            }
            return null;
        }

        formatPrice(price) {
            return new Intl.NumberFormat('en-US', {
                style: 'currency',
                currency: 'USD'
            }).format(price);
        }

        escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
    }

    // Initialize when DOM is ready
    document.addEventListener('DOMContentLoaded', function () {
        const container = document.querySelector('#product-configurator');
        if (container) {
            new ProductConfigurator(container);
        }
    });
})();

