<?php
/**
 * ConfiguratorValidator – validates a configurator selection before it is saved to cart/order.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class ConfiguratorValidator
{
    /**
     * Validate the selection array for a given product.
     *
     * @param int   $idProduct   Product ID
     * @param array $selection   Decoded JSON from `config_json`
     *                           Expected format:
     *                           [
     *                               'selected_options' => [int, int, ...],
     *                               'field_values'    => [optionId => value, ...]
     *                           ]
     * @return bool  true if valid, false otherwise
     */
    public function validateSelection($idProduct, array $selection)
    {
        // $selection is now a map of field_id => value (or option_id)
        
        // Load all required fields for the product (steps → fields)
        $sql = new DbQuery();
        $sql->select('ga.id_configurator_attribute')
            ->from('configurator_group_attribute', 'ga')
            ->leftJoin('configurator_product_group', 'pg', 'pg.id_configurator_group = ga.id_configurator_group')
            ->where('pg.id_product = '.(int)$idProduct);
            
        // Also include Global fields if any? (Usually assigned to groups)
        // For now assume all fields are in groups assigned to product.
        
        $fieldIds = Db::getInstance()->executeS($sql);

        if (!$fieldIds) return true; // No fields assigned

        foreach ($fieldIds as $row) {
            $fieldId = (int)$row['id_configurator_attribute'];
            $field = new ConfiguratorField($fieldId);
            
            if (!Validate::isLoadedObject($field)) continue;
            
            // 1. Check Required
            if ($field->is_required) {
                if (!isset($selection[$fieldId]) || $selection[$fieldId] === '' || $selection[$fieldId] === null) {
                    return false;
                }
            }
            
            // 2. Check Dimensions Type Validation
            if (isset($selection[$fieldId]) && $field->field_type === 'dimensions') {
                $val = $selection[$fieldId];
                if (!is_array($val) || !isset($val['width'], $val['height'])) {
                    // If required, we failed above. If not required and partial/invalid, fail?
                    // If it is present, it must be valid.
                    return false; 
                }
                
                $w = (float)$val['width'];
                $h = (float)$val['height'];
                
                if ($field->min_width > 0 && $w < $field->min_width) return false;
                if ($field->max_width > 0 && $w > $field->max_width) return false;
                if ($field->min_height > 0 && $h < $field->min_height) return false;
                if ($field->max_height > 0 && $h > $field->max_height) return false;
            }
            
            // 3. Option Validation (if field requires options)
            if ($field->requiresOptions() && isset($selection[$fieldId])) {
                // Ensure the selected option ID actually belongs to this field
                $optId = (int)$selection[$fieldId];
                $option = new ConfiguratorOption($optId);
                if (!Validate::isLoadedObject($option) || $option->id_configurator_attribute != $fieldId) {
                    return false;
                }
            }
        }
        
        return true;
    }
}
?>
