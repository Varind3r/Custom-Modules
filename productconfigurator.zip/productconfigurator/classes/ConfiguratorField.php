<?php
/**
 * ConfiguratorField ObjectModel
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class ConfiguratorField extends ObjectModel
{
    public $field_type;
    public $is_required = 0;
    public $show_on_product = 1;
    public $show_on_cart = 1;
    public $min_value;
    public $max_value;
    public $step_value;
    public $price_impact = 0.0;
    public $price_impact_type = 'fixed';
    
    public $dimension_type = 'none'; // REMOVED in V4 refactor, but kept for backward compat if needed? No, user wants it clean.
    // Actually user said "remove dimension dropdown". I should likely deprecate it or just ignore it.
    // New fields:
    public $min_width;
    public $max_width;
    public $min_height;
    public $max_height;

    public $validation_rule;
    public $validation_error_msg;
    public $active = 1;
    public $sort_order = 0;
    public $date_add;
    public $date_upd;
    // multilang fields
    public $name;
    public $description;
    public $placeholder;
    public $suffix;


    public static $definition = [
        'table' => 'configurator_attribute',
        'primary' => 'id_configurator_attribute',
        'multilang' => true,
        'multishop' => false,
        'fields' => [
            'field_type' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'required' => true, 'size' => 50],
            'is_required' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'show_on_product' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'show_on_cart' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'min_value' => ['type' => self::TYPE_FLOAT, 'validate' => 'isFloat'],
            'max_value' => ['type' => self::TYPE_FLOAT, 'validate' => 'isFloat'],
            'step_value' => ['type' => self::TYPE_FLOAT, 'validate' => 'isFloat'],
            
            // New Range Fields
            'min_width' => ['type' => self::TYPE_FLOAT, 'validate' => 'isFloat'],
            'max_width' => ['type' => self::TYPE_FLOAT, 'validate' => 'isFloat'],
            'min_height' => ['type' => self::TYPE_FLOAT, 'validate' => 'isFloat'],
            'max_height' => ['type' => self::TYPE_FLOAT, 'validate' => 'isFloat'],

            'price_impact' => ['type' => self::TYPE_FLOAT, 'validate' => 'isFloat', 'default' => '0.0'],
            'price_impact_type' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'size' => 20, 'default' => 'fixed'],
            
            'dimension_type' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'size' => 20, 'default' => 'none'],

            'validation_rule' => ['type' => self::TYPE_STRING, 'validate' => 'isString', 'size' => 255],
            'active' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool', 'required' => true],
            'sort_order' => ['type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => true],
            'date_add' => ['type' => self::TYPE_DATE, 'validate' => 'isDate'],
            'date_upd' => ['type' => self::TYPE_DATE, 'validate' => 'isDate'],
            // multilang
            'name' => ['type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isGenericName', 'required' => true, 'size' => 255],
            'description' => ['type' => self::TYPE_HTML, 'lang' => true, 'validate' => 'isCleanHtml'],
            'placeholder' => ['type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isGenericName', 'size' => 255],
            'suffix' => ['type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isGenericName', 'size' => 50],
            'validation_error_msg' => ['type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isGenericName', 'size' => 255],
        ],
    ];

    /** Get attributes belonging to a step (group) */
    public static function getByStep($id_step, $idLang = null)
    {
        $idLang = $idLang ?: Context::getContext()->language->id;
        $sql = new DbQuery();
        $sql->select('a.*, b.name, b.description, b.placeholder, b.suffix, b.validation_error_msg')
            ->from('configurator_attribute', 'a')
            ->leftJoin('configurator_attribute_lang', 'b', 'a.id_configurator_attribute = b.id_configurator_attribute AND b.id_lang = '.(int)$idLang)
            ->innerJoin('configurator_group_attribute', 'ga', 'ga.id_configurator_attribute = a.id_configurator_attribute')
            ->where('ga.id_configurator_group = '.(int)$id_step)
            ->where('a.active = 1')
            ->orderBy('a.sort_order ASC');
        $results = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
        return $results ? $results : [];
    }

    /** Check if this field type requires options (select, radio, checkbox) */
    public function requiresOptions()
    {
        $optionTypes = ['select', 'radio', 'checkbox', 'dropdown', 'radio_image', 'radio_color', 'radio_text'];
        return in_array($this->field_type, $optionTypes);
    }
}
?>
