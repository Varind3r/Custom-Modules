<?php
/**
 * ConfiguratorDependency – loads dependency rules for options.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class ConfiguratorDependency
{
    /**
     * Load all dependencies for a given product (or globally if $idProduct is null).
     * Returns an array keyed by option ID containing the JSON rule set.
     */
    public static function loadForProduct($idProduct = null)
    {
        $sql = new DbQuery();
        $sql->select('id_configurator_option, dependency_json')
            ->from('configurator_option_dependency');
        if ($idProduct) {
            $sql->where('id_product = '.(int)$idProduct);
        }
        $rows = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
        $map = [];
        foreach ($rows as $row) {
            $map[(int)$row['id_configurator_option']] = json_decode($row['dependency_json'], true);
        }
        return $map;
    }
}
?>
