<?php
/**
 * ConfiguratorAttribute ObjectModel
 */

class ConfiguratorAttribute extends ObjectModel
{
    public $id_configurator_attribute;
    public $name;
    public $description;
    public $placeholder;
    public $suffix;
    public $field_type;
    public $is_required;
    public $show_on_product;
    public $show_on_cart;
    public $min_value;
    public $max_value;
    public $step_value;
    public $price_impact;
    public $price_impact_type;
    public $sort_order;
    public $active;
    public $validation_rule;
    public $validation_error_msg;
    public $date_add;
    public $date_upd;

    public static $definition = [
        'table' => 'configurator_attribute',
        'primary' => 'id_configurator_attribute',
        'multilang' => true,
        'fields' => [
            'field_type' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'required' => true, 'size' => 50],
            'is_required' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'show_on_product' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'show_on_cart' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'min_value' => ['type' => self::TYPE_FLOAT, 'validate' => 'isFloat'],
            'max_value' => ['type' => self::TYPE_FLOAT, 'validate' => 'isFloat'],
            'step_value' => ['type' => self::TYPE_FLOAT, 'validate' => 'isFloat'],
            'price_impact' => ['type' => self::TYPE_FLOAT, 'validate' => 'isFloat'],
            'price_impact_type' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'size' => 20],
            'sort_order' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'],
            'active' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'date_add' => ['type' => self::TYPE_DATE, 'validate' => 'isDate'],
            'date_upd' => ['type' => self::TYPE_DATE, 'validate' => 'isDate'],
            // Multilang fields
            'name' => ['type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isGenericName', 'required' => true, 'size' => 255],
            'description' => ['type' => self::TYPE_HTML, 'lang' => true, 'validate' => 'isCleanHtml'],
            'placeholder' => ['type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isGenericName', 'size' => 255],
            'suffix' => ['type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isGenericName', 'size' => 50],
            'validation_rule' => ['type' => self::TYPE_STRING, 'validate' => 'isString', 'size' => 255],
            'validation_error_msg' => ['type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isGenericName', 'size' => 255],
        ],
    ];

    public function __construct($id = null, $id_lang = null, $id_shop = null)
    {
        parent::__construct($id, $id_lang, $id_shop);
    }

    public function add($auto_date = true, $null_values = false)
    {
        if ($auto_date) {
            $this->date_add = date('Y-m-d H:i:s');
            $this->date_upd = date('Y-m-d H:i:s');
        }
        return parent::add($auto_date, $null_values);
    }

    public function update($null_values = false)
    {
        $this->date_upd = date('Y-m-d H:i:s');
        return parent::update($null_values);
    }

    public function delete()
    {
        // Delete options
        Db::getInstance()->delete('configurator_attribute_option', 'id_configurator_attribute = ' . (int) $this->id);
        Db::getInstance()->delete('configurator_attribute_option_lang', 
            'id_configurator_option NOT IN (SELECT id_configurator_option FROM `' . _DB_PREFIX_ . 'configurator_attribute_option`)'
        );

        // Delete from groups
        Db::getInstance()->delete('configurator_group_attribute', 'id_configurator_attribute = ' . (int) $this->id);

        // Delete from product assignments
        Db::getInstance()->delete('configurator_product_attribute', 'id_configurator_attribute = ' . (int) $this->id);

        return parent::delete();
    }

    /**
     * Get all options for this attribute
     */
    public function getOptions($id_lang = null)
    {
        if (!$id_lang) {
            $id_lang = (int) Context::getContext()->language->id;
        }

        return Db::getInstance()->executeS(
            'SELECT o.*, ol.label, ol.description
             FROM `' . _DB_PREFIX_ . 'configurator_attribute_option` o
             LEFT JOIN `' . _DB_PREFIX_ . 'configurator_attribute_option_lang` ol 
                ON ol.id_configurator_option = o.id_configurator_option 
                AND ol.id_lang = ' . (int) $id_lang . '
             WHERE o.id_configurator_attribute = ' . (int) $this->id . '
             AND o.active = 1
             ORDER BY o.sort_order ASC'
        ) ?: [];
    }

    /**
     * Check if this field type requires options
     */
    public function requiresOptions()
    {
        return in_array($this->field_type, ['dropdown', 'radio', 'checkbox', 'image_selector', 'color_picker']);
    }
}
