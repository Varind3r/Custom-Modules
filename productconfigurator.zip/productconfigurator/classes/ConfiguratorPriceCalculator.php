<?php
/**
 * ConfiguratorPriceCalculator – calculates the final price based on base price and selected options.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class ConfiguratorPriceCalculator
{
    /**
     * Calculate final price.
     *
     * @param int   $idProduct   Product ID
     * @param array $selection   Decoded configurator JSON (same format as validator)
     * @param Context $context   PrestaShop context (for currency, tax, etc.)
     * @return float Final price (rounded to shop precision)
     */
    public static function calculate($idProduct, array $selections, Context $context = null)
    {
        $context = $context ?: Context::getContext();
        
        // Fetch Pricing Mode
        $pricingMode = Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue(
            'SELECT `pricing_mode` FROM `'._DB_PREFIX_.'configurator_product` WHERE `id_product` = '.(int)$idProduct
        ) ?: 'additive';

        $basePrice = 0;
        if ($pricingMode === 'additive') {
            $basePrice = Product::getPriceStatic($idProduct, false, null, 6, null, false, true, 1, false, null, null, null, $context->shop->id);
        }
        
        $impacts = self::getImpacts($selections, $idProduct);
        
        // Base formulation: (Base + FixedExtras) + (Base * Percent / 100)
        $price = $basePrice + $impacts['fixed'];
        if ($basePrice > 0) {
            $price += ($basePrice * $impacts['percent'] / 100);
        }
        
        return Tools::ps_round($price, (int)Configuration::get('PS_PRICE_DISPLAY_PRECISION'));
    }

    /**
     * Get validated impacts
     * @param array $selections Map of FieldID => Value (OptionID or InputValue)
     */
    public static function getImpacts(array $selections, $idProduct = null)
    {
        $fixed = 0.0;
        $percent = 0.0;
        
        $width = 0.0;
        $height = 0.0;
        
        // 1. First pass: Identify Dimensions
        foreach ($selections as $fieldId => $value) {
            // Check for Composite Dimensions (Array from JSON)
            if (is_array($value) && isset($value['width'], $value['height'])) {
                $width = (float)$value['width'];
                $height = (float)$value['height'];
                continue; 
            }

            $field = new ConfiguratorField((int)$fieldId);
            if (Validate::isLoadedObject($field)) {
                if ($field->dimension_type === 'width') {
                    $width = (float)$value;
                } elseif ($field->dimension_type === 'height') {
                    $height = (float)$value;
                }
            }
        }
        
        // mm to m conversion
        $widthM = $width / 1000;
        $heightM = $height / 1000;
        $area = $widthM * $heightM;
        $perimeter = 2 * ($widthM + $heightM);
        
        // 2. Second pass: Calculate Price Impacts
        foreach ($selections as $fieldId => $value) {
            $field = new ConfiguratorField((int)$fieldId);
            if (!Validate::isLoadedObject($field)) continue;

            // 2a. Apply Attribute-level Fixed Price Impact (if any)
            if ($idProduct) {
                $fieldOverride = Db::getInstance()->getRow('SELECT price_impact, price_impact_type FROM '._DB_PREFIX_.'configurator_product_attribute_value WHERE id_product = '.(int)$idProduct.' AND id_configurator_attribute = '.(int)$fieldId);
                if ($fieldOverride && (float)$fieldOverride['price_impact'] != 0) {
                    if ($fieldOverride['price_impact_type'] === 'percent') {
                        $percent += (float)$fieldOverride['price_impact'];
                    } else {
                        $fixed += (float)$fieldOverride['price_impact'];
                    }
                }
            }

            // 2b. Apply Option Price Impacts
            if ($field->requiresOptions()) {
                $optionId = (int)$value;
                $option = new ConfiguratorOption($optionId);
                
                if (Validate::isLoadedObject($option) && $option->active == 1) {
                    $price = (float)$option->price_impact;
                    $type = $option->price_impact_type;
                    
                    // Check product specific overrides
                    if ($idProduct) {
                        $override = Db::getInstance()->getRow('SELECT price_impact, price_impact_type FROM '._DB_PREFIX_.'configurator_product_option_value WHERE id_product = '.(int)$idProduct.' AND id_configurator_option = '.(int)$optionId);
                        if ($override) {
                            $price = (float)$override['price_impact'];
                            $type = $override['price_impact_type'];
                        }
                    }
                    
                    if ($type === 'rate_m2') {
                        $fixed += $price * $area;
                    } elseif ($type === 'rate_m') {
                        $fixed += $price * $perimeter;
                    } elseif ($type === 'percent') {
                        $percent += $price;
                    } else {
                        $fixed += $price;
                    }
                }
            }
        }
        
        return ['fixed' => $fixed, 'percent' => $percent];
    }
}
?>
