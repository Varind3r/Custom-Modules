<?php

class ConfiguratorOption extends ObjectModel
{
    public $id_configurator_attribute;
    public $color_code;
    public $image;
    public $price_impact;
    public $price_impact_type = 'fixed'; // fixed or percentage
    public $is_default = 0;
    public $sort_order = 0;
    public $active = 1;

    // Lang fields
    public $label;
    public $description;

    public static $definition = [
        'table' => 'configurator_attribute_option',
        'primary' => 'id_configurator_option',
        'multilang' => true,
        'fields' => [
            'id_configurator_attribute' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true],
            'color_code' => ['type' => self::TYPE_STRING, 'validate' => 'isColor', 'size' => 20],
            'image' => ['type' => self::TYPE_STRING, 'validate' => 'isCleanHtml', 'size' => 255],
            'price_impact' => ['type' => self::TYPE_FLOAT, 'validate' => 'isFloat'],
            'price_impact_type' => ['type' => self::TYPE_STRING, 'validate' => 'isString', 'size' => 20],
            'is_default' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'sort_order' => ['type' => self::TYPE_INT, 'validate' => 'isInt'],
            'active' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            
            // Lang fields
            'label' => ['type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isGenericName', 'required' => true, 'size' => 255],
            'description' => ['type' => self::TYPE_HTML, 'lang' => true, 'validate' => 'isCleanHtml'],
        ],
    ];
}
