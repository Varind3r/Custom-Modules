<?php
/**
 * ConfiguratorOption ObjectModel
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class ConfiguratorOption extends ObjectModel
{
    public $id_configurator_attribute; // foreign key to attribute (field)
    public $price_impact = 0.0;
    public $price_impact_type = 'fixed'; // fixed|percent
    public $active = 1;
    public $sort_order = 0;
    // multilang fields
    public $label;
    public $description; // HTML
    
    public $image;
    public $color_code;
    public $dependencies; // JSON

    public $badge; // e.g. "Promotion"
    public $features; // HTML/Text list

    public static $definition = [
        'table' => 'configurator_attribute_option',
        'primary' => 'id_configurator_option',
        'multilang' => true,
        'multishop' => false,
        'fields' => [
            'id_configurator_attribute' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true],
            'price_impact' => ['type' => self::TYPE_FLOAT, 'validate' => 'isFloat', 'default' => '0.0'],
            'price_impact_type' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'size' => 20, 'default' => 'fixed'],
            'active' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool', 'required' => true],
            'sort_order' => ['type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => true],
            'image' => ['type' => self::TYPE_STRING, 'validate' => 'isCleanHtml', 'size' => 255],
            'color_code' => ['type' => self::TYPE_STRING, 'validate' => 'isColor', 'size' => 32],
            'dependencies' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            // multilang
            'label' => ['type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isGenericName', 'required' => true, 'size' => 255],
            'badge' => ['type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isGenericName', 'size' => 64],
            'features' => ['type' => self::TYPE_HTML, 'lang' => true, 'validate' => 'isCleanHtml'],
            'description' => ['type' => self::TYPE_HTML, 'lang' => true, 'validate' => 'isCleanHtml'],
        ],
    ];

    /** Get options for a given attribute (field) */
    public static function getByField($id_attribute, $idLang = null)
    {
        $idLang = $idLang ?: Context::getContext()->language->id;
        $sql = new DbQuery();
        $sql->select('o.*, l.label, l.description')
            ->from('configurator_attribute_option', 'o')
            ->leftJoin('configurator_attribute_option_lang', 'l', 'o.id_configurator_option = l.id_configurator_option AND l.id_lang = '.(int)$idLang)
            ->where('o.id_configurator_attribute = '.(int)$id_attribute)
            ->where('o.active = 1')
            ->orderBy('o.sort_order ASC');
        $results = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
        return $results ? $results : [];
    }
}
?>
