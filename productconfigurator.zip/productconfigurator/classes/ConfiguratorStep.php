<?php
/**
 * ConfiguratorStep ObjectModel
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class ConfiguratorStep extends ObjectModel
{
    public $active = 1;
    public $sort_order = 0;
    public $date_add;
    public $date_upd;
    // multilang fields
    public $name;
    public $description;

    public static $definition = [
        'table' => 'configurator_group',
        'primary' => 'id_configurator_group',
        'multilang' => true,
        'multishop' => false,
        'fields' => [
            'active' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool', 'required' => true],
            'sort_order' => ['type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => true],
            'date_add' => ['type' => self::TYPE_DATE, 'validate' => 'isDate'],
            'date_upd' => ['type' => self::TYPE_DATE, 'validate' => 'isDate'],
            // multilang
            'name' => ['type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isGenericName', 'required' => true, 'size' => 255],
            'description' => ['type' => self::TYPE_HTML, 'lang' => true, 'validate' => 'isCleanHtml'],
        ],
    ];

    /** Get all active steps */
    public static function getActive($idLang = null)
    {
        $idLang = $idLang ?: Context::getContext()->language->id;
        $sql = new DbQuery();
        $sql->select('a.*, b.name, b.description')
            ->from('configurator_group', 'a')
            ->leftJoin('configurator_group_lang', 'b', 'a.id_configurator_group = b.id_configurator_group AND b.id_lang = '.(int)$idLang)
            ->where('a.active = 1')
            ->orderBy('a.sort_order ASC');
        $results = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
        return $results ? $results : [];
    }
}
?>
