<?php
/**
 * ConfiguratorGroup ObjectModel
 */

class ConfiguratorGroup extends ObjectModel
{
    public $id_configurator_group;
    public $name;
    public $description;
    public $image;
    public $sort_order;
    public $active;
    public $date_add;
    public $date_upd;

    public static $definition = [
        'table' => 'configurator_group',
        'primary' => 'id_configurator_group',
        'multilang' => true,
        'fields' => [
            'image' => ['type' => self::TYPE_STRING, 'validate' => 'isUrl', 'size' => 255],
            'sort_order' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'],
            'active' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'date_add' => ['type' => self::TYPE_DATE, 'validate' => 'isDate'],
            'date_upd' => ['type' => self::TYPE_DATE, 'validate' => 'isDate'],
            // Multilang fields
            'name' => ['type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isGenericName', 'required' => true, 'size' => 255],
            'description' => ['type' => self::TYPE_HTML, 'lang' => true, 'validate' => 'isCleanHtml'],
        ],
    ];

    public function __construct($id = null, $id_lang = null, $id_shop = null)
    {
        parent::__construct($id, $id_lang, $id_shop);
    }

    public function add($auto_date = true, $null_values = false)
    {
        if ($auto_date) {
            $this->date_add = date('Y-m-d H:i:s');
            $this->date_upd = date('Y-m-d H:i:s');
        }
        return parent::add($auto_date, $null_values);
    }

    public function update($null_values = false)
    {
        $this->date_upd = date('Y-m-d H:i:s');
        return parent::update($null_values);
    }

    public function delete()
    {
        // Delete attribute mappings
        Db::getInstance()->delete('configurator_group_attribute', 'id_configurator_group = ' . (int) $this->id);

        // Remove from product assignments
        Db::getInstance()->update('configurator_product', 
            ['id_configurator_group' => null], 
            'id_configurator_group = ' . (int) $this->id
        );

        // Remove from category assignments
        Db::getInstance()->delete('configurator_category', 'id_configurator_group = ' . (int) $this->id);

        // Delete image if exists
        if ($this->image && file_exists(_PS_ROOT_DIR_ . '/' . $this->image)) {
            @unlink(_PS_ROOT_DIR_ . '/' . $this->image);
        }

        return parent::delete();
    }

    /**
     * Get all attributes in this group
     */
    public function getAttributes($id_lang = null)
    {
        if (!$id_lang) {
            $id_lang = (int) Context::getContext()->language->id;
        }

        $attributes = Db::getInstance()->executeS(
            'SELECT a.*, al.name, al.description, al.placeholder, al.suffix, ga.sort_order as group_sort_order
             FROM `' . _DB_PREFIX_ . 'configurator_group_attribute` ga
             JOIN `' . _DB_PREFIX_ . 'configurator_attribute` a ON a.id_configurator_attribute = ga.id_configurator_attribute
             LEFT JOIN `' . _DB_PREFIX_ . 'configurator_attribute_lang` al 
                ON al.id_configurator_attribute = a.id_configurator_attribute 
                AND al.id_lang = ' . (int) $id_lang . '
             WHERE ga.id_configurator_group = ' . (int) $this->id . '
             AND a.active = 1
             ORDER BY ga.sort_order ASC'
        ) ?: [];

        // Load options for each attribute
        foreach ($attributes as &$attr) {
            $attrObj = new ConfiguratorAttribute($attr['id_configurator_attribute'], $id_lang);
            if ($attrObj->requiresOptions()) {
                $attr['options'] = $attrObj->getOptions($id_lang);
            }
        }

        return $attributes;
    }

    /**
     * Get attribute IDs in this group
     */
    public function getAttributeIds()
    {
        $results = Db::getInstance()->executeS(
            'SELECT id_configurator_attribute FROM `' . _DB_PREFIX_ . 'configurator_group_attribute`
             WHERE id_configurator_group = ' . (int) $this->id . '
             ORDER BY sort_order ASC'
        ) ?: [];

        return array_column($results, 'id_configurator_attribute');
    }

    /**
     * Set attributes for this group
     */
    public function setAttributes($attributeIds)
    {
        // Clear existing
        Db::getInstance()->delete('configurator_group_attribute', 'id_configurator_group = ' . (int) $this->id);

        // Add new
        if (is_array($attributeIds) && !empty($attributeIds)) {
            $sortOrder = 0;
            foreach ($attributeIds as $attrId) {
                Db::getInstance()->insert('configurator_group_attribute', [
                    'id_configurator_group' => (int) $this->id,
                    'id_configurator_attribute' => (int) $attrId,
                    'sort_order' => $sortOrder++,
                ]);
            }
        }

        return true;
    }

    /**
     * Get all products using this group
     */
    public function getProducts()
    {
        return Db::getInstance()->executeS(
            'SELECT p.*, pl.name as product_name
             FROM `' . _DB_PREFIX_ . 'configurator_product` cp
             JOIN `' . _DB_PREFIX_ . 'product` p ON p.id_product = cp.id_product
             LEFT JOIN `' . _DB_PREFIX_ . 'product_lang` pl ON pl.id_product = p.id_product AND pl.id_lang = ' . (int) Context::getContext()->language->id . '
             WHERE cp.id_configurator_group = ' . (int) $this->id
        ) ?: [];
    }

    /**
     * Get all categories using this group
     */
    public function getCategories()
    {
        return Db::getInstance()->executeS(
            'SELECT c.*, cl.name as category_name
             FROM `' . _DB_PREFIX_ . 'configurator_category` cc
             JOIN `' . _DB_PREFIX_ . 'category` c ON c.id_category = cc.id_category
             LEFT JOIN `' . _DB_PREFIX_ . 'category_lang` cl ON cl.id_category = c.id_category AND cl.id_lang = ' . (int) Context::getContext()->language->id . '
             WHERE cc.id_configurator_group = ' . (int) $this->id
        ) ?: [];
    }
}
