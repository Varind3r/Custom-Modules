<?php
/**
 * ConfiguratorJsonBuilder – builds the frontend JSON structure according to spec
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class ConfiguratorJsonBuilder
{
    /**
     * Build the complete configurator JSON for a product
     * 
     * @param int $idProduct Product ID
     * @param int $idLang Language ID
     * @return array JSON structure matching spec
     */
    public static function buildForProduct($idProduct, $idLang = null)
    {
        $context = Context::getContext();
        $idLang = $idLang ?: $context->language->id;

        // Check if configurator is enabled for this product
        $enabled = (int)Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue(
            'SELECT `enabled` FROM `'._DB_PREFIX_.'configurator_product` WHERE `id_product` = '.(int)$idProduct
        );
        
        if (!$enabled) {
            return ['steps' => []];
        }

        // Get product's assigned steps (in order)
        $sql = new DbQuery();
        $sql->select('cpg.id_configurator_group, cpg.sort_order')
            ->from('configurator_product_group', 'cpg')
            ->innerJoin('configurator_group', 'cg', 'cg.id_configurator_group = cpg.id_configurator_group')
            ->where('cpg.id_product = '.(int)$idProduct)
            ->where('cg.active = 1')
            ->orderBy('cpg.sort_order ASC');
        
        $assignedSteps = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
        
        if (empty($assignedSteps)) {
            return ['steps' => []];
        }

        $steps = [];
        
        // Get product-specific option price overrides
        $priceOverrides = self::getProductPriceOverrides($idProduct);
        $attrOverrides  = self::getProductAttributeOverrides($idProduct);

        foreach ($assignedSteps as $stepRow) {
            $stepId = (int)$stepRow['id_configurator_group'];
            
            // Get step info
            $step = new ConfiguratorStep($stepId, $idLang);
            if (!Validate::isLoadedObject($step) || !$step->active) {
                continue;
            }

            // Get fields for this step
            $fields = ConfiguratorField::getByStep($stepId);
            
            $stepFields = [];
            
            foreach ($fields as $fieldRow) {
                $fieldId = (int)$fieldRow['id_configurator_attribute'];
                
                // Get field info
                $field = new ConfiguratorField($fieldId, $idLang);
                if (!Validate::isLoadedObject($field) || !$field->active) {
                    continue;
                }

                $fieldOverrides = isset($attrOverrides[$fieldId]) ? $attrOverrides[$fieldId] : [];
                
                // If field is hidden for this product
                if (isset($fieldOverrides['is_available']) && !(bool)$fieldOverrides['is_available']) {
                    continue;
                }

                $fieldData = [
                    'id' => $fieldId,
                    'type' => $field->field_type,
                    'name' => !empty($fieldOverrides['custom_label']) ? $fieldOverrides['custom_label'] : $field->name,
                    'description' => $field->description,
                    'is_required' => (bool)$field->is_required,
                    'placeholder' => $field->placeholder,
                    'suffix' => $field->suffix,
                    'dimension_type' => $field->dimension_type, 
                    'price' => (float)($fieldOverrides['price_impact'] ?? 0),
                    'price_type' => $fieldOverrides['price_impact_type'] ?? 'fixed',
                    // New Phase 3.5 fields
                    'min_width' => (float)$field->min_width,
                    'max_width' => (float)$field->max_width,
                    'min_height' => (float)$field->min_height,
                    'max_height' => (float)$field->max_height,
                ];

                // Add validation rules for number/text fields
                if (in_array($field->field_type, ['number', 'text'])) {
                    if ($field->min_value !== null) {
                        $fieldData['min_value'] = (float)$field->min_value;
                    }
                    if ($field->max_value !== null) {
                        $fieldData['max_value'] = (float)$field->max_value;
                    }
                    if ($field->step_value !== null) {
                        $fieldData['step_value'] = (float)$field->step_value;
                    }
                }

                // Get options for fields that need them
                if ($field->requiresOptions()) {
                    // Get options with all columns including image, color_code, dependencies
                    $sql = new DbQuery();
                    $sql->select('o.*')
                        ->from('configurator_attribute_option', 'o')
                        ->where('o.id_configurator_attribute = '.(int)$fieldId)
                        ->where('o.active = 1')
                        ->orderBy('o.sort_order ASC');
                    $options = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
                    $fieldOptions = [];
                    
                    foreach ($options as $optionRow) {
                        $optionId = (int)$optionRow['id_configurator_option'];
                        $option = new ConfiguratorOption($optionId, $idLang);
                        
                        if (!Validate::isLoadedObject($option) || !$option->active) {
                            continue;
                        }

                        // Check if option is available for this product
                        $isAvailable = true;
                        if (isset($priceOverrides[$optionId])) {
                            $isAvailable = (bool)$priceOverrides[$optionId]['is_available'];
                        }

                        if (!$isAvailable) {
                            continue;
                        }

                        // Get base price
                        $price = (float)$option->price_impact;
                        $priceType = $option->price_impact_type;

                        // Apply product-specific override
                        if (isset($priceOverrides[$optionId])) {
                            $price = (float)$priceOverrides[$optionId]['price_impact'];
                            $priceType = $priceOverrides[$optionId]['price_impact_type'];
                        }

                        $optionData = [
                            'id' => $optionId,
                            'label' => !empty($priceOverrides[$optionId]['custom_label']) ? $priceOverrides[$optionId]['custom_label'] : $option->label,
                            'description' => !empty($priceOverrides[$optionId]['custom_description']) ? $priceOverrides[$optionId]['custom_description'] : $option->description,
                            'price' => $price,
                            'price_type' => $priceType,
                        ];

                        // Add image if available
                        if (isset($priceOverrides[$optionId]) && !empty($priceOverrides[$optionId]['image'])) {
                            $optionData['image'] = $priceOverrides[$optionId]['image'];
                        } elseif (!empty($optionRow['image'])) {
                            $optionData['image'] = $optionRow['image'];
                        }

                        // Add color code if available
                        if (!empty($optionRow['color_code'])) {
                            $optionData['color_code'] = $optionRow['color_code'];
                        }

                        // Load dependencies (check both DB row and separate method)
                        $dependencies = [];
                        if (!empty($optionRow['dependencies'])) {
                            $deps = json_decode($optionRow['dependencies'], true);
                            if (is_array($deps)) {
                                $dependencies = $deps;
                            }
                        }
                        if (empty($dependencies)) {
                            $dependencies = self::loadDependencies($optionId);
                        }
                        if (!empty($dependencies)) {
                            $optionData['dependencies'] = $dependencies;
                        }

                        // Add rich content
                        if (!empty($optionRow['badge'])) {
                            $optionData['badge'] = $optionRow['badge'];
                        }
                        if (!empty($optionRow['features'])) {
                            // Features might be raw HTML or text, we pass it as is
                            // The JS will handle splitting if it's a list
                            $optionData['features'] = $optionRow['features'];
                        }
                        // Ensure full HTML description is passed
                        $optionData['description'] = $option->description; 

                        $fieldOptions[] = $optionData;
                    }
                    
                    $fieldData['options'] = $fieldOptions;
                }

                $stepFields[] = $fieldData;
            }

            if (!empty($stepFields)) {
                $steps[] = [
                    'id' => $stepId,
                    'name' => $step->name,
                    'description' => $step->description,
                    'fields' => $stepFields,
                ];
            }
        }

        return ['steps' => $steps];
    }

    /**
     * Get product-specific price overrides for options
     */
    protected static function getProductPriceOverrides($idProduct)
    {
        $sql = new DbQuery();
        $sql->select('id_configurator_option, price_impact, price_impact_type, is_available, image, custom_label, custom_description')
            ->from('configurator_product_option_value')
            ->where('id_product = '.(int)$idProduct);
        
        $rows = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
        $overrides = [];
        
        foreach ($rows as $row) {
            $overrides[(int)$row['id_configurator_option']] = [
                'price_impact' => $row['price_impact'],
                'price_impact_type' => $row['price_impact_type'],
                'is_available' => (bool)$row['is_available'],
                'image' => isset($row['image']) ? $row['image'] : null,
                'custom_label' => isset($row['custom_label']) ? $row['custom_label'] : null,
                'custom_description' => isset($row['custom_description']) ? $row['custom_description'] : null,
            ];
        }
        
        return $overrides;
    }

    /**
     * Get product-specific attribute overrides
     */
    protected static function getProductAttributeOverrides($idProduct)
    {
        $sql = new DbQuery();
        $sql->select('id_configurator_attribute, price_impact, price_impact_type, custom_label, is_available')
            ->from('configurator_product_attribute_value')
            ->where('id_product = '.(int)$idProduct);
        
        $rows = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
        $overrides = [];
        if ($rows) {
            foreach ($rows as $row) {
                $overrides[(int)$row['id_configurator_attribute']] = $row;
            }
        }
        return $overrides;
    }

    /**
     * Load dependencies for an option
     */
    protected static function loadDependencies($optionId)
    {
        // Check if dependencies are stored in the option table
        $dependencyJson = Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue(
            'SELECT `dependencies` FROM `'._DB_PREFIX_.'configurator_attribute_option` WHERE `id_configurator_option` = '.(int)$optionId
        );
        
        if ($dependencyJson) {
            $deps = json_decode($dependencyJson, true);
            if (is_array($deps)) {
                return $deps;
            }
        }
        
        // Fallback: check dependency table if it exists
        $dependencyJson = Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue(
            'SELECT `dependency_json` FROM `'._DB_PREFIX_.'configurator_option_dependency` WHERE `id_configurator_option` = '.(int)$optionId
        );
        
        if ($dependencyJson) {
            $deps = json_decode($dependencyJson, true);
            if (is_array($deps)) {
                return $deps;
            }
        }
        
        return [];
    }
}
?>

