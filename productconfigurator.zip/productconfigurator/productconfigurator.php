<?php
/**
 * Product Configurator Module
 * Allows creation of custom product attributes/fields for configurable products
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

// Load custom classes
require_once __DIR__ . '/classes/ConfiguratorAttribute.php';
require_once __DIR__ . '/classes/ConfiguratorGroup.php';
require_once __DIR__ . '/classes/ConfiguratorOption.php';

class ProductConfigurator extends Module
{
    public function __construct()
    {
        $this->name = 'productconfigurator';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'Custom Development';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = ['min' => '1.7', 'max' => _PS_VERSION_];
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Product Configurator');
        $this->description = $this->l('Create custom configurable attributes for products with groups and pricing options.');
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall? All configurator data will be deleted.');
    }

    public function install()
    {
        return parent::install()
            && $this->registerHook('displayAdminProductsExtra')
            && $this->registerHook('displayAdminProductsMainStepLeftColumnMiddle')
            && $this->registerHook('actionProductUpdate')
            && $this->registerHook('actionProductAdd')
            && $this->registerHook('displayHeader')
            && $this->registerHook('actionCartSave')
            && $this->registerHook('actionValidateOrder')
            && $this->registerHook('displayProductAdditionalInfo')
            && $this->installDb()
            && $this->installTabs();
    }

    public function uninstall()
    {
        return parent::uninstall()
            && $this->uninstallDb()
            && $this->uninstallTabs();
    }

    private function installDb()
    {
        $sql = [];

        // Attribute Types table
        $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'configurator_attribute` (
            `id_configurator_attribute` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
            `field_type` VARCHAR(50) NOT NULL,
            `is_required` TINYINT(1) NOT NULL DEFAULT 0,
            `show_on_product` TINYINT(1) NOT NULL DEFAULT 1,
            `show_on_cart` TINYINT(1) NOT NULL DEFAULT 1,
            `min_value` DECIMAL(20,6) DEFAULT NULL,
            `max_value` DECIMAL(20,6) DEFAULT NULL,
            `step_value` DECIMAL(20,6) DEFAULT NULL,
            `price_impact` DECIMAL(20,6) DEFAULT NULL,
            `price_impact_type` VARCHAR(20) DEFAULT "fixed",
            `sort_order` INT(11) NOT NULL DEFAULT 0,
            `active` TINYINT(1) NOT NULL DEFAULT 1,
            `date_add` DATETIME NOT NULL,
            `date_upd` DATETIME NOT NULL,
            PRIMARY KEY (`id_configurator_attribute`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

        // Attribute Types lang table
        $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'configurator_attribute_lang` (
            `id_configurator_attribute` INT(11) UNSIGNED NOT NULL,
            `id_lang` INT(11) UNSIGNED NOT NULL,
            `name` VARCHAR(255) NOT NULL,
            `description` TEXT,
            `placeholder` VARCHAR(255) DEFAULT NULL,
            `suffix` VARCHAR(50) DEFAULT NULL,
            PRIMARY KEY (`id_configurator_attribute`, `id_lang`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

        // Attribute Options table (for dropdowns, radio, checkboxes, image selectors)
        $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'configurator_attribute_option` (
            `id_configurator_option` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
            `id_configurator_attribute` INT(11) UNSIGNED NOT NULL,
            `color_code` VARCHAR(20) DEFAULT NULL,
            `image` VARCHAR(255) DEFAULT NULL,
            `price_impact` DECIMAL(20,6) DEFAULT NULL,
            `price_impact_type` VARCHAR(20) DEFAULT "fixed",
            `is_default` TINYINT(1) NOT NULL DEFAULT 0,
            `sort_order` INT(11) NOT NULL DEFAULT 0,
            `active` TINYINT(1) NOT NULL DEFAULT 1,
            PRIMARY KEY (`id_configurator_option`),
            KEY `id_configurator_attribute` (`id_configurator_attribute`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

        // Attribute Options lang table
        $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'configurator_attribute_option_lang` (
            `id_configurator_option` INT(11) UNSIGNED NOT NULL,
            `id_lang` INT(11) UNSIGNED NOT NULL,
            `label` VARCHAR(255) NOT NULL,
            `description` TEXT,
            PRIMARY KEY (`id_configurator_option`, `id_lang`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

        // Attribute Groups table
        $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'configurator_group` (
            `id_configurator_group` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
            `image` VARCHAR(255) DEFAULT NULL,
            `sort_order` INT(11) NOT NULL DEFAULT 0,
            `active` TINYINT(1) NOT NULL DEFAULT 1,
            `date_add` DATETIME NOT NULL,
            `date_upd` DATETIME NOT NULL,
            PRIMARY KEY (`id_configurator_group`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

        // Attribute Groups lang table
        $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'configurator_group_lang` (
            `id_configurator_group` INT(11) UNSIGNED NOT NULL,
            `id_lang` INT(11) UNSIGNED NOT NULL,
            `name` VARCHAR(255) NOT NULL,
            `description` TEXT,
            PRIMARY KEY (`id_configurator_group`, `id_lang`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

        // Group-Attribute mapping table
        $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'configurator_group_attribute` (
            `id_configurator_group` INT(11) UNSIGNED NOT NULL,
            `id_configurator_attribute` INT(11) UNSIGNED NOT NULL,
            `sort_order` INT(11) NOT NULL DEFAULT 0,
            PRIMARY KEY (`id_configurator_group`, `id_configurator_attribute`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

        // Product Configurator Assignment table
        $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'configurator_product` (
            `id_product` INT(11) UNSIGNED NOT NULL,
            `enabled` TINYINT(1) NOT NULL DEFAULT 1,
            `pricing_mode` VARCHAR(50) DEFAULT "additive",
            `price_formula` TEXT,
            PRIMARY KEY (`id_product`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

        // Product-Group assignment (Ordering of steps)
        $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'configurator_product_group` (
            `id_product` INT(11) UNSIGNED NOT NULL,
            `id_configurator_group` INT(11) UNSIGNED NOT NULL,
            `sort_order` INT(11) NOT NULL DEFAULT 0,
            PRIMARY KEY (`id_product`, `id_configurator_group`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

        // Product-Attribute direct assignment (when not using groups)
        $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'configurator_product_attribute` (
            `id_product` INT(11) UNSIGNED NOT NULL,
            `id_configurator_attribute` INT(11) UNSIGNED NOT NULL,
            `sort_order` INT(11) NOT NULL DEFAULT 0,
            PRIMARY KEY (`id_product`, `id_configurator_attribute`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

        // Cart Configurations table
        $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'configurator_cart` (
            `id_configurator_cart` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
            `id_cart` INT(11) UNSIGNED NOT NULL,
            `id_product` INT(11) UNSIGNED NOT NULL,
            `id_product_attribute` INT(11) UNSIGNED DEFAULT 0,
            `configuration` TEXT NOT NULL,
            `calculated_price` DECIMAL(20,6) DEFAULT NULL,
            `date_add` DATETIME NOT NULL,
            PRIMARY KEY (`id_configurator_cart`),
            KEY `id_cart` (`id_cart`),
            KEY `id_product` (`id_product`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

        // Order Configurations table (saved after order)
        $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'configurator_order` (
            `id_configurator_order` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
            `id_order` INT(11) UNSIGNED NOT NULL,
            `id_order_detail` INT(11) UNSIGNED NOT NULL,
            `id_product` INT(11) UNSIGNED NOT NULL,
            `configuration` TEXT NOT NULL,
            `configuration_display` TEXT,
            `calculated_price` DECIMAL(20,6) DEFAULT NULL,
            `date_add` DATETIME NOT NULL,
            PRIMARY KEY (`id_configurator_order`),
            KEY `id_order` (`id_order`),
            KEY `id_order_detail` (`id_order_detail`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

        // Category Assignment (for applying groups to all products in a category)
        $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'configurator_category` (
            `id_category` INT(11) UNSIGNED NOT NULL,
            `id_configurator_group` INT(11) UNSIGNED NOT NULL,
            PRIMARY KEY (`id_category`, `id_configurator_group`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

        // Product-Attribute custom values table
        $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'configurator_product_attribute_value` (
            `id_product` INT(11) UNSIGNED NOT NULL,
            `id_configurator_attribute` INT(11) UNSIGNED NOT NULL,
            `custom_value` TEXT,
            `custom_price` DECIMAL(20,6) DEFAULT NULL,
            PRIMARY KEY (`id_product`, `id_configurator_attribute`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

        // Product-Option custom/override values table
        $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'configurator_product_option_value` (
            `id_product` INT(11) UNSIGNED NOT NULL,
            `id_configurator_option` INT(11) UNSIGNED NOT NULL,
            `price_impact` DECIMAL(20,6) DEFAULT NULL,
            `price_impact_type` VARCHAR(20) DEFAULT "fixed",
            `is_available` TINYINT(1) NOT NULL DEFAULT 1,
            PRIMARY KEY (`id_product`, `id_configurator_option`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

        foreach ($sql as $query) {
            if (!Db::getInstance()->execute($query)) {
                return false;
            }
        }

        return true;
    }

    private function uninstallDb()
    {
        $tables = [
            'configurator_attribute',
            'configurator_attribute_lang',
            'configurator_attribute_option',
            'configurator_attribute_option_lang',
            'configurator_group',
            'configurator_group_lang',
            'configurator_group_attribute',
            'configurator_product',
            'configurator_product_group',
            'configurator_product_attribute',
            'configurator_cart',
            'configurator_order',
            'configurator_category',
            'configurator_product_option_value',
        ];

        foreach ($tables as $table) {
            Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . $table . '`');
        }

        return true;
    }

    private function installTabs()
    {
        // Parent Tab
        $parentTab = new Tab();
        $parentTab->active = 1;
        $parentTab->class_name = 'AdminConfiguratorParent';
        $parentTab->name = [];
        foreach (Language::getLanguages(true) as $lang) {
            $parentTab->name[$lang['id_lang']] = 'Product Configurator';
        }
        $parentTab->id_parent = (int) Tab::getIdFromClassName('IMPROVE');
        $parentTab->module = $this->name;
        $parentTab->icon = 'settings';
        $parentTab->add();

        // Attributes Tab
        $attrTab = new Tab();
        $attrTab->active = 1;
        $attrTab->class_name = 'AdminConfiguratorAttributes';
        $attrTab->name = [];
        foreach (Language::getLanguages(true) as $lang) {
            $attrTab->name[$lang['id_lang']] = 'Attribute Types';
        }
        $attrTab->id_parent = (int) Tab::getIdFromClassName('AdminConfiguratorParent');
        $attrTab->module = $this->name;
        $attrTab->add();

        // Groups Tab
        $groupTab = new Tab();
        $groupTab->active = 1;
        $groupTab->class_name = 'AdminConfiguratorGroups';
        $groupTab->name = [];
        foreach (Language::getLanguages(true) as $lang) {
            $groupTab->name[$lang['id_lang']] = 'Attribute Groups';
        }
        $groupTab->id_parent = (int) Tab::getIdFromClassName('AdminConfiguratorParent');
        $groupTab->module = $this->name;
        $groupTab->add();

        // Assignments Tab
        $assignTab = new Tab();
        $assignTab->active = 1;
        $assignTab->class_name = 'AdminConfiguratorAssignments';
        $assignTab->name = [];
        foreach (Language::getLanguages(true) as $lang) {
            $assignTab->name[$lang['id_lang']] = 'Category Assignments';
        }
        $assignTab->id_parent = (int) Tab::getIdFromClassName('AdminConfiguratorParent');
        $assignTab->module = $this->name;
        $assignTab->add();

        return true;
    }

    private function uninstallTabs()
    {
        $tabClasses = [
            'AdminConfiguratorAttributes',
            'AdminConfiguratorGroups',
            'AdminConfiguratorAssignments',
            'AdminConfiguratorParent',
        ];

        foreach ($tabClasses as $tabClass) {
            $idTab = (int) Tab::getIdFromClassName($tabClass);
            if ($idTab) {
                $tab = new Tab($idTab);
                $tab->delete();
            }
        }

        return true;
    }

    /**
     * Hook: Display configurator tab in product edit page
     */
    public function hookDisplayAdminProductsMainStepLeftColumnMiddle($params)
    {
        return $this->hookDisplayAdminProductsExtra($params);
    }

    public function hookDisplayAdminProductsExtra($params)
    {
        $idProduct = (int) $params['id_product'];
        $idLang = (int) $this->context->language->id;

        // Get all available attribute groups (potential steps)
        $allGroups = $this->getAllGroups($idLang);

        // Get currently assigned groups (steps) for this product
        $assignedGroupsRaw = Db::getInstance()->executeS(
            'SELECT * FROM `' . _DB_PREFIX_ . 'configurator_product_group` 
             WHERE `id_product` = ' . (int) $idProduct . ' 
             ORDER BY `sort_order` ASC'
        ) ?: [];
        
        $assignedGroupIds = array_column($assignedGroupsRaw, 'id_configurator_group');
        $assignedGroups = [];
        
        // Populate assigned groups with details
        foreach ($assignedGroupsRaw as $g) {
            foreach ($allGroups as $fullGroup) {
                if ($fullGroup['id_configurator_group'] == $g['id_configurator_group']) {
                    $assignedGroups[] = $fullGroup;
                    break;
                }
            }
        }

        // Get current product configuration (enabled/formulas)
        $productConfig = $this->getProductConfiguration($idProduct);
        
        // Load custom values (Attribute level overrides)
        $customValues = $this->getProductCustomValues($idProduct);
        
        // Load option overrides
        $optionOverrides = Db::getInstance()->executeS(
            'SELECT * FROM `' . _DB_PREFIX_ . 'configurator_product_option_value` WHERE `id_product` = ' . (int) $idProduct
        ) ?: [];
        $optionOverridesMap = [];
        foreach ($optionOverrides as $oo) {
            $optionOverridesMap[$oo['id_configurator_option']] = $oo;
        }

        // Prepare "Effective Steps" data structure for the view (Ordered Steps -> Attributes -> Options)
        $stepsData = [];
        
        // 1. Process assigned groups (steps)
        foreach ($assignedGroups as $group) {
            $step = $group;
            $step['attributes'] = $this->getGroupAttributes($group['id_configurator_group'], $idLang);
            
            // Apply overrides
            foreach ($step['attributes'] as &$attr) {
                // Attribute Custom Value/Price
                $attr['custom_value'] = isset($customValues[$attr['id_configurator_attribute']]) ? $customValues[$attr['id_configurator_attribute']]['custom_value'] : '';
                $attr['custom_price'] = isset($customValues[$attr['id_configurator_attribute']]) ? $customValues[$attr['id_configurator_attribute']]['custom_price'] : '';
                
                // Option Overrides
                if (!empty($attr['options'])) {
                    foreach ($attr['options'] as &$opt) {
                        if (isset($optionOverridesMap[$opt['id_configurator_option']])) {
                            $override = $optionOverridesMap[$opt['id_configurator_option']];
                            if ($override['price_impact'] !== null) {
                                $opt['price_impact'] = $override['price_impact'];
                                $opt['price_impact_type'] = $override['price_impact_type']; // If we allow overriding type
                                $opt['is_override'] = true;
                            }
                        }
                    }
                }
            }
            $stepsData[] = $step;
        }

        $this->context->smarty->assign([
            'id_product' => $idProduct,
            'all_groups' => $allGroups, // Available groups
            'assigned_groups' => $assignedGroups, // Selected steps
            'assigned_group_ids' => $assignedGroupIds,
            'steps_data' => $stepsData, // Full hierarchy for overrides
            'product_configurator_config' => $productConfig,
            'configurator_enabled' => $productConfig ? $productConfig['enabled'] : 0,
            'configurator_pricing_mode' => $productConfig ? $productConfig['pricing_mode'] : 'additive',
            'configurator_price_formula' => $productConfig ? $productConfig['price_formula'] : '',
            'configurator_currency_sign' => Context::getContext()->currency->sign,
        ]);

        return $this->display(__FILE__, 'views/templates/admin/product_tab.tpl');
    }

    /**
     * Hook: Save product configurator settings
     */
    public function hookActionProductUpdate($params)
    {
        $this->saveProductConfiguratorSettings($params['id_product']);
    }

    public function hookActionProductAdd($params)
    {
        $this->saveProductConfiguratorSettings($params['id_product']);
    }

    private function saveProductConfiguratorSettings($idProduct)
    {
        if (!Tools::isSubmit('configurator_enabled')) {
            return;
        }

        $enabled = (int) Tools::getValue('configurator_enabled', 0);
        $assignedGroupIds = Tools::getValue('assigned_groups', []); // From JS hidden inputs
        $pricingMode = pSQL(Tools::getValue('configurator_pricing_mode', 'additive'));
        $priceFormula = pSQL(Tools::getValue('configurator_price_formula', ''));

        // Save product configuration
        $exists = Db::getInstance()->getRow(
            'SELECT * FROM `' . _DB_PREFIX_ . 'configurator_product` WHERE `id_product` = ' . (int) $idProduct
        );

        if ($exists) {
            Db::getInstance()->update('configurator_product', [
                'enabled' => $enabled,
                'pricing_mode' => $pricingMode,
                'price_formula' => $priceFormula,
            ], 'id_product = ' . (int) $idProduct);
        } else {
            Db::getInstance()->insert('configurator_product', [
                'id_product' => (int) $idProduct,
                'enabled' => $enabled,
                'pricing_mode' => $pricingMode,
                'price_formula' => $priceFormula,
            ]);
        }

        // Save Group/Step Assignments
        Db::getInstance()->delete('configurator_product_group', 'id_product = ' . (int) $idProduct);
        if (is_array($assignedGroupIds) && !empty($assignedGroupIds)) {
            $sortOrder = 0;
            // assignedGroupIds is expected to be an ordered array
            foreach ($assignedGroupIds as $groupId) {
                Db::getInstance()->insert('configurator_product_group', [
                    'id_product' => (int) $idProduct,
                    'id_configurator_group' => (int) $groupId,
                    'sort_order' => $sortOrder++,
                ]);
            }
        }

        // Save product-wise attribute content (Custom Values)
        $customValues = Tools::getValue('config_custom_value', []);
        $customPrices = Tools::getValue('config_custom_price', []);

        Db::getInstance()->delete('configurator_product_attribute_value', 'id_product = ' . (int) $idProduct);
        if (is_array($customValues)) {
            foreach ($customValues as $attrId => $val) {
                $price = (isset($customPrices[$attrId]) && $customPrices[$attrId] !== '') ? (float)$customPrices[$attrId] : null;
                if (!empty($val) || $price !== null) {
                    Db::getInstance()->insert('configurator_product_attribute_value', [
                        'id_product' => (int) $idProduct,
                        'id_configurator_attribute' => (int) $attrId,
                        'custom_value' => pSQL($val),
                        'custom_price' => $price,
                    ]);
                }
            }
        }
        
        // Save Option Overrides
        $optionPrices = Tools::getValue('config_option_price', []);
        
        Db::getInstance()->delete('configurator_product_option_value', 'id_product = ' . (int) $idProduct);
        if (is_array($optionPrices)) {
            foreach ($optionPrices as $optionId => $priceImpact) {
                
                if ($priceImpact === '') continue; // Skip if empty 
                
                Db::getInstance()->insert('configurator_product_option_value', [
                    'id_product' => (int) $idProduct,
                    'id_configurator_option' => (int) $optionId,
                    'price_impact' => (float) $priceImpact,
                    'price_impact_type' => 'fixed', // Defaulting to fixed for now, as UI doesn't allow changing type yet
                ]);
            }
        }
    }

    /**
     * Hook: Add CSS/JS to frontend
     */
    public function hookDisplayHeader($params)
    {
        // Check if we're on a product page with configurator enabled
        if ($this->context->controller->php_self === 'product') {
            $idProduct = (int) Tools::getValue('id_product');
            if ($idProduct && $this->isConfiguratorEnabled($idProduct)) {
                $this->context->controller->registerStylesheet(
                    'module-productconfigurator-style',
                    'modules/' . $this->name . '/views/css/front.css',
                    ['media' => 'all', 'priority' => 150]
                );
                $this->context->controller->registerJavascript(
                    'module-productconfigurator-script',
                    'modules/' . $this->name . '/views/js/front.js',
                    ['position' => 'bottom', 'priority' => 150]
                );
            }
        }
    }

    /**
     * Hook: Display configurator on product page (provides data, template handles display)
     */
    public function hookDisplayProductAdditionalInfo($params)
    {
        $idProduct = (int) $params['product']['id_product'];
        
        if (!$this->isConfiguratorEnabled($idProduct)) {
            return '';
        }

        $idLang = (int) $this->context->language->id;
        $configuratorData = $this->getProductConfiguratorData($idProduct, $idLang);

        $this->context->smarty->assign([
            'configurator_data' => $configuratorData,
            'configurator_product_id' => $idProduct,
        ]);

        return $this->display(__FILE__, 'views/templates/hook/product_configurator.tpl');
    }

    /**
     * Get all configurator data for a product
     */
    public function getProductConfiguratorData($idProduct, $idLang = null)
    {
        if (!$idLang) {
            $idLang = (int) Context::getContext()->language->id;
        }

        $productConfig = $this->getProductConfiguration($idProduct);
        if (!$productConfig || !$productConfig['enabled']) {
            return null;
        }

        // 1. Get Assigned Groups (Steps)
        $assignedGroupsRaw = Db::getInstance()->executeS(
            'SELECT g.*, gl.name, gl.description
             FROM `' . _DB_PREFIX_ . 'configurator_product_group` cpg
             JOIN `' . _DB_PREFIX_ . 'configurator_group` g ON g.id_configurator_group = cpg.id_configurator_group
             LEFT JOIN `' . _DB_PREFIX_ . 'configurator_group_lang` gl ON gl.id_configurator_group = g.id_configurator_group AND gl.id_lang = ' . (int) $idLang . '
             WHERE cpg.id_product = ' . (int) $idProduct . '
             AND g.active = 1
             ORDER BY cpg.sort_order ASC'
        ) ?: [];

        // 2. Load Option Overrides
        $optionOverrides = Db::getInstance()->executeS(
            'SELECT * FROM `' . _DB_PREFIX_ . 'configurator_product_option_value` WHERE `id_product` = ' . (int) $idProduct
        ) ?: [];
        $optionOverridesMap = [];
        foreach ($optionOverrides as $oo) {
            $optionOverridesMap[$oo['id_configurator_option']] = $oo;
        }

        // 3. Load Custom Values (Attr Overrides)
        $customValues = $this->getProductCustomValues($idProduct);

        // 4. Build Steps Data
        $steps = [];
        foreach ($assignedGroupsRaw as $group) {
            $step = $group;
            $step['attributes'] = $this->getGroupAttributes($group['id_configurator_group'], $idLang);

            foreach ($step['attributes'] as &$attr) {
                // Apply Attr Overrides
                if (isset($customValues[$attr['id_configurator_attribute']])) {
                    if (!empty($customValues[$attr['id_configurator_attribute']]['custom_value'])) {
                        $attr['description'] = $customValues[$attr['id_configurator_attribute']]['custom_value'];
                    }
                    if ($customValues[$attr['id_configurator_attribute']]['custom_price'] !== null) {
                        $attr['price_impact'] = $customValues[$attr['id_configurator_attribute']]['custom_price'];
                    }
                }

                // Apply Option Overrides
                if (!empty($attr['options'])) {
                    foreach ($attr['options'] as &$opt) {
                        if (isset($optionOverridesMap[$opt['id_configurator_option']])) {
                            $override = $optionOverridesMap[$opt['id_configurator_option']];
                            if ($override['price_impact'] !== null) {
                                $opt['price_impact'] = $override['price_impact'];
                            }
                            // Add other overrides here if needed
                        }
                    }
                }
            }
            $steps[] = $step;
        }
        
        // Return structured data
        return [
            'enabled' => true,
            'pricing_mode' => $productConfig['pricing_mode'],
            'price_formula' => $productConfig['price_formula'],
            'steps' => $steps, // New structure
            // maintain backward compatibility if possible, or just break it cleanly since we are rewriting template
        ];
    }

    /**
     * Check if configurator is enabled for a product
     */
    public function isConfiguratorEnabled($idProduct)
    {
        $result = Db::getInstance()->getRow(
            'SELECT `enabled` FROM `' . _DB_PREFIX_ . 'configurator_product` 
             WHERE `id_product` = ' . (int) $idProduct
        );

        return $result && $result['enabled'];
    }

    /**
     * Get product configuration
     */
    public function getProductConfiguration($idProduct)
    {
        return Db::getInstance()->getRow(
            'SELECT * FROM `' . _DB_PREFIX_ . 'configurator_product` 
             WHERE `id_product` = ' . (int) $idProduct
        );
    }

    /**
     * Get product's assigned attribute IDs
     */
    public function getProductAttributes($idProduct)
    {
        $results = Db::getInstance()->executeS(
            'SELECT `id_configurator_attribute` FROM `' . _DB_PREFIX_ . 'configurator_product_attribute` 
             WHERE `id_product` = ' . (int) $idProduct . ' ORDER BY `sort_order` ASC'
        );

        if (!$results) {
            return [];
        }

        return array_column($results, 'id_configurator_attribute');
    }

    /**
     * Get product's attributes with full details
     */
    public function getProductAttributesWithDetails($idProduct, $idLang)
    {
        return Db::getInstance()->executeS(
            'SELECT a.*, al.name, al.description, al.placeholder, al.suffix, pa.sort_order
             FROM `' . _DB_PREFIX_ . 'configurator_product_attribute` pa
             JOIN `' . _DB_PREFIX_ . 'configurator_attribute` a ON a.id_configurator_attribute = pa.id_configurator_attribute
             LEFT JOIN `' . _DB_PREFIX_ . 'configurator_attribute_lang` al ON al.id_configurator_attribute = a.id_configurator_attribute AND al.id_lang = ' . (int) $idLang . '
             WHERE pa.id_product = ' . (int) $idProduct . '
             AND a.active = 1
             ORDER BY pa.sort_order ASC'
        ) ?: [];
    }

    /**
     * Get all attribute groups
     */
    public function getAllGroups($idLang)
    {
        $result = Db::getInstance()->executeS(
            'SELECT g.*, gl.name, gl.description
             FROM `' . _DB_PREFIX_ . 'configurator_group` g
             LEFT JOIN `' . _DB_PREFIX_ . 'configurator_group_lang` gl ON gl.id_configurator_group = g.id_configurator_group AND gl.id_lang = ' . (int) $idLang . '
             WHERE g.active = 1
             ORDER BY g.sort_order ASC'
        );

        return $result ?: [];
    }

    /**
     * Get all attributes
     */
    public function getAllAttributes($idLang)
    {
        $result = Db::getInstance()->executeS(
            'SELECT a.*, al.name, al.description, al.placeholder, al.suffix
             FROM `' . _DB_PREFIX_ . 'configurator_attribute` a
             LEFT JOIN `' . _DB_PREFIX_ . 'configurator_attribute_lang` al ON al.id_configurator_attribute = a.id_configurator_attribute AND al.id_lang = ' . (int) $idLang . '
             WHERE a.active = 1
             ORDER BY a.sort_order ASC'
        );

        return $result ?: [];
    }

    /**
     * Get attributes in a group
     */
    public function getGroupAttributes($idGroup, $idLang)
    {
        $attributes = Db::getInstance()->executeS(
            'SELECT a.*, al.name, al.description, al.placeholder, al.suffix, ga.sort_order
             FROM `' . _DB_PREFIX_ . 'configurator_group_attribute` ga
             JOIN `' . _DB_PREFIX_ . 'configurator_attribute` a ON a.id_configurator_attribute = ga.id_configurator_attribute
             LEFT JOIN `' . _DB_PREFIX_ . 'configurator_attribute_lang` al ON al.id_configurator_attribute = a.id_configurator_attribute AND al.id_lang = ' . (int) $idLang . '
             WHERE ga.id_configurator_group = ' . (int) $idGroup . '
             AND a.active = 1
             ORDER BY ga.sort_order ASC'
        ) ?: [];

        // Load options for each attribute
        foreach ($attributes as &$attr) {
            if (in_array($attr['field_type'], ['dropdown', 'radio', 'checkbox', 'image_selector', 'color_picker'])) {
                $attr['options'] = $this->getAttributeOptions($attr['id_configurator_attribute'], $idLang);
            }
        }

        return $attributes;
    }

    /**
     * Get attribute options
     */
    public function getAttributeOptions($idAttribute, $idLang)
    {
        return Db::getInstance()->executeS(
            'SELECT o.*, ol.label, ol.description
             FROM `' . _DB_PREFIX_ . 'configurator_attribute_option` o
             LEFT JOIN `' . _DB_PREFIX_ . 'configurator_attribute_option_lang` ol ON ol.id_configurator_option = o.id_configurator_option AND ol.id_lang = ' . (int) $idLang . '
             WHERE o.id_configurator_attribute = ' . (int) $idAttribute . '
             AND o.active = 1
             ORDER BY o.sort_order ASC'
        ) ?: [];
    }

    /**
     * Save cart configuration
     */
    public function saveCartConfiguration($idCart, $idProduct, $idProductAttribute, $configuration, $calculatedPrice)
    {
        // Remove existing configuration for this product in cart
        Db::getInstance()->delete(
            'configurator_cart',
            'id_cart = ' . (int) $idCart . ' AND id_product = ' . (int) $idProduct
        );

        return Db::getInstance()->insert('configurator_cart', [
            'id_cart' => (int) $idCart,
            'id_product' => (int) $idProduct,
            'id_product_attribute' => (int) $idProductAttribute,
            'configuration' => pSQL(json_encode($configuration, JSON_UNESCAPED_UNICODE), true),
            'calculated_price' => (float) $calculatedPrice,
            'date_add' => date('Y-m-d H:i:s'),
        ]);
    }

    /**
     * Get cart configuration
     */
    public function getCartConfiguration($idCart, $idProduct)
    {
        $result = Db::getInstance()->getRow(
            'SELECT * FROM `' . _DB_PREFIX_ . 'configurator_cart` 
             WHERE `id_cart` = ' . (int) $idCart . ' AND `id_product` = ' . (int) $idProduct
        );

        if ($result && $result['configuration']) {
            $result['configuration'] = json_decode($result['configuration'], true);
        }

        return $result;
    }

    /**
     * Hook: Save configuration to order when order is validated
     */
    public function hookActionValidateOrder($params)
    {
        $order = $params['order'];
        $cart = $params['cart'];

        $orderDetails = $order->getOrderDetailList();

        foreach ($orderDetails as $detail) {
            $cartConfig = $this->getCartConfiguration($cart->id, $detail['product_id']);

            if ($cartConfig) {
                Db::getInstance()->insert('configurator_order', [
                    'id_order' => (int) $order->id,
                    'id_order_detail' => (int) $detail['id_order_detail'],
                    'id_product' => (int) $detail['product_id'],
                    'configuration' => pSQL(json_encode($cartConfig['configuration'], JSON_UNESCAPED_UNICODE), true),
                    'configuration_display' => pSQL($this->formatConfigurationForDisplay($cartConfig['configuration']), true),
                    'calculated_price' => (float) $cartConfig['calculated_price'],
                    'date_add' => date('Y-m-d H:i:s'),
                ]);
            }
        }
    }

    /**
     * Format configuration for display
     */
    private function formatConfigurationForDisplay($configuration)
    {
        if (!is_array($configuration)) {
            return '';
        }

        $display = [];
        foreach ($configuration as $key => $value) {
            if (is_array($value)) {
                $display[] = $key . ': ' . implode(', ', $value);
            } else {
                $display[] = $key . ': ' . $value;
            }
        }

        return implode("\n", $display);
    }

    /**
     * Get order configuration
     */
    public function getOrderConfiguration($idOrder, $idProduct = null)
    {
        $where = 'id_order = ' . (int) $idOrder;
        if ($idProduct) {
            $where .= ' AND id_product = ' . (int) $idProduct;
        }

        $results = Db::getInstance()->executeS(
            'SELECT * FROM `' . _DB_PREFIX_ . 'configurator_order` WHERE ' . $where
        ) ?: [];

        foreach ($results as &$result) {
            if ($result['configuration']) {
                $result['configuration'] = json_decode($result['configuration'], true);
            }
        }

        return $results;
    }

    /**
     * Get field types available
     */
    public static function getFieldTypes()
    {
        return [
            'text' => 'Text Input',
            'textarea' => 'Textarea',
            'number' => 'Number Input',
            'dropdown' => 'Dropdown Select',
            'radio' => 'Radio Buttons',
            'checkbox' => 'Checkboxes',
            'image_selector' => 'Image Selector',
            'image_upload' => 'Image Upload',
            'file_upload' => 'File Upload',
            'heading' => 'Section Heading',
        ];
    }

    public function getProductCustomValues($idProduct)
    {
        $results = Db::getInstance()->executeS(
            'SELECT * FROM `' . _DB_PREFIX_ . 'configurator_product_attribute_value` 
             WHERE `id_product` = ' . (int) $idProduct
        );

        $values = [];
        if ($results) {
            foreach ($results as $row) {
                $values[$row['id_configurator_attribute']] = $row;
            }
        }
        return $values;
    }

    public function getAttributeWithDetails($idAttribute, $idLang)
    {
        return Db::getInstance()->getRow(
            'SELECT a.*, al.name, al.description, al.placeholder, al.suffix
             FROM `' . _DB_PREFIX_ . 'configurator_attribute` a
             LEFT JOIN `' . _DB_PREFIX_ . 'configurator_attribute_lang` al ON al.id_configurator_attribute = a.id_configurator_attribute AND al.id_lang = ' . (int) $idLang . '
             WHERE a.id_configurator_attribute = ' . (int) $idAttribute . '
             AND a.active = 1'
        );
    }

    /**
     * Get pricing modes available
     */
    public static function getPricingModes()
    {
        return [
            'additive' => 'Base Price + Attribute Prices',
            'formula' => 'Calculate from Formula',
            'quote' => 'Request Quote (No Price)',
        ];
    }
}
