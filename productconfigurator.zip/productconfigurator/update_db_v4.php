<?php
require_once dirname(__FILE__).'/../../config/config.inc.php';
require_once dirname(__FILE__).'/../../init.php';

$db = Db::getInstance();

echo "Updating database schema for Phase 3.5 (Dimension Refactor)...\n";

// Add min_width, max_width, min_height, max_height
$columns = [
    'min_width' => 'FLOAT DEFAULT 0',
    'max_width' => 'FLOAT DEFAULT 0',
    'min_height' => 'FLOAT DEFAULT 0',
    'max_height' => 'FLOAT DEFAULT 0',
];

foreach ($columns as $name => $def) {
    $check = $db->getValue("SELECT count(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = '"._DB_NAME_."' AND TABLE_NAME = '"._DB_PREFIX_."configurator_attribute' AND COLUMN_NAME = '$name'");
    if (!$check) {
        if ($db->execute("ALTER TABLE `"._DB_PREFIX_."configurator_attribute` ADD COLUMN `$name` $def")) {
            echo "[OK] Added '$name'.\n";
        } else {
            echo "[ERROR] Failed to add '$name': " . $db->getMsgError() . "\n";
        }
    } else {
        echo "[SKIP] '$name' already exists.\n";
    }
}

echo "Database update complete.\n";
