<?php
require_once dirname(__FILE__) . '/../../config/config.inc.php';
require_once dirname(__FILE__) . '/../../init.php';

$sql = 'ALTER TABLE `'._DB_PREFIX_.'configurator_product_option_value` ADD COLUMN `image` VARCHAR(255) NULL AFTER `is_available`';

try {
    if (Db::getInstance()->execute($sql)) {
        echo "Success: Added image column to configurator_product_option_value\n";
    } else {
        echo "Error or Column already exists\n";
    }
} catch (Exception $e) {
    echo "Exception: " . $e->getMessage() . "\n";
}
