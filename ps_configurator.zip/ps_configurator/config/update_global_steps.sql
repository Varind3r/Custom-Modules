-- Create junction table for configurator-step associations
CREATE TABLE IF NOT EXISTS `PREFIX_configurator_step_association` (
    `id_association` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `id_configurator` INT UNSIGNED NOT NULL,
    `id_step` INT UNSIGNED NOT NULL,
    `position` INT UNSIGNED DEFAULT 0,
    `date_add` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id_association`),
    UNIQUE KEY `unique_config_step` (`id_configurator`, `id_step`),
    INDEX `id_configurator` (`id_configurator`),
    INDEX `id_step` (`id_step`),
    INDEX `position` (`position`)
) ENGINE=ENGINE_TYPE DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Migrate existing data: Create associations from existing steps
INSERT INTO `PREFIX_configurator_step_association` (`id_configurator`, `id_step`, `position`)
SELECT `id_configurator`, `id_step`, `position`
FROM `PREFIX_configurator_step`
ON DUPLICATE KEY UPDATE `position` = VALUES(`position`);

-- Make id_configurator nullable in configurator_step for global steps
ALTER TABLE `PREFIX_configurator_step` 
MODIFY COLUMN `id_configurator` INT UNSIGNED NULL DEFAULT NULL,
ADD COLUMN `is_global` TINYINT(1) UNSIGNED DEFAULT 0 AFTER `id_configurator`,
ADD INDEX `is_global` (`is_global`);
