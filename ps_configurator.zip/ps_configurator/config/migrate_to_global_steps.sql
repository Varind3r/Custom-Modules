-- Migration SQL for Global Steps Architecture
-- Run this via phpMyAdmin or MySQL CLI
-- Replace PREFIX_ with your actual database prefix (usually ps_)

-- Step 1: Create junction table for configurator-step associations
CREATE TABLE IF NOT EXISTS `PREFIX_configurator_step_association` (
    `id_association` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `id_configurator` INT UNSIGNED NOT NULL,
    `id_step` INT UNSIGNED NOT NULL,
    `position` INT UNSIGNED DEFAULT 0,
    `date_add` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id_association`),
    UNIQUE KEY `unique_config_step` (`id_configurator`, `id_step`),
    INDEX `id_configurator` (`id_configurator`),
    INDEX `id_step` (`id_step`),
    INDEX `position` (`position`)
) ENGINE=ENGINE_TYPE DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Step 2: Add is_global column to configurator_step table
-- Note: This will fail if column already exists - that's OK, just continue
ALTER TABLE `PREFIX_configurator_step` 
ADD COLUMN `is_global` TINYINT(1) UNSIGNED DEFAULT 0 AFTER `id_configurator`;

-- Step 3: Add index for is_global (if column was added)
-- Note: This will fail if index already exists - that's OK
ALTER TABLE `PREFIX_configurator_step` 
ADD INDEX `is_global` (`is_global`);

-- Step 4: Make id_configurator nullable for global steps
ALTER TABLE `PREFIX_configurator_step` 
MODIFY COLUMN `id_configurator` INT UNSIGNED NULL DEFAULT NULL;

-- Step 5: Migrate existing data: Create associations from existing steps
-- This creates junction table entries for all existing configurator-step relationships
INSERT INTO `PREFIX_configurator_step_association` (`id_configurator`, `id_step`, `position`)
SELECT `id_configurator`, `id_step`, `position`
FROM `PREFIX_configurator_step`
WHERE `id_configurator` IS NOT NULL
ON DUPLICATE KEY UPDATE `position` = VALUES(`position`);

-- Step 6: Verify migration (optional - uncomment to check)
-- SELECT 
--     (SELECT COUNT(*) FROM PREFIX_configurator_step WHERE id_configurator IS NOT NULL) as steps_with_configurator,
--     (SELECT COUNT(*) FROM PREFIX_configurator_step_association) as associations_created;
