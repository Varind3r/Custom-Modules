CREATE TABLE IF NOT EXISTS `PREFIX_configurator` (
    `id_configurator` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(255) NOT NULL,
    `categories` VARCHAR(1000),
    `id_product_base` INT UNSIGNED NOT NULL,
    `active` TINYINT(1) UNSIGNED DEFAULT 0,
    `date_add` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `date_upd` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id_configurator`),
    INDEX `id_product_base` (`id_product_base`),
    INDEX `active` (`active`)
) ENGINE=ENGINE_TYPE DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `PREFIX_configurator_step` (
    `id_step` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `id_configurator` INT UNSIGNED NOT NULL,
    `position` INT UNSIGNED DEFAULT 0,
    `type` VARCHAR(50) NOT NULL DEFAULT 'choice',
    `title` VARCHAR(255) NOT NULL,
    `description` LONGTEXT,
    `required` TINYINT(1) UNSIGNED DEFAULT 0,
    `depends_on_step` INT UNSIGNED DEFAULT 0,
    `depends_on_value` VARCHAR(500),
    `show_condition` VARCHAR(10) DEFAULT 'ANY',
    `active` TINYINT(1) UNSIGNED DEFAULT 1,
    `date_add` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `date_upd` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id_step`),
    INDEX `id_configurator` (`id_configurator`),
    INDEX `position` (`position`),
    INDEX `active` (`active`)
) ENGINE=ENGINE_TYPE DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `PREFIX_configurator_option` (
    `id_option` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `id_step` INT UNSIGNED NOT NULL,
    `position` INT UNSIGNED DEFAULT 0,
    `option_type` VARCHAR(50) NOT NULL,
    `label` VARCHAR(255) NOT NULL,
    `description` LONGTEXT,
    `image` VARCHAR(255),
    `value_key` VARCHAR(255),
    `price_type` VARCHAR(20) DEFAULT 'fixed',
    `price_value` DECIMAL(20,6) DEFAULT 0,
    `config` JSON,
    `show_options` VARCHAR(500),
    `hide_options` VARCHAR(500),
    `price_calculation` VARCHAR(500),
    `date_add` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `date_upd` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id_option`),
    INDEX `id_step` (`id_step`),
    INDEX `position` (`position`)
) ENGINE=ENGINE_TYPE DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `PREFIX_configurator_selection` (
    `id_selection` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `id_cart` INT UNSIGNED NOT NULL,
    `id_product` INT UNSIGNED NOT NULL,
    `id_configurator` INT UNSIGNED,
    `selections` JSON,
    `dimensions` JSON,
    `comment` TEXT,
    `file_path` VARCHAR(255),
    `date_add` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id_selection`),
    INDEX `id_cart` (`id_cart`),
    INDEX `id_product` (`id_product`)
) ENGINE=ENGINE_TYPE DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `PREFIX_configurator_product_association` (
    `id_configurator` INT UNSIGNED NOT NULL,
    `id_product` INT UNSIGNED NOT NULL,
    PRIMARY KEY (`id_configurator`, `id_product`),
    KEY `id_product` (`id_product`)
) ENGINE=ENGINE_TYPE DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
