-- Migration script to add id_customization column to configurator_selection table
-- This column is required for proper cart functionality

-- Check if column exists, if not add it
SET @dbname = DATABASE();
SET @tablename = CONCAT('`', REPLACE('PREFIX_configurator_selection', 'PREFIX', _DB_PREFIX_), '`');
SET @columnname = 'id_customization';
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE
      (TABLE_SCHEMA = @dbname)
      AND (TABLE_NAME = REPLACE('PREFIX_configurator_selection', 'PREFIX', _DB_PREFIX_))
      AND (COLUMN_NAME = @columnname)
  ) > 0,
  "SELECT 'Column already exists.' AS result;",
  CONCAT("ALTER TABLE ", @tablename, " ADD COLUMN `id_customization` INT UNSIGNED NULL DEFAULT NULL AFTER `id_product`, ADD INDEX `id_customization` (`id_customization`);")
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

