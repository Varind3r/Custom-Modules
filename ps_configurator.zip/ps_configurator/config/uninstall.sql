DROP TABLE IF EXISTS `PREFIX_configurator`;
DROP TABLE IF EXISTS `PREFIX_configurator_step`;
DROP TABLE IF EXISTS `PREFIX_configurator_option`;
DROP TABLE IF EXISTS `PREFIX_configurator_selection`;
DROP TABLE IF EXISTS `PREFIX_configurator_product_association`;
DROP TABLE IF EXISTS `PREFIX_configurator_custom_color`;
