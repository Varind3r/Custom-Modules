<?php
require_once(dirname(__FILE__) . '/../../config/config.inc.php');
require_once(dirname(__FILE__) . '/../../init.php');

$db = Db::getInstance();

// 1. Create ps_configurator_product_association table
$sql1 = "CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "ps_configurator_product_association` (
    `id_configurator` INT UNSIGNED NOT NULL,
    `id_product` INT UNSIGNED NOT NULL,
    PRIMARY KEY (`id_configurator`, `id_product`),
    KEY `id_product` (`id_product`)
) ENGINE=" . _MYSQL_ENGINE_ . " DEFAULT CHARSET=utf8;";

if ($db->execute($sql1)) {
    echo "Table ps_configurator_product_association created/checked.<br>";
} else {
    echo "Error creating table: " . $db->getMsgError() . "<br>";
}

// 2. Add description column to ps_configurator_option if it doesn't exist
$sqlCheck = "SHOW COLUMNS FROM `" . _DB_PREFIX_ . "ps_configurator_option` LIKE 'description'";
$result = $db->executeS($sqlCheck);

if (empty($result)) {
    $sql2 = "ALTER TABLE `" . _DB_PREFIX_ . "ps_configurator_option` ADD `description` TEXT DEFAULT NULL AFTER `label`";
    if ($db->execute($sql2)) {
        echo "Column 'description' added to ps_configurator_option.<br>";
    } else {
        echo "Error adding column: " . $db->getMsgError() . "<br>";
    }
} else {
    echo "Column 'description' already exists.<br>";
}

// 3. Populate association from id_product_base if applicable? 
// Maybe logic for later.

echo "Schema update complete.";
