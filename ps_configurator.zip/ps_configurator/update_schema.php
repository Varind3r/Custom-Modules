<?php
/**
 * Update script to add configurator_product_association table if missing
 * Run this once if you have existing installation without this table
 */

require_once(dirname(__FILE__) . '/../../config/config.inc.php');
require_once(dirname(__FILE__) . '/../../init.php');

$db = Db::getInstance();

// Check if table exists
$sqlCheck = "SHOW TABLES LIKE '" . _DB_PREFIX_ . "configurator_product_association'";
$result = $db->executeS($sqlCheck);

if (empty($result)) {
    // Create table
    $sql1 = "CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "configurator_product_association` (
        `id_configurator` INT UNSIGNED NOT NULL,
        `id_product` INT UNSIGNED NOT NULL,
        PRIMARY KEY (`id_configurator`, `id_product`),
        KEY `id_product` (`id_product`)
    ) ENGINE=" . _MYSQL_ENGINE_ . " DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    if ($db->execute($sql1)) {
        echo "✅ Successfully created configurator_product_association table\n";
    } else {
        echo "❌ Error creating table: " . $db->getMsgError() . "\n";
    }
} else {
    echo "✅ configurator_product_association table already exists. No update needed.\n";
}

