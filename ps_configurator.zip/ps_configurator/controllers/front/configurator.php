<?php
/**
 * Front Configurator Controller
 */

class Ps_configuratorConfiguratorModuleFrontController extends ModuleFrontController
{
    public $ssl = true;
    public $display_column_left = false;

    public function initContent()
    {
        parent::initContent();
    }

    public function postProcess()
    {
        try {
            $action = Tools::getValue('action');

            if ($action === 'calculate_price') {
                $this->ajaxPriceCalculation();
            } elseif ($action === 'add_to_cart') {
                $this->ajaxAddToCart();
            } elseif ($action === 'getRalLibrary') {
                $this->ajaxGetRalLibrary();
            } else {
                throw new Exception('Invalid action');
            }
        } catch (Exception $e) {
            header('Content-Type: application/json');
            die(json_encode([
                'success' => false, 
                'errors' => $e->getMessage()
            ]));
        }
    }
    
    /**
     * AJAX: Get RAL Library (categories and colors)
     */
    protected function ajaxGetRalLibrary()
    {
        require_once _PS_MODULE_DIR_ . 'ps_configurator/classes/RalCategory.php';
        require_once _PS_MODULE_DIR_ . 'ps_configurator/classes/RalColor.php';
        
        header('Content-Type: application/json');
        
        try {
            $categories = RalCategory::getAllCategories(true);
            $result = [
                'success' => true,
                'categories' => [],
                'colors' => []
            ];

            if (empty($categories)) {
                // Try direct database query as fallback
                $sql = 'SELECT * FROM `' . _DB_PREFIX_ . 'configurator_ral_category` WHERE `active` = 1 ORDER BY `position` ASC';
                $categories_data = Db::getInstance()->executeS($sql);
                
                if ($categories_data) {
                    foreach ($categories_data as $cat_data) {
                        $category = new RalCategory($cat_data['id_ral_category']);
                        if (Validate::isLoadedObject($category)) {
                            $colors = $category->getColors(true);
                            $colorArray = [];

                            foreach ($colors as $color) {
                                if (Validate::isLoadedObject($color)) {
                                    // Clean RAL code (remove "RAL " prefix if present)
                                    $ral_code = preg_replace('/^RAL\s+/i', '', $color->ral_code);
                                    $colorArray[] = [
                                        'id' => (int)$color->id_ral_color,
                                        'code' => $ral_code,
                                        'name' => $color->name,
                                        'hex' => $color->hex,
                                        'category_id' => (int)$category->id_ral_category,
                                    ];
                                }
                            }

                            // Always add category, even if empty
                            $result['categories'][] = [
                                'id' => (int)$category->id_ral_category,
                                'name' => $category->name,
                                'position' => (int)$category->position,
                            ];

                            // Always add colors array, even if empty
                            $result['colors'][$category->id_ral_category] = $colorArray;
                        }
                    }
                }
            } else {
                foreach ($categories as $category) {
                    if (Validate::isLoadedObject($category)) {
                        $colors = $category->getColors(true);
                        $colorArray = [];

                        foreach ($colors as $color) {
                            if (Validate::isLoadedObject($color)) {
                                // Clean RAL code (remove "RAL " prefix if present)
                                $ral_code = preg_replace('/^RAL\s+/i', '', $color->ral_code);
                                $colorArray[] = [
                                    'id' => (int)$color->id_ral_color,
                                    'code' => $ral_code,
                                    'name' => $color->name,
                                    'hex' => $color->hex,
                                    'category_id' => (int)$category->id_ral_category,
                                ];
                            }
                        }

                        // Always add category, even if empty
                        $result['categories'][] = [
                            'id' => (int)$category->id_ral_category,
                            'name' => $category->name,
                            'position' => (int)$category->position,
                        ];

                        // Always add colors array, even if empty
                        $result['colors'][$category->id_ral_category] = $colorArray;
                    }
                }
            }

            // Sort categories by position
            usort($result['categories'], function($a, $b) {
                return $a['position'] - $b['position'];
            });

            die(json_encode($result));
        } catch (Exception $e) {
            PrestaShopLogger::addLog('RAL Library Frontend AJAX Error: ' . $e->getMessage(), 3);
            die(json_encode([
                'success' => false,
                'error' => $e->getMessage()
            ]));
        }
    }

    /**
     * AJAX: Add configured product to cart
     */
    protected function ajaxAddToCart()
    {
        $id_product = (int)Tools::getValue('id_product');
        $qty = (int)Tools::getValue('qty') ?: 1;
        $comment = Tools::getValue('comment');
        
        $selections_raw = Tools::getValue('selections');
        $dimensions_raw = Tools::getValue('dimensions');

        // Parse JSON strings from JS
        $selections = json_decode($selections_raw, true) ?: [];
        $dimensions = json_decode($dimensions_raw, true) ?: [];

        if (!$id_product) {
            throw new Exception('Product ID is required');
        }
        
        if ($qty < 1) {
            throw new Exception('Quantity must be at least 1');
        }

        // 1. Ensure Cart exists and is linked to cookie
        if (!$this->context->cart->id) {
            $this->context->cart->add();
            $this->context->cookie->id_cart = (int)$this->context->cart->id;
            $this->context->cookie->write();
        }

        $fileName = null;
        // 2. Handle File Upload (to PS upload dir for security)
        if (isset($_FILES['custom_file']) && !empty($_FILES['custom_file']['name'])) {
            $file = $_FILES['custom_file'];
            $allowedExts = ['pdf', 'jpg', 'jpeg', 'png'];
            $maxSize = 5 * 1024 * 1024; // 5MB

            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, $allowedExts)) {
                throw new Exception('Invalid file type. Allowed: PDF, JPEG, PNG.');
            }

            if ($file['size'] > $maxSize) {
                throw new Exception('File too large. Max 5MB.');
            }

            $uploadDir = _PS_UPLOAD_DIR_ . 'configurator/';
            if (!is_dir($uploadDir)) {
                if (!mkdir($uploadDir, 0755, true)) {
                    throw new Exception('Could not create upload directory.');
                }
            }

            $newFileName = md5(uniqid()) . '.' . $ext;
            if (move_uploaded_file($file['tmp_name'], $uploadDir . $newFileName)) {
                $fileName = $newFileName;
            } else {
                throw new Exception('Failed to upload file. Check folder permissions.');
            }
        }

        // 3. Calculate additional price from configurator BEFORE creating customization
        // This way we can store it in the customization price field
        $product = new Product($id_product);
        if (!Validate::isLoadedObject($product)) {
            throw new Exception('Product not found');
        }
        
        // Get base price WITHOUT tax (PrestaShop will add tax later)
        // Customization prices are stored without tax, PrestaShop adds tax automatically
        $base_price = (float)$product->getPrice(false, null, 6); // Price without tax
        
        // Extract option IDs from selections
        $optionIds = [];
        if (is_array($selections)) {
            foreach ($selections as $stepId => $options) {
                if (is_array($options)) {
                    $optionIds = array_merge($optionIds, array_keys($options));
                }
            }
        }
        $optionIds = array_unique(array_filter(array_map('intval', $optionIds)));
        
        // Calculate additional price (configurator options + dimensions)
        // This should be WITHOUT tax - PrestaShop will add tax when displaying
        $final_price = PriceCalculator::calculate($base_price, $optionIds, $dimensions);
        $additional_price = $final_price - $base_price;
        
        // Log for debugging
        PrestaShopLogger::addLog("Configurator AddToCart: Prod $id_product, Base (HT) $base_price, Additional $additional_price, Final (HT) $final_price, Options: " . count($optionIds) . ", Dims: " . count($dimensions), 1);
        
        // 4. Create a unique "Customization" reference
        // This ensures the cart treats different configs as unique items
        $id_customization = $this->createCustomizationReference($id_product, $selections, $dimensions);

        // 5. Store the additional price in customized_data table
        // PrestaShop will automatically add this via Customization::getCustomizationPrice()
        if ($id_customization > 0 && $additional_price > 0) {
            // Update the price in customized_data table
            Db::getInstance()->execute('
                UPDATE ' . _DB_PREFIX_ . 'customized_data
                SET price = ' . (float)$additional_price . '
                WHERE id_customization = ' . (int)$id_customization . '
                LIMIT 1
            ');
            
            // If no row exists, create one (shouldn't happen, but safety check)
            $exists = Db::getInstance()->getValue('
                SELECT COUNT(*) FROM ' . _DB_PREFIX_ . 'customized_data
                WHERE id_customization = ' . (int)$id_customization
            );
            
            if (!$exists) {
                // Get the customization field ID
                $id_customization_field = (int)Db::getInstance()->getValue('
                    SELECT id_customization_field 
                    FROM ' . _DB_PREFIX_ . 'customization_field 
                    WHERE id_product = ' . (int)$id_product . ' 
                    AND type = ' . (int)Product::CUSTOMIZE_TEXTFIELD . ' 
                    AND is_deleted = 0
                    LIMIT 1
                ');
                
                if ($id_customization_field) {
                    Db::getInstance()->insert('customized_data', [
                        'id_cart' => (int)$this->context->cart->id,
                        'id_product' => (int)$id_product,
                        'id_customization' => (int)$id_customization,
                        'type' => (int)Product::CUSTOMIZE_TEXTFIELD,
                        'index' => (int)$id_customization_field,
                        'value' => 'Configurator',
                        'price' => (float)$additional_price
                    ]);
                }
            }
        }

        // 6. Get configurator ID for tracking
        $configurator = Configurator::getByProduct($id_product);
        if (!$configurator) {
            $categories = Product::getProductCategories($id_product);
            $configurator = Configurator::getByCategory($categories);
        }
        $id_configurator = $configurator ? (int)$configurator->id : 0;

        // 7. Save to Selection Table
        Db::getInstance()->insert('configurator_selection', [
            'id_cart' => (int)$this->context->cart->id,
            'id_product' => (int)$id_product,
            'id_customization' => (int)$id_customization,
            'id_configurator' => (int)$id_configurator,
            'selections' => pSQL(json_encode($selections)),
            'dimensions' => pSQL(json_encode($dimensions)),
            'comment' => pSQL($comment),
            'file_path' => pSQL($fileName),
            'date_add' => date('Y-m-d H:i:s'),
        ]);

        // 8. Add Product To Cart WITH customization ID
        $update = $this->context->cart->updateQty(
            $qty, 
            $id_product, 
            0, 
            $id_customization, 
            'up'
        );
        
        if (!$update) {
            throw new Exception('Could not add product to cart.');
        }

        // Save cart to ensure totals are updated
        $this->context->cart->save();
        
        // Force update of customization quantity in ps_customization table
        // This fixes an issue where ps_customization quantity remains 0 despite updateQty
        Db::getInstance()->execute('
            UPDATE ' . _DB_PREFIX_ . 'customization c
            SET c.quantity = (
                SELECT cp.quantity 
                FROM ' . _DB_PREFIX_ . 'cart_product cp 
                WHERE cp.id_cart = ' . (int)$this->context->cart->id . ' 
                AND cp.id_product = ' . (int)$id_product . ' 
                AND cp.id_customization = ' . (int)$id_customization . '
            )
            WHERE c.id_customization = ' . (int)$id_customization . '
        ');
        
        // Get updated cart info
        $cart_count = $this->context->cart->nbProducts();
        $cart_total = $this->context->cart->getOrderTotal(true, Cart::BOTH);
        
        // Generate the "Added to Cart" modal HTML using the native shoppingcart module
        $modal = '';
        try {
            // Force refresh cart products to ensure prices are recalculated via hooks
            $this->context->cart->getProducts(true);
            
            // Clear existing cart variable from Smarty to force re-presentation with new prices
            $this->context->smarty->clearAssign('cart');
            
            $ps_shoppingcart = Module::getInstanceByName('ps_shoppingcart');
            if ($ps_shoppingcart && $ps_shoppingcart->active) {
                // Suppress warnings/notices that might break the JSON response
                $old_error_level = error_reporting(0);
                $modal = $ps_shoppingcart->renderModal((int)$id_product, 0, (int)$id_customization);
                error_reporting($old_error_level);
            } else {
                // Fallback if ps_shoppingcart is disabled
                $this->context->smarty->assign([
                    'product_name' => Product::getProductName($id_product),
                    'cart_count' => $cart_count,
                    'cart_total' => PriceCalculator::formatPrice($cart_total),
                    'cart_url' => $this->context->link->getPageLink('cart', true),
                ]);
                $modal = $this->context->smarty->fetch(_PS_MODULE_DIR_ . 'ps_configurator/views/templates/front/simple_modal.tpl');
            }
        } catch (Exception $e) {
            PrestaShopLogger::addLog('Configurator: Modal generation failed: ' . $e->getMessage(), 3);
        }

        header('Content-Type: application/json');
        die(json_encode([
            'success' => true,
            'message' => $this->module->l('Product successfully added to cart', 'Modules.Psconfigurator.Shop'),
            'cart_count' => $cart_count,
            'cart_total' => $cart_total,
            'cart_total_formatted' => PriceCalculator::formatPrice($cart_total),
            'redirect' => $this->context->link->getPageLink('cart', true),
            'id_cart' => (int)$this->context->cart->id,
            'id_product' => (int)$id_product,
            'id_customization' => $id_customization,
            'quantity' => $qty,
            'modal' => $modal
        ]));
    }

    /**
     * Helper to create a dummy customization so PS treats the item as unique
     */
    private function createCustomizationReference($id_product, $selections, $dimensions)
    {
        // 1. Check if product has a customization field, if not create one
        $id_customization_field = (int)Db::getInstance()->getValue('
            SELECT id_customization_field 
            FROM ' . _DB_PREFIX_ . 'customization_field 
            WHERE id_product = ' . (int)$id_product . ' 
            AND type = ' . (int)Product::CUSTOMIZE_TEXTFIELD . ' 
            AND is_deleted = 0
        ');

        if (!$id_customization_field) {
            // Create a field if none exists to allow customization
            Db::getInstance()->insert('customization_field', [
                'id_product' => (int)$id_product,
                'type' => (int)Product::CUSTOMIZE_TEXTFIELD,
                'required' => 0,
                'is_module' => 1
            ]);
            $id_customization_field = (int)Db::getInstance()->Insert_ID();
            
            $languages = Language::getLanguages(false);
            foreach ($languages as $lang) {
                Db::getInstance()->insert('customization_field_lang', [
                    'id_customization_field' => $id_customization_field,
                    'id_lang' => (int)$lang['id_lang'],
                    'id_shop' => (int)$this->context->shop->id,
                    'name' => 'Configurator Selection'
                ]);
            }
        }

        // 2. Add unique identifier as text value
        $label = 'Configurator Selection: ' . md5(serialize($selections) . serialize($dimensions) . uniqid());
        
        $this->context->cart->addTextFieldToProduct(
            $id_product, 
            $id_customization_field, 
            Product::CUSTOMIZE_TEXTFIELD, 
            $label
        );

        $customizations = $this->context->cart->getProductCustomization($id_product);
        if ($customizations) {
            $last_customization = end($customizations);
            return (int)$last_customization['id_customization'];
        }
        return 0;
    }

    /**
     * AJAX: Calculate price
     */
    protected function ajaxPriceCalculation()
    {
        $id_product = (int)Tools::getValue('id_product');
        if (!$id_product) {
            throw new Exception('Product ID is required');
        }
        
        $selections_raw = Tools::getValue('selections'); 
        $dimensions_raw = Tools::getValue('dimensions');

        // Parse JSON from JS
        $selections = json_decode($selections_raw, true) ?: [];
        $dimensions = json_decode($dimensions_raw, true) ?: [];

        // Flatten selections to just get individual option IDs
        $optionIds = [];
        if (is_array($selections)) {
            foreach ($selections as $stepSelections) {
                if (is_array($stepSelections)) {
                    $optionIds = array_merge($optionIds, array_keys($stepSelections));
                } else {
                    $optionIds[] = $stepSelections;
                }
            }
        }
        // Deduplicate and filter out non-integers
        $optionIds = array_unique(array_filter(array_map('intval', $optionIds)));

        $product = new Product($id_product);
        if (!Validate::isLoadedObject($product)) {
            throw new Exception('Product not found');
        }

        $base_price = (float)$product->getPrice(true, null, 6);
        $final_price = PriceCalculator::calculate($base_price, $optionIds, $dimensions);

        header('Content-Type: application/json');
        die(json_encode([
            'success' => true,
            'price' => round($final_price, 2),
            'price_formatted' => PriceCalculator::formatPrice($final_price)
        ]));
    }
}

