<?php
/**
 * Front Configurator Controller
 */

class Ps_configuratorConfiguratorModuleFrontController extends ModuleFrontController
{
    public $ssl = true;
    public $display_column_left = false;

    public function initContent()
    {
        parent::initContent();
    }

    public function postProcess()
    {
        $action = Tools::getValue('action');

        if ($action === 'calculate_price') {
            $this->ajaxPriceCalculation();
        } elseif ($action === 'add_to_cart') {
            $this->ajaxAddToCart();
        }
    }

    /**
     * AJAX: Add configured product to cart
     */
    protected function ajaxAddToCart()
    {
        $id_product = (int)Tools::getValue('id_product');
        $qty = (int)Tools::getValue('qty') ?: 1;
        $comment = Tools::getValue('comment');
        
        $selections_raw = Tools::getValue('selections');
        $dimensions_raw = Tools::getValue('dimensions');

        // Parse JSON strings from JS
        $selections = json_decode($selections_raw, true) ?: [];
        $dimensions = json_decode($dimensions_raw, true) ?: [];

        if (!$id_product || $qty < 1) {
            die(json_encode(['success' => false, 'errors' => 'Invalid product or quantity']));
        }

        $fileName = null;
        // Handle File Upload
        if (isset($_FILES['custom_file']) && !empty($_FILES['custom_file']['name'])) {
            $file = $_FILES['custom_file'];
            $allowedExts = ['pdf', 'jpg', 'jpeg', 'png'];
            $maxSize = 5 * 1024 * 1024; // 5MB

            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, $allowedExts)) {
                die(json_encode(['success' => false, 'errors' => 'Invalid file type. Allowed: PDF, JPEG, PNG.']));
            }

            if ($file['size'] > $maxSize) {
                die(json_encode(['success' => false, 'errors' => 'File too large. Max 5MB.']));
            }

            $uploadDir = _PS_ROOT_DIR_ . '/themes/child_classic/assets/img/configurator/uploads/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }

            $newFileName = uniqid('config_') . '_' . preg_replace('/[^a-zA-Z0-9\._-]/', '', $file['name']);
            if (move_uploaded_file($file['tmp_name'], $uploadDir . $newFileName)) {
                $fileName = $newFileName;
            } else {
                die(json_encode(['success' => false, 'errors' => 'Failed to upload file.']));
            }
        }

        // Ensure cart exists
        $id_cart = (int)$this->context->cart->id;
        if (!$id_cart) {
            $this->context->cart->add();
            $id_cart = (int)$this->context->cart->id;
        }

        if (!$id_cart) {
            die(json_encode(['success' => false, 'errors' => 'Could not create cart.']));
        }

        // Get configurator ID for tracking
        $configurator = Configurator::getByProduct($id_product);
        if (!$configurator) {
            $categories = Product::getProductCategories($id_product);
            $configurator = Configurator::getByCategory($categories);
        }
        $id_configurator = $configurator ? (int)$configurator->id : 0;

        // Save to Selection Table
        Db::getInstance()->insert('configurator_selection', [
            'id_cart' => (int)$id_cart,
            'id_product' => (int)$id_product,
            'id_configurator' => (int)$id_configurator,
            'selections' => pSQL(json_encode($selections)),
            'dimensions' => pSQL(json_encode($dimensions)),
            'comment' => pSQL($comment),
            'file_path' => pSQL($fileName),
            'date_add' => date('Y-m-d H:i:s'),
        ]);

        // Add Product To Cart (Standard PS Logic)
        $update = $this->context->cart->updateQty($qty, $id_product);
        
        if ($update) {
             die(json_encode(['success' => true]));
        } else {
             die(json_encode(['success' => false, 'errors' => 'Could not add product to cart.']));
        }
    }

    /**
     * AJAX: Calculate price
     */
    protected function ajaxPriceCalculation()
    {
        $id_product = (int)Tools::getValue('id_product');
        $selections_raw = Tools::getValue('selections'); 
        $dimensions_raw = Tools::getValue('dimensions');

        // Parse JSON from JS
        $selections = json_decode($selections_raw, true) ?: [];
        $dimensions = json_decode($dimensions_raw, true) ?: [];

        // Flatten selections to just get individual option IDs
        $optionIds = [];
        if (is_array($selections)) {
            foreach ($selections as $stepSelections) {
                if (is_array($stepSelections)) {
                    $optionIds = array_merge($optionIds, array_keys($stepSelections));
                } else {
                    // It might already be a simple array of IDs if sent that way
                    $optionIds[] = $stepSelections;
                }
            }
        }
        // Deduplicate and filter out non-integers
        $optionIds = array_unique(array_filter(array_map('intval', $optionIds)));

        $product = new Product($id_product);
        if (!Validate::isLoadedObject($product)) {
            die(json_encode(['success' => false, 'errors' => 'Product not found']));
        }

        $base_price = (float)$product->getPrice(true, null, 6);
        $final_price = PriceCalculator::calculate($base_price, $optionIds, $dimensions);

        die(json_encode([
            'success' => true,
            'price' => round($final_price, 2),
            'price_formatted' => PriceCalculator::formatPrice($final_price)
        ]));
    }
}
