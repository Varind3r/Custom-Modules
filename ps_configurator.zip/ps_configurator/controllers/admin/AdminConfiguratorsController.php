<?php
/**
 * AdminConfiguratorsController
 */

class AdminConfiguratorsController extends ModuleAdminController
{
    public function __construct()
    {
        $this->table = 'configurator';
        $this->className = 'Configurator';
        $this->identifier = 'id_configurator';
        $this->lang = false;
        $this->bootstrap = true;

        parent::__construct();

        $this->fields_list = [
            'id_configurator' => [
                'title' => $this->module->l('ID'),
                'align' => 'center',
                'class' => 'fixed-width-xs',
            ],
            'name' => [
                'title' => $this->module->l('Name'),
            ],
            'categories' => [
                'title' => $this->module->l('Categories'),
                'callback' => 'displayCategories',
            ],
            'steps_count' => [
                'title' => $this->module->l('Steps'),
                'align' => 'center',
                'class' => 'fixed-width-xs',
                'search' => false,
                'orderby' => false,
            ],
            'active' => [
                'title' => $this->module->l('Active'),
                'active' => 'status',
                'type' => 'bool',
            ],
        ];

        $this->addRowAction('edit');
        $this->addRowAction('delete');
        $this->addRowAction('view');
        $this->addRowAction('duplicate');
        $this->bulk_actions = [
            'delete' => [
                'text' => $this->module->l('Delete selected'),
                'confirm' => $this->module->l('Delete selected items?'),
                'icon' => 'icon-trash',
            ],
        ];
    }

    public function renderList()
    {
        $this->_select .= '(SELECT COUNT(*) FROM ' . _DB_PREFIX_ . 'configurator_step s WHERE s.id_configurator = a.id_configurator) as steps_count';
        $list_content = parent::renderList();

        $this->context->smarty->assign([
            'current_page' => 'list',
            'content' => $list_content,
            'link' => $this->context->link
        ]);

        return $this->context->smarty->fetch($this->module->getLocalPath() . 'views/templates/admin/configurators_layout.tpl');
    }

    public function displayCategories($value, $row)
    {
        $cats = explode(',', $value);
        $output = '';
        foreach ($cats as $cat) {
            $output .= '<span class="label label-info" style="margin-right:2px;">' . trim($cat) . '</span>';
        }
        return $output;
    }

    public function renderForm()
    {
        $products = Product::getProducts($this->context->language->id, 0, 0, 'name', 'ASC');
        if (!is_array($products)) {
            $products = [];
        }
        $product_options = [];
        foreach ($products as $p) {
            $product_options[] = [
                'id_product' => $p['id_product'],
                'name' => '[' . $p['id_product'] . '] ' . $p['name']
            ];
        }

        $selected_categories = [];
        if ($this->object->categories) {
            $selected_categories = explode(',', $this->object->categories);
        }

        $selected_products = [];
        if ($this->object->id) {
            $selected_products = $this->object->getAssociatedProductIds();
        }

        $this->fields_form = [
            'legend' => [
                'title' => $this->module->l('Configurator Settings'),
                'icon' => 'icon-cogs',
            ],
            'input' => [
                [
                    'type' => 'text',
                    'label' => $this->module->l('Configurator Name'),
                    'name' => 'name',
                    'required' => true,
                ],
                [
                    'type' => 'select',
                    'label' => $this->module->l('Products'),
                    'name' => 'products[]',
                    'multiple' => true,
                    'size' => 10,
                    'options' => [
                        'query' => $product_options,
                        'id' => 'id_product',
                        'name' => 'name',
                    ],
                    'required' => true,
                    'desc' => $this->module->l('Select products that will use this configurator. Steps will be global and reusable.'),
                ],
                [
                    'type' => 'categories',
                    'label' => $this->module->l('Categories (Optional)'),
                    'name' => 'categories',
                    'tree' => [
                        'id' => 'category_tree',
                        'selected_categories' => $selected_categories,
                        'use_checkbox' => true,
                    ],
                    'required' => false,
                    'desc' => $this->module->l('Select categories where this configurator should appear (optional, products take priority).'),
                ],
                [
                    'type' => 'select',
                    'label' => $this->module->l('Base Product'),
                    'name' => 'id_product_base',
                    'required' => true,
                    'options' => [
                        'query' => $product_options,
                        'id' => 'id_product',
                        'name' => 'name',
                    ],
                    'desc' => $this->module->l('Select the product that will be used as a base for this configurator.'),
                ],
                [
                    'type' => 'switch',
                    'label' => $this->module->l('Active'),
                    'name' => 'active',
                    'is_bool' => true,
                    'values' => [
                        [
                            'id' => 'active_on',
                            'value' => 1,
                            'label' => $this->module->l('Enabled'),
                        ],
                        [
                            'id' => 'active_off',
                            'value' => 0,
                            'label' => $this->module->l('Disabled'),
                        ],
                    ],
                ],
            ],
            'submit' => [
                'title' => $this->module->l('Save'),
            ],
        ];

        // Set default values
        if (!$this->object->id) {
            $this->fields_value['id_product_base'] = 0;
        } else {
            // Set selected products
            $this->fields_value['products[]'] = $selected_products;
        }

        $form_content = parent::renderForm();

        $current_page = Tools::getValue('id_configurator') ? 'edit' : 'add';
        $this->context->smarty->assign([
            'current_page' => $current_page,
            'content' => $form_content,
            'link' => $this->context->link
        ]);

        return $this->context->smarty->fetch($this->module->getLocalPath() . 'views/templates/admin/configurators_layout.tpl');
    }

    public function postProcess()
    {
        if (Tools::isSubmit('submitAdd' . $this->table) || Tools::isSubmit('submitUpdate' . $this->table)) {
            $categories = Tools::getValue('categories');
            if (is_array($categories)) {
                $_POST['categories'] = implode(',', array_map('intval', $categories));
            } else {
                $_POST['categories'] = ''; // Handle deselect all
            }
            
            $result = parent::postProcess();
            
            // Save product associations after configurator is saved
            if ($result && $this->object->id) {
                $products = Tools::getValue('products');
                if (is_array($products)) {
                    $this->object->setAssociatedProducts($products);
                }
            }
            
            return $result;
        }
        return parent::postProcess();
    }

    public function renderView()
    {
        // Redirect to Steps Controller for this configurator
        $id_configurator = (int)Tools::getValue('id_configurator');
        Tools::redirectAdmin($this->context->link->getAdminLink('AdminSteps') . '&id_configurator=' . $id_configurator);
    }

    public function initListMerge()
    {
        parent::initListMerge();
        if (isset($this->fields_list['id_configurator'])) {
            $this->fields_list['id_configurator']['title'] = $this->module->l('ID');
        }
    }

    /**
     * Duplicate/Copy configurator
     */
    public function processDuplicate()
    {
        if (Tools::isSubmit('id_configurator')) {
            $id_configurator = (int)Tools::getValue('id_configurator');
            $source_configurator = new Configurator($id_configurator);

            if (!Validate::isLoadedObject($source_configurator)) {
                $this->errors[] = $this->module->l('Configurator not found');
                return false;
            }

            // Create new configurator
            $new_configurator = new Configurator();
            $new_configurator->name = $source_configurator->name . ' (Copy)';
            $new_configurator->categories = $source_configurator->categories;
            $new_configurator->id_product_base = $source_configurator->id_product_base;
            $new_configurator->active = 0; // Inactive by default

            if ($new_configurator->add()) {
                // Copy all steps with ID mapping for dependencies
                $steps = $source_configurator->getSteps();
                $step_id_mapping = []; // Map old step ID to new step ID
                
                foreach ($steps as $step) {
                    $new_step = new Step();
                    $new_step->id_configurator = $new_configurator->id;
                    $new_step->position = $step->position;
                    $new_step->type = $step->type;
                    $new_step->title = $step->title;
                    $new_step->description = $step->description;
                    $new_step->required = $step->required;
                    // Store old ID for mapping, will update depends_on_step after all steps are created
                    $old_step_id = $step->id;
                    $new_step->depends_on_step = $step->depends_on_step; // Temporary, will fix below
                    $new_step->depends_on_value = $step->depends_on_value;
                    $new_step->show_condition = $step->show_condition;
                    $new_step->active = $step->active;

                    if ($new_step->add()) {
                        // Map old step ID to new step ID
                        $step_id_mapping[$old_step_id] = $new_step->id;
                    }
                }
                
                // Update step dependencies to point to new step IDs
                foreach ($step_id_mapping as $old_id => $new_id) {
                    $step_to_update = new Step($new_id);
                    if (Validate::isLoadedObject($step_to_update) && $step_to_update->depends_on_step > 0) {
                        // Map the depends_on_step to the new step ID
                        if (isset($step_id_mapping[$step_to_update->depends_on_step])) {
                            $step_to_update->depends_on_step = $step_id_mapping[$step_to_update->depends_on_step];
                            $step_to_update->update();
                        } else {
                            // If dependency doesn't exist in mapping, clear it
                            $step_to_update->depends_on_step = 0;
                            $step_to_update->update();
                        }
                    }
                }

                // Copy all options with custom colors
                foreach ($steps as $step) {
                    if (!isset($step_id_mapping[$step->id])) {
                        continue; // Skip if step wasn't created
                    }
                    
                    $new_step_id = $step_id_mapping[$step->id];
                    $options = $step->getOptions();
                    $option_id_mapping = []; // Map old option ID to new option ID
                    
                    foreach ($options as $option) {
                        $new_option = new Option();
                        $new_option->id_step = $new_step_id;
                        $new_option->position = $option->position;
                        $new_option->option_type = $option->option_type;
                        $new_option->label = $option->label;
                        $new_option->description = $option->description;
                        $new_option->image = $option->image;
                        // Add suffix to value_key to avoid conflicts
                        $new_option->value_key = $option->value_key . '_copy';
                        $new_option->price_type = $option->price_type;
                        $new_option->price_value = $option->price_value;
                        $new_option->config = $option->config;
                        // Update show_options and hide_options to use new option IDs (will fix after all options created)
                        $new_option->show_options = $option->show_options;
                        $new_option->hide_options = $option->hide_options;
                        $new_option->price_calculation = $option->price_calculation;
                        
                        $old_option_id = $option->id;
                        if ($new_option->add()) {
                            $option_id_mapping[$old_option_id] = $new_option->id;
                            
                            // Copy custom colors for RAL options
                            if ($option->option_type == 'ral_system') {
                                $custom_colors = CustomColor::getByOption($option->id);
                                foreach ($custom_colors as $color) {
                                    $new_color = new CustomColor();
                                    $new_color->id_option = $new_option->id;
                                    $new_color->color_name = $color->color_name;
                                    $new_color->color_code = $color->color_code;
                                    $new_color->hex_code = $color->hex_code;
                                    $new_color->position = $color->position;
                                    $new_color->active = $color->active;
                                    $new_color->add();
                                }
                            }
                        }
                    }
                    
                    // Update show_options and hide_options to reference new option IDs
                    foreach ($option_id_mapping as $old_opt_id => $new_opt_id) {
                        $opt_to_update = new Option($new_opt_id);
                        if (Validate::isLoadedObject($opt_to_update)) {
                            // Update show_options
                            if (!empty($opt_to_update->show_options)) {
                                $show_opts = explode(',', $opt_to_update->show_options);
                                $new_show_opts = [];
                                foreach ($show_opts as $show_opt_id) {
                                    $show_opt_id = trim($show_opt_id);
                                    if (isset($option_id_mapping[$show_opt_id])) {
                                        $new_show_opts[] = $option_id_mapping[$show_opt_id];
                                    }
                                }
                                if (!empty($new_show_opts)) {
                                    $opt_to_update->show_options = implode(',', $new_show_opts);
                                } else {
                                    $opt_to_update->show_options = '';
                                }
                            }
                            
                            // Update hide_options
                            if (!empty($opt_to_update->hide_options)) {
                                $hide_opts = explode(',', $opt_to_update->hide_options);
                                $new_hide_opts = [];
                                foreach ($hide_opts as $hide_opt_id) {
                                    $hide_opt_id = trim($hide_opt_id);
                                    if (isset($option_id_mapping[$hide_opt_id])) {
                                        $new_hide_opts[] = $option_id_mapping[$hide_opt_id];
                                    }
                                }
                                if (!empty($new_hide_opts)) {
                                    $opt_to_update->hide_options = implode(',', $new_hide_opts);
                                } else {
                                    $opt_to_update->hide_options = '';
                                }
                            }
                            
                            $opt_to_update->update();
                        }
                    }
                }

                // Copy product associations
                $product_associations = Db::getInstance()->executeS('
                    SELECT id_product 
                    FROM ' . _DB_PREFIX_ . 'configurator_product_association 
                    WHERE id_configurator = ' . (int)$id_configurator
                );
                
                if ($product_associations) {
                    foreach ($product_associations as $assoc) {
                        Db::getInstance()->insert('configurator_product_association', [
                            'id_configurator' => (int)$new_configurator->id,
                            'id_product' => (int)$assoc['id_product']
                        ]);
                    }
                }

                $this->confirmations[] = $this->module->l('Configurator duplicated successfully');
                Tools::redirectAdmin($this->context->link->getAdminLink('AdminConfigurators'));
                return true;
            } else {
                $this->errors[] = $this->module->l('Failed to duplicate configurator');
                return false;
            }
        }
        return false;
    }
}
