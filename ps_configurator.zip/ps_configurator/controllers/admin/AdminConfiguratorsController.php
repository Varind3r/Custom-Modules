<?php
/**
 * AdminConfiguratorsController
 */

class AdminConfiguratorsController extends ModuleAdminController
{
    public function __construct()
    {
        $this->table = 'configurator';
        $this->className = 'Configurator';
        $this->identifier = 'id_configurator';
        $this->lang = false;
        $this->bootstrap = true;

        parent::__construct();

        $this->fields_list = [
            'id_configurator' => [
                'title' => $this->module->l('ID'),
                'align' => 'center',
                'class' => 'fixed-width-xs',
            ],
            'name' => [
                'title' => $this->module->l('Name'),
            ],
            'categories' => [
                'title' => $this->module->l('Categories'),
                'callback' => 'displayCategories',
            ],
            'steps_count' => [
                'title' => $this->module->l('Steps'),
                'align' => 'center',
                'class' => 'fixed-width-xs',
                'search' => false,
                'orderby' => false,
            ],
            'active' => [
                'title' => $this->module->l('Active'),
                'active' => 'status',
                'type' => 'bool',
            ],
        ];

        $this->addRowAction('edit');
        $this->addRowAction('delete');
        $this->addRowAction('view');
        $this->bulk_actions = [
            'delete' => [
                'text' => $this->module->l('Delete selected'),
                'confirm' => $this->module->l('Delete selected items?'),
                'icon' => 'icon-trash',
            ],
        ];
    }

    public function renderList()
    {
        $this->_select .= '(SELECT COUNT(*) FROM ' . _DB_PREFIX_ . 'configurator_step s WHERE s.id_configurator = a.id_configurator) as steps_count';
        return parent::renderList();
    }

    public function displayCategories($value, $row)
    {
        $cats = explode(',', $value);
        $output = '';
        foreach ($cats as $cat) {
            $output .= '<span class="label label-info" style="margin-right:2px;">' . trim($cat) . '</span>';
        }
        return $output;
    }

    public function renderForm()
    {
        $products = Product::getProducts($this->context->language->id, 0, 0, 'name', 'ASC');
        $product_options = [];
        foreach ($products as $p) {
            $product_options[] = [
                'id_product' => $p['id_product'],
                'name' => '[' . $p['id_product'] . '] ' . $p['name']
            ];
        }

        $selected_categories = [];
        if ($this->object->categories) {
            $selected_categories = explode(',', $this->object->categories);
        }

        $this->fields_form = [
            'legend' => [
                'title' => $this->module->l('Configurator Settings'),
                'icon' => 'icon-cogs',
            ],
            'input' => [
                [
                    'type' => 'text',
                    'label' => $this->module->l('Configurator Name'),
                    'name' => 'name',
                    'required' => true,
                ],
                [
                    'type' => 'categories',
                    'label' => $this->module->l('Categories'),
                    'name' => 'categories',
                    'tree' => [
                        'id' => 'category_tree',
                        'selected_categories' => $selected_categories,
                        'use_checkbox' => true,
                    ],
                    'required' => false,
                    'desc' => $this->module->l('Select all categories where this configurator should appear.'),
                ],
                [
                    'type' => 'select',
                    'label' => $this->module->l('Base Product'),
                    'name' => 'id_product_base',
                    'required' => true,
                    'options' => [
                        'query' => $product_options,
                        'id' => 'id_product',
                        'name' => 'name',
                    ],
                    'desc' => $this->module->l('Select the product that will be used as a base for this configurator.'),
                ],
                [
                    'type' => 'switch',
                    'label' => $this->module->l('Active'),
                    'name' => 'active',
                    'is_bool' => true,
                    'values' => [
                        [
                            'id' => 'active_on',
                            'value' => 1,
                            'label' => $this->module->l('Enabled'),
                        ],
                        [
                            'id' => 'active_off',
                            'value' => 0,
                            'label' => $this->module->l('Disabled'),
                        ],
                    ],
                ],
            ],
            'submit' => [
                'title' => $this->module->l('Save'),
            ],
        ];

        return parent::renderForm();
    }

    public function postProcess()
    {
        if (Tools::isSubmit('submitAdd' . $this->table)) {
            $categories = Tools::getValue('categories');
            if (is_array($categories)) {
                $_POST['categories'] = implode(',', array_map('intval', $categories));
            } else {
                $_POST['categories'] = ''; // Handle deselect all
            }
        }
        return parent::postProcess();
    }

    public function renderView()
    {
        // Redirect to Steps Controller for this configurator
        $id_configurator = (int)Tools::getValue('id_configurator');
        Tools::redirectAdmin($this->context->link->getAdminLink('AdminSteps') . '&id_configurator=' . $id_configurator);
    }

    public function initListMerge()
    {
        parent::initListMerge();
        if (isset($this->fields_list['id_configurator'])) {
            $this->fields_list['id_configurator']['title'] = $this->module->l('ID');
        }
    }
}
