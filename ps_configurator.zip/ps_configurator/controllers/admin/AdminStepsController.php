<?php
/**
 * AdminStepsController
 */

class AdminStepsController extends ModuleAdminController
{
    protected $id_configurator;

    public function __construct()
    {
        $this->table = 'configurator_step';
        $this->className = 'Step';
        $this->identifier = 'id_step';
        $this->bootstrap = true;

        parent::__construct();

        $this->id_configurator = (int) Tools::getValue('id_configurator');

        if (Tools::isSubmit('duplicateconfigurator_step')) {
            $id_step = (int) Tools::getValue('id_step');
            if ($this->duplicateStep($id_step)) {
                $this->confirmations[] = $this->module->l('Step duplicated successfully.');
                Tools::redirectAdmin($this->context->link->getAdminLink('AdminSteps') . '&id_configurator=' . (int) $this->id_configurator);
            }
        }

        $this->fields_list = [
            'id_step' => ['title' => $this->module->l('ID'), 'width' => 25],
            'title' => ['title' => $this->module->l('Title')],
            'type' => ['title' => $this->module->l('Type')],
            'position' => [
                'title' => $this->module->l('Position'),
                'filter_key' => 'a!position',
                'position' => 'position',
                'align' => 'center',
                'class' => 'fixed-width-sm'
            ],
            'active' => ['title' => $this->module->l('Active'), 'active' => 'status', 'type' => 'bool'],
        ];

        $this->addRowAction('edit');
        $this->addRowAction('delete');

        $this->position_identifier = 'id_step';
        $this->position_group_identifier = 'id_configurator'; // Crucial for multi-configurator support
        
        // Set WHERE clause based on configurator - use junction table for filtering
        if ($this->id_configurator) {
            // Filter steps that belong to this configurator via junction table
            $this->_where = 'AND id_step IN (SELECT id_step FROM ' . _DB_PREFIX_ . 'configurator_step_association WHERE id_configurator = ' . (int)$this->id_configurator . ')';
        } else {
            // Show global steps only when no configurator is selected
            $this->_where = 'AND is_global = 1';
        }
        
        $this->_orderBy = 'position';
        $this->_defaultOrderBy = 'position';
    }

    public function ajaxProcessGetRalLibrary()
    {
        try {
            header('Content-Type: application/json');
            
            $categories = RalCategory::getAllCategories(true);
            $result = [
                'success' => true,
                'categories' => [],
                'colors' => []
            ];

            if (empty($categories)) {
                // Try direct database query as fallback
                $sql = 'SELECT * FROM `' . _DB_PREFIX_ . 'configurator_ral_category` WHERE `active` = 1 ORDER BY `position` ASC';
                $categories_data = Db::getInstance()->executeS($sql);
                
                if ($categories_data) {
                    foreach ($categories_data as $cat_data) {
                        $category = new RalCategory($cat_data['id_ral_category']);
                        if (Validate::isLoadedObject($category)) {
                            $colors = $category->getColors(true);
                            $colorArray = [];

                            foreach ($colors as $color) {
                                if (Validate::isLoadedObject($color)) {
                                    $colorArray[] = [
                                        'id' => (int)$color->id_ral_color,
                                        'code' => $color->ral_code,
                                        'name' => $color->name,
                                        'hex' => $color->hex,
                                        'category_id' => (int)$category->id_ral_category,
                                    ];
                                }
                            }

                            $result['categories'][] = [
                                'id' => (int)$category->id_ral_category,
                                'name' => $category->name,
                                'position' => (int)$category->position,
                            ];

                            if (!empty($colorArray)) {
                                $result['colors'][$category->id_ral_category] = $colorArray;
                            }
                        }
                    }
                }
            } else {
                foreach ($categories as $category) {
                    if (Validate::isLoadedObject($category)) {
                        $colors = $category->getColors(true);
                        $colorArray = [];

                        foreach ($colors as $color) {
                            if (Validate::isLoadedObject($color)) {
                                $colorArray[] = [
                                    'id' => (int)$color->id_ral_color,
                                    'code' => $color->ral_code,
                                    'name' => $color->name,
                                    'hex' => $color->hex,
                                    'category_id' => (int)$category->id_ral_category,
                                ];
                            }
                        }

                        $result['categories'][] = [
                            'id' => (int)$category->id_ral_category,
                            'name' => $category->name,
                            'position' => (int)$category->position,
                        ];

                        if (!empty($colorArray)) {
                            $result['colors'][$category->id_ral_category] = $colorArray;
                        }
                    }
                }
            }

            // Sort categories by position
            usort($result['categories'], function($a, $b) {
                return $a['position'] - $b['position'];
            });

            die(json_encode($result));
        } catch (Exception $e) {
            PrestaShopLogger::addLog('RAL Library AJAX Error: ' . $e->getMessage(), 3);
            die(json_encode([
                'success' => false,
                'error' => $e->getMessage()
            ]));
        }
    }

    public function ajaxProcessUpdatePositions()
    {
        $id_configurator = (int) Tools::getValue('id_configurator');
        $steps = Tools::getValue('steps');
        
        if (!$steps) {
            $steps = Tools::getValue($this->table);
        }

        if (!is_array($steps) || empty($steps)) {
            die(json_encode(['success' => false, 'error' => 'No steps data found']));
        }

        $success = true;

        // Handle both formats: array of IDs [5,6,7] or associative array [0=>5, 1=>6]
        $step_array = [];
        foreach ($steps as $key => $value) {
            if (is_numeric($key)) {
                // It's an indexed array - use key as position
                $id_step_raw = $value;
                $position = (int)$key;
            } else {
                // It's an associative array - use value as position
                $id_step_raw = $key;
                $position = (int)$value;
            }
            
            // Extract step ID from various formats
            $id_step = (int) preg_replace('/[^0-9]/', '', $id_step_raw);

            if ($id_step <= 0) {
                continue;
            }

            $step_array[] = ['id_step' => $id_step, 'position' => $position];
        }

        // Sort by position to ensure correct order
        usort($step_array, function($a, $b) {
            return $a['position'] - $b['position'];
        });

        // Update positions
        foreach ($step_array as $index => $step_data) {
            $id_step = (int)$step_data['id_step'];
            $position = (int)$step_data['position'];
            
            // Use index as position if position is 0 or invalid
            if ($position <= 0) {
                $position = $index + 1;
            }

            // Update position in junction table if configurator-specific
            if ($id_configurator) {
                $res = Db::getInstance()->execute('
                    UPDATE `' . _DB_PREFIX_ . 'configurator_step_association`
                    SET `position` = ' . (int) $position . '
                    WHERE `id_step` = ' . (int) $id_step . '
                    AND `id_configurator` = ' . (int) $id_configurator
                );
            } else {
                // Update position in step table for global steps
                $res = Db::getInstance()->execute('
                    UPDATE `' . _DB_PREFIX_ . 'configurator_step`
                    SET `position` = ' . (int) $position . '
                    WHERE `id_step` = ' . (int) $id_step . '
                    AND `is_global` = 1'
                );
            }

            if (!$res) {
                $success = false;
                PrestaShopLogger::addLog("Failed to update step $id_step to position $position");
            }
        }

        die(json_encode(['success' => $success]));
    }

    public function init()
    {
        parent::init();
        
        // Handle adding step from global library to configurator
        if (Tools::isSubmit('addStepToConfigurator')) {
            $id_step = (int)Tools::getValue('id_step');
            $id_configurator = (int)Tools::getValue('id_configurator');
            if ($id_step && $id_configurator) {
                $configurator = new Configurator($id_configurator);
                if (Validate::isLoadedObject($configurator)) {
                    if ($configurator->addStep($id_step)) {
                        $this->confirmations[] = $this->module->l('Step added to configurator successfully.');
                    } else {
                        $this->errors[] = $this->module->l('Failed to add step to configurator.');
                    }
                }
                Tools::redirectAdmin($this->context->link->getAdminLink('AdminSteps') . '&id_configurator=' . $id_configurator);
            }
        }
        
        // Handle duplicating step to configurator
        if (Tools::isSubmit('duplicateStepToConfigurator')) {
            $id_step = (int)Tools::getValue('id_step');
            $id_configurator = (int)Tools::getValue('id_configurator');
            if ($id_step && $id_configurator) {
                $step = new Step($id_step);
                if (Validate::isLoadedObject($step)) {
                    $new_step = $step->duplicate($id_configurator);
                    if ($new_step) {
                        $this->confirmations[] = $this->module->l('Step duplicated successfully.');
                    } else {
                        $this->errors[] = $this->module->l('Failed to duplicate step.');
                    }
                }
                Tools::redirectAdmin($this->context->link->getAdminLink('AdminSteps') . '&id_configurator=' . $id_configurator);
            }
        }
        
        // Only show global steps if id_configurator is explicitly 0 or not provided
        // Don't override if id_configurator is set (even if it's a new configurator with 0 steps)
        // This ensures new configurators show empty lists instead of global steps
        
        // Re-apply WHERE clause in init() to ensure it's set correctly after parent::init()
        if ($this->id_configurator) {
            // Filter steps that belong to this configurator via junction table
            $this->_where = 'AND id_step IN (SELECT id_step FROM ' . _DB_PREFIX_ . 'configurator_step_association WHERE id_configurator = ' . (int)$this->id_configurator . ')';
        } else {
            // Show global steps only when no configurator is selected
            $this->_where = 'AND is_global = 1';
        }
    }

    public function initToolbar()
    {
        parent::initToolbar();
        if (isset($this->toolbar_btn['new'])) {
            $this->toolbar_btn['new']['href'] .= '&id_configurator=' . (int) $this->id_configurator;
        }
        $this->context->smarty->assign('help_link', '');
    }

    public function renderForm()
    {
        if (!($obj = $this->loadObject(true))) {
            return;
        }

        // Fetch all steps for the conditional dropdown (from junction table if configurator-specific)
        // Exclude current step to prevent self-dependency
        $current_step_id = (int)$obj->id;
        if ($this->id_configurator) {
            $all_steps = Db::getInstance()->executeS('
                SELECT cs.id_step, cs.title, cs.type, cs.is_global
                FROM ' . _DB_PREFIX_ . 'configurator_step_association csa
                INNER JOIN ' . _DB_PREFIX_ . 'configurator_step cs ON cs.id_step = csa.id_step
                WHERE csa.id_configurator = ' . (int) $this->id_configurator . '
                AND cs.id_step != ' . (int)$current_step_id . '
                ORDER BY csa.position ASC
            ');
        } else {
            $all_steps = [];
        }
        
        // Also get global steps for reference - convert to arrays
        $global_steps_objects = Step::getGlobalSteps();
        $global_steps = [];
        foreach ($global_steps_objects as $step_obj) {
            if (is_object($step_obj) && Validate::isLoadedObject($step_obj)) {
                // Exclude current step
                if ($step_obj->id_step != $current_step_id) {
                    $global_steps[] = [
                        'id' => (int)$step_obj->id_step,
                        'id_step' => (int)$step_obj->id_step,
                        'title' => $step_obj->title . ' (Global)',
                        'type' => $step_obj->type,
                        'is_global' => isset($step_obj->is_global) ? (int)$step_obj->is_global : 0
                    ];
                }
            }
        }
        
        // Format steps for dropdown - show title with type
        $formatted_steps = [];
        foreach ($all_steps as $step) {
            if (!isset($step['id_step']) || !isset($step['title'])) {
                continue; // Skip invalid steps
            }
            $step_type = isset($step['type']) && !empty($step['type']) ? ucfirst($step['type']) : 'Unknown';
            $formatted_steps[] = [
                'id_step' => (int)$step['id_step'],
                'title' => $step['title'] . ' (' . $step_type . ')'
            ];
        }
        $all_steps = $formatted_steps;

        $this->fields_form = [
            'legend' => [
                'title' => ($obj->id ? $this->module->l('Edit Step:') . ' ' . $obj->title : $this->module->l('Create New Step')),
                'icon' => 'icon-pencil',
            ],
            'input' => [
                [
                    'type' => 'hidden',
                    'name' => 'id_configurator',
                ],
                [
                    'type' => 'switch',
                    'label' => $this->module->l('Global Step (Reusable)'),
                    'name' => 'is_global',
                    'desc' => $this->module->l('If enabled, this step can be reused across multiple configurators.'),
                    'is_bool' => true,
                    'values' => [
                        ['id' => 'global_on', 'value' => 1, 'label' => $this->module->l('Yes')],
                        ['id' => 'global_off', 'value' => 0, 'label' => $this->module->l('No')],
                    ],
                ],
                [
                    'type' => 'text',
                    'label' => $this->module->l('Title'),
                    'name' => 'title',
                    'required' => true,
                ],
                [
                    'type' => 'text',
                    'label' => $this->module->l('Position'),
                    'name' => 'position',
                    'desc' => $this->module->l('Set the order/position of this step. Lower numbers appear first.'),
                    'class' => 'fixed-width-sm',
                ],
                [
                    'type' => 'textarea',
                    'label' => $this->module->l('Description'),
                    'name' => 'description',
                    'autoload_rte' => true,
                ],
                [
                    'type' => 'select',
                    'label' => $this->module->l('Step Type'),
                    'name' => 'type',
                    'options' => [
                        'query' => [
                            ['id' => 'content', 'name' => 'Content Only'],
                            ['id' => 'choice', 'name' => 'Choice'],
                            ['id' => 'dimension', 'name' => 'Dimension'],
                            ['id' => 'multi_choice', 'name' => 'Multi Choice'],
                            ['id' => 'summary', 'name' => 'Summary'],
                        ],
                        'id' => 'id',
                        'name' => 'name',
                    ],
                ],
                [
                    'type' => 'switch',
                    'label' => $this->module->l('Required'),
                    'name' => 'required',
                    'is_bool' => true,
                    'values' => [
                        ['id' => 'req_on', 'value' => 1, 'label' => $this->module->l('Yes')],
                        ['id' => 'req_off', 'value' => 0, 'label' => $this->module->l('No')],
                    ],
                ],
                [
                    'type' => 'select',
                    'label' => $this->module->l('Depends on Step'),
                    'name' => 'depends_on_step',
                    'options' => [
                        'query' => array_merge([['id_step' => 0, 'title' => 'None']], $all_steps),
                        'id' => 'id_step',
                        'name' => 'title',
                    ],
                ],
                [
                    'type' => 'text',
                    'label' => $this->module->l('Trigger Values'),
                    'name' => 'depends_on_value',
                    'desc' => $this->module->l('Comma separated values that trigger this step.'),
                ],
                [
                    'type' => 'select',
                    'label' => $this->module->l('Show Condition'),
                    'name' => 'show_condition',
                    'options' => [
                        'query' => [
                            ['id' => 'ANY', 'name' => 'Any'],
                            ['id' => 'ALL', 'name' => 'All'],
                            ['id' => 'NONE', 'name' => 'None'],
                        ],
                        'id' => 'id',
                        'name' => 'name',
                    ],
                ],
                [
                    'type' => 'switch',
                    'label' => $this->module->l('Active'),
                    'name' => 'active',
                    'is_bool' => true,
                    'values' => [
                        ['id' => 'active_on', 'value' => 1, 'label' => $this->module->l('Yes')],
                        ['id' => 'active_off', 'value' => 0, 'label' => $this->module->l('No')],
                    ],
                ],
            ],
            'submit' => [
                'title' => $this->module->l('Save'),
            ],
        ];

        if (!$obj->id_configurator) {
            $this->fields_value['id_configurator'] = $this->id_configurator;
        }
        
        // Set default is_global value - if no configurator, default to global
        if (!$obj->id && !$this->id_configurator) {
            $this->fields_value['is_global'] = 1;
        } elseif (!$obj->id) {
            $this->fields_value['is_global'] = 0;
        }

        // Get custom colors for RAL options
        $options = $obj->getOptions();
        
        // Ensure $options is always an array
        if (!is_array($options)) {
            $options = [];
        }
        
        $custom_colors_data = [];
        foreach ($options as $option) {
            if (is_object($option) && isset($option->option_type) && $option->option_type == 'ral_system') {
                $colors = CustomColor::getByOption($option->id);
                if (is_array($colors)) {
                    $custom_colors_data[$option->id] = $colors;
                } else {
                    $custom_colors_data[$option->id] = [];
                }
            }
        }
        
        // Load RAL Library data directly (no AJAX needed)
        require_once _PS_MODULE_DIR_ . 'ps_configurator/classes/RalCategory.php';
        require_once _PS_MODULE_DIR_ . 'ps_configurator/classes/RalColor.php';
        
        $ral_library = [
            'categories' => [],
            'colors' => []
        ];
        
        try {
            $categories = RalCategory::getAllCategories(true);
            foreach ($categories as $category) {
                if (Validate::isLoadedObject($category)) {
                    // Always add category, even if it has no colors
                    $ral_library['categories'][] = [
                        'id' => (int)$category->id_ral_category,
                        'name' => $category->name,
                        'position' => (int)$category->position,
                    ];
                    
                    $colors = $category->getColors(true);
                    $colorArray = [];
                    foreach ($colors as $color) {
                        if (Validate::isLoadedObject($color)) {
                            // Clean RAL code (remove "RAL " prefix if present)
                            $ral_code = preg_replace('/^RAL\s+/i', '', $color->ral_code);
                            $colorArray[] = [
                                'id' => (int)$color->id_ral_color,
                                'code' => $ral_code,
                                'name' => $color->name,
                                'hex' => $color->hex,
                                'category_id' => (int)$category->id_ral_category,
                            ];
                        }
                    }
                    
                    // Always add colors array, even if empty (so category shows up)
                    $ral_library['colors'][$category->id_ral_category] = $colorArray;
                }
            }
        } catch (Exception $e) {
            PrestaShopLogger::addLog('Error loading RAL library: ' . $e->getMessage(), 3);
        }

        // Add Options Repeater
        $this->context->smarty->assign([
            'options' => $options,
            'custom_colors' => $custom_colors_data,
            'ral_library_json' => json_encode($ral_library, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT),
            'option_types' => [
                'visual_choice' => 'Visual Choice',
                'color_choice' => 'Standard Color', // Renaming visual_choice alias if we wanted, but let's stick to new types
                'ral_system' => 'RAL Color System',
                'dimension_range' => 'Dimension Range',
                'fixed_range' => 'Fixed Range',
                'toggle' => 'Toggle'
            ],
            'price_types' => [
                'fixed' => 'Fixed',
                'percentage' => 'Percentage',
                'per_unit' => 'Per Unit',
                'formula' => 'Formula'
            ],
            'img_path' => __PS_BASE_URI__ . 'themes/' . Context::getContext()->shop->theme_name . '/assets/img/configurator/'
        ]);

        $options_tpl = $this->context->smarty->fetch($this->module->getLocalPath() . 'views/templates/admin/step_options.tpl');

        $this->fields_form['input'][] = [
            'type' => 'free',
            'name' => 'options_repeater',
            'label' => $this->module->l('Step Options'),
        ];
        $this->fields_value['options_repeater'] = $options_tpl;

        $form_content = parent::renderForm();

        $this->context->smarty->assign([
            'id_configurator' => $this->id_configurator,
            'all_steps' => $all_steps,
            'global_steps' => $global_steps,
            'current_step_id' => $obj->id,
            'form_content' => $form_content,
            'link' => $this->context->link,
            'is_editing_step' => true // Hide sidebar when editing
        ]);

        return $this->context->smarty->fetch($this->module->getLocalPath() . 'views/templates/admin/builder_layout.tpl');
    }

    public function renderList()
    {
        // Get global steps library - convert to arrays
        $global_steps_objects = Step::getGlobalSteps();
        $global_steps = [];
        foreach ($global_steps_objects as $step_obj) {
            if (is_object($step_obj) && Validate::isLoadedObject($step_obj)) {
                $global_steps[] = [
                    'id' => (int)$step_obj->id_step,
                    'id_step' => (int)$step_obj->id_step,
                    'title' => $step_obj->title,
                    'type' => $step_obj->type,
                    'is_global' => isset($step_obj->is_global) ? (int)$step_obj->is_global : 0
                ];
            }
        }
        
        // Get configurators list for adding steps
        $configurators = Db::getInstance()->executeS('
            SELECT id_configurator, name 
            FROM ' . _DB_PREFIX_ . 'configurator 
            ORDER BY name ASC
        ');
        
        if ($this->id_configurator) {
            // Fetch steps for this configurator (from junction table)
            // This will return empty array if configurator has no steps
            $all_steps = Db::getInstance()->executeS('
                SELECT cs.id_step, cs.title, cs.type, cs.is_global, csa.position
                FROM ' . _DB_PREFIX_ . 'configurator_step_association csa
                INNER JOIN ' . _DB_PREFIX_ . 'configurator_step cs ON cs.id_step = csa.id_step
                WHERE csa.id_configurator = ' . (int) $this->id_configurator . '
                ORDER BY csa.position ASC
            ');
            
            // Ensure $all_steps is an array (empty if no steps found)
            if (!is_array($all_steps)) {
                $all_steps = [];
            }
            
            // Ensure all steps have required fields (safety check)
            foreach ($all_steps as $key => $step) {
                if (!isset($step['type']) || empty($step['type'])) {
                    // Try to load the step object to get the type
                    $step_obj = new Step((int)$step['id_step']);
                    if (Validate::isLoadedObject($step_obj) && isset($step_obj->type)) {
                        $all_steps[$key]['type'] = $step_obj->type;
                    } else {
                        $all_steps[$key]['type'] = 'Unknown';
                    }
                }
            }
            
            // Update WHERE clause for list - this ensures parent::renderList() shows only steps for this configurator
            $this->_where = 'AND id_step IN (SELECT id_step FROM ' . _DB_PREFIX_ . 'configurator_step_association WHERE id_configurator = ' . (int)$this->id_configurator . ')';
        } else {
            // Show global steps only when no configurator is selected
            $all_steps = [];
            $this->_where = 'AND is_global = 1';
        }

        $list_content = parent::renderList();

        $this->context->smarty->assign([
            'id_configurator' => $this->id_configurator,
            'all_steps' => $all_steps,
            'global_steps' => $global_steps,
            'configurators' => $configurators,
            'current_step_id' => 0, // No step selected in list view
            'form_content' => $list_content,
            'link' => $this->context->link
        ]);

        return $this->context->smarty->fetch($this->module->getLocalPath() . 'views/templates/admin/builder_layout.tpl');
    }

    /**
     * Validate step data before saving
     */
    protected function validateStepData()
    {
        $errors = [];
        
        // Get values from POST or from object if POST is empty (for programmatic saves)
        $type = Tools::getValue('type');
        if (empty($type) && isset($this->object) && Validate::isLoadedObject($this->object)) {
            $type = $this->object->type;
        }
        
        if (empty($type)) {
            $errors[] = $this->module->l('Step type is required.');
        } elseif (!in_array($type, ['content', 'choice', 'dimension', 'multi_choice', 'summary'])) {
            $errors[] = $this->module->l('Invalid step type. Allowed types: content, choice, dimension, multi_choice, summary.');
        }
        
        $title = Tools::getValue('title');
        if (empty($title) && isset($this->object) && Validate::isLoadedObject($this->object)) {
            $title = $this->object->title;
        }
        
        if (empty($title) || trim($title) === '') {
            $errors[] = $this->module->l('Step title is required.');
        } elseif (strlen($title) > 255) {
            $errors[] = $this->module->l('Step title cannot exceed 255 characters.');
        }
        
        // Validate depends_on_step if set
        $depends_on_step = (int)Tools::getValue('depends_on_step');
        if ($depends_on_step > 0) {
            $depends_step = new Step($depends_on_step);
            if (!Validate::isLoadedObject($depends_step)) {
                $errors[] = $this->module->l('Invalid dependency step selected.');
            } else {
                // Check for circular dependencies
                $current_step_id = (int)Tools::getValue('id_step');
                if ($current_step_id > 0 && $depends_on_step == $current_step_id) {
                    $errors[] = $this->module->l('Step cannot depend on itself.');
                }
            }
        }
        
        // Validate show_condition if depends_on_step is set
        $show_condition = Tools::getValue('show_condition');
        if ($depends_on_step > 0 && !empty($show_condition) && !in_array($show_condition, ['ANY', 'ALL', 'NONE'])) {
            $errors[] = $this->module->l('Invalid show condition. Allowed values: ANY, ALL, NONE.');
        }
        
        // Validate position
        $position = Tools::getValue('position');
        if ($position !== '' && $position !== null && (int)$position < 0) {
            $errors[] = $this->module->l('Position cannot be negative.');
        }
        
        // Validate configurator if step is not global
        $is_global = (int)Tools::getValue('is_global');
        if (!$is_global && $this->id_configurator) {
            $configurator = new Configurator($this->id_configurator);
            if (!Validate::isLoadedObject($configurator)) {
                $errors[] = $this->module->l('Invalid configurator selected.');
            }
        }
        
        return $errors;
    }

    public function postProcess()
    {
        // Check for both submitAddconfigurator_step and updateconfigurator_step
        $is_submit = Tools::isSubmit('submitAdd' . $this->table) || Tools::isSubmit('update' . $this->table);
        
        if ($is_submit) {
            PrestaShopLogger::addLog('AdminStepsController::postProcess - Form submitted', 1);
            PrestaShopLogger::addLog('POST data keys: ' . implode(', ', array_keys($_POST)), 1);
            PrestaShopLogger::addLog('custom_colors in POST: ' . (isset($_POST['custom_colors']) ? 'YES' : 'NO'), 1);
            
            // Load object first to get existing values
            $this->loadObject(true);
            
            // Comprehensive validation before processing - only if we have POST data
            // Skip validation if this is a programmatic save (no POST data for type/title)
            $has_post_data = Tools::getValue('type') || Tools::getValue('title');
            if ($has_post_data) {
                $validation_errors = $this->validateStepData();
                if (!empty($validation_errors)) {
                    foreach ($validation_errors as $error) {
                        $this->errors[] = $error;
                    }
                    return false;
                }
            }
            
            // Ensure id_configurator is set in POST if we have it
            if ($this->id_configurator && !Tools::getValue('id_configurator')) {
                $_POST['id_configurator'] = $this->id_configurator;
            }
            
            $res = parent::postProcess();
            
            if ($res && ($id_step = (int) $this->object->id)) {
                PrestaShopLogger::addLog('Saving options for step ID: ' . $id_step, 1);
                
                // If step is not global and configurator is set, ensure association exists
                if ($this->id_configurator && !$this->object->is_global) {
                    // Check if association already exists
                    $association_exists = Db::getInstance()->getValue('
                        SELECT COUNT(*) 
                        FROM ' . _DB_PREFIX_ . 'configurator_step_association 
                        WHERE id_configurator = ' . (int)$this->id_configurator . ' 
                        AND id_step = ' . (int)$id_step
                    );
                    
                    if (!$association_exists) {
                        // Create association in junction table
                        $position = Step::getHigherPosition($this->id_configurator) + 1;
                        $this->object->copyToConfigurator($this->id_configurator);
                        PrestaShopLogger::addLog('Created step association for step ID: ' . $id_step . ' with configurator ID: ' . $this->id_configurator, 1);
                    }
                }
                
                $this->saveOptions($id_step);
                
                // Redirect back to AdminSteps (not AdminConfigurators)
                $redirect_url = $this->context->link->getAdminLink('AdminSteps') . 
                               '&updateconfigurator_step' . 
                               '&id_step=' . (int)$id_step . 
                               '&id_configurator=' . (int)$this->id_configurator . 
                               '&token=' . $this->token;
                
                Tools::redirectAdmin($redirect_url);
                return;
            }
            return $res;
        }
        return parent::postProcess();
    }

    protected function saveOptions($id_step)
    {
        $options_data = Tools::getValue('options');
        $files = $_FILES['option_images'] ?? [];

        // Validate step exists
        $step = new Step($id_step);
        if (!Validate::isLoadedObject($step)) {
            PrestaShopLogger::addLog('Cannot save options: Invalid step ID ' . $id_step, 3);
            return;
        }

        // Remove old options
        Db::getInstance()->delete('configurator_option', 'id_step = ' . (int) $id_step);

        if (!is_array($options_data)) {
            return;
        }
        
        // Validate options data structure
        $validation_errors = [];
        foreach ($options_data as $optionId => $opt) {
            if (empty($opt['label'])) {
                continue; // Skip empty options
            }
            
            // Validate option type
            if (empty($opt['type']) || !in_array($opt['type'], ['visual_choice', 'color_choice', 'ral_system', 'dimension_range', 'fixed_range', 'toggle'])) {
                $validation_errors[] = $this->module->l('Invalid option type for option: ') . $opt['label'];
                continue;
            }
            
            // Validate label length
            if (strlen($opt['label']) > 255) {
                $validation_errors[] = $this->module->l('Option label too long for: ') . $opt['label'];
                continue;
            }
            
            // Validate price_value if provided
            if (isset($opt['price_value']) && $opt['price_value'] !== '' && !is_numeric(str_replace(',', '.', $opt['price_value']))) {
                $validation_errors[] = $this->module->l('Invalid price value for option: ') . $opt['label'];
                continue;
            }
        }
        
        if (!empty($validation_errors)) {
            foreach ($validation_errors as $error) {
                $this->errors[] = $error;
            }
            PrestaShopLogger::addLog('Option validation errors: ' . implode(', ', $validation_errors), 3);
            return;
        }

        $currentTheme = Context::getContext()->shop->theme_name;
        $uploadDir = _PS_ROOT_DIR_ . '/themes/' . $currentTheme . '/assets/img/configurator/';
        if (!is_dir($uploadDir)) {
            @mkdir($uploadDir, 0755, true);
        }

        $pos = 0;
        // Store mapping of form option IDs to new option IDs for color saving
        $option_id_mapping = [];
        
        foreach ($options_data as $optionId => $opt) {

            if (empty($opt['label'])) {
                continue;
            }

            $label = $opt['label'];
            $value_key = !empty($opt['value_key']) ? $opt['value_key'] : Tools::str2url($label);

            $option = new Option();
            $option->id_step = (int) $id_step;
            $option->position = isset($opt['position']) ? (int) $opt['position'] : $pos++;
            $option->option_type = pSQL($opt['type']);
            $option->label = pSQL($label);
            $option->description = pSQL($opt['description'] ?? '', true); // HTML allowed
            $option->price_type = pSQL($opt['price_type']);

            $option->price_value = (float) str_replace(',', '.', $opt['price_value']);
            $option->value_key = pSQL($value_key);
            $option->show_options = pSQL($opt['show_options'] ?? '');
            $option->hide_options = pSQL($opt['hide_options'] ?? '');
            $option->price_calculation = pSQL($opt['price_calculation'] ?? '');
            $option->config = json_encode($opt['config'] ?? []);

            // 🖼 IMAGE UPLOAD
            if (!empty($files['tmp_name'][$optionId])) {

                $file = [
                    'name' => $files['name'][$optionId],
                    'tmp_name' => $files['tmp_name'][$optionId],
                    'size' => $files['size'][$optionId],
                    'type' => $files['type'][$optionId],
                    'error' => $files['error'][$optionId],
                ];

                $error = ImageManager::validateUpload($file, 2000000);
                if (!$error) {
                    $ext = Tools::strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                    $fileName = 'option_' . $id_step . '_' . uniqid() . '.' . $ext;

                    move_uploaded_file($file['tmp_name'], $uploadDir . $fileName);
                    $option->image = pSQL($fileName);
                }
            } else {
                // keep old image if no new upload
                $option->image = pSQL($opt['image'] ?? '');
            }

            if ($option->add()) {
                // Store mapping: form option ID => new option ID
                $option_id_mapping[$optionId] = $option->id;
                
                PrestaShopLogger::addLog('Option saved - Form ID: ' . $optionId . ', New DB ID: ' . $option->id . ', Type: ' . $option->option_type, 1);
                
                // Save custom colors for RAL options (after option is saved and has ID)
                // Use form option ID to find colors in POST data, then save with new option ID
                if ($option->option_type == 'ral_system' && $option->id) {
                    PrestaShopLogger::addLog('Calling saveCustomColors for RAL option - DB ID: ' . $option->id . ', Form ID: ' . $optionId, 1);
                    $this->saveCustomColors($option->id, $optionId);
                }
            } else {
                PrestaShopLogger::addLog('Failed to save option - Form ID: ' . $optionId . ', Error: ' . print_r($option->getErrors(), true), 3);
            }
        }
    }

    /**
     * Save custom colors for an option
     */
    protected function saveCustomColors($id_option, $form_option_id = null)
    {
        $custom_colors = Tools::getValue('custom_colors');
        
        // Debug logging
        PrestaShopLogger::addLog('saveCustomColors called - id_option: ' . $id_option . ', form_option_id: ' . $form_option_id, 1);
        PrestaShopLogger::addLog('custom_colors POST data keys: ' . (is_array($custom_colors) ? implode(', ', array_keys($custom_colors)) : 'not array'), 1);
        
        if (!is_array($custom_colors) || empty($custom_colors)) {
            // Nothing posted - check if we should delete existing colors
            $existing = Db::getInstance()->getValue('SELECT COUNT(*) FROM ' . _DB_PREFIX_ . 'configurator_custom_color WHERE id_option = ' . (int)$id_option);
            if ($existing > 0) {
                // Option exists but no colors in form - delete all (user removed all colors)
                Db::getInstance()->delete('configurator_custom_color', 'id_option = ' . (int)$id_option);
                PrestaShopLogger::addLog('Deleted all existing colors for option ' . $id_option . ' (no colors in POST)', 1);
            }
            return;
        }
        
        // Find colors for this option - try multiple matching strategies
        $colors_data = null;
        
        // Strategy 1: Try by form option ID first (for new options)
        if ($form_option_id) {
            $form_keys = [$form_option_id, (string)$form_option_id, (int)$form_option_id];
            foreach ($form_keys as $key) {
                if (isset($custom_colors[$key]) && is_array($custom_colors[$key]) && !empty($custom_colors[$key])) {
                    $colors_data = $custom_colors[$key];
                    PrestaShopLogger::addLog('Found colors by form_option_id key: ' . $key, 1);
                    break;
                }
            }
        }
        
        // Strategy 2: Try by database option ID (for existing options being edited)
        if (!$colors_data) {
            $db_keys = [$id_option, (string)$id_option, (int)$id_option];
            foreach ($db_keys as $key) {
                if (isset($custom_colors[$key]) && is_array($custom_colors[$key]) && !empty($custom_colors[$key])) {
                    $colors_data = $custom_colors[$key];
                    PrestaShopLogger::addLog('Found colors by id_option key: ' . $key, 1);
                    break;
                }
            }
        }
        
        // Strategy 3: Find by checking existing color IDs (for editing existing colors)
        if (!$colors_data) {
            PrestaShopLogger::addLog('Trying to find colors by checking existing color IDs. Available keys: ' . implode(', ', array_keys($custom_colors)), 1);
            
            foreach ($custom_colors as $key => $data) {
                if (is_array($data) && !empty($data)) {
                    // Check if any color in this set belongs to our option
                    foreach ($data as $colorItem) {
                        if (isset($colorItem['id_color']) && is_numeric($colorItem['id_color']) && $colorItem['id_color'] > 0) {
                            $testColor = new CustomColor((int)$colorItem['id_color']);
                            if (Validate::isLoadedObject($testColor) && $testColor->id_option == $id_option) {
                                $colors_data = $data;
                                PrestaShopLogger::addLog('Found colors by existing color ID check, key: ' . $key, 1);
                                break 2; // Break both loops
                            }
                        }
                    }
                }
            }
        }
        
        // Strategy 4: If still not found, check all keys and find the one with colors that match this option
        if (!$colors_data) {
            foreach ($custom_colors as $key => $data) {
                if (is_array($data) && !empty($data)) {
                    // If this is the only option being saved, it might be this one
                    // Check if any color name/hex matches existing colors for this option
                    $existing_colors = CustomColor::getByOption($id_option);
                    if (!empty($existing_colors)) {
                        foreach ($data as $colorItem) {
                            foreach ($existing_colors as $existing_color) {
                                if (isset($colorItem['color_name']) && $colorItem['color_name'] == $existing_color->color_name) {
                                    $colors_data = $data;
                                    PrestaShopLogger::addLog('Found colors by matching color name, key: ' . $key, 1);
                                    break 3; // Break all loops
                                }
                            }
                        }
                    }
                }
            }
        }
        
        if (!$colors_data || !is_array($colors_data)) {
            PrestaShopLogger::addLog('No colors_data found for option ' . $id_option . '. Available keys: ' . implode(', ', array_keys($custom_colors)), 2);
            return;
        }
        
        PrestaShopLogger::addLog('Saving ' . count($colors_data) . ' colors for option ' . $id_option, 1);
        PrestaShopLogger::addLog('Colors data structure: ' . print_r($colors_data, true), 1);

        $existing_color_ids = [];
        $position = 0;
        
        foreach ($colors_data as $colorId => $colorData) {
            // Skip if not an array or empty
            if (!is_array($colorData)) {
                continue;
            }
            
            // Validate required fields
            if (empty($colorData['color_name']) || empty($colorData['hex_code'])) {
                PrestaShopLogger::addLog('Skipping invalid color (missing name or hex): ' . print_r($colorData, true), 2);
                continue; // Skip invalid colors
            }

            $color = null;
            $is_existing = false;
            
            // Check if it's an existing color (has numeric id_color)
            if (isset($colorData['id_color']) && is_numeric($colorData['id_color']) && $colorData['id_color'] > 0) {
                $color = new CustomColor((int)$colorData['id_color']);
                if (Validate::isLoadedObject($color)) {
                    // Check if color belongs to this option (or if option was recreated, update it)
                    if ($color->id_option == $id_option) {
                        $is_existing = true;
                        PrestaShopLogger::addLog('Updating existing color ID: ' . $color->id_color . ' for option ' . $id_option, 1);
                    } else {
                        // Color belongs to different option - might be from old option ID before recreation
                        // Update it to belong to new option ID
                        PrestaShopLogger::addLog('Color ID ' . $colorData['id_color'] . ' belongs to old option ' . $color->id_option . ', updating to new option ' . $id_option, 1);
                        $is_existing = true; // Still update, just change the option ID
                    }
                } else {
                    // Color doesn't exist - create new
                    $color = new CustomColor();
                    PrestaShopLogger::addLog('Color ID ' . $colorData['id_color'] . ' not found, creating new color', 1);
                }
            } else {
                // New color (no id_color provided)
                $color = new CustomColor();
                PrestaShopLogger::addLog('Creating new color (no ID provided)', 1);
            }

            // Set color properties
            $color->id_option = (int)$id_option;
            $color->color_name = pSQL(trim($colorData['color_name']));
            $color->color_code = pSQL(trim($colorData['color_code'] ?? ''));
            $color->hex_code = pSQL(trim($colorData['hex_code']));
            
            // Set position - use provided position or auto-increment
            if (isset($colorData['position']) && is_numeric($colorData['position'])) {
                $color->position = (int)$colorData['position'];
            } else {
                $color->position = $position++;
            }
            
            // Set active status
            $color->active = isset($colorData['active']) ? (int)$colorData['active'] : 1;

            // Save color
            if ($is_existing && $color->id) {
                if ($color->update()) {
                    $existing_color_ids[] = $color->id;
                    PrestaShopLogger::addLog('Successfully updated color ID: ' . $color->id, 1);
                } else {
                    PrestaShopLogger::addLog('Failed to update color ID: ' . $color->id . '. Errors: ' . print_r($color->getErrors(), true), 3);
                }
            } else {
                if ($color->add()) {
                    $existing_color_ids[] = $color->id;
                    PrestaShopLogger::addLog('Successfully added new color ID: ' . $color->id, 1);
                } else {
                    PrestaShopLogger::addLog('Failed to add color. Errors: ' . print_r($color->getErrors(), true), 3);
                }
            }
        }

        // Delete colors that were removed
        if (!empty($existing_color_ids)) {
            Db::getInstance()->execute('
                DELETE FROM ' . _DB_PREFIX_ . 'configurator_custom_color 
                WHERE id_option = ' . (int)$id_option . ' 
                AND id_color NOT IN (' . implode(',', array_map('intval', $existing_color_ids)) . ')
            ');
        } else {
            // No colors left, delete all
            Db::getInstance()->delete('configurator_custom_color', 'id_option = ' . (int)$id_option);
        }
    }

    protected function duplicateStep($id_step)
    {
        $old_step = new Step((int) $id_step);
        if (!Validate::isLoadedObject($old_step)) {
            $this->errors[] = $this->module->l('Step not found.');
            return false;
        }

        // Create new step with all required fields explicitly set
        $new_step = new Step();
        $new_step->type = $old_step->type ?: 'choice'; // Ensure type is set
        $new_step->title = $old_step->title ? ($old_step->title . ' (Copy)') : 'Step (Copy)'; // Ensure title is set
        $new_step->description = $old_step->description;
        $new_step->is_global = $old_step->is_global;
        $new_step->required = isset($old_step->required) ? $old_step->required : 0;
        $new_step->active = isset($old_step->active) ? $old_step->active : 1;
        $new_step->depends_on_step = 0; // Reset dependencies
        $new_step->depends_on_value = '';
        $new_step->show_condition = $old_step->show_condition ?: 'ANY';
        
        // Set configurator if step is not global
        if (!$new_step->is_global && $this->id_configurator) {
            $new_step->id_configurator = $this->id_configurator;
        }

        if ($new_step->add()) {
            // Duplicate options
            $options = $old_step->getOptions();
            foreach ($options as $old_opt) {
                $new_opt = new Option();
                $new_opt->id_step = (int) $new_step->id;
                $new_opt->option_type = $old_opt->option_type;
                $new_opt->label = $old_opt->label;
                $new_opt->description = $old_opt->description;
                $new_opt->image = $old_opt->image;
                $new_opt->value_key = $old_opt->value_key . '_copy';
                $new_opt->price_type = $old_opt->price_type;
                $new_opt->price_value = $old_opt->price_value;
                $new_opt->position = $old_opt->position;
                $new_opt->config = $old_opt->config;
                $new_opt->show_options = ''; // Reset since option IDs will be different
                $new_opt->hide_options = ''; // Reset since option IDs will be different
                $new_opt->price_calculation = $old_opt->price_calculation;
                
                if ($new_opt->add()) {
                    // Copy custom colors for RAL options
                    if ($old_opt->option_type == 'ral_system') {
                        $custom_colors = CustomColor::getByOption($old_opt->id);
                        foreach ($custom_colors as $color) {
                            $new_color = new CustomColor();
                            $new_color->id_option = $new_opt->id;
                            $new_color->color_name = $color->color_name;
                            $new_color->color_code = $color->color_code;
                            $new_color->hex_code = $color->hex_code;
                            $new_color->position = $color->position;
                            $new_color->active = $color->active;
                            $new_color->add();
                        }
                    }
                }
            }
            
            // If step is not global and configurator is set, create association
            if (!$new_step->is_global && $this->id_configurator) {
                $new_step->copyToConfigurator($this->id_configurator);
            }
            
            return true;
        } else {
            // Log the error for debugging
            PrestaShopLogger::addLog('Failed to duplicate step ID: ' . $id_step . '. Validation errors: ' . print_r($new_step->getErrors(), true), 3);
        }
        return false;
    }
}
