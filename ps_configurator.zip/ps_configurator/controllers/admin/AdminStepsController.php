<?php
/**
 * AdminStepsController
 */

class AdminStepsController extends ModuleAdminController
{
    protected $id_configurator;

    public function __construct()
    {
        $this->table = 'configurator_step';
        $this->className = 'Step';
        $this->identifier = 'id_step';
        $this->bootstrap = true;

        parent::__construct();

        $this->id_configurator = (int)Tools::getValue('id_configurator');

        if (Tools::isSubmit('duplicateconfigurator_step')) {
            $id_step = (int)Tools::getValue('id_step');
            if ($this->duplicateStep($id_step)) {
                $this->confirmations[] = $this->module->l('Step duplicated successfully.');
                Tools::redirectAdmin($this->context->link->getAdminLink('AdminSteps') . '&id_configurator=' . (int)$this->id_configurator);
            }
        }

        $this->fields_list = [
            'id_step' => ['title' => $this->module->l('ID'), 'width' => 25],
            'title' => ['title' => $this->module->l('Title')],
            'type' => ['title' => $this->module->l('Type')],
            'position' => [
                'title' => $this->module->l('Position'), 
                'filter_key' => 'a!position', 
                'position' => 'position',
                'align' => 'center',
                'class' => 'fixed-width-sm'
            ],
            'active' => ['title' => $this->module->l('Active'), 'active' => 'status', 'type' => 'bool'],
        ];

        $this->addRowAction('edit');
        $this->addRowAction('delete');
        
        $this->position_identifier = 'id_step';
        $this->position_group_identifier = 'id_configurator'; // Crucial for multi-configurator support
        $this->_where = 'AND id_configurator = ' . (int)$this->id_configurator;
        $this->_orderBy = 'position';
        $this->_defaultOrderBy = 'position';
    }

    public function ajaxProcessUpdatePositions()
    {
        $id_configurator = (int)Tools::getValue('id_configurator');
        $steps = Tools::getValue('steps');
        if (!$steps) {
            $steps = Tools::getValue($this->table);
        }

        if (is_array($steps)) {
            $success = true;
            foreach ($steps as $position => $id_step_raw) {
                // PrestaShop handles may send "tr_13" or "ps_configurator_step_13"
                $id_step = (int)preg_replace('/[^0-9]/', '', $id_step_raw);
                
                if ($id_step > 0) {
                    $res = Db::getInstance()->execute('
                        UPDATE `' . _DB_PREFIX_ . 'configurator_step`
                        SET `position` = ' . (int)$position . '
                        WHERE `id_step` = ' . (int)$id_step . '
                        AND `id_configurator` = ' . (int)($id_configurator ?: $this->id_configurator)
                    );
                    if (!$res) $success = false;
                }
            }
            die(json_encode(['success' => $success]));
        }
        die(json_encode(['success' => false, 'error' => 'No steps data found']));
    }

    public function init()
    {
        parent::init();
        if (!$this->id_configurator && !Tools::isSubmit('submitAdd' . $this->table) && !Tools::isSubmit('update' . $this->table) && !Tools::isSubmit('delete' . $this->table)) {
            Tools::redirectAdmin($this->context->link->getAdminLink('AdminConfigurators'));
        }
    }

    public function initToolbar()
    {
        parent::initToolbar();
        if (isset($this->toolbar_btn['new'])) {
            $this->toolbar_btn['new']['href'] .= '&id_configurator=' . (int)$this->id_configurator;
        }
        $this->context->smarty->assign('help_link', '');
    }

    public function renderForm()
    {
        if (!($obj = $this->loadObject(true))) {
            return;
        }

        // Fetch all steps for the sidebar
        $all_steps = Db::getInstance()->executeS('
            SELECT id_step, title, type 
            FROM ' . _DB_PREFIX_ . 'configurator_step 
            WHERE id_configurator = ' . (int)$this->id_configurator . '
            ORDER BY position ASC
        ');

        $this->fields_form = [
            'legend' => [
                'title' => ($obj->id ? $this->module->l('Edit Step:') . ' ' . $obj->title : $this->module->l('Create New Step')),
                'icon' => 'icon-pencil',
            ],
            'input' => [
                [
                    'type' => 'hidden',
                    'name' => 'id_configurator',
                ],
                [
                    'type' => 'text',
                    'label' => $this->module->l('Title'),
                    'name' => 'title',
                    'required' => true,
                ],
                [
                    'type' => 'textarea',
                    'label' => $this->module->l('Description'),
                    'name' => 'description',
                    'autoload_rte' => true,
                ],
                [
                    'type' => 'select',
                    'label' => $this->module->l('Step Type'),
                    'name' => 'type',
                    'options' => [
                        'query' => [
                            ['id' => 'content', 'name' => 'Content Only'],
                            ['id' => 'choice', 'name' => 'Choice'],
                            ['id' => 'dimension', 'name' => 'Dimension'],
                            ['id' => 'multi_choice', 'name' => 'Multi Choice'],
                            ['id' => 'summary', 'name' => 'Summary'],
                        ],
                        'id' => 'id',
                        'name' => 'name',
                    ],
                ],
                [
                    'type' => 'switch',
                    'label' => $this->module->l('Required'),
                    'name' => 'required',
                    'is_bool' => true,
                    'values' => [
                        ['id' => 'req_on', 'value' => 1, 'label' => $this->module->l('Yes')],
                        ['id' => 'req_off', 'value' => 0, 'label' => $this->module->l('No')],
                    ],
                ],
                [
                    'type' => 'select',
                    'label' => $this->module->l('Depends on Step'),
                    'name' => 'depends_on_step',
                    'options' => [
                        'query' => array_merge([['id_step' => 0, 'title' => 'None']], $all_steps),
                        'id' => 'id_step',
                        'name' => 'title',
                    ],
                ],
                [
                    'type' => 'text',
                    'label' => $this->module->l('Trigger Values'),
                    'name' => 'depends_on_value',
                    'desc' => $this->module->l('Comma separated values that trigger this step.'),
                ],
                [
                    'type' => 'select',
                    'label' => $this->module->l('Show Condition'),
                    'name' => 'show_condition',
                    'options' => [
                        'query' => [
                            ['id' => 'ANY', 'name' => 'Any'],
                            ['id' => 'ALL', 'name' => 'All'],
                            ['id' => 'NONE', 'name' => 'None'],
                        ],
                        'id' => 'id',
                        'name' => 'name',
                    ],
                ],
                [
                    'type' => 'switch',
                    'label' => $this->module->l('Active'),
                    'name' => 'active',
                    'is_bool' => true,
                    'values' => [
                        ['id' => 'active_on', 'value' => 1, 'label' => $this->module->l('Yes')],
                        ['id' => 'active_off', 'value' => 0, 'label' => $this->module->l('No')],
                    ],
                ],
            ],
            'submit' => [
                'title' => $this->module->l('Save'),
            ],
        ];

        if (!$obj->id_configurator) {
            $this->fields_value['id_configurator'] = $this->id_configurator;
        }

        // Add Options Repeater
        $this->context->smarty->assign([
            'options' => $obj->getOptions(),
            'option_types' => [
                'visual_choice' => 'Visual Choice',
                'color_choice' => 'Standard Color', // Renaming visual_choice alias if we wanted, but let's stick to new types
                'ral_system' => 'RAL Color System',
                'dimension_range' => 'Dimension Range',
                'fixed_range' => 'Fixed Range',
                'toggle' => 'Toggle'
            ],
            'price_types' => [
                'fixed' => 'Fixed',
                'per_unit' => 'Per Unit',
                'formula' => 'Formula'
            ],
            'img_path' => __PS_BASE_URI__ . 'themes/child_classic/assets/img/configurator/'
        ]);

        $options_tpl = $this->context->smarty->fetch($this->module->getLocalPath() . 'views/templates/admin/step_options.tpl');
        
        $this->fields_form['input'][] = [
            'type' => 'free',
            'name' => 'options_repeater',
            'label' => $this->module->l('Step Options'),
        ];
        $this->fields_value['options_repeater'] = $options_tpl;

        $form_content = parent::renderForm();

        $this->context->smarty->assign([
            'id_configurator' => $this->id_configurator,
            'all_steps' => $all_steps,
            'current_step_id' => $obj->id,
            'form_content' => $form_content,
            'link' => $this->context->link
        ]);

        return $this->context->smarty->fetch($this->module->getLocalPath() . 'views/templates/admin/builder_layout.tpl');
    }

    public function renderList()
    {
        // If we are listing steps, we should also use the layout or redirect
        // For now, let's just show the standard list which will be wrapped in the same feeling if needed.
        return parent::renderList();
    }

    public function postProcess()
    {
        if (Tools::isSubmit('submitAdd' . $this->table)) {
            $res = parent::postProcess();
            if ($res && ($id_step = (int)$this->object->id)) {
                $this->saveOptions($id_step);
            }
            return $res;
        }
        return parent::postProcess();
    }

    protected function saveOptions($id_step)
{
    $options_data = Tools::getValue('options');
    $files = $_FILES['option_images'] ?? [];

    // Remove old options
    Db::getInstance()->delete('configurator_option', 'id_step = ' . (int)$id_step);

    if (!is_array($options_data)) {
        return;
    }

    $uploadDir = _PS_ROOT_DIR_ . '/themes/child_classic/assets/img/configurator/';
    if (!is_dir($uploadDir)) {
        @mkdir($uploadDir, 0755, true);
    }

    $pos = 0;
    foreach ($options_data as $optionId => $opt) {

        if (empty($opt['label'])) {
            continue;
        }

        $label = $opt['label'];
        $value_key = !empty($opt['value_key']) ? $opt['value_key'] : Tools::str2url($label);

        $option = new Option();
        $option->id_step = (int)$id_step;
        $option->position = isset($opt['position']) ? (int)$opt['position'] : $pos++;
        $option->option_type = pSQL($opt['type']);
        $option->label = pSQL($label);
        $option->description = pSQL($opt['description'] ?? '', true); // HTML allowed
        $option->price_type = pSQL($opt['price_type']);

        $option->price_value = (float)str_replace(',', '.', $opt['price_value']);
        $option->value_key = pSQL($value_key);
        $option->show_options = pSQL($opt['show_options'] ?? '');
        $option->hide_options = pSQL($opt['hide_options'] ?? '');
        $option->price_calculation = pSQL($opt['price_calculation'] ?? '');
        $option->config = json_encode($opt['config'] ?? []);

        // 🖼 IMAGE UPLOAD
        if (!empty($files['tmp_name'][$optionId])) {

            $file = [
                'name'     => $files['name'][$optionId],
                'tmp_name' => $files['tmp_name'][$optionId],
                'size'     => $files['size'][$optionId],
                'type'     => $files['type'][$optionId],
                'error'    => $files['error'][$optionId],
            ];

            $error = ImageManager::validateUpload($file, 2000000);
            if (!$error) {
                $ext = Tools::strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                $fileName = 'option_' . $id_step . '_' . uniqid() . '.' . $ext;

                move_uploaded_file($file['tmp_name'], $uploadDir . $fileName);
                $option->image = pSQL($fileName);
            }
        } else {
            // keep old image if no new upload
            $option->image = pSQL($opt['image'] ?? '');
        }

        $option->add();
    }
}

    protected function duplicateStep($id_step)
    {
        $old_step = new Step((int)$id_step);
        if (!Validate::isLoadedObject($old_step)) {
            return false;
        }

        $new_step = clone $old_step;
        $new_step->id = null;
        $new_step->position = (int)Step::getHigherPosition((int)$old_step->id_configurator) + 1;
        
        if ($new_step->add()) {
            // Duplicate options
            $options = $old_step->getOptions();
            foreach ($options as $old_opt) {
                // We shouldn't use deep clone directly for database objects without care
                $new_opt = new Option();
                $new_opt->id_step = (int)$new_step->id;
                $new_opt->option_type = $old_opt->option_type;
                $new_opt->label = $old_opt->label;
                $new_opt->description = $old_opt->description;
                $new_opt->image = $old_opt->image;
                $new_opt->value_key = $old_opt->value_key . '_copy';
                $new_opt->price_type = $old_opt->price_type;
                $new_opt->price_value = $old_opt->price_value;
                $new_opt->position = $old_opt->position;
                $new_opt->config = $old_opt->config;
                $new_opt->add();
            }
            return true;
        }
        return false;
    }
}
