<?php
/**
 * AdminStepsController
 */

class AdminStepsController extends ModuleAdminController
{
    protected $id_configurator;

    public function __construct()
    {
        $this->table = 'configurator_step';
        $this->className = 'Step';
        $this->identifier = 'id_step';
        $this->bootstrap = true;

        parent::__construct();

        $this->id_configurator = (int) Tools::getValue('id_configurator');

        if (Tools::isSubmit('duplicateconfigurator_step')) {
            $id_step = (int) Tools::getValue('id_step');
            if ($this->duplicateStep($id_step)) {
                $this->confirmations[] = $this->module->l('Step duplicated successfully.');
                Tools::redirectAdmin($this->context->link->getAdminLink('AdminSteps') . '&id_configurator=' . (int) $this->id_configurator);
            }
        }

        $this->fields_list = [
            'id_step' => ['title' => $this->module->l('ID'), 'width' => 25],
            'title' => ['title' => $this->module->l('Title')],
            'type' => ['title' => $this->module->l('Type')],
            'position' => [
                'title' => $this->module->l('Position'),
                'filter_key' => 'a!position',
                'position' => 'position',
                'align' => 'center',
                'class' => 'fixed-width-sm'
            ],
            'active' => ['title' => $this->module->l('Active'), 'active' => 'status', 'type' => 'bool'],
        ];

        $this->addRowAction('edit');
        $this->addRowAction('delete');

        $this->position_identifier = 'id_step';
        $this->position_group_identifier = 'id_configurator'; // Crucial for multi-configurator support
        $this->_where = 'AND id_configurator = ' . (int) $this->id_configurator;
        $this->_orderBy = 'position';
        $this->_defaultOrderBy = 'position';
    }

    public function ajaxProcessUpdatePositions()
    {
        $id_configurator = (int) Tools::getValue('id_configurator');
        $steps = Tools::getValue('steps');
        
        if (!$steps) {
            $steps = Tools::getValue($this->table);
        }

        if (!is_array($steps) || empty($steps)) {
            die(json_encode(['success' => false, 'error' => 'No steps data found']));
        }

        $success = true;

        // Handle both formats: array of IDs [5,6,7] or associative array [0=>5, 1=>6]
        $step_array = [];
        foreach ($steps as $key => $value) {
            if (is_numeric($key)) {
                // It's an indexed array - use key as position
                $id_step_raw = $value;
                $position = (int)$key;
            } else {
                // It's an associative array - use value as position
                $id_step_raw = $key;
                $position = (int)$value;
            }
            
            // Extract step ID from various formats
            $id_step = (int) preg_replace('/[^0-9]/', '', $id_step_raw);

            if ($id_step <= 0) {
                continue;
            }

            $step_array[] = ['id_step' => $id_step, 'position' => $position];
        }

        // Sort by position to ensure correct order
        usort($step_array, function($a, $b) {
            return $a['position'] - $b['position'];
        });

        // Update positions
        foreach ($step_array as $index => $step_data) {
            $id_step = (int)$step_data['id_step'];
            $position = (int)$step_data['position'];
            
            // Use index as position if position is 0 or invalid
            if ($position <= 0) {
                $position = $index + 1;
            }

            // Update position in junction table if configurator-specific
            if ($id_configurator) {
                $res = Db::getInstance()->execute('
                    UPDATE `' . _DB_PREFIX_ . 'configurator_step_association`
                    SET `position` = ' . (int) $position . '
                    WHERE `id_step` = ' . (int) $id_step . '
                    AND `id_configurator` = ' . (int) $id_configurator
                );
            } else {
                // Update position in step table for global steps
                $res = Db::getInstance()->execute('
                    UPDATE `' . _DB_PREFIX_ . 'configurator_step`
                    SET `position` = ' . (int) $position . '
                    WHERE `id_step` = ' . (int) $id_step . '
                    AND `is_global` = 1'
                );
            }

            if (!$res) {
                $success = false;
                PrestaShopLogger::addLog("Failed to update step $id_step to position $position");
            }
        }

        die(json_encode(['success' => $success]));
    }

    public function init()
    {
        parent::init();
        
        // Handle adding step from global library to configurator
        if (Tools::isSubmit('addStepToConfigurator')) {
            $id_step = (int)Tools::getValue('id_step');
            $id_configurator = (int)Tools::getValue('id_configurator');
            if ($id_step && $id_configurator) {
                $configurator = new Configurator($id_configurator);
                if (Validate::isLoadedObject($configurator)) {
                    if ($configurator->addStep($id_step)) {
                        $this->confirmations[] = $this->module->l('Step added to configurator successfully.');
                    } else {
                        $this->errors[] = $this->module->l('Failed to add step to configurator.');
                    }
                }
                Tools::redirectAdmin($this->context->link->getAdminLink('AdminSteps') . '&id_configurator=' . $id_configurator);
            }
        }
        
        // Handle duplicating step to configurator
        if (Tools::isSubmit('duplicateStepToConfigurator')) {
            $id_step = (int)Tools::getValue('id_step');
            $id_configurator = (int)Tools::getValue('id_configurator');
            if ($id_step && $id_configurator) {
                $step = new Step($id_step);
                if (Validate::isLoadedObject($step)) {
                    $new_step = $step->duplicate($id_configurator);
                    if ($new_step) {
                        $this->confirmations[] = $this->module->l('Step duplicated successfully.');
                    } else {
                        $this->errors[] = $this->module->l('Failed to duplicate step.');
                    }
                }
                Tools::redirectAdmin($this->context->link->getAdminLink('AdminSteps') . '&id_configurator=' . $id_configurator);
            }
        }
        
        // Allow access without id_configurator for global steps library
        if (!$this->id_configurator && !Tools::isSubmit('submitAdd' . $this->table) && !Tools::isSubmit('update' . $this->table) && !Tools::isSubmit('delete' . $this->table) && !Tools::isSubmit('viewGlobalSteps')) {
            // Show global steps library instead of redirecting
            $this->id_configurator = 0; // 0 means global steps
        }
    }

    public function initToolbar()
    {
        parent::initToolbar();
        if (isset($this->toolbar_btn['new'])) {
            $this->toolbar_btn['new']['href'] .= '&id_configurator=' . (int) $this->id_configurator;
        }
        $this->context->smarty->assign('help_link', '');
    }

    public function renderForm()
    {
        if (!($obj = $this->loadObject(true))) {
            return;
        }

        // Fetch all steps for the sidebar (from junction table if configurator-specific)
        if ($this->id_configurator) {
            $all_steps = Db::getInstance()->executeS('
                SELECT cs.id_step, cs.title, cs.type, cs.is_global
                FROM ' . _DB_PREFIX_ . 'configurator_step_association csa
                INNER JOIN ' . _DB_PREFIX_ . 'configurator_step cs ON cs.id_step = csa.id_step
                WHERE csa.id_configurator = ' . (int) $this->id_configurator . '
                ORDER BY csa.position ASC
            ');
        } else {
            $all_steps = [];
        }
        
        // Also get global steps for reference - convert to arrays
        $global_steps_objects = Step::getGlobalSteps();
        $global_steps = [];
        foreach ($global_steps_objects as $step_obj) {
            if (is_object($step_obj) && Validate::isLoadedObject($step_obj)) {
                $global_steps[] = [
                    'id' => (int)$step_obj->id_step,
                    'id_step' => (int)$step_obj->id_step,
                    'title' => $step_obj->title,
                    'type' => $step_obj->type,
                    'is_global' => isset($step_obj->is_global) ? (int)$step_obj->is_global : 0
                ];
            }
        }

        $this->fields_form = [
            'legend' => [
                'title' => ($obj->id ? $this->module->l('Edit Step:') . ' ' . $obj->title : $this->module->l('Create New Step')),
                'icon' => 'icon-pencil',
            ],
            'input' => [
                [
                    'type' => 'hidden',
                    'name' => 'id_configurator',
                ],
                [
                    'type' => 'switch',
                    'label' => $this->module->l('Global Step (Reusable)'),
                    'name' => 'is_global',
                    'desc' => $this->module->l('If enabled, this step can be reused across multiple configurators.'),
                    'is_bool' => true,
                    'values' => [
                        ['id' => 'global_on', 'value' => 1, 'label' => $this->module->l('Yes')],
                        ['id' => 'global_off', 'value' => 0, 'label' => $this->module->l('No')],
                    ],
                ],
                [
                    'type' => 'text',
                    'label' => $this->module->l('Title'),
                    'name' => 'title',
                    'required' => true,
                ],
                [
                    'type' => 'textarea',
                    'label' => $this->module->l('Description'),
                    'name' => 'description',
                    'autoload_rte' => true,
                ],
                [
                    'type' => 'select',
                    'label' => $this->module->l('Step Type'),
                    'name' => 'type',
                    'options' => [
                        'query' => [
                            ['id' => 'content', 'name' => 'Content Only'],
                            ['id' => 'choice', 'name' => 'Choice'],
                            ['id' => 'dimension', 'name' => 'Dimension'],
                            ['id' => 'multi_choice', 'name' => 'Multi Choice'],
                            ['id' => 'summary', 'name' => 'Summary'],
                        ],
                        'id' => 'id',
                        'name' => 'name',
                    ],
                ],
                [
                    'type' => 'switch',
                    'label' => $this->module->l('Required'),
                    'name' => 'required',
                    'is_bool' => true,
                    'values' => [
                        ['id' => 'req_on', 'value' => 1, 'label' => $this->module->l('Yes')],
                        ['id' => 'req_off', 'value' => 0, 'label' => $this->module->l('No')],
                    ],
                ],
                [
                    'type' => 'select',
                    'label' => $this->module->l('Depends on Step'),
                    'name' => 'depends_on_step',
                    'options' => [
                        'query' => array_merge([['id_step' => 0, 'title' => 'None']], $all_steps),
                        'id' => 'id_step',
                        'name' => 'title',
                    ],
                ],
                [
                    'type' => 'text',
                    'label' => $this->module->l('Trigger Values'),
                    'name' => 'depends_on_value',
                    'desc' => $this->module->l('Comma separated values that trigger this step.'),
                ],
                [
                    'type' => 'select',
                    'label' => $this->module->l('Show Condition'),
                    'name' => 'show_condition',
                    'options' => [
                        'query' => [
                            ['id' => 'ANY', 'name' => 'Any'],
                            ['id' => 'ALL', 'name' => 'All'],
                            ['id' => 'NONE', 'name' => 'None'],
                        ],
                        'id' => 'id',
                        'name' => 'name',
                    ],
                ],
                [
                    'type' => 'switch',
                    'label' => $this->module->l('Active'),
                    'name' => 'active',
                    'is_bool' => true,
                    'values' => [
                        ['id' => 'active_on', 'value' => 1, 'label' => $this->module->l('Yes')],
                        ['id' => 'active_off', 'value' => 0, 'label' => $this->module->l('No')],
                    ],
                ],
            ],
            'submit' => [
                'title' => $this->module->l('Save'),
            ],
        ];

        if (!$obj->id_configurator) {
            $this->fields_value['id_configurator'] = $this->id_configurator;
        }
        
        // Set default is_global value - if no configurator, default to global
        if (!$obj->id && !$this->id_configurator) {
            $this->fields_value['is_global'] = 1;
        } elseif (!$obj->id) {
            $this->fields_value['is_global'] = 0;
        }

        // Get custom colors for RAL options
        $options = $obj->getOptions();
        
        // Ensure $options is always an array
        if (!is_array($options)) {
            $options = [];
        }
        
        $custom_colors_data = [];
        foreach ($options as $option) {
            if (is_object($option) && isset($option->option_type) && $option->option_type == 'ral_system') {
                $colors = CustomColor::getByOption($option->id);
                if (is_array($colors)) {
                    $custom_colors_data[$option->id] = $colors;
                } else {
                    $custom_colors_data[$option->id] = [];
                }
            }
        }

        // Add Options Repeater
        $this->context->smarty->assign([
            'options' => $options,
            'custom_colors' => $custom_colors_data,
            'option_types' => [
                'visual_choice' => 'Visual Choice',
                'color_choice' => 'Standard Color', // Renaming visual_choice alias if we wanted, but let's stick to new types
                'ral_system' => 'RAL Color System',
                'dimension_range' => 'Dimension Range',
                'fixed_range' => 'Fixed Range',
                'toggle' => 'Toggle'
            ],
            'price_types' => [
                'fixed' => 'Fixed',
                'percentage' => 'Percentage',
                'per_unit' => 'Per Unit',
                'formula' => 'Formula'
            ],
            'img_path' => __PS_BASE_URI__ . 'themes/' . Context::getContext()->shop->theme_name . '/assets/img/configurator/'
        ]);

        $options_tpl = $this->context->smarty->fetch($this->module->getLocalPath() . 'views/templates/admin/step_options.tpl');

        $this->fields_form['input'][] = [
            'type' => 'free',
            'name' => 'options_repeater',
            'label' => $this->module->l('Step Options'),
        ];
        $this->fields_value['options_repeater'] = $options_tpl;

        $form_content = parent::renderForm();

        $this->context->smarty->assign([
            'id_configurator' => $this->id_configurator,
            'all_steps' => $all_steps,
            'global_steps' => $global_steps,
            'current_step_id' => $obj->id,
            'form_content' => $form_content,
            'link' => $this->context->link
        ]);

        return $this->context->smarty->fetch($this->module->getLocalPath() . 'views/templates/admin/builder_layout.tpl');
    }

    public function renderList()
    {
        // Get global steps library - convert to arrays
        $global_steps_objects = Step::getGlobalSteps();
        $global_steps = [];
        foreach ($global_steps_objects as $step_obj) {
            if (is_object($step_obj) && Validate::isLoadedObject($step_obj)) {
                $global_steps[] = [
                    'id' => (int)$step_obj->id_step,
                    'id_step' => (int)$step_obj->id_step,
                    'title' => $step_obj->title,
                    'type' => $step_obj->type,
                    'is_global' => isset($step_obj->is_global) ? (int)$step_obj->is_global : 0
                ];
            }
        }
        
        // Get configurators list for adding steps
        $configurators = Db::getInstance()->executeS('
            SELECT id_configurator, name 
            FROM ' . _DB_PREFIX_ . 'configurator 
            ORDER BY name ASC
        ');
        
        if ($this->id_configurator) {
            // Fetch steps for this configurator (from junction table)
            $all_steps = Db::getInstance()->executeS('
                SELECT cs.id_step, cs.title, cs.type, cs.is_global, csa.position
                FROM ' . _DB_PREFIX_ . 'configurator_step_association csa
                INNER JOIN ' . _DB_PREFIX_ . 'configurator_step cs ON cs.id_step = csa.id_step
                WHERE csa.id_configurator = ' . (int) $this->id_configurator . '
                ORDER BY csa.position ASC
            ');
            
            // Update WHERE clause for list
            $this->_where = 'AND id_step IN (SELECT id_step FROM ' . _DB_PREFIX_ . 'configurator_step_association WHERE id_configurator = ' . (int)$this->id_configurator . ')';
        } else {
            // Show global steps
            $all_steps = [];
            $this->_where = 'AND is_global = 1';
        }

        $list_content = parent::renderList();

        $this->context->smarty->assign([
            'id_configurator' => $this->id_configurator,
            'all_steps' => $all_steps,
            'global_steps' => $global_steps,
            'configurators' => $configurators,
            'current_step_id' => 0, // No step selected in list view
            'form_content' => $list_content,
            'link' => $this->context->link
        ]);

        return $this->context->smarty->fetch($this->module->getLocalPath() . 'views/templates/admin/builder_layout.tpl');
    }

    public function postProcess()
    {
        if (Tools::isSubmit('submitAdd' . $this->table)) {
            $res = parent::postProcess();
            if ($res && ($id_step = (int) $this->object->id)) {
                $this->saveOptions($id_step);
            }
            return $res;
        }
        return parent::postProcess();
    }

    protected function saveOptions($id_step)
    {
        $options_data = Tools::getValue('options');
        $files = $_FILES['option_images'] ?? [];

        // Remove old options
        Db::getInstance()->delete('configurator_option', 'id_step = ' . (int) $id_step);

        if (!is_array($options_data)) {
            return;
        }

        $currentTheme = Context::getContext()->shop->theme_name;
        $uploadDir = _PS_ROOT_DIR_ . '/themes/' . $currentTheme . '/assets/img/configurator/';
        if (!is_dir($uploadDir)) {
            @mkdir($uploadDir, 0755, true);
        }

        $pos = 0;
        foreach ($options_data as $optionId => $opt) {

            if (empty($opt['label'])) {
                continue;
            }

            $label = $opt['label'];
            $value_key = !empty($opt['value_key']) ? $opt['value_key'] : Tools::str2url($label);

            $option = new Option();
            $option->id_step = (int) $id_step;
            $option->position = isset($opt['position']) ? (int) $opt['position'] : $pos++;
            $option->option_type = pSQL($opt['type']);
            $option->label = pSQL($label);
            $option->description = pSQL($opt['description'] ?? '', true); // HTML allowed
            $option->price_type = pSQL($opt['price_type']);

            $option->price_value = (float) str_replace(',', '.', $opt['price_value']);
            $option->value_key = pSQL($value_key);
            $option->show_options = pSQL($opt['show_options'] ?? '');
            $option->hide_options = pSQL($opt['hide_options'] ?? '');
            $option->price_calculation = pSQL($opt['price_calculation'] ?? '');
            $option->config = json_encode($opt['config'] ?? []);

            // 🖼 IMAGE UPLOAD
            if (!empty($files['tmp_name'][$optionId])) {

                $file = [
                    'name' => $files['name'][$optionId],
                    'tmp_name' => $files['tmp_name'][$optionId],
                    'size' => $files['size'][$optionId],
                    'type' => $files['type'][$optionId],
                    'error' => $files['error'][$optionId],
                ];

                $error = ImageManager::validateUpload($file, 2000000);
                if (!$error) {
                    $ext = Tools::strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                    $fileName = 'option_' . $id_step . '_' . uniqid() . '.' . $ext;

                    move_uploaded_file($file['tmp_name'], $uploadDir . $fileName);
                    $option->image = pSQL($fileName);
                }
            } else {
                // keep old image if no new upload
                $option->image = pSQL($opt['image'] ?? '');
            }

            if ($option->add()) {
                // Save custom colors for RAL options (after option is saved and has ID)
                if ($option->option_type == 'ral_system' && $option->id) {
                    $this->saveCustomColors($option->id, $optionId);
                }
            }
        }
    }

    /**
     * Save custom colors for an option
     */
    protected function saveCustomColors($id_option, $form_option_id = null)
    {
        $custom_colors = Tools::getValue('custom_colors');
        if (!is_array($custom_colors)) {
            // Nothing posted (or invalid payload) — avoid foreach warnings
            return;
        }
        
        // Find colors for this option - match by form option ID or actual option ID
        $colors_data = null;
        
        // Try to find by form option ID first (for new options)
        if ($form_option_id && isset($custom_colors[$form_option_id]) && is_array($custom_colors[$form_option_id])) {
            $colors_data = $custom_colors[$form_option_id];
        }
        // Try to find by actual option ID (for existing options)
        elseif (isset($custom_colors[$id_option]) && is_array($custom_colors[$id_option])) {
            $colors_data = $custom_colors[$id_option];
        } else {
            // Try to find by checking existing colors
            foreach ($custom_colors as $key => $data) {
                if (is_array($data) && !empty($data)) {
                    // Check if any color in this set belongs to our option
                    $firstColor = reset($data);
                    if (isset($firstColor['id_color']) && is_numeric($firstColor['id_color'])) {
                        $testColor = new CustomColor((int)$firstColor['id_color']);
                        if (Validate::isLoadedObject($testColor) && $testColor->id_option == $id_option) {
                            $colors_data = $data;
                            break;
                        }
                    }
                }
            }
        }
        
        if (!$colors_data || !is_array($colors_data)) {
            // No colors provided - check if we should delete existing ones
            // Only delete if this is an update (option already exists)
            $existing = Db::getInstance()->getValue('SELECT COUNT(*) FROM ' . _DB_PREFIX_ . 'configurator_custom_color WHERE id_option = ' . (int)$id_option);
            if ($existing > 0) {
                // Option exists but no colors in form - delete all
                Db::getInstance()->delete('configurator_custom_color', 'id_option = ' . (int)$id_option);
            }
            return;
        }

        $existing_color_ids = [];
        
        foreach ($colors_data as $colorId => $colorData) {
            if (empty($colorData['color_name']) || empty($colorData['hex_code'])) {
                continue; // Skip invalid colors
            }

            $color = null;
            
            // Check if it's an existing color (has numeric ID) or new (starts with 'new_')
            if (isset($colorData['id_color']) && is_numeric($colorData['id_color']) && $colorData['id_color'] > 0) {
                $color = new CustomColor((int)$colorData['id_color']);
                if (!Validate::isLoadedObject($color) || $color->id_option != $id_option) {
                    $color = new CustomColor(); // Create new if ID doesn't match
                }
            } else {
                $color = new CustomColor(); // New color
            }

            $color->id_option = (int)$id_option;
            $color->color_name = pSQL($colorData['color_name']);
            $color->color_code = pSQL($colorData['color_code'] ?? '');
            $color->hex_code = pSQL($colorData['hex_code']);
            $color->position = isset($colorData['position']) ? (int)$colorData['position'] : 0;
            $color->active = isset($colorData['active']) ? (int)$colorData['active'] : 1;

            if ($color->id) {
                $color->update();
                $existing_color_ids[] = $color->id;
            } else {
                $color->add();
                $existing_color_ids[] = $color->id;
            }
        }

        // Delete colors that were removed
        if (!empty($existing_color_ids)) {
            Db::getInstance()->execute('
                DELETE FROM ' . _DB_PREFIX_ . 'configurator_custom_color 
                WHERE id_option = ' . (int)$id_option . ' 
                AND id_color NOT IN (' . implode(',', array_map('intval', $existing_color_ids)) . ')
            ');
        } else {
            // No colors left, delete all
            Db::getInstance()->delete('configurator_custom_color', 'id_option = ' . (int)$id_option);
        }
    }

    protected function duplicateStep($id_step)
    {
        $old_step = new Step((int) $id_step);
        if (!Validate::isLoadedObject($old_step)) {
            return false;
        }

        $new_step = clone $old_step;
        $new_step->id = null;
        $new_step->position = (int) Step::getHigherPosition((int) $old_step->id_configurator) + 1;
        // Reset dependencies since we're duplicating within same configurator
        $new_step->depends_on_step = 0;
        $new_step->depends_on_value = '';

        if ($new_step->add()) {
            // Duplicate options
            $options = $old_step->getOptions();
            foreach ($options as $old_opt) {
                $new_opt = new Option();
                $new_opt->id_step = (int) $new_step->id;
                $new_opt->option_type = $old_opt->option_type;
                $new_opt->label = $old_opt->label;
                $new_opt->description = $old_opt->description;
                $new_opt->image = $old_opt->image;
                $new_opt->value_key = $old_opt->value_key . '_copy';
                $new_opt->price_type = $old_opt->price_type;
                $new_opt->price_value = $old_opt->price_value;
                $new_opt->position = $old_opt->position;
                $new_opt->config = $old_opt->config;
                $new_opt->show_options = ''; // Reset since option IDs will be different
                $new_opt->hide_options = ''; // Reset since option IDs will be different
                $new_opt->price_calculation = $old_opt->price_calculation;
                
                if ($new_opt->add()) {
                    // Copy custom colors for RAL options
                    if ($old_opt->option_type == 'ral_system') {
                        $custom_colors = CustomColor::getByOption($old_opt->id);
                        foreach ($custom_colors as $color) {
                            $new_color = new CustomColor();
                            $new_color->id_option = $new_opt->id;
                            $new_color->color_name = $color->color_name;
                            $new_color->color_code = $color->color_code;
                            $new_color->hex_code = $color->hex_code;
                            $new_color->position = $color->position;
                            $new_color->active = $color->active;
                            $new_color->add();
                        }
                    }
                }
            }
            return true;
        }
        return false;
    }
}
