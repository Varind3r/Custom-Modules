<?php

class AdminConfiguratorRulesController extends ModuleAdminController
{
    protected $id_configurator;

    public function __construct()
    {
        require_once _PS_MODULE_DIR_ . 'ps_configurator/classes/Step.php';
        $this->table = 'configurator_rule';
        $this->className = 'ConfiguratorRule';
        $this->identifier = 'id_rule';
        $this->bootstrap = true;

        parent::__construct();

        $this->id_configurator = (int)Tools::getValue('id_configurator');

        $this->fields_list = [
            'id_rule' => ['title' => $this->module->l('ID'), 'width' => 25],
            'id_step_target' => [
                'title' => $this->module->l('Show Step'),
                'callback' => 'getStepTitle',
                'orderby' => false
            ],
            'rule_summary' => [
                'title' => $this->module->l('Condition'),
                'callback' => 'getRuleSummary',
                'search' => false,
                'orderby' => false
            ],
            'active' => ['title' => $this->module->l('Active'), 'active' => 'status', 'type' => 'bool'],
        ];

        $this->addRowAction('edit');
        $this->addRowAction('delete');

        if ($this->id_configurator) {
            $this->_where = 'AND a.id_configurator = ' . (int)$this->id_configurator;
        }

        $this->_select .= 'c.name as configurator_name';
        $this->_join .= ' LEFT JOIN `' . _DB_PREFIX_ . 'configurator` c ON (c.id_configurator = a.id_configurator)';

        $this->fields_list = array_merge([
            'id_rule' => ['title' => $this->module->l('ID'), 'width' => 25],
            'configurator_name' => ['title' => $this->module->l('Configurator'), 'filter_key' => 'c!name'],
        ], $this->fields_list);
    }

    public function getList($id_lang, $order_by = null, $order_way = null, $start = 0, $limit = null, $id_lang_shop = null)
    {
        parent::getList($id_lang, $order_by, $order_way, $start, $limit, $id_lang_shop);
        
        return true;
    }

    public function getStepTitle($id_step)
    {
        $step = new Step((int)$id_step);
        return Validate::isLoadedObject($step) ? $step->title : $this->module->l('Unknown Step');
    }

    public function getRuleSummary($rule_data)
    {
        $data = json_decode($rule_data, true);
        if (!$data || !isset($data['rules'])) {
            return '---';
        }

        $summary = [];
        foreach ($data['rules'] as $rule) {
            $step = new Step((int)$rule['step_id']);
            $step_title = Validate::isLoadedObject($step) ? $step->title : 'Unknown';
            $vals = is_array($rule['values']) ? implode(', ', $rule['values']) : $rule['values'];
            $op_label = $rule['op'] === 'NOT_IN' ? 'NOT one of' : 'one of';
            $summary[] = sprintf('%s %s [%s]', $step_title, $op_label, $vals);
        }

        return implode(' ' . strtoupper($data['op'] ?? 'AND') . ' ', $summary);
    }

    public function renderForm()
    {
        if (!($obj = $this->loadObject(true))) {
            return;
        }

        // Get id_configurator from multiple sources
        $id_configurator = (int)Tools::getValue('id_configurator');
        if (!$id_configurator && isset($obj->id_configurator) && $obj->id_configurator) {
            $id_configurator = (int)$obj->id_configurator;
        }
        if (!$id_configurator && $this->id_configurator) {
            $id_configurator = $this->id_configurator;
        }

        // Fetch all steps for this configurator
        // Try association table first, then fallback to direct id_configurator link
        $all_steps = [];
        if ($id_configurator) {
            // Method 1: Try association table (newer method)
            $all_steps = Db::getInstance()->executeS('
                SELECT s.id_step, s.title, s.type 
                FROM ' . _DB_PREFIX_ . 'configurator_step s
                INNER JOIN ' . _DB_PREFIX_ . 'configurator_step_association sa ON s.id_step = sa.id_step
                WHERE sa.id_configurator = ' . (int)$id_configurator . '
                ORDER BY sa.position ASC
            ');
            
            // Method 2: Fallback to direct id_configurator link (older method)
            if (empty($all_steps)) {
                $all_steps = Db::getInstance()->executeS('
                    SELECT id_step, title, type 
                    FROM ' . _DB_PREFIX_ . 'configurator_step
                    WHERE id_configurator = ' . (int)$id_configurator . '
                    ORDER BY position ASC
                ');
            }
        }

        if (!$all_steps) {
            $all_steps = [];
        }

        $configurators = Db::getInstance()->executeS('SELECT id_configurator, name FROM ' . _DB_PREFIX_ . 'configurator ORDER BY name ASC');

        $this->fields_form = [
            'legend' => [
                'title' => ($obj->id ? $this->module->l('Edit Rule') : $this->module->l('Create New Rule')),
                'icon' => 'icon-random',
            ],
            'input' => [
                [
                    'type' => 'select',
                    'label' => $this->module->l('Configurator:'),
                    'name' => 'id_configurator',
                    'required' => true,
                    'options' => [
                        'query' => $configurators,
                        'id' => 'id_configurator',
                        'name' => 'name',
                    ],
                ],
                [
                    'type' => 'select',
                    'label' => $this->module->l('Show this step:'),
                    'name' => 'id_step_target',
                    'required' => true,
                    'options' => [
                        'query' => $all_steps,
                        'id' => 'id_step',
                        'name' => 'title',
                    ],
                ],
                [
                    'type' => 'free',
                    'name' => 'rule_builder',
                    'label' => $this->module->l('When these conditions are met:'),
                ],
                [
                    'type' => 'switch',
                    'label' => $this->module->l('Active'),
                    'name' => 'active',
                    'is_bool' => true,
                    'values' => [
                        ['id' => 'active_on', 'value' => 1, 'label' => $this->module->l('Yes')],
                        ['id' => 'active_off', 'value' => 0, 'label' => $this->module->l('No')],
                    ],
                ],
            ],
            'submit' => [
                'title' => $this->module->l('Save Rule'),
            ],
        ];

        $this->fields_value['id_configurator'] = $id_configurator;

        // Prepare rule data
        $rule_data = $obj->rule_data ?: json_encode(['op' => 'AND', 'rules' => []]);
        
        try {
            $decoded = json_decode($rule_data, true);
            if (!is_array($decoded) || !isset($decoded['op']) || !isset($decoded['rules'])) {
                $rule_data = json_encode(['op' => 'AND', 'rules' => []]);
            }
        } catch (Exception $e) {
            $rule_data = json_encode(['op' => 'AND', 'rules' => []]);
        }

        // Get AJAX URLs
        $ajax_url = $this->context->link->getAdminLink('AdminConfiguratorRules') . 
                    '&ajax=1&action=getStepOptions';
                    
        $ajax_url_steps = $this->context->link->getAdminLink('AdminConfiguratorRules') . 
                    '&ajax=1&action=getStepsByConfigurator';

        // Pass data via Smarty
        $this->context->smarty->assign([
            'all_steps' => $all_steps,
            'rule_data' => $rule_data,
            'ajax_url' => $ajax_url,
            'ajax_url_steps' => $ajax_url_steps,
            'id_configurator' => (int)$id_configurator,
        ]);

        // Fetch rule builder template
        $rule_builder_html = $this->context->smarty->fetch(
            $this->module->getLocalPath() . 'views/templates/admin/rule_builder.tpl'
        );

        $this->fields_value['rule_builder'] = $rule_builder_html;

        return parent::renderForm();
    }

    public function ajaxProcessGetStepsByConfigurator()
    {
        header('Content-Type: application/json');
        $id_configurator = (int)Tools::getValue('id_configurator');
        
        if (!$id_configurator) {
            die(json_encode(['error' => 'No configurator ID provided']));
        }

        // Method 1: Try association table (newer method)
        $steps = Db::getInstance()->executeS('
            SELECT s.id_step, s.title, s.type 
            FROM ' . _DB_PREFIX_ . 'configurator_step s
            INNER JOIN ' . _DB_PREFIX_ . 'configurator_step_association sa ON s.id_step = sa.id_step
            WHERE sa.id_configurator = ' . (int)$id_configurator . '
            ORDER BY sa.position ASC
        ');

        // Method 2: Fallback to direct id_configurator link (older method)
        if (empty($steps)) {
            $steps = Db::getInstance()->executeS('
                SELECT id_step, title, type 
                FROM ' . _DB_PREFIX_ . 'configurator_step
                WHERE id_configurator = ' . (int)$id_configurator . '
                ORDER BY position ASC
            ');
        }

        if (empty($steps)) {
            die(json_encode(['error' => 'No steps found for this configurator']));
        }

        die(json_encode($steps));
    }

    public function ajaxProcessGetStepOptions()
    {
        header('Content-Type: application/json');
        
        $id_step = (int)Tools::getValue('id_step');
        
        if (!$id_step) {
            die(json_encode([]));
        }

        try {
            $step = new Step($id_step);
            
            if (!Validate::isLoadedObject($step)) {
                die(json_encode([]));
            }

            // Get options for this step
            if (method_exists($step, 'getOptions')) {
                $options = $step->getOptions();
                // Convert objects to arrays
                $options_array = [];
                foreach ($options as $opt) {
                    if (is_object($opt)) {
                        $options_array[] = [
                            'id_option' => $opt->id_option,
                            'label' => $opt->label,
                            'value_key' => $opt->value_key
                        ];
                    }
                }
                die(json_encode($options_array));
            } else {
                // Fallback: query options directly from database
                $options = Db::getInstance()->executeS('
                    SELECT id_option, label, value_key 
                    FROM ' . _DB_PREFIX_ . 'configurator_option 
                    WHERE id_step = ' . (int)$id_step . '
                    ORDER BY position ASC
                ');
                die(json_encode($options ?: []));
            }
        } catch (Exception $e) {
            error_log('Error in ajaxProcessGetStepOptions: ' . $e->getMessage());
            die(json_encode([]));
        }
    }

    public function postProcess()
    {
        if (Tools::isSubmit('submitAdd' . $this->table) || Tools::isSubmit('submitUpdate' . $this->table)) {
            // Transfer the JSON rule data from frontend to the rule_data field
            $rule_data_json = Tools::getValue('rule_data_json');
            if ($rule_data_json) {
                $_POST['rule_data'] = $rule_data_json;
            }
        }
        return parent::postProcess();
    }

    public function initPageHeaderToolbar()
    {
        parent::initPageHeaderToolbar();    
        // Ensure id_configurator is maintained in breadcrumbs/navigation
        if ($this->id_configurator && isset($this->page_header_toolbar_btn['new'])) {
            $this->page_header_toolbar_btn['new']['href'] .= '&id_configurator=' . (int)$this->id_configurator;
        }
    }
}

