<?php

require_once _PS_MODULE_DIR_ . 'ps_configurator/classes/RalCategory.php';
require_once _PS_MODULE_DIR_ . 'ps_configurator/classes/RalColor.php';

class AdminRalManagementController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        $this->table = 'configurator_ral_category';
        $this->className = 'RalCategory';
        $this->identifier = 'id_ral_category';
        $this->position_identifier = 'id_ral_category';
        $this->orderBy = 'position';
        $this->orderWay = 'ASC';

        parent::__construct();
        
        // Check if we're editing a color (not a category)
        $id_ral_color = (int)Tools::getValue('id_ral_color');
        if ($id_ral_color > 0 || isset($_GET['updateconfigurator_ral_color']) || isset($_GET['addconfigurator_ral_color'])) {
            // Temporarily change table and class for color editing
            $this->table = 'configurator_ral_color';
            $this->className = 'RalColor';
            $this->identifier = 'id_ral_color';
        }

        $this->fields_list = [
            'id_ral_category' => [
                'title' => $this->module->l('ID'),
                'align' => 'center',
                'width' => 30
            ],
            'name' => [
                'title' => $this->module->l('Category Name'),
                'width' => 'auto'
            ],
            'price_impact' => [
                'title' => $this->module->l('Base Price Impact'),
                'type' => 'price',
                'width' => 100
            ],
            'position' => [
                'title' => $this->module->l('Position'),
                'filter_key' => 'a!position',
                'position' => 'position',
                'align' => 'center',
                'class' => 'fixed-width-md'
            ],
            'active' => [
                'title' => $this->module->l('Active'),
                'active' => 'status',
                'type' => 'bool',
                'align' => 'center',
                'width' => 30
            ],
        ];

        $this->bulk_actions = [
            'delete' => [
                'text' => $this->module->l('Delete selected'),
                'confirm' => $this->module->l('Delete selected items?'),
                'icon' => 'icon-trash'
            ]
        ];
    }

    public function renderForm()
    {
        // Check if we're editing a color instead of a category
        $id_ral_color = (int)Tools::getValue('id_ral_color');
        if ($id_ral_color > 0 || isset($_GET['updateconfigurator_ral_color']) || isset($_GET['addconfigurator_ral_color'])) {
            // Render color form instead
            return $this->renderColorForm();
        }
        
        // Otherwise render category form
        $this->fields_form = [
            'legend' => [
                'title' => $this->module->l('RAL Category'),
                'icon' => 'icon-tint'
            ],
            'input' => [
                [
                    'type' => 'text',
                    'label' => $this->module->l('Category Name'),
                    'name' => 'name',
                    'required' => true,
                    'hint' => $this->module->l('e.g. Les Gris, Les Bleus...')
                ],
                [
                    'type' => 'text',
                    'label' => $this->module->l('Base Price Impact'),
                    'name' => 'price_impact',
                    'prefix' => $this->context->currency->sign,
                    'hint' => $this->module->l('Default price for all colors in this category.')
                ],
                [
                    'type' => 'switch',
                    'label' => $this->module->l('Active'),
                    'name' => 'active',
                    'is_bool' => true,
                    'values' => [
                        ['id' => 'active_on', 'value' => 1, 'label' => $this->module->l('Enabled')],
                        ['id' => 'active_off', 'value' => 0, 'label' => $this->module->l('Disabled')]
                    ],
                ],
            ],
            'submit' => [
                'title' => $this->module->l('Save')
            ]
        ];

        return parent::renderForm();
    }

    public function renderList()
    {
        $content = parent::renderList();
        
        // Add a second list for colors - always show it
        $colors_list = $this->renderColorsList();
        if ($colors_list) {
            $content .= '<div class="panel" style="margin-top: 20px;">';
            $content .= $colors_list;
            $content .= '</div>';
        }
        
        return $content;
    }
    
    public function renderView()
    {
        // Check if we're viewing/editing a color
        $id_ral_color = (int)Tools::getValue('id_ral_color');
        if ($id_ral_color > 0 || isset($_GET['updateconfigurator_ral_color']) || isset($_GET['addconfigurator_ral_color'])) {
            // Render color form instead of category view
            return $this->renderColorForm();
        }
        // Otherwise show category list
        return $this->renderList();
    }

    protected function renderColorsList()
    {
        $helper = new HelperList();
        $helper->shopLinkType = '';
        $helper->simple_header = false;
        $helper->identifier = 'id_ral_color';
        $helper->actions = ['edit', 'delete'];
        $helper->show_toolbar = true;
        $helper->module = $this->module;
        $helper->title = $this->module->l('RAL Colors Library');
        $helper->table = 'configurator_ral_color';
        $helper->token = Tools::getAdminTokenLite('AdminRalManagement');
        $helper->currentIndex = $this->context->link->getAdminLink('AdminRalManagement');
        $helper->list_id = 'configurator_ral_color';
        
        $helper->toolbar_btn['new'] = [
            'href' => $this->context->link->getAdminLink('AdminRalManagement').'&addconfigurator_ral_color=1',
            'desc' => $this->module->l('Add New Color'),
            'icon' => 'process-icon-new'
        ];

        $fields_list = [
            'id_ral_color' => ['title' => $this->module->l('ID'), 'width' => 30, 'align' => 'center'],
            'category_name' => ['title' => $this->module->l('Category'), 'width' => 150],
            'ral_code' => ['title' => $this->module->l('RAL Code'), 'width' => 100],
            'name' => ['title' => $this->module->l('Color Name'), 'width' => 'auto'],
            'hex' => ['title' => $this->module->l('HEX'), 'width' => 120, 'callback' => 'displayColorPreview', 'callback_object' => $this, 'align' => 'center'],
            'price_impact' => ['title' => $this->module->l('Price Override'), 'type' => 'price', 'width' => 100, 'align' => 'right'],
            'active' => ['title' => $this->module->l('Active'), 'active' => 'status', 'type' => 'bool', 'align' => 'center', 'width' => 50],
        ];

        $list = Db::getInstance()->executeS('
            SELECT c.*, cat.name as category_name 
            FROM '._DB_PREFIX_.'configurator_ral_color c
            LEFT JOIN '._DB_PREFIX_.'configurator_ral_category cat ON c.id_ral_category = cat.id_ral_category
            ORDER BY cat.position, c.position
        ');

        // Add bulk actions for colors
        $helper->bulk_actions = [
            'delete' => [
                'text' => $this->module->l('Delete selected'),
                'confirm' => $this->module->l('Delete selected colors?'),
                'icon' => 'icon-trash'
            ]
        ];

        return $helper->generateList($list, $fields_list);
    }

    public function displayColorPreview($value, $row)
    {
        if (empty($value) || !preg_match('/^#[0-9A-Fa-f]{6}$/', $value)) {
            $value = '#000000';
        }
        return '<div style="width:30px;height:30px;background-color:'.$value.';border:2px solid #333;border-radius:4px;display:inline-block;vertical-align:middle;margin-right:8px;box-shadow:0 1px 3px rgba(0,0,0,0.3);"></div><span style="font-weight:bold;">'.$value.'</span>';
    }

    public function initContent()
    {
        // Check if we're managing colors (not categories)
        $id_ral_color = (int)Tools::getValue('id_ral_color');
        
        // PrestaShop HelperList generates URLs like: update{table_name}&{identifier}={id}
        // So for configurator_ral_color table, it's: updateconfigurator_ral_color&id_ral_color=X
        // Note: The parameter might exist but be empty, so check isset() as well
        $is_color_action = Tools::isSubmit('addps_configurator_ral_color') || 
            Tools::isSubmit('addconfigurator_ral_color') ||
            Tools::isSubmit('updateps_configurator_ral_color') || 
            Tools::isSubmit('updateconfigurator_ral_color') ||
            isset($_GET['addps_configurator_ral_color']) ||
            isset($_GET['addconfigurator_ral_color']) ||
            isset($_GET['updateps_configurator_ral_color']) ||
            isset($_GET['updateconfigurator_ral_color']) ||
            $id_ral_color > 0;
        
        // Debug logging
        PrestaShopLogger::addLog('initContent - id_ral_color: ' . $id_ral_color . ', is_color_action: ' . ($is_color_action ? 'YES' : 'NO'), 1);
        PrestaShopLogger::addLog('GET params: ' . print_r($_GET, true), 1);
        
        if ($is_color_action) {
            // Don't call parent::initContent() as it will try to render category list
            // Instead, manually initialize the page structure
            $this->initHeader();
            $this->initFooter();
            $this->initToolbar();
            $this->initPageHeaderToolbar();
            
            // Set page title
            if ($id_ral_color > 0) {
                $this->page_header_toolbar_title = $this->module->l('Edit RAL Color');
            } else {
                $this->page_header_toolbar_title = $this->module->l('Add RAL Color');
            }
            
            // Render color form
            $color_form = $this->renderColorForm();
            if ($color_form) {
                $this->content = $color_form;
                // Also show the colors list below
                $this->content .= '<div class="panel" style="margin-top: 20px;">';
                $this->content .= $this->renderColorsList();
                $this->content .= '</div>';
            } else {
                $this->content = '<div class="alert alert-danger">' . $this->module->l('Failed to load color form.') . '</div>';
            }
        } else {
            // Call parent to render category list
            parent::initContent();
        }
    }

    protected function renderColorForm()
    {
        $id = (int)Tools::getValue('id_ral_color');
        
        // Debug logging
        PrestaShopLogger::addLog('renderColorForm called - id_ral_color: ' . $id, 1);
        PrestaShopLogger::addLog('GET params: ' . print_r($_GET, true), 1);
        
        $obj = new RalColor();
        
        // Load object if ID is provided
        if ($id > 0) {
            $obj = new RalColor($id);
            PrestaShopLogger::addLog('Loading RalColor with ID: ' . $id . ', Loaded: ' . (Validate::isLoadedObject($obj) ? 'YES' : 'NO'), 1);
            if (!Validate::isLoadedObject($obj)) {
                $this->errors[] = $this->module->l('Color not found.');
                return '<div class="alert alert-danger">' . $this->module->l('Color not found. ID: ') . $id . '</div>';
            }
            PrestaShopLogger::addLog('Color loaded - Name: ' . $obj->name . ', Code: ' . $obj->ral_code, 1);
        }

        $categories = RalCategory::getAllCategories(false);
        $cat_options = [];
        foreach ($categories as $cat) {
            $price_display = $cat->price_impact ? $this->context->currency->sign . number_format($cat->price_impact, 2) : $this->module->l('Free');
            $cat_options[] = ['id' => $cat->id_ral_category, 'name' => $cat->name . ' (' . $this->module->l('Price: ') . $price_display . ')'];
        }
        
        // Get parent category price for display when editing
        $parent_price_display = '';
        if ($id > 0 && Validate::isLoadedObject($obj) && $obj->id_ral_category) {
            $parent_cat = new RalCategory($obj->id_ral_category);
            if (Validate::isLoadedObject($parent_cat)) {
                $parent_price_display = $parent_cat->price_impact ? 
                    $this->context->currency->sign . number_format($parent_cat->price_impact, 2) : 
                    $this->module->l('Free');
            }
        }

        $fields_form = [
            'form' => [
                'legend' => [
                    'title' => $this->module->l('RAL Color Details'),
                    'icon' => 'icon-tint'
                ],
                'input' => [
                    [
                        'type' => 'hidden',
                        'name' => 'id_ral_color',
                    ],
                    [
                        'type' => 'select',
                        'label' => $this->module->l('Parent Category'),
                        'name' => 'id_ral_category',
                        'required' => true,
                        'desc' => $this->module->l('Select the parent color category. The color will inherit the category price if no specific price is set.'),
                        'options' => [
                            'query' => $cat_options,
                            'id' => 'id',
                            'name' => 'name'
                        ]
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->module->l('RAL Code'),
                        'name' => 'ral_code',
                        'required' => true,
                        'desc' => $this->module->l('Enter the RAL color code (e.g. 7016, 9010)'),
                        'hint' => $this->module->l('e.g. RAL 7016 or just 7016')
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->module->l('Color Name'),
                        'name' => 'name',
                        'required' => true,
                        'desc' => $this->module->l('Enter the descriptive name for this color'),
                        'hint' => $this->module->l('e.g. Gris Anthracite, Blanc Pur')
                    ],
                    [
                        'type' => 'color',
                        'label' => $this->module->l('HEX Color'),
                        'name' => 'hex',
                        'required' => true,
                        'desc' => $this->module->l('Select the color using the color picker'),
                        'hint' => $this->module->l('Click to open color picker')
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->module->l('Price Override'),
                        'name' => 'price_impact',
                        'prefix' => $this->context->currency->sign,
                        'desc' => $this->module->l('Enter a specific price for this color. Leave empty to use the parent category price.') . 
                                  ($parent_price_display ? '<br><strong>' . $this->module->l('Parent Category Price: ') . $parent_price_display . '</strong>' : ''),
                        'hint' => $this->module->l('Leave empty to use parent category price')
                    ],
                    [
                        'type' => 'switch',
                        'label' => $this->module->l('Active'),
                        'name' => 'active',
                        'is_bool' => true,
                        'desc' => $this->module->l('Enable or disable this color'),
                        'values' => [
                            ['id' => 'active_on', 'value' => 1, 'label' => $this->module->l('Enabled')],
                            ['id' => 'active_off', 'value' => 0, 'label' => $this->module->l('Disabled')]
                        ],
                    ],
                ],
                'submit' => [
                    'title' => $this->module->l('Save'),
                    'name' => 'submitAddRalColor'
                ],
                'buttons' => [
                    [
                        'href' => $this->context->link->getAdminLink('AdminRalManagement'),
                        'title' => $this->module->l('Back to List'),
                        'icon' => 'process-icon-back'
                    ]
                ]
            ]
        ];

        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = 'configurator_ral_color';
        $helper->identifier = 'id_ral_color';
        $helper->submit_action = 'submitAddRalColor';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminRalManagement');
        $helper->token = Tools::getAdminTokenLite('AdminRalManagement');
        
        // Get display price - show color price if set, otherwise leave empty (will use parent)
        $display_price = '';
        if (Validate::isLoadedObject($obj) && $obj->price_impact !== null && $obj->price_impact != '' && $obj->price_impact != 0) {
            $display_price = $obj->price_impact;
        }
        
        $helper->fields_value = [
            'id_ral_color' => Validate::isLoadedObject($obj) && isset($obj->id_ral_color) ? $obj->id_ral_color : '',
            'id_ral_category' => Validate::isLoadedObject($obj) && isset($obj->id_ral_category) ? $obj->id_ral_category : '',
            'ral_code' => Validate::isLoadedObject($obj) && isset($obj->ral_code) ? $obj->ral_code : '',
            'name' => Validate::isLoadedObject($obj) && isset($obj->name) ? $obj->name : '',
            'hex' => Validate::isLoadedObject($obj) && isset($obj->hex) && !empty($obj->hex) ? $obj->hex : '#000000',
            'price_impact' => $display_price,
            'active' => Validate::isLoadedObject($obj) && isset($obj->active) && $obj->active !== null ? $obj->active : 1,
        ];

        return $helper->generateForm([$fields_form]);
    }

    public function postProcess()
    {
        // Handle RAL Color operations
        if (Tools::isSubmit('submitAddRalColor')) {
            $id = (int)Tools::getValue('id_ral_color');
            $obj = new RalColor($id);
            
            // Validate required fields
            $id_category = (int)Tools::getValue('id_ral_category');
            $ral_code = trim(Tools::getValue('ral_code'));
            $name = trim(Tools::getValue('name'));
            $hex = trim(Tools::getValue('hex'));
            
            if (!$id_category) {
                $this->errors[] = $this->module->l('Category is required.');
            }
            if (!$ral_code) {
                $this->errors[] = $this->module->l('RAL Code is required.');
            }
            if (!$name) {
                $this->errors[] = $this->module->l('Color Name is required.');
            }
            if (!$hex || !preg_match('/^#[0-9A-Fa-f]{6}$/', $hex)) {
                $this->errors[] = $this->module->l('Valid HEX color is required (e.g. #FF0000).');
            }
            
            if (empty($this->errors)) {
                $obj->id_ral_category = $id_category;
                $obj->ral_code = $ral_code;
                $obj->name = $name;
                $obj->hex = $hex;
                $price = Tools::getValue('price_impact');
                $obj->price_impact = ($price === '' || $price === null ? null : (float)$price);
                $obj->active = (int)Tools::getValue('active', 1);
            
                if ($obj->save()) {
                    $conf = $id ? 4 : 3; // 4 = updated, 3 = added
                    Tools::redirectAdmin($this->context->link->getAdminLink('AdminRalManagement').'&conf='.$conf);
                } else {
                    $this->errors[] = $this->module->l('An error occurred while saving the color: ') . (Db::getInstance()->getMsgError() ?: 'Unknown error');
                }
            }
        } elseif (Tools::isSubmit('deleteps_configurator_ral_color') || Tools::isSubmit('deleteconfigurator_ral_color')) {
            $id = (int)Tools::getValue('id_ral_color');
            if ($id) {
                $obj = new RalColor($id);
                if (Validate::isLoadedObject($obj) && $obj->delete()) {
                    Tools::redirectAdmin($this->context->link->getAdminLink('AdminRalManagement').'&conf=1');
                } else {
                    $this->errors[] = $this->module->l('An error occurred while deleting the color.');
                }
            }
        } elseif (Tools::isSubmit('statusps_configurator_ral_color') || Tools::isSubmit('statusconfigurator_ral_color')) {
            $id = (int)Tools::getValue('id_ral_color');
            if ($id) {
                $obj = new RalColor($id);
                if (Validate::isLoadedObject($obj)) {
                    $obj->active = !$obj->active;
                    if ($obj->save()) {
                        Tools::redirectAdmin($this->context->link->getAdminLink('AdminRalManagement').'&conf=5');
                    }
                }
            }
        } elseif (Tools::isSubmit('submitBulkdeleteps_configurator_ral_color') || Tools::isSubmit('submitBulkdeleteconfigurator_ral_color')) {
            // Handle bulk delete for colors
            $ids = Tools::getValue('configurator_ral_colorBox');
            if (is_array($ids) && !empty($ids)) {
                $deleted = 0;
                foreach ($ids as $id) {
                    $id = (int)$id;
                    if ($id) {
                        $obj = new RalColor($id);
                        if (Validate::isLoadedObject($obj) && $obj->delete()) {
                            $deleted++;
                        }
                    }
                }
                if ($deleted > 0) {
                    Tools::redirectAdmin($this->context->link->getAdminLink('AdminRalManagement').'&conf=1');
                } else {
                    $this->errors[] = $this->module->l('No colors were deleted.');
                }
            } else {
                $this->errors[] = $this->module->l('Please select at least one color to delete.');
            }
        }

        parent::postProcess();
    }
}

