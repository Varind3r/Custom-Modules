<?php

require_once _PS_MODULE_DIR_ . 'ps_configurator/classes/RalCategory.php';
require_once _PS_MODULE_DIR_ . 'ps_configurator/classes/RalColor.php';

class AdminRalManagementController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        $this->table = 'ps_configurator_ral_category';
        $this->className = 'RalCategory';
        $this->identifier = 'id_ral_category';
        $this->position_identifier = 'id_ral_category';
        $this->orderBy = 'position';
        $this->orderWay = 'ASC';

        parent::__construct();

        $this->fields_list = [
            'id_ral_category' => [
                'title' => $this->module->l('ID'),
                'align' => 'center',
                'width' => 30
            ],
            'name' => [
                'title' => $this->module->l('Category Name'),
                'width' => 'auto'
            ],
            'price_impact' => [
                'title' => $this->module->l('Base Price Impact'),
                'type' => 'price',
                'width' => 100
            ],
            'position' => [
                'title' => $this->module->l('Position'),
                'filter_key' => 'a!position',
                'position' => 'position',
                'align' => 'center',
                'class' => 'fixed-width-md'
            ],
            'active' => [
                'title' => $this->module->l('Active'),
                'active' => 'status',
                'type' => 'bool',
                'align' => 'center',
                'width' => 30
            ],
        ];

        $this->bulk_actions = [
            'delete' => [
                'text' => $this->module->l('Delete selected'),
                'confirm' => $this->module->l('Delete selected items?'),
                'icon' => 'icon-trash'
            ]
        ];
    }

    public function renderForm()
    {
        $this->fields_form = [
            'legend' => [
                'title' => $this->module->l('RAL Category'),
                'icon' => 'icon-tint'
            ],
            'input' => [
                [
                    'type' => 'text',
                    'label' => $this->module->l('Category Name'),
                    'name' => 'name',
                    'required' => true,
                    'hint' => $this->module->l('e.g. Les Gris, Les Bleus...')
                ],
                [
                    'type' => 'text',
                    'label' => $this->module->l('Base Price Impact'),
                    'name' => 'price_impact',
                    'prefix' => $this->context->currency->sign,
                    'hint' => $this->module->l('Default price for all colors in this category.')
                ],
                [
                    'type' => 'switch',
                    'label' => $this->module->l('Active'),
                    'name' => 'active',
                    'is_bool' => true,
                    'values' => [
                        ['id' => 'active_on', 'value' => 1, 'label' => $this->module->l('Enabled')],
                        ['id' => 'active_off', 'value' => 0, 'label' => $this->module->l('Disabled')]
                    ],
                ],
            ],
            'submit' => [
                'title' => $this->module->l('Save')
            ]
        ];

        return parent::renderForm();
    }

    public function renderList()
    {
        $content = parent::renderList();
        
        // Add a second list for colors
        $content .= $this->renderColorsList();
        
        return $content;
    }

    protected function renderColorsList()
    {
        $helper = new HelperList();
        $helper->shopLinkType = '';
        $helper->simple_header = false;
        $helper->identifier = 'id_ral_color';
        $helper->actions = ['edit', 'delete'];
        $helper->show_toolbar = true;
        $helper->module = $this->module;
        $helper->title = $this->module->l('RAL Colors Library');
        $helper->table = 'ps_configurator_ral_color';
        $helper->token = Tools::getAdminTokenLite('AdminRalManagement');
        $helper->currentIndex = AdminController::$currentIndex.'&renderColors=1';
        
        $helper->toolbar_btn['new'] = [
            'href' => $this->context->link->getAdminLink('AdminRalManagement').'&addps_configurator_ral_color',
            'desc' => $this->module->l('Add New Color')
        ];

        $fields_list = [
            'id_ral_color' => ['title' => $this->module->l('ID'), 'width' => 30],
            'category_name' => ['title' => $this->module->l('Category'), 'width' => 'auto'],
            'ral_code' => ['title' => $this->module->l('RAL Code'), 'width' => 80],
            'name' => ['title' => $this->module->l('Color Name'), 'width' => 'auto'],
            'hex' => ['title' => $this->module->l('HEX'), 'width' => 80, 'callback' => 'displayColorPreview'],
            'price_impact' => ['title' => $this->module->l('Price Override'), 'type' => 'price', 'width' => 100],
            'active' => ['title' => $this->module->l('Active'), 'active' => 'status', 'type' => 'bool', 'align' => 'center', 'width' => 30],
        ];

        $list = Db::getInstance()->executeS('
            SELECT c.*, cat.name as category_name 
            FROM '._DB_PREFIX_.'ps_configurator_ral_color c
            LEFT JOIN '._DB_PREFIX_.'ps_configurator_ral_category cat ON c.id_ral_category = cat.id_ral_category
            ORDER BY cat.position, c.position
        ');

        return $helper->generateList($list, $fields_list);
    }

    public function displayColorPreview($value)
    {
        return '<div style="width:20px;height:20px;background-color:'.$value.';border:1px solid #000;display:inline-block;vertical-align:middle;margin-right:5px;"></div> '.$value;
    }

    public function initContent()
    {
        if (Tools::isSubmit('addps_configurator_ral_color') || Tools::isSubmit('updateps_configurator_ral_color')) {
            $this->content .= $this->renderColorForm();
        } else {
            parent::initContent();
        }
    }

    protected function renderColorForm()
    {
        $id = (int)Tools::getValue('id_ral_color');
        $obj = new RalColor($id);

        $categories = RalCategory::getAllCategories(false);
        $cat_options = [];
        foreach ($categories as $cat) {
            $cat_options[] = ['id' => $cat->id_ral_category, 'name' => $cat->name];
        }

        $fields_form = [
            'form' => [
                'legend' => [
                    'title' => $this->module->l('RAL Color Details'),
                    'icon' => 'icon-tint'
                ],
                'input' => [
                    [
                        'type' => 'select',
                        'label' => $this->module->l('Category'),
                        'name' => 'id_ral_category',
                        'required' => true,
                        'options' => [
                            'query' => $cat_options,
                            'id' => 'id',
                            'name' => 'name'
                        ]
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->module->l('RAL Code'),
                        'name' => 'ral_code',
                        'required' => true,
                        'hint' => $this->module->l('e.g. RAL 7016')
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->module->l('Color Name'),
                        'name' => 'name',
                        'required' => true
                    ],
                    [
                        'type' => 'color',
                        'label' => $this->module->l('HEX Color'),
                        'name' => 'hex',
                        'required' => true
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->module->l('Price Override'),
                        'name' => 'price_impact',
                        'prefix' => $this->context->currency->sign,
                        'hint' => $this->module->l('Leave empty to use category price.')
                    ],
                    [
                        'type' => 'switch',
                        'label' => $this->module->l('Active'),
                        'name' => 'active',
                        'is_bool' => true,
                        'values' => [
                            ['id' => 'active_on', 'value' => 1, 'label' => $this->module->l('Enabled')],
                            ['id' => 'active_off', 'value' => 0, 'label' => $this->module->l('Disabled')]
                        ],
                    ],
                ],
                'submit' => [
                    'title' => $this->module->l('Save'),
                    'name' => 'submitAddRalColor'
                ],
                'buttons' => [
                    [
                        'href' => $this->context->link->getAdminLink('AdminRalManagement'),
                        'title' => $this->module->l('Cancel'),
                        'icon' => 'process-icon-cancel'
                    ]
                ]
            ]
        ];

        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = 'ps_configurator_ral_color';
        $helper->identifier = 'id_ral_color';
        $helper->submit_action = 'submitAddRalColor';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminRalManagement');
        $helper->token = Tools::getAdminTokenLite('AdminRalManagement');
        
        $helper->fields_value = [
            'id_ral_category' => $obj->id_ral_category,
            'ral_code' => $obj->ral_code,
            'name' => $obj->name,
            'hex' => $obj->hex,
            'price_impact' => $obj->price_impact,
            'active' => $obj->active,
        ];

        return $helper->generateForm([$fields_form]);
    }

    public function postProcess()
    {
        if (Tools::isSubmit('submitAddRalColor')) {
            $id = (int)Tools::getValue('id_ral_color');
            $obj = new RalColor($id);
            $obj->id_ral_category = (int)Tools::getValue('id_ral_category');
            $obj->ral_code = Tools::getValue('ral_code');
            $obj->name = Tools::getValue('name');
            $obj->hex = Tools::getValue('hex');
            $price = Tools::getValue('price_impact');
            $obj->price_impact = ($price === '' ? null : (float)$price);
            $obj->active = (int)Tools::getValue('active');
            
            if ($obj->save()) {
                Tools::redirectAdmin($this->context->link->getAdminLink('AdminRalManagement').'&conf=4');
            } else {
                $this->errors[] = $this->module->l('An error occurred while saving the color.');
            }
        } elseif (Tools::isSubmit('deleteps_configurator_ral_color')) {
            $id = (int)Tools::getValue('id_ral_color');
            $obj = new RalColor($id);
            if ($obj->delete()) {
                Tools::redirectAdmin($this->context->link->getAdminLink('AdminRalManagement').'&conf=1');
            }
        } elseif (Tools::isSubmit('statusps_configurator_ral_color')) {
             $id = (int)Tools::getValue('id_ral_color');
             $obj = new RalColor($id);
             $obj->active = !$obj->active;
             $obj->save();
             Tools::redirectAdmin($this->context->link->getAdminLink('AdminRalManagement').'&conf=5');
        }

        parent::postProcess();
    }
}

