# Complete Issues Guide - All 5 Problems Explained

## Issue 1: Input Fields & Steps Not Appearing

### **Files Involved:**
1. **`views/js/front.js`** - Main JavaScript file
   - Function: `evaluateStepVisibility()` (lines 104-225)
   - Function: `updateUI()` (lines 33-87)
   - Function: `initializeDimensions()` (lines 1207-1221)
   - Function: `handleDimensionChange()` (lines 482-560)

2. **`views/templates/front/configurator.tpl`** - Frontend template
   - Lines 30-35: Step rendering with conditional attributes
   - Lines 173-218: Dimension input fields rendering

3. **`classes/Step.php`** - Step model
   - Method: `getOptions()` (lines 39-57)
   - Properties: `depends_on_step`, `depends_on_value`, `show_condition`

### **What I Did:**
- Fixed `evaluateStepVisibility()` to handle step ID mismatches (string vs number)
- Improved value matching with case-insensitive comparison
- Added better error handling in `updateUI()` to prevent crashes
- Fixed dimension initialization to NOT auto-select (prevents unwanted price additions)

### **What You Need to Check:**
1. **Step IDs**: Ensure `depends_on_step` uses correct step ID (check database `configurator_step` table)
2. **Trigger Values**: Must match option labels/valueKeys exactly (case-insensitive now)
3. **Template Rendering**: Check if steps are being rendered in template (check `configurator.tpl` line 31-35)
4. **JavaScript Console**: Enable debug with `window.configuratorDebug = true` to see evaluation logs

### **Database Fields:**
- `configurator_step.depends_on_step` - ID of step it depends on (0 = no dependency)
- `configurator_step.depends_on_value` - Comma-separated trigger values
- `configurator_step.show_condition` - "ANY", "ALL", or "NONE"

---

## Issue 2: Conditional Logic Not Showing Step Names & Hard to Work With

### **Files Involved:**
1. **`controllers/admin/AdminStepsController.php`** - Admin controller
   - Lines 284-300: Conditional fields definition
   - Method: `renderForm()` - Form rendering
   - Method: `postProcess()` - Form processing

2. **`views/templates/admin/step_options.tpl`** - Admin template (if exists)
   - Conditional fields rendering

3. **`views/js/front.js`** - Frontend JavaScript
   - Function: `evaluateStepVisibility()` (lines 104-225)
   - Debug logging (lines 214-218)

### **What I Did:**
- Improved conditional logic matching (case-insensitive, partial matching)
- Added debug logging to help troubleshoot
- Better step ID handling (string/number conversion)

### **What You Need to Do:**
1. **Improve Admin UI**: 
   - File: `controllers/admin/AdminStepsController.php`
   - Function: `renderForm()` around line 280-300
   - Add dropdown to select step by NAME instead of ID
   - Show step titles in dropdown, store IDs

2. **Better Conditional Display**:
   - Add helper text showing which step names match
   - Add preview of conditional logic
   - Show step names in admin instead of just IDs

3. **Frontend Display**:
   - File: `views/templates/front/configurator.tpl`
   - Line 34: `data-depends-on="{$step->depends_on_step}"`
   - Consider showing step title in debug/console

### **Database Fields:**
- `configurator_step.depends_on_step` - Currently stores ID, should show name
- `configurator_step.depends_on_value` - Trigger values
- `configurator_step.show_condition` - Condition type

### **Suggested Improvements:**
```php
// In AdminStepsController.php renderForm()
// Instead of:
'depends_on_step' => ['type' => 'text', ...]

// Use:
'depends_on_step' => [
    'type' => 'select',
    'options' => [
        'query' => Step::getStepsForDropdown($this->id_configurator),
        'id' => 'id_step',
        'name' => 'title'
    ]
]
```

---

## Issue 3: Steps Tab Not Appearing in Backoffice

### **Files Involved:**
1. **`ps_configurator.php`** - Main module file
   - Function: `installTabs()` (lines 174-223)
   - Function: `uninstallTabs()` (lines 225-242)
   - Function: `install()` (line 59) - Calls installTabs()

2. **Database Table**: `ps_tab` - PrestaShop tabs table

### **What I Did:**
- Changed `$tab2->active = 1` (was 0, now visible)
- Changed tab name to 'Steps' (was 'Configurator Steps')

### **Why It Might Not Appear:**
1. **Module Not Reinstalled**: Tabs are created on install, need to reinstall
2. **Cache Issue**: PrestaShop caches tabs, clear cache
3. **Permission Issue**: User might not have permission
4. **Tab Already Exists**: Old tab might exist with different settings

### **What You Need to Do:**
1. **Check if Tab Exists**:
   ```sql
   SELECT * FROM ps_tab WHERE class_name = 'AdminSteps';
   ```
   - Check `active` field (should be 1)
   - Check `id_parent` (should match AdminConfigurators tab ID)

2. **Reinstall Module**:
   - Go to Modules → ps_configurator
   - Uninstall → Install (data preserved)
   - OR manually update tab:
   ```sql
   UPDATE ps_tab SET active = 1 WHERE class_name = 'AdminSteps';
   ```

3. **Clear Cache**:
   - Delete `var/cache/dev/*` and `var/cache/prod/*`
   - Or use PrestaShop cache clear in admin

4. **Manual Tab Creation** (if needed):
   ```php
   // Run this in a PHP file or PrestaShop console
   $tab = new Tab();
   $tab->class_name = 'AdminSteps';
   $tab->module = 'ps_configurator';
   $tab->id_parent = Tab::getIdFromClassName('AdminConfigurators');
   $tab->active = 1;
   foreach (Language::getLanguages(false) as $lang) {
       $tab->name[$lang['id_lang']] = 'Steps';
   }
   $tab->add();
   ```

### **File Location:**
- **`ps_configurator.php`** lines 189-198: Steps tab definition

---

## Issue 4: RAL Colors - Manual Addition vs Better System

### **Files Involved:**
1. **`classes/CustomColor.php`** - Custom colors for options
   - Method: `getByOption()` (lines 32-53)
   - Table: `configurator_custom_color`

2. **`classes/RalColor.php`** - RAL color system
   - Method: `getColorsByCategory()` (lines 31-52)
   - Table: `ps_configurator_ral_color`

3. **`classes/RalCategory.php`** - RAL categories
   - Method: `getAllCategories()` (lines 25-45)
   - Table: `ps_configurator_ral_category`

4. **`controllers/admin/AdminRalManagementController.php`** - RAL admin
   - Manages RAL categories and colors

5. **`views/templates/admin/step_options.tpl`** - Option form
   - Lines 84-100: Custom colors section for RAL options

6. **`views/js/front.js`** - Frontend
   - Function: `initializeRalPicker()` (lines 863-928)
   - Uses hardcoded RAL_FAMILIES or custom colors

### **Current System:**
- **Option 1**: Hardcoded RAL colors in JavaScript (lines 667-849 in front.js)
- **Option 2**: Custom colors per option via `CustomColor` class
- **Option 3**: Global RAL system via `RalCategory` and `RalColor`

### **What You Can Do:**

#### **Option A: Use Global RAL System (Recommended)**
1. **File**: `views/js/front.js` function `initializeRalPicker()`
2. **Modify**: Load RAL colors from database instead of hardcoded
3. **Add AJAX call** to fetch colors:
   ```javascript
   // In initializeRalPicker()
   fetch(ajaxUrl + '?action=get_ral_colors&id_option=' + optionId)
       .then(response => response.json())
       .then(data => {
           // Use data.colors instead of hardcoded RAL_FAMILIES
       });
   ```

4. **Create endpoint** in `controllers/front/configurator.php`:
   ```php
   if ($action === 'get_ral_colors') {
       $id_option = (int)Tools::getValue('id_option');
       $colors = CustomColor::getByOption($id_option, true);
       // OR use global RAL system
       $categories = RalCategory::getAllCategories(true);
       // Return JSON
   }
   ```

#### **Option B: Improve Custom Color Management**
1. **File**: `controllers/admin/AdminStepsController.php`
2. **Add**: Better UI for managing custom colors per option
3. **File**: `views/templates/admin/step_options.tpl`
4. **Enhance**: Lines 84-100 with better color picker, bulk import

#### **Option C: Bulk Import System**
1. **Create**: `controllers/admin/AdminRalImportController.php`
2. **Add**: CSV/JSON import for RAL colors
3. **Link**: From AdminRalManagement page

### **Database Tables:**
- `configurator_custom_color` - Per-option custom colors
- `ps_configurator_ral_category` - RAL categories
- `ps_configurator_ral_color` - RAL colors (global)

### **Recommended Approach:**
Use **Option A** - Load from database via AJAX. This allows:
- Centralized color management
- Easy updates without code changes
- Per-option customization still possible
- Better performance (lazy loading)

---

## Issue 5: Step Ordering Not Working

### **Files Involved:**
1. **`controllers/admin/AdminStepsController.php`** - Admin controller
   - Property: `$position_identifier = 'id_step'` (line 46)
   - Property: `$position_group_identifier = 'id_configurator'` (line 47)
   - Property: `$_orderBy = 'position'` (line 49)
   - Method: `ajaxProcessUpdatePositions()` (lines 53-120)

2. **`classes/Step.php`** - Step model
   - Property: `$position` (line 11)
   - Method: `getHigherPosition()` (lines 59-69)
   - Method: `add()` (lines 156-166) - Auto-sets position

3. **Database**: `configurator_step.position` field
4. **Database**: `configurator_step_association.position` (for configurator-specific steps)

### **What I Did:**
- Position system is already implemented
- `ajaxProcessUpdatePositions()` handles drag-and-drop
- Position auto-assigned on creation

### **Why It Might Not Work:**
1. **Missing JavaScript**: Admin template might not have drag-drop JS
2. **Wrong Table**: Using `configurator_step` vs `configurator_step_association`
3. **Global vs Configurator Steps**: Different position handling

### **What You Need to Check:**

1. **Admin Template**:
   - File: Check if there's a template for AdminSteps list
   - Should have: Drag handles, position column
   - Should call: `ajaxProcessUpdatePositions()` on drag

2. **Position Field**:
   ```sql
   SELECT id_step, title, position, id_configurator 
   FROM ps_configurator_step 
   WHERE id_configurator = YOUR_CONFIGURATOR_ID 
   ORDER BY position;
   ```
   - Check if positions are sequential
   - Check if they're unique per configurator

3. **Junction Table** (if using associations):
   ```sql
   SELECT * FROM ps_configurator_step_association 
   WHERE id_configurator = YOUR_CONFIGURATOR_ID 
   ORDER BY position;
   ```

### **What You Need to Add:**

1. **Drag-and-Drop UI**:
   - Add SortableJS or jQuery UI Sortable
   - Add to list template
   - Call AJAX on position change

2. **Position Input Field**:
   - Add manual position input in form
   - File: `AdminStepsController.php` renderForm()
   - Around line 250-280

3. **Bulk Position Update**:
   - Add "Reorder" button
   - Opens modal with drag-drop interface
   - Saves all positions at once

### **Code Example for Drag-Drop:**
```javascript
// In admin template or separate JS file
$('.step-list').sortable({
    handle: '.handle',
    update: function(event, ui) {
        var positions = [];
        $('.step-item').each(function(index) {
            positions.push({
                id_step: $(this).data('id-step'),
                position: index + 1
            });
        });
        
        $.ajax({
            url: adminLink + '&ajax=1&action=updatePositions',
            method: 'POST',
            data: {
                steps: positions,
                id_configurator: idConfigurator
            }
        });
    }
});
```

### **Manual Position Update Function:**
```php
// Add to AdminStepsController.php
public function processUpdatePosition()
{
    $id_step = (int)Tools::getValue('id_step');
    $position = (int)Tools::getValue('position');
    $id_configurator = (int)Tools::getValue('id_configurator');
    
    $step = new Step($id_step);
    if (Validate::isLoadedObject($step)) {
        $step->position = $position;
        $step->save();
        
        // If using associations, update that too
        Db::getInstance()->update(
            'configurator_step_association',
            ['position' => $position],
            'id_configurator = ' . (int)$id_configurator . ' AND id_step = ' . (int)$id_step
        );
    }
}
```

---

## Summary of All Files

### **Core Files:**
1. `ps_configurator.php` - Main module (tabs, hooks)
2. `classes/Step.php` - Step model
3. `classes/Option.php` - Option model
4. `classes/Configurator.php` - Configurator model
5. `classes/CustomColor.php` - Custom colors
6. `classes/RalColor.php` - RAL colors
7. `classes/RalCategory.php` - RAL categories
8. `classes/PriceCalculator.php` - Price calculation

### **Controllers:**
1. `controllers/admin/AdminStepsController.php` - Steps management
2. `controllers/admin/AdminConfiguratorsController.php` - Configurators
3. `controllers/admin/AdminConfiguratorRulesController.php` - Rules
4. `controllers/admin/AdminRalManagementController.php` - RAL management
5. `controllers/front/configurator.php` - Frontend AJAX

### **Templates:**
1. `views/templates/front/configurator.tpl` - Frontend display
2. `views/templates/admin/step_options.tpl` - Option form
3. `views/templates/admin/configurators_layout.tpl` - Configurator list
4. `views/templates/admin/rule_builder.tpl` - Rule builder

### **JavaScript:**
1. `views/js/front.js` - Frontend logic (1230 lines)
2. Admin JS (if exists in templates)

### **Database:**
- `configurator` - Configurators
- `configurator_step` - Steps
- `configurator_option` - Options
- `configurator_custom_color` - Custom colors
- `configurator_step_association` - Step-configurator links
- `ps_configurator_ral_category` - RAL categories
- `ps_configurator_ral_color` - RAL colors
- `configurator_selection` - User selections
- `ps_tab` - Admin tabs

---

## Quick Fix Checklist

- [ ] **Issue 1**: Check step IDs match, enable debug mode, verify template rendering
- [ ] **Issue 2**: Add step name dropdown in admin, improve conditional UI
- [ ] **Issue 3**: Reinstall module OR manually update `ps_tab` table
- [ ] **Issue 4**: Choose RAL system approach, implement AJAX loading
- [ ] **Issue 5**: Add drag-drop UI, verify position field updates, check junction table

