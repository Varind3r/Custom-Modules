<?php
/**
 * ps_configurator module
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

// Autoload classes
spl_autoload_register(function ($class) {
    $classes = [
        'Configurator' => 'classes/Configurator.php',
        'Step' => 'classes/Step.php',
        'Option' => 'classes/Option.php',
        'PriceCalculator' => 'classes/PriceCalculator.php',
        'CustomColor' => 'classes/CustomColor.php',
        'ConfiguratorRule' => 'classes/ConfiguratorRule.php',
        'RalCategory' => 'classes/RalCategory.php',
        'RalColor' => 'classes/RalColor.php',
        'AjaxHandler' => 'classes/AjaxHandler.php'
    ];
    
    if (isset($classes[$class])) {
        $file = __DIR__ . '/' . $classes[$class];
        if (file_exists($file)) {
            require_once $file;
        }
    }
});

class Ps_configurator extends Module
{
    public function __construct()
    {
        $this->name = 'ps_configurator';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = '';
        $this->need_instance = 0;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Product Configurator');
        $this->description = $this->l('A config-driven product engine for custom products.');

        $this->ps_versions_compliancy = array('min' => '1.7', 'max' => _PS_VERSION_);
    }

    public function install()
    {
        if (Shop::isFeatureActive()) {
            Shop::setContext(Shop::CONTEXT_ALL);
        }

        return parent::install() &&
            $this->installDb() &&
            $this->installTabs() &&
            $this->registerHook('actionProductPriceCalculation') &&
            $this->registerHook('displayConfigurator') &&
            $this->registerHook('displayAdminProductsExtra') &&
            $this->registerHook('displayProductPriceBlock') && // Extra hook for safety
            $this->registerHook('displayShoppingCart') &&
            $this->registerHook('actionValidateOrder') &&
            $this->registerHook('displayOrderConfirmation') &&
            $this->registerHook('displayOrderDetail') &&
            $this->registerHook('displayAdminOrder') &&
            $this->registerHook('header');
    }

    public function getContent()
    {
        // Ensure we have a valid context
        if (!$this->context) {
            $this->context = Context::getContext();
        }
        
        // Build the admin link directly
        $token = Tools::getAdminTokenLite('AdminConfigurators');
        $adminLink = $this->context->link->getAdminLink('AdminConfigurators', true, [], ['token' => $token]);
        
        // Redirect to AdminConfigurators controller
        if ($adminLink) {
            Tools::redirectAdmin($adminLink);
            return '';
        }
        
        // Fallback: Manual redirect with JavaScript if Tools::redirectAdmin fails
        $output = '<script type="text/javascript">';
        $output .= 'window.location.href = "' . $this->context->link->getAdminLink('AdminConfigurators') . '";';
        $output .= '</script>';
        $output .= '<div class="panel">';
        $output .= '<div class="panel-heading"><i class="icon-cogs"></i> ' . $this->l('Product Configurator Configuration') . '</div>';
        $output .= '<div class="panel-body">';
        $output .= '<p>' . $this->l('Redirecting to Configurators...') . '</p>';
        $output .= '<p><a href="' . $this->context->link->getAdminLink('AdminConfigurators') . '" class="btn btn-primary">';
        $output .= '<i class="icon-list"></i> ' . $this->l('Go to Configurators List') . '</a></p>';
        $output .= '</div></div>';
        
        return $output;
    }

    public function uninstall()
    {
        // Unregister all hooks first
        $this->unregisterHook('actionProductPriceCalculation');
        $this->unregisterHook('displayConfigurator');
        $this->unregisterHook('displayAdminProductsExtra');
        $this->unregisterHook('displayProductPriceBlock');
        $this->unregisterHook('displayShoppingCart');
        $this->unregisterHook('actionValidateOrder');
        $this->unregisterHook('displayOrderConfirmation');
        $this->unregisterHook('displayOrderDetail');
        $this->unregisterHook('displayAdminOrder');
        $this->unregisterHook('header');

        // Uninstall tabs
        $tabs_result = $this->uninstallTabs();
        
        // Uninstall database
        $db_result = $this->uninstallDb();
        
        // Call parent uninstall last
        $parent_result = parent::uninstall();
        
        return $parent_result && $db_result && $tabs_result;
    }

    protected function installDb()
    {
        $sql = file_get_contents($this->local_path . 'config/install.sql');
        $sql = str_replace(['PREFIX_', 'ENGINE_TYPE'], [_DB_PREFIX_, _MYSQL_ENGINE_], $sql);
        $queries = explode(';', $sql);

        foreach ($queries as $query) {
            $query = trim($query);
            if (!empty($query)) {
                if (!Db::getInstance()->execute($query)) {
                    return false;
                }
            }
        }
        return true;
    }

    protected function uninstallDb()
    {
        $sql_file = $this->local_path . 'config/uninstall.sql';
        if (!file_exists($sql_file)) {
            return true; // No uninstall SQL file, nothing to do
        }
        
        $sql = file_get_contents($sql_file);
        $sql = str_replace('PREFIX_', _DB_PREFIX_, $sql);
        $queries = explode(';', $sql);

        foreach ($queries as $query) {
            $query = trim($query);
            if (!empty($query)) {
                try {
                    if (!Db::getInstance()->execute($query)) {
                        // Log error but continue with other queries
                        PrestaShopLogger::addLog('Configurator module: Failed to execute uninstall query: ' . $query, 3);
                    }
                } catch (Exception $e) {
                    PrestaShopLogger::addLog('Configurator module: Exception during uninstall: ' . $e->getMessage(), 3);
                }
            }
        }
        return true; // Return true even if some queries fail to allow uninstall to complete
    }

private function installTabs()
{
    $res = true;
    
    $improve_id = (int)Tab::getIdFromClassName('IMPROVE');
    
    // Configurators Tab
    $tab1 = new Tab();
    $tab1->class_name = 'AdminConfigurators';
    $tab1->module = $this->name;
    $tab1->id_parent = $improve_id;
    $tab1->icon = 'settings_input_component';
    $tab1->active = 1;
    foreach (Language::getLanguages(false) as $lang) {
        $tab1->name[$lang['id_lang']] = 'Configurators';
    }
    $res &= $tab1->add();

    // Rules Tab
    $tab3 = new Tab();
    $tab3->class_name = 'AdminConfiguratorRules';
    $tab3->module = $this->name;
    $tab3->id_parent = $improve_id;
    $tab3->icon = 'rule';
    $tab3->active = 1;
    foreach (Language::getLanguages(false) as $lang) {
        $tab3->name[$lang['id_lang']] = 'Configurator Rules';
    }
    $res &= $tab3->add();

    // RAL Colors Tab
    $tab4 = new Tab();
    $tab4->class_name = 'AdminRalManagement';
    $tab4->module = $this->name;
    $tab4->id_parent = $improve_id;
    $tab4->icon = 'palette';
    $tab4->active = 1;
    foreach (Language::getLanguages(false) as $lang) {
        $tab4->name[$lang['id_lang']] = 'RAL Colors';
    }
    $res &= $tab4->add();

    return $res;
}

private function uninstallTabs()
{
    $res = true;
    foreach (['AdminConfigurators', 'AdminConfiguratorRules', 'AdminRalManagement'] as $class_name) {
        try {
            $id_tab = (int)Tab::getIdFromClassName($class_name);
            if ($id_tab) {
                $tab = new Tab($id_tab);
                if (Validate::isLoadedObject($tab)) {
                    $res &= $tab->delete();
                }
            }
        } catch (Exception $e) {
            PrestaShopLogger::addLog('Configurator module: Exception deleting tab ' . $class_name . ': ' . $e->getMessage(), 3);
        }
    }
    return $res;
}

    public function hookHeader()
    {
        if ($this->context->controller->php_self == 'product') {
            $this->context->controller->addJS($this->_path . 'views/js/front.js');
            $this->context->controller->addCSS($this->_path . 'views/css/front.css');
        }
        return ''; // Must return a string
    }

    public function hookDisplayConfigurator($params)
    {
        $id_product = 0;
        if (isset($params['product'])) {
            $product = $params['product'];
            if (is_object($product)) {
                $id_product = isset($product->id) ? (int)$product->id : (isset($product->id_product) ? (int)$product->id_product : 0);
            } elseif (is_array($product)) {
                $id_product = isset($product['id_product']) ? (int)$product['id_product'] : (isset($product['id']) ? (int)$product['id'] : 0);
            }
        }

        if (!$id_product && isset($this->context->controller->php_self) && $this->context->controller->php_self == 'product') {
             $id_product = (int)Tools::getValue('id_product');
        }

        if (!$id_product) return '';

        // 1. First try to find a configurator explicitly linked to this product
        $configurator = Configurator::getByProduct($id_product);

        if (!$configurator) {
            // 2. Fallback to Category matching
            $categories = Product::getProductCategories($id_product);
            $configurator = Configurator::getByCategory($categories);
        }

        if ($configurator && $configurator->active) {
            // Get custom colors for all RAL options
            $steps = $configurator->getSteps(true);
            $custom_colors = [];
            foreach ($steps as $step) {
                $options = $step->getOptions();
                foreach ($options as $option) {
                    if ($option->option_type == 'ral_system') {
                        $colors = CustomColor::getByOption($option->id, true);
                        $custom_colors[$option->id] = [];
                        foreach ($colors as $color) {
                            $custom_colors[$option->id][] = [
                                'id_color' => $color->id_color,
                                'color_name' => $color->color_name,
                                'color_code' => $color->color_code,
                                'hex_code' => $color->hex_code
                            ];
                        }
                    }
                }
            }

            $this->context->smarty->assign([
                'configurator' => $configurator,
                'steps' => $steps,
                'custom_colors' => $custom_colors,
                'custom_colors_json' => json_encode($custom_colors),
                'ajax_url' => $this->context->link->getModuleLink($this->name, 'configurator'),
                'base_url' => $this->context->shop->getBaseURL(true),
                'urls' => ['base_url' => $this->context->shop->getBaseURL(true)]
            ]);

            $output = $this->display(__FILE__, 'views/templates/front/configurator.tpl');
            return is_string($output) ? $output : '';
        }

        return '';
    }

    public function hookDisplayAdminProductsExtra($params)
    {
        $id_product = isset($params['id_product']) ? (int)$params['id_product'] : (isset($params['id']) ? (int)$params['id'] : 0);
        
        if (!$id_product) {
            return '';
        }

        $product = new Product($id_product);
        if (!Validate::isLoadedObject($product)) {
            return '';
        }

        $categories = $product->getCategories();
        $configurator = Configurator::getByCategory($categories);
        
        $this->context->smarty->assign([
            'id_product' => $id_product,
            'configurator' => $configurator,
            'link' => $this->context->link,
            'builder_link' => $configurator ? $this->context->link->getAdminLink('AdminSteps') . '&id_configurator=' . $configurator->id : null
        ]);

        $output = $this->display(__FILE__, 'views/templates/admin/product_tab.tpl');
        return is_string($output) ? $output : '';
    }

    public function hookActionProductPriceCalculation($params)
    {
        try {
            // Ensure classes are loaded
            if (!class_exists('PriceCalculator')) {
                require_once _PS_MODULE_DIR_ . 'ps_configurator/classes/PriceCalculator.php';
            }
            if (!class_exists('Option')) {
                require_once _PS_MODULE_DIR_ . 'ps_configurator/classes/Option.php';
            }

            $id_cart = isset($params['id_cart']) ? (int)$params['id_cart'] : 0;
            $id_product = isset($params['id_product']) ? (int)$params['id_product'] : 0;
            $base_price = isset($params['price']) ? (float)$params['price'] : 0;

            if (!$id_cart || !$id_product) {
                return null;
            }

            // Fetch selection from DB
            $sql = "SELECT selections, dimensions FROM " . _DB_PREFIX_ . "configurator_selection 
                    WHERE id_cart = " . (int)$id_cart . " 
                    AND id_product = " . (int)$id_product . " 
                    ORDER BY date_add DESC";
            $row = Db::getInstance()->getRow($sql);

            if ($row) {
                $selections = json_decode($row['selections'], true);
                $dimensions = json_decode($row['dimensions'], true);
                
                $optionIds = [];
                if ($selections && is_array($selections)) {
                    foreach ($selections as $stepId => $options) {
                        if (is_array($options)) {
                            foreach ($options as $optId => $details) {
                                $optionIds[] = $optId;
                            }
                        }
                    }
                }

                $final_price = PriceCalculator::calculate($base_price, $optionIds, $dimensions);
                
                return $final_price;
            }
        } catch (Exception $e) {
            // Silently fail to avoid breaking the site
            return null;
        }

        return null;
    }

    /**
     * Display product price block hook
     * This hook is used as a safety measure for price display
     */
    public function hookDisplayProductPriceBlock($params)
    {
        // This hook can be used to modify price display if needed
        // For now, we rely on actionProductPriceCalculation for price calculation
        return '';
    }

    /**
     * Display configuration in shopping cart
     */
    public function hookDisplayShoppingCart($params)
    {
        $cart = $params['cart'];
        if (!Validate::isLoadedObject($cart)) {
            return '';
        }

        $products = $cart->getProducts(true);
        $configurations = [];

        foreach ($products as $product) {
            $id_product = (int)$product['id_product'];
            $id_product_attribute = isset($product['id_product_attribute']) ? (int)$product['id_product_attribute'] : 0;
            
            // Get configuration for this cart product
            $sql = "SELECT selections, dimensions, comment, file_path 
                    FROM " . _DB_PREFIX_ . "configurator_selection 
                    WHERE id_cart = " . (int)$cart->id . " 
                    AND id_product = " . $id_product . " 
                    ORDER BY date_add DESC 
                    LIMIT 1";
            $row = Db::getInstance()->getRow($sql);

            if ($row) {
                $selections = json_decode($row['selections'], true);
                $dimensions = json_decode($row['dimensions'], true);
                
                // Calculate additional price
                $optionIds = [];
                if ($selections && is_array($selections)) {
                    foreach ($selections as $stepId => $options) {
                        if (is_array($options)) {
                            foreach ($options as $optId => $details) {
                                $optionIds[] = $optId;
                            }
                        }
                    }
                }

                $base_price = (float)$product['price'];
                $final_price = PriceCalculator::calculate($base_price, $optionIds, $dimensions);
                $additional_price = $final_price - $base_price;

                $configurations[$id_product] = [
                    'selections' => $selections,
                    'dimensions' => $dimensions,
                    'comment' => $row['comment'],
                    'file_path' => $row['file_path'],
                    'additional_price' => $additional_price,
                    'final_price' => $final_price,
                    'formatted_price' => PriceCalculator::formatPrice($additional_price)
                ];
            }
        }

        if (empty($configurations)) {
            return '';
        }

        $this->context->smarty->assign([
            'configurations' => $configurations,
            'link' => $this->context->link
        ]);

        $output = $this->display(__FILE__, 'views/templates/front/cart_configuration.tpl');
        return is_string($output) ? $output : '';
    }

    /**
     * Link configuration to order when order is validated
     */
    public function hookActionValidateOrder($params)
    {
        $order = $params['order'];
        $cart = $params['cart'];
        
        if (!Validate::isLoadedObject($order) || !Validate::isLoadedObject($cart)) {
            return '';
        }

        // Link all configurations from cart to order
        $sql = "UPDATE " . _DB_PREFIX_ . "configurator_selection 
                SET id_order = " . (int)$order->id . " 
                WHERE id_cart = " . (int)$cart->id . " 
                AND id_order IS NULL";
        Db::getInstance()->execute($sql);
        
        return '';
    }

    /**
     * Display configuration on order confirmation page
     */
    public function hookDisplayOrderConfirmation($params)
    {
        $order = $params['order'];
        if (!Validate::isLoadedObject($order)) {
            return '';
        }

        $order_products = $order->getProducts();
        $configurations = [];

        foreach ($order_products as $product) {
            $id_product = (int)$product['id_product'];
            
            // Get configuration for this order product
            $sql = "SELECT selections, dimensions, comment, file_path 
                    FROM " . _DB_PREFIX_ . "configurator_selection 
                    WHERE id_order = " . (int)$order->id . " 
                    AND id_product = " . $id_product . " 
                    ORDER BY date_add DESC 
                    LIMIT 1";
            $row = Db::getInstance()->getRow($sql);

            if ($row) {
                $selections = json_decode($row['selections'], true);
                $dimensions = json_decode($row['dimensions'], true);
                
                // Calculate additional price
                $optionIds = [];
                if ($selections && is_array($selections)) {
                    foreach ($selections as $stepId => $options) {
                        if (is_array($options)) {
                            foreach ($options as $optId => $details) {
                                $optionIds[] = $optId;
                            }
                        }
                    }
                }

                $base_price = (float)$product['product_price'];
                $final_price = PriceCalculator::calculate($base_price, $optionIds, $dimensions);
                $additional_price = $final_price - $base_price;

                $configurations[$id_product] = [
                    'selections' => $selections,
                    'dimensions' => $dimensions,
                    'comment' => $row['comment'],
                    'file_path' => $row['file_path'],
                    'additional_price' => $additional_price,
                    'final_price' => $final_price,
                    'formatted_price' => PriceCalculator::formatPrice($additional_price)
                ];
            }
        }

        if (empty($configurations)) {
            return '';
        }

        $this->context->smarty->assign([
            'configurations' => $configurations,
            'link' => $this->context->link,
            'order' => $order
        ]);

        $output = $this->display(__FILE__, 'views/templates/front/order_confirmation.tpl');
        return is_string($output) ? $output : '';
    }

    /**
     * Display configuration in customer order detail page
     */
    public function hookDisplayOrderDetail($params)
    {
        $order = $params['order'];
        if (!Validate::isLoadedObject($order)) {
            return '';
        }

        $order_products = $order->getProducts();
        $configurations = [];

        foreach ($order_products as $product) {
            $id_product = (int)$product['id_product'];
            
            // Get configuration for this order product
            $sql = "SELECT selections, dimensions, comment, file_path 
                    FROM " . _DB_PREFIX_ . "configurator_selection 
                    WHERE id_order = " . (int)$order->id . " 
                    AND id_product = " . $id_product . " 
                    ORDER BY date_add DESC 
                    LIMIT 1";
            $row = Db::getInstance()->getRow($sql);

            if ($row) {
                $selections = json_decode($row['selections'], true);
                $dimensions = json_decode($row['dimensions'], true);
                
                $configurations[$id_product] = [
                    'selections' => $selections,
                    'dimensions' => $dimensions,
                    'comment' => $row['comment'],
                    'file_path' => $row['file_path']
                ];
            }
        }

        if (empty($configurations)) {
            return '';
        }

        $this->context->smarty->assign([
            'configurations' => $configurations,
            'link' => $this->context->link
        ]);

        $output = $this->display(__FILE__, 'views/templates/front/order_detail.tpl');
        return is_string($output) ? $output : '';
    }

    /**
     * Display configuration in admin order view
     */
    public function hookDisplayAdminOrder($params)
    {
        $id_order = (int)$params['id_order'];
        if (!$id_order) {
            return '';
        }

        $order = new Order($id_order);
        if (!Validate::isLoadedObject($order)) {
            return '';
        }

        $order_products = $order->getProducts();
        $configurations = [];

        foreach ($order_products as $product) {
            $id_product = (int)$product['id_product'];
            
            // Get configuration for this order product
            $sql = "SELECT selections, dimensions, comment, file_path 
                    FROM " . _DB_PREFIX_ . "configurator_selection 
                    WHERE id_order = " . (int)$id_order . " 
                    AND id_product = " . $id_product . " 
                    ORDER BY date_add DESC 
                    LIMIT 1";
            $row = Db::getInstance()->getRow($sql);

            if ($row) {
                $selections = json_decode($row['selections'], true);
                $dimensions = json_decode($row['dimensions'], true);
                
                $configurations[$id_product] = [
                    'selections' => $selections,
                    'dimensions' => $dimensions,
                    'comment' => $row['comment'],
                    'file_path' => $row['file_path']
                ];
            }
        }

        if (empty($configurations)) {
            return '';
        }

        $this->context->smarty->assign([
            'configurations' => $configurations,
            'link' => $this->context->link
        ]);

        $output = $this->display(__FILE__, 'views/templates/admin/order_configuration.tpl');
        return is_string($output) ? $output : '';
    }
}
