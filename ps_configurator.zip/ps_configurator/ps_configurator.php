<?php
/**
 * ps_configurator module
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

// Autoload classes
spl_autoload_register(function ($class) {
    $classes = [
        'Configurator' => 'classes/Configurator.php',
        'Step' => 'classes/Step.php',
        'Option' => 'classes/Option.php',
        'PriceCalculator' => 'classes/PriceCalculator.php',
        'CustomColor' => 'classes/CustomColor.php',
        'ConfiguratorRule' => 'classes/ConfiguratorRule.php',
        'RalCategory' => 'classes/RalCategory.php',
        'RalColor' => 'classes/RalColor.php'
        // 'AjaxHandler' => 'classes/AjaxHandler.php' // Removed: Legacy class, replaced by front controller
    ];
    
    if (isset($classes[$class])) {
        $file = __DIR__ . '/' . $classes[$class];
        if (file_exists($file)) {
            require_once $file;
        }
    }
});

class Ps_configurator extends Module
{
    public function __construct()
    {
        $this->name = 'ps_configurator';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = '';
        $this->need_instance = 0;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Product Configurator');
        $this->description = $this->l('A config-driven product engine for custom products.');

        $this->ps_versions_compliancy = array('min' => '1.7', 'max' => _PS_VERSION_);
    }

    public function install()
    {
        if (Shop::isFeatureActive()) {
            Shop::setContext(Shop::CONTEXT_ALL);
        }

        return parent::install() &&
            $this->installDb() &&
            $this->migrateDatabase() &&
            $this->installTabs() &&
            $this->registerHook('actionProductPriceCalculation') &&
            $this->registerHook('displayConfigurator') &&
            $this->registerHook('displayAdminProductsExtra') &&
            $this->registerHook('displayProductPriceBlock') && // Extra hook for safety
            $this->registerHook('displayShoppingCart') &&
            $this->registerHook('actionCartUpdateQuantityAfter') &&
            $this->registerHook('actionCartSave') &&
            $this->registerHook('actionValidateOrder') &&
            $this->registerHook('displayOrderConfirmation') &&
            $this->registerHook('displayOrderDetail') &&
            $this->registerHook('displayAdminOrder') &&
            $this->registerHook('header');
    }

    public function getContent()
    {
        // Ensure we have a valid context
        if (!$this->context) {
            $this->context = Context::getContext();
        }
        
        // Build the admin link directly
        $token = Tools::getAdminTokenLite('AdminConfigurators');
        $adminLink = $this->context->link->getAdminLink('AdminConfigurators', true, [], ['token' => $token]);
        
        // Redirect to AdminConfigurators controller
        if ($adminLink) {
            Tools::redirectAdmin($adminLink);
            return '';
        }
        
        // Fallback: Manual redirect with JavaScript if Tools::redirectAdmin fails
        $output = '<script type="text/javascript">';
        $output .= 'window.location.href = "' . $this->context->link->getAdminLink('AdminConfigurators') . '";';
        $output .= '</script>';
        $output .= '<div class="panel">';
        $output .= '<div class="panel-heading"><i class="icon-cogs"></i> ' . $this->l('Product Configurator Configuration') . '</div>';
        $output .= '<div class="panel-body">';
        $output .= '<p>' . $this->l('Redirecting to Configurators...') . '</p>';
        $output .= '<p><a href="' . $this->context->link->getAdminLink('AdminConfigurators') . '" class="btn btn-primary">';
        $output .= '<i class="icon-list"></i> ' . $this->l('Go to Configurators List') . '</a></p>';
        $output .= '</div></div>';
        
        return $output;
    }

    public function uninstall()
    {
        // Unregister all hooks first
        $this->unregisterHook('actionProductPriceCalculation');
        $this->unregisterHook('displayConfigurator');
        $this->unregisterHook('displayAdminProductsExtra');
        $this->unregisterHook('displayProductPriceBlock');
        $this->unregisterHook('displayShoppingCart');
        $this->unregisterHook('actionCartUpdateQuantityAfter');
        $this->unregisterHook('actionCartSave');
        $this->unregisterHook('actionValidateOrder');
        $this->unregisterHook('displayOrderConfirmation');
        $this->unregisterHook('displayOrderDetail');
        $this->unregisterHook('displayAdminOrder');
        $this->unregisterHook('header');

        // Uninstall tabs
        $tabs_result = $this->uninstallTabs();
        
        // Uninstall database
        $db_result = $this->uninstallDb();
        
        // Call parent uninstall last
        $parent_result = parent::uninstall();
        
        return $parent_result && $db_result && $tabs_result;
    }

    protected function installDb()
    {
        $sql = file_get_contents($this->local_path . 'config/install.sql');
        $sql = str_replace(['PREFIX_', 'ENGINE_TYPE'], [_DB_PREFIX_, _MYSQL_ENGINE_], $sql);
        $queries = explode(';', $sql);

        foreach ($queries as $query) {
            $query = trim($query);
            if (!empty($query)) {
                if (!Db::getInstance()->execute($query)) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * Run database migrations for existing installations
     */
    protected function migrateDatabase()
    {
        // Check if id_customization column exists in configurator_selection table
        $table = _DB_PREFIX_ . 'configurator_selection';
        $column_exists = Db::getInstance()->executeS("
            SELECT COUNT(*) as count 
            FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_SCHEMA = '" . _DB_NAME_ . "' 
            AND TABLE_NAME = '" . $table . "' 
            AND COLUMN_NAME = 'id_customization'
        ");
        
        if (isset($column_exists[0]['count']) && (int)$column_exists[0]['count'] == 0) {
            // Column doesn't exist, add it
            $sql = "ALTER TABLE `" . $table . "` 
                    ADD COLUMN `id_customization` INT UNSIGNED NULL DEFAULT NULL AFTER `id_product`,
                    ADD INDEX `id_customization` (`id_customization`)";
            
            if (!Db::getInstance()->execute($sql)) {
                PrestaShopLogger::addLog('Configurator: Failed to add id_customization column', 3);
                return false;
            }
        }
        
        return true;
    }

    protected function uninstallDb()
    {
        $sql_file = $this->local_path . 'config/uninstall.sql';
        if (!file_exists($sql_file)) {
            return true; // No uninstall SQL file, nothing to do
        }
        
        $sql = file_get_contents($sql_file);
        $sql = str_replace('PREFIX_', _DB_PREFIX_, $sql);
        $queries = explode(';', $sql);

        foreach ($queries as $query) {
            $query = trim($query);
            if (!empty($query)) {
                try {
                    if (!Db::getInstance()->execute($query)) {
                        // Log error but continue with other queries
                        PrestaShopLogger::addLog('Configurator module: Failed to execute uninstall query: ' . $query, 3);
                    }
                } catch (Exception $e) {
                    PrestaShopLogger::addLog('Configurator module: Exception during uninstall: ' . $e->getMessage(), 3);
                }
            }
        }
        return true; // Return true even if some queries fail to allow uninstall to complete
    }

private function installTabs()
{
    $res = true;
    
    $improve_id = (int)Tab::getIdFromClassName('IMPROVE');
    
    // Configurators Tab
    $tab1 = new Tab();
    $tab1->class_name = 'AdminConfigurators';
    $tab1->module = $this->name;
    $tab1->id_parent = $improve_id;
    $tab1->icon = 'settings_input_component';
    $tab1->active = 1;
    foreach (Language::getLanguages(false) as $lang) {
        $tab1->name[$lang['id_lang']] = 'Configurators';
    }
    $res &= $tab1->add();

    // Rules Tab
    $tab3 = new Tab();
    $tab3->class_name = 'AdminConfiguratorRules';
    $tab3->module = $this->name;
    $tab3->id_parent = $improve_id;
    $tab3->icon = 'rule';
    $tab3->active = 1;
    foreach (Language::getLanguages(false) as $lang) {
        $tab3->name[$lang['id_lang']] = 'Configurator Rules';
    }
    $res &= $tab3->add();

    // RAL Colors Tab
    $tab4 = new Tab();
    $tab4->class_name = 'AdminRalManagement';
    $tab4->module = $this->name;
    $tab4->id_parent = $improve_id;
    $tab4->icon = 'palette';
    $tab4->active = 1;
    foreach (Language::getLanguages(false) as $lang) {
        $tab4->name[$lang['id_lang']] = 'RAL Colors';
    }
    $res &= $tab4->add();

    return $res;
}

private function uninstallTabs()
{
    $res = true;
    foreach (['AdminConfigurators', 'AdminConfiguratorRules', 'AdminRalManagement'] as $class_name) {
        try {
            $id_tab = (int)Tab::getIdFromClassName($class_name);
            if ($id_tab) {
                $tab = new Tab($id_tab);
                if (Validate::isLoadedObject($tab)) {
                    $res &= $tab->delete();
                }
            }
        } catch (Exception $e) {
            PrestaShopLogger::addLog('Configurator module: Exception deleting tab ' . $class_name . ': ' . $e->getMessage(), 3);
        }
    }
    return $res;
}

    public function hookHeader()
    {
        if ($this->context->controller->php_self == 'product') {
            $this->context->controller->addJS($this->_path . 'views/js/front.js');
            $this->context->controller->addCSS($this->_path . 'views/css/front.css');
        }
        return ''; // Must return a string
    }

    public function hookDisplayConfigurator($params)
    {
        $id_product = 0;
        if (isset($params['product'])) {
            $product = $params['product'];
            if (is_object($product)) {
                $id_product = isset($product->id) ? (int)$product->id : (isset($product->id_product) ? (int)$product->id_product : 0);
            } elseif (is_array($product)) {
                $id_product = isset($product['id_product']) ? (int)$product['id_product'] : (isset($product['id']) ? (int)$product['id'] : 0);
            }
        }

        if (!$id_product && isset($this->context->controller->php_self) && $this->context->controller->php_self == 'product') {
             $id_product = (int)Tools::getValue('id_product');
        }

        if (!$id_product) return '';

        // 1. First try to find a configurator explicitly linked to this product
        $configurator = Configurator::getByProduct($id_product);

        if (!$configurator) {
            // 2. Fallback to Category matching
            $categories = Product::getProductCategories($id_product);
            $configurator = Configurator::getByCategory($categories);
        }

        if ($configurator && $configurator->active) {
            // Get custom colors for all RAL options
            $steps = $configurator->getSteps(true);
            
            // Ensure we have steps
            if (empty($steps) || !is_array($steps)) {
                $steps = [];
            }
            
            $custom_colors = [];
            foreach ($steps as $step) {
                if (!Validate::isLoadedObject($step)) {
                    continue;
                }
                
                $options = $step->getOptions();
                if (!is_array($options)) {
                    $options = [];
                }
                
                foreach ($options as $option) {
                    if (!Validate::isLoadedObject($option)) {
                        continue;
                    }
                    
                    if ($option->option_type == 'ral_system') {
                        $colors = CustomColor::getByOption($option->id, true);
                        if (!is_array($colors)) {
                            $colors = [];
                        }
                        
                        $custom_colors[$option->id] = [];
                        foreach ($colors as $color) {
                            if (Validate::isLoadedObject($color)) {
                            $custom_colors[$option->id][] = [
                                'id_color' => $color->id_color,
                                'color_name' => $color->color_name,
                                'color_code' => $color->color_code,
                                'hex_code' => $color->hex_code
                            ];
                        }
                    }
                }
            }
            }

            // Fetch advanced rules
            require_once _PS_MODULE_DIR_ . 'ps_configurator/classes/ConfiguratorRule.php';
            $advanced_rules = ConfiguratorRule::getRulesByConfigurator((int)$configurator->id);
            $advanced_rules_json = json_encode($advanced_rules ?: [], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

            // Ensure custom_colors_json is properly formatted
            $custom_colors_json = json_encode($custom_colors, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

            $this->context->smarty->assign([
                'configurator' => $configurator,
                'steps' => $steps,
                'custom_colors' => $custom_colors,
                'custom_colors_json' => $custom_colors_json,
                'advanced_rules_json' => $advanced_rules_json,
                'ajax_url' => $this->context->link->getModuleLink($this->name, 'configurator'),
                'base_url' => $this->context->shop->getBaseURL(true),
                'urls' => ['base_url' => $this->context->shop->getBaseURL(true)]
            ]);

            $output = $this->display(__FILE__, 'views/templates/front/configurator.tpl');
            return is_string($output) ? $output : '';
        }

        return '';
    }

    public function hookDisplayAdminProductsExtra($params)
    {
        $id_product = isset($params['id_product']) ? (int)$params['id_product'] : (isset($params['id']) ? (int)$params['id'] : 0);
        
        if (!$id_product) {
            return '';
        }

        $product = new Product($id_product);
        if (!Validate::isLoadedObject($product)) {
            return '';
        }

        $categories = $product->getCategories();
        $configurator = Configurator::getByCategory($categories);
        
        $this->context->smarty->assign([
            'id_product' => $id_product,
            'configurator' => $configurator,
            'link' => $this->context->link,
            'builder_link' => $configurator ? $this->context->link->getAdminLink('AdminSteps') . '&id_configurator=' . $configurator->id : null
        ]);

        $output = $this->display(__FILE__, 'views/templates/admin/product_tab.tpl');
        return is_string($output) ? $output : '';
    }

    public function hookActionProductPriceCalculation($params)
    {
        try {
            // Ensure classes are loaded
            if (!class_exists('PriceCalculator')) {
                require_once _PS_MODULE_DIR_ . 'ps_configurator/classes/PriceCalculator.php';
            }
            if (!class_exists('Option')) {
                require_once _PS_MODULE_DIR_ . 'ps_configurator/classes/Option.php';
            }
            $id_cart = isset($params['id_cart']) ? (int)$params['id_cart'] : (isset($this->context->cart->id) ? (int)$this->context->cart->id : 0);
            $id_product = isset($params['id_product']) ? (int)$params['id_product'] : 0;
            $base_price = (isset($params['base_price']) && $params['base_price'] > 0) ? (float)$params['base_price'] : (isset($params['price']) ? (float)$params['price'] : 0);

            $id_customization = 0;
            if (isset($params['id_customization'])) {
                $id_customization = (int)$params['id_customization'];
            } elseif (isset($params['cart_product']['id_customization'])) {
                $id_customization = (int)$params['cart_product']['id_customization'];
            }

            if (!$id_product) {
                return null;
            }

            // Fallback for missing id_customization in cart context
            if (!$id_customization && $id_cart && $this->context->controller->php_self == 'cart') {
                $cart_products = $this->context->cart->getProducts();
                foreach ($cart_products as $p) {
                    if ((int)$p['id_product'] === (int)$id_product && (int)$p['id_customization'] > 0) {
                        $id_customization = (int)$p['id_customization'];
                        PrestaShopLogger::addLog("Configur. Price: Auto-detected customization $id_customization for product $id_product in cart $id_cart", 1);
                        break;
                    }
                }
            }

            $sql = "SELECT selections, dimensions FROM " . _DB_PREFIX_ . "configurator_selection 
                    WHERE id_product = " . (int)$id_product;
            
            if ($id_customization) {
                $sql .= " AND id_customization = " . (int)$id_customization;
            } elseif ($id_cart) {
                $sql .= " AND id_cart = " . (int)$id_cart;
            } else {
                return null;
            }

            $sql .= " ORDER BY date_add DESC LIMIT 1";
            
            $selection = Db::getInstance()->getRow($sql);

            if ($selection) {
                // First, try to get price from customized_data (the proper PrestaShop way)
                // If price is in customized_data, PrestaShop will add it automatically via Customization::getCustomizationPrice()
                // We should NOT modify $params['price'] in this case to avoid double addition
                if ($id_customization > 0) {
                    $customization_price = (float)Db::getInstance()->getValue('
                        SELECT SUM(price) FROM ' . _DB_PREFIX_ . 'customized_data
                        WHERE id_customization = ' . (int)$id_customization
                    );
                    
                    if ($customization_price > 0) {
                        // Price is already stored in customized_data, PrestaShop will add it automatically
                        // DO NOT modify $params['price'] here - PrestaShop handles it via Customization::getCustomizationPrice()
                        PrestaShopLogger::addLog("Configur. Price (from customized_data): Prod $id_product, Cust $id_customization, Customization price $customization_price (PrestaShop will add automatically)", 1);
                        return null; // Price handled via customization - PrestaShop will add it automatically
                    }
                }
                
                // Fallback: Calculate price from selections/dimensions if not in customized_data
                $selections = json_decode($selection['selections'], true);
                $dimensions = json_decode($selection['dimensions'], true);
                
                // Extract option IDs from nested selections structure
                // Selections structure: {stepId: {optionId: {label, valueKey, price}}}
                $optionIds = [];
                if ($selections && is_array($selections)) {
                    foreach ($selections as $stepId => $options) {
                        if (is_array($options)) {
                            foreach ($options as $optId => $details) {
                                $optionIds[] = $optId;
                            }
                        }
                    }
                }

                if (!is_array($dimensions)) {
                    $dimensions = [];
                }

                // Get the current price from params (passed by reference)
                $current_price = isset($params['price']) ? (float)$params['price'] : 0;
                
                // If base_price is not provided or invalid, use current price or fetch from product
                if ($base_price <= 0) {
                    if ($current_price > 0) {
                        $base_price = $current_price;
                    } else {
                        // Try to get base price from product if not provided
                        $product = new Product($id_product);
                        if (Validate::isLoadedObject($product)) {
                            $base_price = (float)$product->getPrice(false, null, 6); // Get price without tax
                        }
                    }
                }
                
                // Prevent infinite loops - check if price was already modified by us
                if (isset($params['price_modified_by_configurator'])) {
            return null;
        }

                // Calculate the additional price from configurator options and dimensions
                $additional_price = 0;
                
                // Calculate option prices
                foreach ($optionIds as $optId) {
                    $additional_price += PriceCalculator::getOptionPrice($optId, $dimensions);
                }
                
                // Calculate dimension prices
                if (!empty($dimensions) && is_array($dimensions)) {
                    foreach ($dimensions as $key => $dim) {
                        if (is_array($dim)) {
                            $priceType = isset($dim['priceType']) ? $dim['priceType'] : (isset($dim['price_type']) ? $dim['price_type'] : null);
                            $priceValue = isset($dim['priceValue']) ? (float)$dim['priceValue'] : (isset($dim['price_value']) ? (float)$dim['price_value'] : 0);
                            $value = isset($dim['value']) ? (float)$dim['value'] : 0;
                            
                            if ($priceType && $priceValue > 0 && $value > 0) {
                                switch ($priceType) {
                                    case 'per_unit':
                                        $adjustedValue = $value;
                                        if ($value > 10) {
                                            $adjustedValue = $value / 1000; // mm to m
                                        }
                                        $additional_price += $adjustedValue * $priceValue;
                                        break;
                                    case 'fixed':
                                        $additional_price += $priceValue;
                                        break;
                                    case 'percentage':
                                        $additional_price += ($base_price * $priceValue / 100);
                                        break;
                                }
                            }
                        }
                    }
                }
                
                // Calculate final price
                $final_price = $base_price + $additional_price;
                
                // Store additional price in customized_data (PrestaShop will add it automatically)
                // DO NOT modify $params['price'] - PrestaShop handles customization prices via Customization::getCustomizationPrice()
                if ($id_customization > 0 && $additional_price > 0) {
                    // Update or insert customization price
                    $exists = Db::getInstance()->getValue('
                        SELECT COUNT(*) FROM ' . _DB_PREFIX_ . 'customized_data
                        WHERE id_customization = ' . (int)$id_customization
                    );
                    
                    if ($exists) {
                        Db::getInstance()->execute('
                            UPDATE ' . _DB_PREFIX_ . 'customized_data
                            SET price = ' . (float)$additional_price . '
                            WHERE id_customization = ' . (int)$id_customization . '
                            LIMIT 1
                        ');
                    } else {
                        // Get customization field ID
                        $id_customization_field = (int)Db::getInstance()->getValue('
                            SELECT id_customization_field 
                            FROM ' . _DB_PREFIX_ . 'customization_field 
                            WHERE id_product = ' . (int)$id_product . ' 
                            AND type = ' . (int)Product::CUSTOMIZE_TEXTFIELD . ' 
                            AND is_deleted = 0
                            LIMIT 1
                        ');
                        
                        if ($id_customization_field) {
                            Db::getInstance()->insert('customized_data', [
                                'id_customization' => (int)$id_customization,
                                'type' => Product::CUSTOMIZE_TEXTFIELD,
                                'index' => 0,
                                'value' => '',
                                'price' => (float)$additional_price
                            ]);
                        }
                    }
                    
                    // Debug logging
                    PrestaShopLogger::addLog("Configur. Price (stored in customized_data): Prod $id_product, Cart $id_cart, Cust $id_customization, Base $base_price, Additional $additional_price (Options: " . count($optionIds) . ", Dims: " . count($dimensions) . ") - PrestaShop will add automatically", 1);
                } else {
                    PrestaShopLogger::addLog("Configur. Price: No customization or no additional price - Prod $id_product, Cust $id_customization, Additional $additional_price", 1);
                }
            } else {
                 // Debug logging for missing configuration
                 PrestaShopLogger::addLog("Configur. Price: MISSING CONFIG for Prod $id_product, Cart $id_cart, Cust $id_customization (Params: ".json_encode(array_keys($params)).")", 1);
            }
        } catch (Exception $e) {
            PrestaShopLogger::addLog("Configur. Price Error: " . $e->getMessage(), 3);
        }
        return null;
    }

    /**
     * Display product price block hook
     * This hook is used as a safety measure for price display
     */
    public function hookDisplayProductPriceBlock($params)
    {
        // This hook can be used to modify price display if needed
        // For now, we rely on actionProductPriceCalculation for price calculation
        return '';
    }

    /**
     * Hook called after cart quantity update
     * Ensures prices are recalculated when cart is updated
     * Also cleans up configuration records for removed products
     */
    public function hookActionCartUpdateQuantityAfter($params)
    {
        // Force cart to recalculate prices
        if (isset($params['cart']) && Validate::isLoadedObject($params['cart'])) {
            $cart = $params['cart'];
            $cart->update();
            
            // Clean up configuration records for products no longer in cart
            $this->cleanupCartConfigurations($cart);
        }
        return '';
    }

    /**
     * Hook called when cart is saved
     * Ensures prices are properly calculated and cleans up orphaned configurations
     */
    public function hookActionCartSave($params)
    {
        // Ensure cart prices are up to date
        if (isset($params['cart']) && Validate::isLoadedObject($params['cart'])) {
            $cart = $params['cart'];
            // Cart will automatically recalculate on save, but we ensure our prices are included
            
            // Clean up configuration records for products no longer in cart
            $this->cleanupCartConfigurations($cart);
        }
        return '';
    }
    
    /**
     * Clean up configuration records for products that are no longer in the cart
     */
    private function cleanupCartConfigurations($cart)
    {
        if (!Validate::isLoadedObject($cart)) {
            return;
        }
        
        // Get all products currently in cart
        $products = $cart->getProducts(true);
        $validProductKeys = [];
        
        foreach ($products as $product) {
            $id_product = (int)$product['id_product'];
            $id_customization = isset($product['id_customization']) ? (int)$product['id_customization'] : 0;
            $key = $id_product . '_' . $id_customization;
            $validProductKeys[] = $key;
        }
        
        // Get all configuration records for this cart
        $configs = Db::getInstance()->executeS('
            SELECT id_selection, id_product, id_customization 
            FROM ' . _DB_PREFIX_ . 'configurator_selection
            WHERE id_cart = ' . (int)$cart->id
        );
        
        if ($configs) {
            foreach ($configs as $config) {
                $id_product = (int)$config['id_product'];
                $id_customization = (int)$config['id_customization'];
                $key = $id_product . '_' . $id_customization;
                
                // If this product/customization is not in cart, delete the configuration record
                if (!in_array($key, $validProductKeys)) {
                    Db::getInstance()->delete('configurator_selection', 'id_selection = ' . (int)$config['id_selection']);
                }
            }
        }
    }

    /**
     * Display configuration in shopping cart
     */
    public function hookDisplayShoppingCart($params)
    {
        $cart = $params['cart'];
        if (!Validate::isLoadedObject($cart)) {
            return '';
        }

        $products = $cart->getProducts(true);
        
        // If cart is empty, return empty string immediately
        if (empty($products) || !is_array($products) || count($products) === 0) {
            return '';
        }
        
        $configurations = [];

        foreach ($products as $product) {
            $id_product = (int)$product['id_product'];
            $id_customization = isset($product['id_customization']) ? (int)$product['id_customization'] : 0;
            
            // Get configuration for this cart product
            $sql = "SELECT selections, dimensions, comment, file_path 
                    FROM " . _DB_PREFIX_ . "configurator_selection 
                    WHERE id_cart = " . (int)$cart->id . " 
                    AND id_product = " . $id_product;
            
            if ($id_customization) {
                $sql .= " AND id_customization = " . $id_customization;
            }
            
            $sql .= " ORDER BY date_add DESC";
            $row = Db::getInstance()->getRow($sql);

            if ($row) {
                $selections = json_decode(stripslashes($row['selections']), true);
                $dimensions = json_decode(stripslashes($row['dimensions']), true);
                
                // Calculate dimension prices for display
                if (is_array($dimensions)) {
                     $base_price_ref = (float)$product['price'];
                     foreach ($dimensions as &$dim) {
                         if (is_array($dim)) {
                             $priceType = isset($dim['priceType']) ? $dim['priceType'] : (isset($dim['price_type']) ? $dim['price_type'] : null);
                             $priceValue = isset($dim['priceValue']) ? (float)$dim['priceValue'] : (isset($dim['price_value']) ? (float)$dim['price_value'] : 0);
                             $value = isset($dim['value']) ? (float)$dim['value'] : 0;
                             
                             $dimPrice = 0;
                             if ($priceType && $priceValue > 0 && $value > 0) {
                                 switch ($priceType) {
                                     case 'per_unit':
                                         $dimPrice = $value * $priceValue;
                                         break;
                                     case 'fixed':
                                         $dimPrice = $priceValue;
                                         break;
                                     case 'percentage':
                                         $dimPrice = ($base_price_ref * $priceValue / 100);
                                         break;
                                 }
                             }
                             
                             if ($dimPrice > 0) {
                                 $dim['formatted_price'] = PriceCalculator::formatPrice($dimPrice);
                             }
                         }
                     }
                     unset($dim);
                }
                
                // Calculate additional price
                $optionIds = [];
                if ($selections && is_array($selections)) {
                    foreach ($selections as $stepId => &$options) {
                        if (is_array($options)) {
                            foreach ($options as $optId => &$details) {
                                $optionIds[] = $optId;
                                
                                // Calculate price for this specific option
                                $optPrice = PriceCalculator::getOptionPrice($optId, $dimensions);
                                if ($optPrice > 0) {
                                    $details['price'] = $optPrice;
                                    $details['formatted_price'] = PriceCalculator::formatPrice($optPrice);
                                }
                            }
                        }
                    }
                }

                $base_price = (float)$product['price'];
                $final_price = PriceCalculator::calculate($base_price, $optionIds, $dimensions);
                $additional_price = $final_price - $base_price;

                // Use product ID as key for template compatibility, but include customization ID
                $config_key = $id_product;
                // If there are multiple customizations, append customization ID
                if ($id_customization > 0) {
                    $config_key = $id_product . '_' . $id_customization;
                }
                
                $configurations[$config_key] = [
                    'id_product' => $id_product,
                    'id_customization' => $id_customization,
                    'product_key' => $id_product . '_' . (isset($product['id_product_attribute']) ? $product['id_product_attribute'] : 0) . '_' . $id_customization,
                    'selections' => $selections,
                    'dimensions' => $dimensions,
                    'comment' => $row['comment'],
                    'file_path' => $row['file_path'],
                    'additional_price' => $additional_price,
                    'final_price' => $final_price,
                    'formatted_price' => PriceCalculator::formatPrice($additional_price)
                ];
            }
        }

        if (empty($configurations)) {
            return '';
        }

        $this->context->smarty->assign([
            'configurations' => $configurations,
            'link' => $this->context->link,
            'cart_products' => $products // Pass products to template for validation
        ]);

        $output = $this->display(__FILE__, 'views/templates/front/cart_configuration.tpl');
        return is_string($output) ? $output : '';
    }

    /**
     * Link configuration to order when order is validated
     */
    public function hookActionValidateOrder($params)
    {
        $order = $params['order'];
        $cart = $params['cart'];
        
        if (!Validate::isLoadedObject($order) || !Validate::isLoadedObject($cart)) {
            return '';
        }

        // Link all configurations from cart to order
        $sql = "UPDATE " . _DB_PREFIX_ . "configurator_selection 
                SET id_order = " . (int)$order->id . " 
                WHERE id_cart = " . (int)$cart->id . " 
                AND id_order IS NULL";
        Db::getInstance()->execute($sql);
        
        return '';
    }

    /**
     * Display configuration on order confirmation page
     */
    public function hookDisplayOrderConfirmation($params)
    {
        $order = $params['order'];
        if (!Validate::isLoadedObject($order)) {
            return '';
        }

        $order_products = $order->getProducts();
        $configurations = [];

        foreach ($order_products as $product) {
            $id_product = (int)$product['product_id'];
            $id_customization = isset($product['id_customization']) ? (int)$product['id_customization'] : 0;
            
            // Get configuration for this order product
            $sql = "SELECT selections, dimensions, comment, file_path 
                    FROM " . _DB_PREFIX_ . "configurator_selection 
                    WHERE id_order = " . (int)$order->id . " 
                    AND id_product = " . $id_product;
            
            if ($id_customization) {
                $sql .= " AND id_customization = " . $id_customization;
            }
            
            $sql .= " ORDER BY date_add DESC LIMIT 1";
            $row = Db::getInstance()->getRow($sql);

            if ($row) {
                $selections = json_decode(stripslashes($row['selections']), true);
                $dimensions = json_decode(stripslashes($row['dimensions']), true);
                
                // Calculate additional price
                $optionIds = [];
                if ($selections && is_array($selections)) {
                    foreach ($selections as $stepId => $options) {
                        if (is_array($options)) {
                            foreach ($options as $optId => $details) {
                                $optionIds[] = $optId;
                            }
                        }
                    }
                }

                $base_price = (float)$product['product_price'];
                $final_price = PriceCalculator::calculate($base_price, $optionIds, $dimensions);
                $additional_price = $final_price - $base_price;

                $config_key = $id_product . '_' . $id_customization;
                $configurations[$config_key] = [
                    'id_product' => $id_product,
                    'id_customization' => $id_customization,
                    'selections' => $selections,
                    'dimensions' => $dimensions,
                    'comment' => $row['comment'],
                    'file_path' => $row['file_path'],
                    'additional_price' => $additional_price,
                    'final_price' => $final_price,
                    'formatted_price' => PriceCalculator::formatPrice($additional_price)
                ];
            }
        }

        if (empty($configurations)) {
            return '';
        }

        $this->context->smarty->assign([
            'configurations' => $configurations,
            'link' => $this->context->link,
            'order' => $order
        ]);

        $output = $this->display(__FILE__, 'views/templates/front/order_confirmation.tpl');
        return is_string($output) ? $output : '';
    }

    /**
     * Display configuration in customer order detail page
     */
    public function hookDisplayOrderDetail($params)
    {
        $order = $params['order'];
        if (!Validate::isLoadedObject($order)) {
            return '';
        }

        $order_products = $order->getProducts();
        $configurations = [];

        foreach ($order_products as $product) {
            $id_product = (int)$product['product_id'];
            $id_customization = isset($product['id_customization']) ? (int)$product['id_customization'] : 0;
            
            // Get configuration for this order product
            $sql = "SELECT selections, dimensions, comment, file_path 
                    FROM " . _DB_PREFIX_ . "configurator_selection 
                    WHERE id_order = " . (int)$order->id . " 
                    AND id_product = " . $id_product;
            
            if ($id_customization) {
                $sql .= " AND id_customization = " . $id_customization;
            }
            
            $sql .= " ORDER BY date_add DESC LIMIT 1";
            $row = Db::getInstance()->getRow($sql);

            if ($row) {
                $selections = json_decode(stripslashes($row['selections']), true);
                $dimensions = json_decode(stripslashes($row['dimensions']), true);
                
                $config_key = $id_product . '_' . $id_customization;
                $configurations[$config_key] = [
                    'id_product' => $id_product,
                    'id_customization' => $id_customization,
                    'selections' => $selections,
                    'dimensions' => $dimensions,
                    'comment' => $row['comment'],
                    'file_path' => $row['file_path']
                ];
            }
        }

        if (empty($configurations)) {
            return '';
        }

        $this->context->smarty->assign([
            'configurations' => $configurations,
            'link' => $this->context->link
        ]);

        $output = $this->display(__FILE__, 'views/templates/front/order_detail.tpl');
        return is_string($output) ? $output : '';
    }

    /**
     * Display configuration in admin order view
     */
    public function hookDisplayAdminOrder($params)
    {
        $id_order = (int)$params['id_order'];
        if (!$id_order) {
            return '';
        }

        $order = new Order($id_order);
        if (!Validate::isLoadedObject($order)) {
            return '';
        }

        $order_products = $order->getProducts();
        $configurations = [];

        foreach ($order_products as $product) {
            $id_product = (int)$product['product_id'];
            $id_customization = isset($product['id_customization']) ? (int)$product['id_customization'] : 0;
            
            // Get configuration for this order product
            $sql = "SELECT selections, dimensions, comment, file_path 
                    FROM " . _DB_PREFIX_ . "configurator_selection 
                    WHERE id_order = " . (int)$id_order . " 
                    AND id_product = " . $id_product;
            
            if ($id_customization) {
                $sql .= " AND id_customization = " . $id_customization;
            }
            
            $sql .= " ORDER BY date_add DESC LIMIT 1";
            $row = Db::getInstance()->getRow($sql);

            if ($row) {
                $selections = json_decode(stripslashes($row['selections']), true);
                $dimensions = json_decode(stripslashes($row['dimensions']), true);
                
                $config_key = $id_product . '_' . $id_customization;
                $configurations[$config_key] = [
                    'id_product' => $id_product,
                    'id_customization' => $id_customization,
                    'selections' => $selections,
                    'dimensions' => $dimensions,
                    'comment' => $row['comment'],
                    'file_path' => $row['file_path']
                ];
            }
        }

        if (empty($configurations)) {
            return '';
        }

        $this->context->smarty->assign([
            'configurations' => $configurations,
            'link' => $this->context->link
        ]);

        $output = $this->display(__FILE__, 'views/templates/admin/order_configuration.tpl');
        return is_string($output) ? $output : '';
    }
}
