<?php
/**
 * ps_configurator module
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

require_once _PS_MODULE_DIR_ . 'ps_configurator/classes/Configurator.php';
require_once _PS_MODULE_DIR_ . 'ps_configurator/classes/Step.php';
require_once _PS_MODULE_DIR_ . 'ps_configurator/classes/Option.php';
require_once _PS_MODULE_DIR_ . 'ps_configurator/classes/PriceCalculator.php';

class Ps_configurator extends Module
{
    public function __construct()
    {
        $this->name = 'ps_configurator';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = '';
        $this->need_instance = 0;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Product Configurator');
        $this->description = $this->l('A config-driven product engine for custom products.');

        $this->ps_versions_compliancy = array('min' => '1.7', 'max' => _PS_VERSION_);
    }

    public function install()
    {
        if (Shop::isFeatureActive()) {
            Shop::setContext(Shop::CONTEXT_ALL);
        }

        return parent::install() &&
            $this->installDb() &&
            $this->installTabs() &&
            $this->registerHook('actionProductPriceCalculation') &&
            $this->registerHook('displayConfigurator') &&
            $this->registerHook('displayAdminProductsExtra') &&
            $this->registerHook('displayProductPriceBlock') && // Extra hook for safety
            $this->registerHook('header');
    }

    public function getContent()
    {
        Tools::redirectAdmin($this->context->link->getAdminLink('AdminConfigurators'));
    }

    public function uninstall()
    {
        return parent::uninstall() &&
            $this->uninstallDb() &&
            $this->uninstallTabs();
    }

    protected function installDb()
    {
        $sql = file_get_contents($this->local_path . 'config/install.sql');
        $sql = str_replace(['PREFIX_', 'ENGINE_TYPE'], [_DB_PREFIX_, _MYSQL_ENGINE_], $sql);
        $queries = explode(';', $sql);

        foreach ($queries as $query) {
            $query = trim($query);
            if (!empty($query)) {
                if (!Db::getInstance()->execute($query)) {
                    return false;
                }
            }
        }
        return true;
    }

    protected function uninstallDb()
    {
        $sql = file_get_contents($this->local_path . 'config/uninstall.sql');
        $sql = str_replace('PREFIX_', _DB_PREFIX_, $sql);
        $queries = explode(';', $sql);

        foreach ($queries as $query) {
            $query = trim($query);
            if (!empty($query)) {
                if (!Db::getInstance()->execute($query)) {
                    return false;
                }
            }
        }
        return true;
    }

    private function installTabs()
    {
        $res = true;
        
        // Parent Tab under "Improve" (Personnaliser)
        $tab1 = new Tab();
        $tab1->class_name = 'AdminConfigurators';
        $tab1->module = $this->name;
        $tab1->id_parent = (int)Tab::getIdFromClassName('IMPROVE');
        $tab1->icon = 'settings_input_component';
        foreach (Language::getLanguages(false) as $lang) {
            $tab1->name[$lang['id_lang']] = 'Configurator Builder';
        }
        $res &= $tab1->add();

        // Steps Tab (Hidden/Sub)
        $tab2 = new Tab();
        $tab2->class_name = 'AdminSteps';
        $tab2->module = $this->name;
        $tab2->id_parent = $tab1->id; // Nest under main
        $tab2->active = 0; // Hide from menu
        foreach (Language::getLanguages(false) as $lang) {
            $tab2->name[$lang['id_lang']] = 'Configurator Steps';
        }
        $res &= $tab2->add();

        return $res;
    }

    private function uninstallTabs()
    {
        $res = true;
        foreach (['AdminConfigurators', 'AdminSteps'] as $class_name) {
            $id_tab = (int)Tab::getIdFromClassName($class_name);
            if ($id_tab) {
                $tab = new Tab($id_tab);
                $res &= $tab->delete();
            }
        }
        return $res;
    }

    public function hookHeader()
    {
        if ($this->context->controller->php_self == 'product') {
            $this->context->controller->addJS($this->_path . 'views/js/front.js');
            $this->context->controller->addCSS($this->_path . 'views/css/front.css');
        }
    }

    public function hookDisplayConfigurator($params)
    {
        $id_product = 0;
        if (isset($params['product'])) {
            $product = $params['product'];
            if (is_object($product)) {
                $id_product = isset($product->id) ? (int)$product->id : (isset($product->id_product) ? (int)$product->id_product : 0);
            } elseif (is_array($product)) {
                $id_product = isset($product['id_product']) ? (int)$product['id_product'] : (isset($product['id']) ? (int)$product['id'] : 0);
            }
        }

        if (!$id_product && isset($this->context->controller->php_self) && $this->context->controller->php_self == 'product') {
             $id_product = (int)Tools::getValue('id_product');
        }

        if (!$id_product) return '';

        // 1. First try to find a configurator explicitly linked to this product
        $configurator = Configurator::getByProduct($id_product);

        if (!$configurator) {
            // 2. Fallback to Category matching
            $categories = Product::getProductCategories($id_product);
            $configurator = Configurator::getByCategory($categories);
        }

        if ($configurator && $configurator->active) {
            $this->context->smarty->assign([
                'configurator' => $configurator,
                'steps' => $configurator->getSteps(true),
                'ajax_url' => $this->context->link->getModuleLink($this->name, 'configurator'),
                'base_url' => $this->context->shop->getBaseURL(true),
                'urls' => ['base_url' => $this->context->shop->getBaseURL(true)]
            ]);

            return $this->display(__FILE__, 'views/templates/front/configurator.tpl');
        }

        return '';
    }

    public function hookDisplayAdminProductsExtra($params)
    {
        $id_product = isset($params['id_product']) ? (int)$params['id_product'] : (isset($params['id']) ? (int)$params['id'] : 0);
        
        if (!$id_product) {
            return '';
        }

        $product = new Product($id_product);
        if (!Validate::isLoadedObject($product)) {
            return '';
        }

        $categories = $product->getCategories();
        $configurator = Configurator::getByCategory($categories);
        
        $this->context->smarty->assign([
            'id_product' => $id_product,
            'configurator' => $configurator,
            'link' => $this->context->link,
            'builder_link' => $configurator ? $this->context->link->getAdminLink('AdminSteps') . '&id_configurator=' . $configurator->id : null
        ]);

        return $this->display(__FILE__, 'views/templates/admin/product_tab.tpl');
    }

    public function hookActionProductPriceCalculation($params)
    {
        try {
            // Ensure classes are loaded
            if (!class_exists('PriceCalculator')) {
                require_once _PS_MODULE_DIR_ . 'ps_configurator/classes/PriceCalculator.php';
            }
            if (!class_exists('Option')) {
                require_once _PS_MODULE_DIR_ . 'ps_configurator/classes/Option.php';
            }

            $id_cart = isset($params['id_cart']) ? (int)$params['id_cart'] : 0;
            $id_product = isset($params['id_product']) ? (int)$params['id_product'] : 0;
            $base_price = isset($params['price']) ? (float)$params['price'] : 0;

            if (!$id_cart || !$id_product) {
                return null;
            }

            // Fetch selection from DB
            $sql = "SELECT selections, dimensions FROM " . _DB_PREFIX_ . "configurator_selection 
                    WHERE id_cart = " . (int)$id_cart . " 
                    AND id_product = " . (int)$id_product . " 
                    ORDER BY date_add DESC";
            $row = Db::getInstance()->getRow($sql);

            if ($row) {
                $selections = json_decode($row['selections'], true);
                $dimensions = json_decode($row['dimensions'], true);
                
                $optionIds = [];
                if ($selections && is_array($selections)) {
                    foreach ($selections as $stepId => $options) {
                        if (is_array($options)) {
                            foreach ($options as $optId => $details) {
                                $optionIds[] = $optId;
                            }
                        }
                    }
                }

                $final_price = PriceCalculator::calculate($base_price, $optionIds, $dimensions);
                
                return $final_price;
            }
        } catch (Exception $e) {
            // Silently fail to avoid breaking the site
            return null;
        }

        return null;
    }
}
