# Conditional Logic System Explanation

## How Conditional Steps Work

### Step Configuration
Each step can have these conditional properties:
- **`depends_on_step`**: The ID of the step it depends on (0 = no dependency, always visible)
- **`depends_on_value`**: Comma-separated list of values that trigger this step to appear
- **`show_condition`**: How to evaluate the trigger values
  - `ANY` = Show if ANY of the trigger values match
  - `ALL` = Show only if ALL trigger values match
  - `NONE` = Show if NONE of the trigger values match

### How Matching Works

When a step depends on another step:
1. **Get selections** from the dependent step (`state.selections[dependsOnStepId]`)
2. **Extract values** from selected options:
   - `label`: The display label of the option (e.g., "White", "Somfy Motor")
   - `valueKey`: The internal value key (e.g., "white", "somfy_motor")
3. **Compare** these values against `depends_on_value` trigger values
4. **Evaluate** using the condition type (ANY/ALL/NONE)

### Example

**Step 1: Color Selection**
- Option: "White" (label="White", valueKey="white")
- Option: "Custom RAL" (label="Custom RAL", valueKey="custom_ral")

**Step 2: RAL Color Picker** (depends on Step 1)
- `depends_on_step` = 1 (Step 1's ID)
- `depends_on_value` = "Custom RAL,custom_ral" (matches label OR valueKey)
- `show_condition` = "ANY"

**Result**: Step 2 only appears when "Custom RAL" is selected in Step 1.

### Common Issues

1. **Step ID Mismatch**: Step IDs must match exactly (string vs number)
2. **Value Matching**: Must match exactly (case-sensitive, exact string match)
3. **RAL Modifications**: RAL selections modify labels (adds RAL code), which can break matching
4. **Multiple Values**: Use comma-separated values in `depends_on_value`

### How to Set Up Conditional Steps

1. **In Admin**: When editing a step, set:
   - **Depends On Step**: Select the step ID it depends on
   - **Trigger Values**: Enter comma-separated values (e.g., "White,white,Custom RAL")
   - **Show Condition**: Choose ANY, ALL, or NONE

2. **What to Match**:
   - Use the option's **label** (what users see)
   - OR use the option's **valueKey** (internal identifier)
   - OR use both separated by commas for flexibility

3. **Best Practice**:
   - Include both label and valueKey in trigger values: "White,white"
   - Use exact matches (case-sensitive)
   - Test with actual selections to verify matching

