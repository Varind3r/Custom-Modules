<?php
require_once(dirname(__FILE__) . '/../../config/config.inc.php');
require_once(dirname(__FILE__) . '/../../init.php');

$db = Db::getInstance();

$sql = "CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "ps_configurator_selection` (
    `id_selection` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `id_cart` INT UNSIGNED NOT NULL,
    `id_product` INT UNSIGNED NOT NULL,
    `selections` TEXT,
    `dimensions` TEXT,
    `comment` TEXT,
    `file_path` VARCHAR(255),
    `date_add` DATETIME NOT NULL,
    PRIMARY KEY (`id_selection`),
    KEY `id_cart_product` (`id_cart`, `id_product`)
) ENGINE=" . _MYSQL_ENGINE_ . " DEFAULT CHARSET=utf8;";

if ($db->execute($sql)) {
    echo "Table ps_configurator_selection created.<br>";
} else {
    echo "Error creating table: " . $db->getMsgError() . "<br>";
}

// Create uploads directory
$uploadDir = _PS_ROOT_DIR_ . '/themes/child_classic/assets/img/configurator/uploads/';
if (!is_dir($uploadDir)) {
    if (mkdir($uploadDir, 0755, true)) {
        echo "Uploads directory created.<br>";
    } else {
        echo "Error creating uploads directory.<br>";
    }
} else {
    echo "Uploads directory exists.<br>";
}
