<?php
/**
 * Update script to add id_order field to existing configurator_selection table
 * Run this once if you have existing installation without id_order field
 */

require_once(dirname(__FILE__) . '/../../config/config.inc.php');
require_once(dirname(__FILE__) . '/../../init.php');

$db = Db::getInstance();

// Check if id_order column already exists
$sqlCheck = "SHOW COLUMNS FROM `" . _DB_PREFIX_ . "configurator_selection` LIKE 'id_order'";
$result = $db->executeS($sqlCheck);

if (empty($result)) {
    // Add id_order field
    $sql = "ALTER TABLE `" . _DB_PREFIX_ . "configurator_selection` 
            ADD COLUMN `id_order` INT UNSIGNED NULL AFTER `id_cart`,
            ADD INDEX `id_order` (`id_order`)";
    
    if ($db->execute($sql)) {
        echo "✅ Successfully added id_order field to configurator_selection table\n";
    } else {
        echo "❌ Error adding id_order field: " . $db->getMsgError() . "\n";
    }
} else {
    echo "✅ id_order field already exists. No update needed.\n";
}

