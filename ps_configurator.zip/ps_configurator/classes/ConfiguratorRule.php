<?php
/**
 * ConfiguratorRule ObjectModel
 */

class ConfiguratorRule extends ObjectModel
{
    public $id_rule;
    public $id_configurator;
    public $id_step_target;
    public $rule_data;
    public $active;

    public static $definition = [
        'table' => 'configurator_rule',
        'primary' => 'id_rule',
        'fields' => [
            'id_configurator' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => true],
            'id_step_target' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => true],
            'rule_data' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'active' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
        ],
    ];

    public static function getRulesByConfigurator($id_configurator)
    {
        $sql = new DbQuery();
        $sql->select('*');
        $sql->from('configurator_rule');
        $sql->where('id_configurator = ' . (int)$id_configurator);
        $sql->where('active = 1');
        $sql->orderBy('id_rule ASC');

        return Db::getInstance()->executeS($sql);
    }

    public function getRuleData()
    {
        if (empty($this->rule_data)) {
            return [];
        }
        $decoded = json_decode($this->rule_data, true);
        return is_array($decoded) ? $decoded : [];
    }

    public function setRuleData($data)
    {
        $this->rule_data = json_encode($data);
    }
}

