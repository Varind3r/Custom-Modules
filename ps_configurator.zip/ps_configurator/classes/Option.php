<?php
/**
 * Option ObjectModel
 */

class Option extends ObjectModel
{
    public $id_option;
    public $id_step;
    public $position;
    public $option_type;
    public $label;
    public $description;
    public $image;
    public $value_key;
    public $price_type;
    public $price_value;
    public $show_options;
    public $hide_options;
    public $price_calculation;
    public $config; // JSON

    public static $definition = [
        'table' => 'configurator_option',
        'primary' => 'id_option',
        'fields' => [
            'id_step' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => true],
            'position' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'],
            'option_type' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'required' => true],
            'label' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'required' => true, 'size' => 255],
            'description' => ['type' => self::TYPE_HTML, 'validate' => 'isCleanHtml'],
            'image' => ['type' => self::TYPE_STRING, 'validate' => 'isString', 'size' => 255],
            'value_key' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'size' => 255],
            'price_type' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName'],
            'price_value' => ['type' => self::TYPE_FLOAT, 'validate' => 'isPrice'],
            'show_options' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'hide_options' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'price_calculation' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'config' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
        ],
    ];

    public function getConfig()
    {
        return json_decode($this->config, true);
    }

    public function setConfig($config)
    {
        $this->config = json_encode($config);
    }

    public static function getHigherPosition($id_step)
    {
        $sql = 'SELECT MAX(`position`) FROM `' . _DB_PREFIX_ . 'configurator_option` WHERE `id_step` = ' . (int)$id_step;
        return (int)Db::getInstance()->getValue($sql);
    }

    public function add($autodate = true, $null_values = false)
    {
        if (!$this->position) {
            $this->position = self::getHigherPosition($this->id_step) + 1;
        }
        return parent::add($autodate, $null_values);
    }
}
