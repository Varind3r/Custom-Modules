<?php
/**
 * Option ObjectModel
 */

class Option extends ObjectModel
{
    public $id_option;
    public $id_step;
    public $position;
    public $option_type;
    public $label;
    public $description;
    public $image;
    public $value_key;
    public $price_type;
    public $price_value;
    public $show_options;
    public $hide_options;
    public $price_calculation;
    public $config; // JSON

    public static $definition = [
        'table' => 'configurator_option',
        'primary' => 'id_option',
        'fields' => [
            'id_step' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => true],
            'position' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'],
            'option_type' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'required' => true],
            'label' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'required' => true, 'size' => 255],
            'description' => ['type' => self::TYPE_HTML, 'validate' => 'isCleanHtml'],
            'image' => ['type' => self::TYPE_STRING, 'validate' => 'isString', 'size' => 255],
            'value_key' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'size' => 255],
            'price_type' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName'],
            'price_value' => ['type' => self::TYPE_FLOAT, 'validate' => 'isPrice'],
            'show_options' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'hide_options' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'price_calculation' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'config' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
        ],
    ];

    public function getConfig()
    {
        if (empty($this->config)) {
            return [];
        }
        $decoded = json_decode($this->config, true);
        return is_array($decoded) ? $decoded : [];
    }

    public function setConfig($config)
    {
        $this->config = json_encode($config);
    }

    public static function getHigherPosition($id_step)
    {
        $sql = 'SELECT MAX(`position`) FROM `' . _DB_PREFIX_ . 'configurator_option` WHERE `id_step` = ' . (int)$id_step;
        return (int)Db::getInstance()->getValue($sql);
    }

    /**
     * Validate option data before saving
     */
    public function validateFields($die = true, $error_return = false)
    {
        $errors = [];
        
        // Validate required fields
        if (empty($this->option_type)) {
            $errors[] = 'Option type is required.';
        } elseif (!in_array($this->option_type, ['visual_choice', 'color_choice', 'ral_system', 'dimension_range', 'fixed_range', 'toggle'])) {
            $errors[] = 'Invalid option type.';
        }
        
        if (empty($this->label)) {
            $errors[] = 'Option label is required.';
        } elseif (strlen($this->label) > 255) {
            $errors[] = 'Option label cannot exceed 255 characters.';
        }
        
        // Validate step exists
        if (empty($this->id_step) || $this->id_step <= 0) {
            $errors[] = 'Step ID is required.';
        } else {
            $step = new Step($this->id_step);
            if (!Validate::isLoadedObject($step)) {
                $errors[] = 'Invalid step selected.';
            }
        }
        
        // Validate price_value if price_type is set
        if (!empty($this->price_type) && $this->price_value !== null && $this->price_value !== '') {
            if (!is_numeric($this->price_value)) {
                $errors[] = 'Price value must be a valid number.';
            }
        }
        
        // Validate position
        if ($this->position < 0) {
            $errors[] = 'Position cannot be negative.';
        }
        
        if (!empty($errors)) {
            if ($error_return) {
                return $errors;
            }
            if ($die) {
                throw new PrestaShopException(implode(' ', $errors));
            }
            return false;
        }
        
        return parent::validateFields($die, $error_return);
    }

    public function add($autodate = true, $null_values = false)
    {
        // Validate before adding
        $validation = $this->validateFields(false, true);
        if ($validation !== true && is_array($validation) && !empty($validation)) {
            $this->validateFields(true, false); // This will throw exception
        }
        
        if (!$this->position) {
            $this->position = self::getHigherPosition($this->id_step) + 1;
        }
        
        // Set defaults
        if (empty($this->value_key)) {
            $this->value_key = Tools::str2url($this->label);
        }
        if (empty($this->price_type)) {
            $this->price_type = 'fixed';
        }
        if ($this->price_value === null || $this->price_value === '') {
            $this->price_value = 0;
        }
        
        return parent::add($autodate, $null_values);
    }
    
    public function update($null_values = false)
    {
        // Validate before updating
        $validation = $this->validateFields(false, true);
        if ($validation !== true && is_array($validation) && !empty($validation)) {
            $this->validateFields(true, false); // This will throw exception
        }
        
        return parent::update($null_values);
    }
}
