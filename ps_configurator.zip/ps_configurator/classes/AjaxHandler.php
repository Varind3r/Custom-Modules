<?php
/**
 * AjaxHandler - Handles AJAX requests for price calculation and other operations
 */

class AjaxHandler
{
    /**
     * Calculate price based on selections
     * 
     * @param int $id_product
     * @param array $selections
     * @param array $dimensions
     * @return array
     */
    public static function calculatePrice($id_product, $selections, $dimensions)
    {
        if (!class_exists('PriceCalculator')) {
            require_once _PS_MODULE_DIR_ . 'ps_configurator/classes/PriceCalculator.php';
        }
        if (!class_exists('Option')) {
            require_once _PS_MODULE_DIR_ . 'ps_configurator/classes/Option.php';
        }

        $product = new Product($id_product);
        if (!Validate::isLoadedObject($product)) {
            return ['success' => false, 'errors' => 'Product not found'];
        }

        $base_price = (float)$product->getPrice(true, null, 6);
        
        // Calculate dimension-based pricing (per_sqm)
        $dimension_price = self::calculateDimensionBasedPrice($dimensions);
        
        // Use PriceCalculator logic for options
        $final_price = PriceCalculator::calculate($base_price, $selections, $dimensions);
        
        // Add dimension-based pricing
        $final_price += $dimension_price;

        return [
            'success' => true,
            'price' => round($final_price, 2),
            'price_formatted' => PriceCalculator::formatPrice($final_price),
            'debug' => [
                'base_price' => $base_price,
                'dimension_price' => $dimension_price,
                'final_price' => $final_price
            ]
        ];
    }

    /**
     * Calculate dimension-based pricing
     * This handles per_sqm pricing for width*height dimensions
     * 
     * @param array $dimensions
     * @return float
     */
    private static function calculateDimensionBasedPrice($dimensions)
    {
        if (empty($dimensions) || !is_array($dimensions)) {
            return 0;
        }

        $price = 0;
        $width = 0;
        $height = 0;
        $pricePerSqm = 0;

        foreach ($dimensions as $key => $dim) {
            if (!is_array($dim)) continue;

            $value = isset($dim['value']) ? (float)$dim['value'] : 0;
            $keyLower = strtolower($key);

            // Detect width/height dimensions
            if (strpos($keyLower, 'width') !== false || strpos($keyLower, 'largeur') !== false) {
                $width = $value;
            } elseif (strpos($keyLower, 'height') !== false || strpos($keyLower, 'hauteur') !== false) {
                $height = $value;
            }

            // Check for per_sqm pricing
            if (isset($dim['price_type']) && $dim['price_type'] === 'per_sqm') {
                $pricePerSqm = isset($dim['price_value']) ? (float)$dim['price_value'] : 0;
            }

            // Calculate per_unit pricing for range sliders
            if (isset($dim['price_per_unit']) && $dim['price_per_unit'] > 0) {
                $price += $value * (float)$dim['price_per_unit'];
            }
        }

        // Calculate area price if we have width, height and per_sqm price
        if ($width > 0 && $height > 0 && $pricePerSqm > 0) {
            // Convert from mm to m for area calculation
            $area = ($width / 1000) * ($height / 1000);
            $price += $area * $pricePerSqm;
        }

        return $price;
    }
}

