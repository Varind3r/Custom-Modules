<?php
/**
 * PriceCalculator class
 */

class PriceCalculator
{
    /**
     * Calculate final price based on base price and selections
     * 
     * @param float $base_price
     * @param array $selected_options Array of option IDs
     * @param array $dimensions [key => value]
     * @return float
     */
    public static function calculate($base_price, $selected_options, $dimensions = [])
    {
        $final_price = (float)$base_price;

        if (!is_array($selected_options) || empty($selected_options)) {
            return $final_price;
        }

        foreach ($selected_options as $id_option) {
            $option = new Option((int)$id_option);
            if (!Validate::isLoadedObject($option)) {
                continue;
            }

            switch ($option->price_type) {
                case 'fixed':
                    $final_price += (float)$option->price_value;
                    break;
                case 'percentage':
                    $final_price += ($base_price * (float)$option->price_value / 100);
                    break;
                case 'per_unit':
                    $multiplier = 1;
                    if (!empty($dimensions)) {
                        foreach ($dimensions as $val) {
                            $multiplier *= (float)$val;
                        }
                    }
                    $final_price += ($multiplier * (float)$option->price_value);
                    break;
                case 'formula':
                    if (!empty($option->price_calculation)) {
                        $final_price += self::evaluateFormula($option->price_calculation, $dimensions);
                    } else {
                        $final_price += (float)$option->price_value;
                    }
                    break;
            }
        }

        return max(0, $final_price); // Never negative
    }

    private static function evaluateFormula($formula, $variables = [])
    {
        if (empty($formula)) {
            return 0;
        }

        // Replace variable names with actual values
        foreach ((array)$variables as $key => $value) {
            $formula = str_replace($key, (float)$value, $formula);
        }

        // Remove any non-mathematical characters for safety
        $formula = preg_replace('/[^0-9\.\+\-\*\/\(\)\s]/', '', $formula);

        if (empty($formula)) {
            return 0;
        }

        try {
            // Safely evaluate mathematical expression
            $result = @eval('return ' . $formula . ';');
            return (float)$result ?: 0;
        } catch (Throwable $e) {
            return 0;
        }
    }

    public static function formatPrice($price)
    {
        $context = Context::getContext();
        $currency = $context->currency;
        $locale = $context->getCurrentLocale();

        if ($locale) {
            return $locale->formatPrice($price, $currency->iso_code);
        }

        return $currency->sign . ' ' . number_format($price, 2);
    }
}
