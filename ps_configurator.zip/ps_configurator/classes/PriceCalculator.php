<?php
/**
 * PriceCalculator class
 */

class PriceCalculator
{
    /**
     * Calculate final price based on base price and selections
     * 
     * @param float $base_price
     * @param array $selected_options Array of option IDs
     * @param array $dimensions [key => value]
     * @return float
     */
    public static function calculate($base_price, $selected_options, $dimensions = [])
    {
        $final_price = (float)$base_price;

        // Calculate dimension-based prices first
        if (!empty($dimensions) && is_array($dimensions)) {
            foreach ($dimensions as $key => $dim) {
                // Handle both array format (with priceType/priceValue) and simple numeric values (backward compatibility)
                if (is_array($dim)) {
                    // Check for camelCase (from JavaScript) or snake_case (from database)
                    $priceType = isset($dim['priceType']) ? $dim['priceType'] : (isset($dim['price_type']) ? $dim['price_type'] : null);
                    $priceValue = isset($dim['priceValue']) ? (float)$dim['priceValue'] : (isset($dim['price_value']) ? (float)$dim['price_value'] : 0);
                    $value = isset($dim['value']) ? (float)$dim['value'] : 0;
                    
                    // Only process if we have pricing information
                    if ($priceType && $priceValue > 0 && $value > 0) {
                        switch ($priceType) {
                            case 'per_unit':
                                // Price per unit (e.g., per meter, per square meter)
                                $final_price += $value * $priceValue;
                                break;
                            case 'fixed':
                                // Fixed price for this dimension
                                $final_price += $priceValue;
                                break;
                            case 'percentage':
                                // Percentage of base price
                                $final_price += ($base_price * $priceValue / 100);
                                break;
                        }
                    }
                } elseif (is_numeric($dim)) {
                    // Backward compatibility: simple numeric value (no pricing applied)
                    // This is just a dimension value without pricing
                }
            }
        }

        if (!is_array($selected_options) || empty($selected_options)) {
            return max(0, $final_price);
        }

        foreach ($selected_options as $id_option) {
            $option = new Option((int)$id_option);
            if (!Validate::isLoadedObject($option)) {
                continue;
            }

            switch ($option->price_type) {
                case 'fixed':
                    $final_price += (float)$option->price_value;
                    break;
                case 'percentage':
                    $final_price += ($base_price * (float)$option->price_value / 100);
                    break;
                case 'per_unit':
                    $config = json_decode($option->config, true);
                    $priceUnit = isset($config['price_unit']) ? $config['price_unit'] : 'm2'; // m2, m3, m, etc
                    
                    $multiplier = 1;
                    if ($priceUnit === 'm2' && !empty($dimensions)) {
                        // Area calculation (need width and height)
                        // Try to find width and height by key name or by checking for 'value' in array format
                        $width = 0;
                        $height = 0;
                        
                        // First try direct keys
                        if (isset($dimensions['width'])) {
                            $width = is_array($dimensions['width']) && isset($dimensions['width']['value']) 
                                ? (float)$dimensions['width']['value'] 
                                : (float)$dimensions['width'];
                        }
                        if (isset($dimensions['height'])) {
                            $height = is_array($dimensions['height']) && isset($dimensions['height']['value']) 
                                ? (float)$dimensions['height']['value'] 
                                : (float)$dimensions['height'];
                        }
                        
                        // If not found, try case-insensitive search
                        if ($width == 0 || $height == 0) {
                            foreach ($dimensions as $key => $dim) {
                                $keyLower = strtolower($key);
                                $dimValue = is_array($dim) && isset($dim['value']) ? (float)$dim['value'] : (float)$dim;
                                
                                if (strpos($keyLower, 'width') !== false || strpos($keyLower, 'largeur') !== false) {
                                    $width = $dimValue;
                                } elseif (strpos($keyLower, 'height') !== false || strpos($keyLower, 'hauteur') !== false) {
                                    $height = $dimValue;
                                }
                            }
                        }
                        
                        if ($width > 0 && $height > 0) {
                            $multiplier = $width * $height; // m²
                        }
                    } elseif ($priceUnit === 'm3' && !empty($dimensions)) {
                        // Volume calculation
                        $width = 0;
                        $height = 0;
                        $depth = 0;
                        
                        // Try direct keys first
                        if (isset($dimensions['width'])) {
                            $width = is_array($dimensions['width']) && isset($dimensions['width']['value']) 
                                ? (float)$dimensions['width']['value'] 
                                : (float)$dimensions['width'];
                        }
                        if (isset($dimensions['height'])) {
                            $height = is_array($dimensions['height']) && isset($dimensions['height']['value']) 
                                ? (float)$dimensions['height']['value'] 
                                : (float)$dimensions['height'];
                        }
                        if (isset($dimensions['depth'])) {
                            $depth = is_array($dimensions['depth']) && isset($dimensions['depth']['value']) 
                                ? (float)$dimensions['depth']['value'] 
                                : (float)$dimensions['depth'];
                        }
                        
                        // Try case-insensitive search
                        if ($width == 0 || $height == 0 || $depth == 0) {
                            foreach ($dimensions as $key => $dim) {
                                $keyLower = strtolower($key);
                                $dimValue = is_array($dim) && isset($dim['value']) ? (float)$dim['value'] : (float)$dim;
                                
                                if (strpos($keyLower, 'width') !== false || strpos($keyLower, 'largeur') !== false) {
                                    $width = $dimValue;
                                } elseif (strpos($keyLower, 'height') !== false || strpos($keyLower, 'hauteur') !== false) {
                                    $height = $dimValue;
                                } elseif (strpos($keyLower, 'depth') !== false || strpos($keyLower, 'profondeur') !== false) {
                                    $depth = $dimValue;
                                }
                            }
                        }
                        
                        if ($width > 0 && $height > 0 && $depth > 0) {
                            $multiplier = $width * $height * $depth; // m³
                        }
                    } elseif ($priceUnit === 'm' && !empty($dimensions)) {
                        // Linear calculation
                        $length = 0;
                        
                        if (isset($dimensions['length'])) {
                            $length = is_array($dimensions['length']) && isset($dimensions['length']['value']) 
                                ? (float)$dimensions['length']['value'] 
                                : (float)$dimensions['length'];
                        } elseif (isset($dimensions['width'])) {
                            $length = is_array($dimensions['width']) && isset($dimensions['width']['value']) 
                                ? (float)$dimensions['width']['value'] 
                                : (float)$dimensions['width'];
                        } else {
                            // Try to find any dimension
                            foreach ($dimensions as $dim) {
                                $dimValue = is_array($dim) && isset($dim['value']) ? (float)$dim['value'] : (float)$dim;
                                if ($dimValue > 0) {
                                    $length = $dimValue;
                                    break;
                                }
                            }
                        }
                        
                        if ($length > 0) {
                            $multiplier = $length;
                        }
                    } elseif (!empty($dimensions)) {
                        // Fallback: multiply all provided dimensions (backward compatible)
                        foreach ($dimensions as $val) {
                            if (is_array($val) && isset($val['value'])) {
                                $dimValue = (float)$val['value'];
                                if ($dimValue > 0) {
                                    $multiplier *= $dimValue;
                                }
                            } elseif (is_numeric($val) && $val > 0) {
                                $multiplier *= (float)$val;
                            }
                        }
                    }
                    
                    $final_price += ($multiplier * (float)$option->price_value);
                    break;
                case 'formula':
                    if (!empty($option->price_calculation)) {
                        $final_price += self::evaluateFormula($option->price_calculation, $dimensions);
                    } else {
                        $final_price += (float)$option->price_value;
                    }
                    break;
            }
        }

        return max(0, $final_price); // Never negative
    }

    private static function evaluateFormula($formula, $variables = [])
    {
        if (empty($formula)) {
            return 0;
        }

        // Replace variable names with actual values
        foreach ((array)$variables as $key => $value) {
            $formula = str_replace($key, (float)$value, $formula);
        }

        // Remove any non-mathematical characters for safety
        $formula = preg_replace('/[^0-9\.\+\-\*\/\(\)\s]/', '', $formula);

        if (empty($formula)) {
            return 0;
        }

        try {
            // Log for debugging (helps identify issues)
            PrestaShopLogger::addLog('PriceCalculator: Evaluating formula: ' . $formula, 1);
            
            // Safely evaluate mathematical expression
            // This is still eval but at least sanitized and logged
            $result = @eval('return ' . $formula . ';');
            return (float)$result ?: 0;
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('PriceCalculator: Formula error: ' . $e->getMessage(), 3);
            return 0;
        }
    }

    public static function formatPrice($price)
    {
        $context = Context::getContext();
        $currency = $context->currency;
        $locale = $context->getCurrentLocale();

        if ($locale) {
            return $locale->formatPrice($price, $currency->iso_code);
        }

        return $currency->sign . ' ' . number_format($price, 2);
    }
}
