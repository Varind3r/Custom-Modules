<?php
/**
 * CustomColor ObjectModel
 */

class CustomColor extends ObjectModel
{
    public $id_color;
    public $id_option;
    public $color_name;
    public $color_code;
    public $hex_code;
    public $position;
    public $active;

    public static $definition = [
        'table' => 'configurator_custom_color',
        'primary' => 'id_color',
        'fields' => [
            'id_option' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => true],
            'color_name' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'required' => true, 'size' => 255],
            'color_code' => ['type' => self::TYPE_STRING, 'validate' => 'isString', 'size' => 50],
            'hex_code' => ['type' => self::TYPE_STRING, 'validate' => 'isColor', 'required' => true, 'size' => 7],
            'position' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'],
            'active' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
        ],
    ];

    /**
     * Get all colors for an option
     */
    public static function getByOption($id_option, $only_active = false)
    {
        $sql = new DbQuery();
        $sql->select('id_color');
        $sql->from('configurator_custom_color');
        $sql->where('id_option = ' . (int)$id_option);
        if ($only_active) {
            $sql->where('active = 1');
        }
        $sql->orderBy('position ASC');

        $result = Db::getInstance()->executeS($sql);
        $colors = [];

        if ($result) {
            foreach ($result as $row) {
                $colors[] = new self($row['id_color']);
            }
        }

        return $colors;
    }

    public static function getHigherPosition($id_option)
    {
        $sql = 'SELECT MAX(`position`) FROM `' . _DB_PREFIX_ . 'configurator_custom_color` WHERE `id_option` = ' . (int)$id_option;
        return (int)Db::getInstance()->getValue($sql);
    }

    public function add($autodate = true, $null_values = false)
    {
        if (!$this->position) {
            $this->position = self::getHigherPosition($this->id_option) + 1;
        }
        return parent::add($autodate, $null_values);
    }
}

