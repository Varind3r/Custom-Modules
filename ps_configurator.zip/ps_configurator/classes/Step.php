<?php
/**
 * Step ObjectModel
 */

class Step extends ObjectModel
{
    public $id_step;
    public $id_configurator;
    public $is_global;
    public $position;
    public $type;
    public $title;
    public $description;
    public $required;
    public $depends_on_step;
    public $depends_on_value;
    public $show_condition;
    public $active;

    public static $definition = [
        'table' => 'configurator_step',
        'primary' => 'id_step',
        'fields' => [
            'id_configurator' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => false],
            'is_global' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'position' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'],
            'type' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'required' => true],
            'title' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'required' => true, 'size' => 255],
            'description' => ['type' => self::TYPE_HTML, 'validate' => 'isCleanHtml'],
            'required' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'depends_on_step' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'],
            'depends_on_value' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'show_condition' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName'],
            'active' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
        ],
    ];

    public function getOptions()
    {
        $sql = new DbQuery();
        $sql->select('id_option');
        $sql->from('configurator_option');
        $sql->where('id_step = ' . (int)$this->id);
        $sql->orderBy('position ASC');

        $result = Db::getInstance()->executeS($sql);
        $options = [];

        if ($result && is_array($result)) {
            foreach ($result as $row) {
                if (isset($row['id_option']) && $row['id_option'] > 0) {
                    $option = new Option((int)$row['id_option']);
                    if (Validate::isLoadedObject($option)) {
                        $options[] = $option;
                    }
                }
            }
        }

        return $options;
    }

    public static function getHigherPosition($id_configurator = null)
    {
        if ($id_configurator) {
            // Get position from junction table for configurator-specific steps
            $sql = 'SELECT MAX(`position`) FROM `' . _DB_PREFIX_ . 'configurator_step_association` WHERE `id_configurator` = ' . (int)$id_configurator;
        } else {
            // Get position for global steps
            $sql = 'SELECT MAX(`position`) FROM `' . _DB_PREFIX_ . 'configurator_step` WHERE `is_global` = 1';
        }
        return (int)Db::getInstance()->getValue($sql);
    }

    /**
     * Get all global steps (steps that can be reused)
     */
    public static function getGlobalSteps()
    {
        $sql = new DbQuery();
        $sql->select('id_step');
        $sql->from('configurator_step');
        $sql->where('is_global = 1');
        $sql->orderBy('title ASC');

        $result = Db::getInstance()->executeS($sql);
        $steps = [];

        if ($result) {
            foreach ($result as $row) {
                $steps[] = new Step($row['id_step']);
            }
        }

        return $steps;
    }

    /**
     * Copy this step to a configurator
     */
    public function copyToConfigurator($id_configurator)
    {
        // Create association in junction table
        $position = self::getHigherPosition($id_configurator) + 1;
        
        $sql = 'INSERT INTO `' . _DB_PREFIX_ . 'configurator_step_association` 
                (`id_configurator`, `id_step`, `position`) 
                VALUES (' . (int)$id_configurator . ', ' . (int)$this->id . ', ' . (int)$position . ')
                ON DUPLICATE KEY UPDATE `position` = VALUES(`position`)';
        
        return Db::getInstance()->execute($sql);
    }

    /**
     * Duplicate step (create new step with same options)
     */
    public function duplicate($id_configurator = null)
    {
        $new_step = new Step();
        $new_step->id_configurator = $id_configurator;
        $new_step->is_global = isset($this->is_global) ? $this->is_global : 0;
        $new_step->type = isset($this->type) && !empty($this->type) ? $this->type : 'choice'; // Ensure type is set
        $base_title = isset($this->title) && !empty($this->title) ? $this->title : 'Step';
        $new_step->title = $base_title . ' (Copy)'; // Ensure title is set
        $new_step->description = isset($this->description) ? $this->description : '';
        $new_step->required = isset($this->required) ? $this->required : 0;
        $new_step->depends_on_step = 0; // Reset dependencies
        $new_step->depends_on_value = '';
        $new_step->show_condition = isset($this->show_condition) && !empty($this->show_condition) ? $this->show_condition : 'ANY';
        $new_step->active = isset($this->active) ? $this->active : 1;
        
        if ($new_step->add()) {
            // Copy options
            $options = $this->getOptions();
            foreach ($options as $option) {
                $new_option = new Option();
                $new_option->id_step = $new_step->id;
                $new_option->position = $option->position;
                $new_option->option_type = $option->option_type;
                $new_option->label = $option->label;
                $new_option->description = $option->description;
                $new_option->image = $option->image;
                $new_option->value_key = $option->value_key . '_copy';
                $new_option->price_type = $option->price_type;
                $new_option->price_value = $option->price_value;
                $new_option->config = $option->config;
                $new_option->add();
            }
            
            // If copying to a configurator, create association
            if ($id_configurator) {
                $new_step->copyToConfigurator($id_configurator);
            }
            
            return $new_step;
        }
        
        return false;
    }

    /**
     * Validate step data before saving
     */
    public function validateFields($die = true, $error_return = false)
    {
        $errors = [];
        
        // Ensure defaults are set before validation
        if (empty($this->type)) {
            $this->type = 'choice';
        }
        if (empty($this->title) || trim($this->title) === '') {
            $this->title = 'Step';
        }
        
        // Validate required fields - now they should always be set
        if (!in_array($this->type, ['content', 'choice', 'dimension', 'multi_choice', 'summary'])) {
            $errors[] = 'Invalid step type. Allowed types: content, choice, dimension, multi_choice, summary.';
        }
        
        if (strlen($this->title) > 255) {
            $errors[] = 'Step title cannot exceed 255 characters.';
        }
        
        // Validate depends_on_step if set
        if ($this->depends_on_step > 0) {
            $depends_step = new Step($this->depends_on_step);
            if (!Validate::isLoadedObject($depends_step)) {
                $errors[] = 'Invalid dependency step selected.';
            } elseif ($depends_step->id_step == $this->id_step) {
                $errors[] = 'Step cannot depend on itself.';
            }
        }
        
        // Validate show_condition if depends_on_step is set
        if ($this->depends_on_step > 0 && empty($this->show_condition)) {
            $this->show_condition = 'ANY'; // Default value
        } elseif ($this->depends_on_step > 0 && !in_array($this->show_condition, ['ANY', 'ALL', 'NONE'])) {
            $errors[] = 'Invalid show condition. Allowed values: ANY, ALL, NONE.';
        }
        
        // Validate position
        if ($this->position < 0) {
            $errors[] = 'Position cannot be negative.';
        }
        
        if (!empty($errors)) {
            if ($error_return) {
                return $errors;
            }
            if ($die) {
                throw new PrestaShopException(implode(' ', $errors));
            }
            return false;
        }
        
        return parent::validateFields($die, $error_return);
    }

    public function add($autodate = true, $null_values = false)
    {
        // Set defaults BEFORE validation to ensure all required fields are present
        if (!isset($this->is_global)) {
            $this->is_global = 0;
        }
        if (!isset($this->required)) {
            $this->required = 0;
        }
        if (!isset($this->active)) {
            $this->active = 1;
        }
        if (!isset($this->depends_on_step)) {
            $this->depends_on_step = 0;
        }
        if (empty($this->show_condition) && $this->depends_on_step > 0) {
            $this->show_condition = 'ANY';
        }
        
        // Set defaults for required fields if they're missing
        if (empty($this->type)) {
            $this->type = 'choice'; // Default type
        }
        if (empty($this->title) || trim($this->title) === '') {
            $this->title = 'Step'; // Default title
        }
        
        // Set position if not set
        if (!$this->position) {
            if ($this->is_global) {
                $this->position = self::getHigherPosition(null) + 1;
            } else {
                $this->position = self::getHigherPosition($this->id_configurator) + 1;
            }
        }
        
        // Validate after setting defaults - but don't throw exceptions, let parent handle it
        $validation = $this->validateFields(false, true);
        if ($validation !== true && is_array($validation) && !empty($validation)) {
            // Log validation errors but don't throw exception - let parent::add() handle it
            PrestaShopLogger::addLog('Step validation errors: ' . implode(', ', $validation), 2);
            // Still call parent::add() - it will handle validation
        }
        
        return parent::add($autodate, $null_values);
    }
    
    public function update($null_values = false)
    {
        // Validate before updating
        $validation = $this->validateFields(false, true);
        if ($validation !== true && is_array($validation) && !empty($validation)) {
            $this->validateFields(true, false); // This will throw exception
        }
        
        return parent::update($null_values);
    }
}
