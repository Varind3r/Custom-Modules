<?php
/**
 * Step ObjectModel
 */

class Step extends ObjectModel
{
    public $id_step;
    public $id_configurator;
    public $position;
    public $type;
    public $title;
    public $description;
    public $required;
    public $depends_on_step;
    public $depends_on_value;
    public $show_condition;
    public $active;

    public static $definition = [
        'table' => 'configurator_step',
        'primary' => 'id_step',
        'fields' => [
            'id_configurator' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => true],
            'position' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'],
            'type' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'required' => true],
            'title' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'required' => true, 'size' => 255],
            'description' => ['type' => self::TYPE_HTML, 'validate' => 'isCleanHtml'],
            'required' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'depends_on_step' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'],
            'depends_on_value' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'show_condition' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName'],
            'active' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
        ],
    ];

    public function getOptions()
    {
        $sql = new DbQuery();
        $sql->select('id_option');
        $sql->from('configurator_option');
        $sql->where('id_step = ' . (int)$this->id);
        $sql->orderBy('position ASC');

        $result = Db::getInstance()->executeS($sql);
        $options = [];

        if ($result) {
            foreach ($result as $row) {
                $options[] = new Option($row['id_option']);
            }
        }

        return $options;
    }

    public static function getHigherPosition($id_configurator)
    {
        $sql = 'SELECT MAX(`position`) FROM `' . _DB_PREFIX_ . 'configurator_step` WHERE `id_configurator` = ' . (int)$id_configurator;
        return (int)Db::getInstance()->getValue($sql);
    }

    public function add($autodate = true, $null_values = false)
    {
        if (!$this->position) {
            $this->position = self::getHigherPosition($this->id_configurator) + 1;
        }
        return parent::add($autodate, $null_values);
    }
}
