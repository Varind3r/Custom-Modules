<?php
/**
 * Step ObjectModel
 */

class Step extends ObjectModel
{
    public $id_step;
    public $id_configurator;
    public $is_global;
    public $position;
    public $type;
    public $title;
    public $description;
    public $required;
    public $depends_on_step;
    public $depends_on_value;
    public $show_condition;
    public $active;

    public static $definition = [
        'table' => 'configurator_step',
        'primary' => 'id_step',
        'fields' => [
            'id_configurator' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => false],
            'is_global' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'position' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'],
            'type' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'required' => true],
            'title' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'required' => true, 'size' => 255],
            'description' => ['type' => self::TYPE_HTML, 'validate' => 'isCleanHtml'],
            'required' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'depends_on_step' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'],
            'depends_on_value' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'show_condition' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName'],
            'active' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
        ],
    ];

    public function getOptions()
    {
        $sql = new DbQuery();
        $sql->select('id_option');
        $sql->from('configurator_option');
        $sql->where('id_step = ' . (int)$this->id);
        $sql->orderBy('position ASC');

        $result = Db::getInstance()->executeS($sql);
        $options = [];

        if ($result) {
            foreach ($result as $row) {
                $options[] = new Option($row['id_option']);
            }
        }

        return $options;
    }

    public static function getHigherPosition($id_configurator = null)
    {
        if ($id_configurator) {
            // Get position from junction table for configurator-specific steps
            $sql = 'SELECT MAX(`position`) FROM `' . _DB_PREFIX_ . 'configurator_step_association` WHERE `id_configurator` = ' . (int)$id_configurator;
        } else {
            // Get position for global steps
            $sql = 'SELECT MAX(`position`) FROM `' . _DB_PREFIX_ . 'configurator_step` WHERE `is_global` = 1';
        }
        return (int)Db::getInstance()->getValue($sql);
    }

    /**
     * Get all global steps (steps that can be reused)
     */
    public static function getGlobalSteps()
    {
        $sql = new DbQuery();
        $sql->select('id_step');
        $sql->from('configurator_step');
        $sql->where('is_global = 1');
        $sql->orderBy('title ASC');

        $result = Db::getInstance()->executeS($sql);
        $steps = [];

        if ($result) {
            foreach ($result as $row) {
                $steps[] = new Step($row['id_step']);
            }
        }

        return $steps;
    }

    /**
     * Copy this step to a configurator
     */
    public function copyToConfigurator($id_configurator)
    {
        // Create association in junction table
        $position = self::getHigherPosition($id_configurator) + 1;
        
        $sql = 'INSERT INTO `' . _DB_PREFIX_ . 'configurator_step_association` 
                (`id_configurator`, `id_step`, `position`) 
                VALUES (' . (int)$id_configurator . ', ' . (int)$this->id . ', ' . (int)$position . ')
                ON DUPLICATE KEY UPDATE `position` = VALUES(`position`)';
        
        return Db::getInstance()->execute($sql);
    }

    /**
     * Duplicate step (create new step with same options)
     */
    public function duplicate($id_configurator = null)
    {
        $new_step = new Step();
        $new_step->id_configurator = $id_configurator;
        $new_step->is_global = $this->is_global;
        $new_step->type = $this->type;
        $new_step->title = $this->title . ' (Copy)';
        $new_step->description = $this->description;
        $new_step->required = $this->required;
        $new_step->depends_on_step = 0; // Reset dependencies
        $new_step->depends_on_value = '';
        $new_step->show_condition = $this->show_condition;
        $new_step->active = $this->active;
        
        if ($new_step->add()) {
            // Copy options
            $options = $this->getOptions();
            foreach ($options as $option) {
                $new_option = new Option();
                $new_option->id_step = $new_step->id;
                $new_option->position = $option->position;
                $new_option->option_type = $option->option_type;
                $new_option->label = $option->label;
                $new_option->description = $option->description;
                $new_option->image = $option->image;
                $new_option->value_key = $option->value_key . '_copy';
                $new_option->price_type = $option->price_type;
                $new_option->price_value = $option->price_value;
                $new_option->config = $option->config;
                $new_option->add();
            }
            
            // If copying to a configurator, create association
            if ($id_configurator) {
                $new_step->copyToConfigurator($id_configurator);
            }
            
            return $new_step;
        }
        
        return false;
    }

    public function add($autodate = true, $null_values = false)
    {
        if (!$this->position) {
            if ($this->is_global) {
                $this->position = self::getHigherPosition(null) + 1;
            } else {
                $this->position = self::getHigherPosition($this->id_configurator) + 1;
            }
        }
        return parent::add($autodate, $null_values);
    }
}
