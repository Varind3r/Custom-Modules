<?php
/**
 * Configurator ObjectModel
 */

class Configurator extends ObjectModel
{
    public $id_configurator;
    public $categories;
    public $id_product_base;
    public $name;
    public $active;

    public static $definition = [
        'table' => 'configurator',
        'primary' => 'id_configurator',
        'fields' => [
            'categories' => ['type' => self::TYPE_STRING, 'validate' => 'isString', 'required' => false],
            'id_product_base' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => true],
            'name' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'required' => true, 'size' => 255],
            'active' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
        ],
    ];

    public static function getByCategory($id_categories)
    {
        if (!is_array($id_categories)) {
            $id_categories = [(int)$id_categories];
        }

        $sql = new DbQuery();
        $sql->select('id_configurator, categories');
        $sql->from('configurator');
        $sql->where('active = 1');
        
        $results = Db::getInstance()->executeS($sql);
        if ($results) {
            foreach ($results as $row) {
                $config_cats = explode(',', $row['categories']);
                foreach ($id_categories as $id_cat) {
                    if (in_array($id_cat, $config_cats)) {
                        return new self($row['id_configurator']);
                    }
                }
            }
        }

        return false;
    }

    public static function getByProduct($id_product)
    {
        $sql = new DbQuery();
        $sql->select('id_configurator');
        $sql->from('configurator_product_association');
        $sql->where('id_product = ' . (int)$id_product);
        
        $id_configurator = Db::getInstance()->getValue($sql);
        
        if ($id_configurator) {
            $configurator = new self($id_configurator);
            if ($configurator->active) {
                return $configurator;
            }
        }
        
        return false;
    }

    public function getSteps($only_active = false)
    {
        // Get steps from junction table (supports both global and configurator-specific steps)
        $sql = new DbQuery();
        $sql->select('csa.id_step, csa.position');
        $sql->from('configurator_step_association', 'csa');
        $sql->innerJoin('configurator_step', 'cs', 'cs.id_step = csa.id_step');
        $sql->where('csa.id_configurator = ' . (int)$this->id);
        if ($only_active) {
            $sql->where('cs.active = 1');
        }
        $sql->orderBy('csa.position ASC');

        $result = Db::getInstance()->executeS($sql);
        $steps = [];

        if ($result && is_array($result)) {
            foreach ($result as $row) {
                if (isset($row['id_step']) && $row['id_step'] > 0) {
                    $step = new Step((int)$row['id_step']);
                    if (Validate::isLoadedObject($step)) {
                        $steps[] = $step;
                    }
                }
            }
        }

        return $steps;
    }

    /**
     * Add a step to this configurator (from global library or duplicate)
     */
    public function addStep($id_step)
    {
        $step = new Step($id_step);
        if (Validate::isLoadedObject($step)) {
            return $step->copyToConfigurator($this->id);
        }
        return false;
    }

    /**
     * Remove a step from this configurator (doesn't delete the step itself if it's global)
     */
    public function removeStep($id_step)
    {
        $sql = 'DELETE FROM `' . _DB_PREFIX_ . 'configurator_step_association` 
                WHERE `id_configurator` = ' . (int)$this->id . ' 
                AND `id_step` = ' . (int)$id_step;
        return Db::getInstance()->execute($sql);
    }

    /**
     * Get associated product IDs for this configurator
     */
    public function getAssociatedProductIds()
    {
        $sql = new DbQuery();
        $sql->select('id_product');
        $sql->from('configurator_product_association');
        $sql->where('id_configurator = ' . (int)$this->id);

        $result = Db::getInstance()->executeS($sql);
        $ids = [];

        if ($result) {
            foreach ($result as $row) {
                $ids[] = (int)$row['id_product'];
            }
        }

        return $ids;
    }

    /**
     * Set associated products for this configurator
     */
    public function setAssociatedProducts($id_products)
    {
        // Delete existing associations
        Db::getInstance()->delete('configurator_product_association', 'id_configurator = ' . (int)$this->id);

        if (!is_array($id_products) || empty($id_products)) {
            return true;
        }

        // Insert new associations
        foreach ($id_products as $id_product) {
            $data = [
                'id_configurator' => (int)$this->id,
                'id_product' => (int)$id_product
            ];
            Db::getInstance()->insert('configurator_product_association', $data);
        }

        return true;
    }

    /**
     * Validate configurator data before saving
     */
    public function validateFields($die = true, $error_return = false)
    {
        $errors = [];
        
        // Validate required fields
        if (empty($this->name)) {
            $errors[] = 'Configurator name is required.';
        } elseif (strlen($this->name) > 255) {
            $errors[] = 'Configurator name cannot exceed 255 characters.';
        }
        
        // Validate base product
        if (empty($this->id_product_base) || $this->id_product_base <= 0) {
            $errors[] = 'Base product is required.';
        } else {
            $product = new Product($this->id_product_base);
            if (!Validate::isLoadedObject($product)) {
                $errors[] = 'Invalid base product selected.';
            }
        }
        
        if (!empty($errors)) {
            if ($error_return) {
                return $errors;
            }
            if ($die) {
                throw new PrestaShopException(implode(' ', $errors));
            }
            return false;
        }
        
        return parent::validateFields($die, $error_return);
    }

    public function add($autodate = true, $null_values = false)
    {
        // Validate before adding
        $validation = $this->validateFields(false, true);
        if ($validation !== true && is_array($validation) && !empty($validation)) {
            $this->validateFields(true, false); // This will throw exception
        }
        
        // Set defaults
        if (!isset($this->active)) {
            $this->active = 1;
        }
        if (empty($this->categories)) {
            $this->categories = '';
        }
        
        return parent::add($autodate, $null_values);
    }
    
    public function update($null_values = false)
    {
        // Validate before updating
        $validation = $this->validateFields(false, true);
        if ($validation !== true && is_array($validation) && !empty($validation)) {
            $this->validateFields(true, false); // This will throw exception
        }
        
        return parent::update($null_values);
    }
}
