<?php
/**
 * RAL Color ObjectModel
 */

class RalColor extends ObjectModel
{
    public $id_ral_color;
    public $id_ral_category;
    public $ral_code;
    public $name;
    public $hex;
    public $position;
    public $active;
    public $price_impact;

    public static $definition = [
        'table' => 'ps_configurator_ral_color',
        'primary' => 'id_ral_color',
        'fields' => [
            'id_ral_category' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => true],
            'ral_code' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'required' => true, 'size' => 10],
            'name' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'required' => true, 'size' => 255],
            'hex' => ['type' => self::TYPE_STRING, 'validate' => 'isColor', 'required' => true, 'size' => 7],
            'position' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'],
            'active' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'price_impact' => ['type' => self::TYPE_FLOAT, 'validate' => 'isPrice'],
        ],
    ];

    public static function getColorsByCategory($id_category, $active = true)
    {
        $query = new DbQuery();
        $query->select('*');
        $query->from('ps_configurator_ral_color');
        $query->where('id_ral_category = ' . (int)$id_category);
        if ($active) {
            $query->where('active = 1');
        }
        $query->orderBy('position ASC');

        $result = Db::getInstance()->executeS($query);
        $colors = [];

        if ($result) {
            foreach ($result as $row) {
                $colors[] = new RalColor($row['id_ral_color']);
            }
        }

        return $colors;
    }

    public static function getHigherPosition($id_category)
    {
        $sql = 'SELECT MAX(`position`) FROM `' . _DB_PREFIX_ . 'ps_configurator_ral_color` WHERE `id_ral_category` = ' . (int)$id_category;
        return (int)Db::getInstance()->getValue($sql);
    }

    public function add($autodate = true, $null_values = false)
    {
        if (!$this->position) {
            $this->position = self::getHigherPosition($this->id_ral_category) + 1;
        }
        return parent::add($autodate, $null_values);
    }
}

