<?php
/**
 * RAL Color ObjectModel
 */

class RalColor extends ObjectModel
{
    public $id_ral_color;
    public $id_ral_category;
    public $ral_code;
    public $name;
    public $hex;
    public $position;
    public $active;
    public $price_impact;

    public static $definition = [
        'table' => 'configurator_ral_color',
        'primary' => 'id_ral_color',
        'fields' => [
            'id_ral_category' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => true],
            'ral_code' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'required' => true, 'size' => 10],
            'name' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'required' => true, 'size' => 255],
            'hex' => ['type' => self::TYPE_STRING, 'validate' => 'isColor', 'required' => true, 'size' => 7],
            'position' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'],
            'active' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'price_impact' => ['type' => self::TYPE_FLOAT, 'validate' => 'isPrice'],
        ],
    ];

    public static function getColorsByCategory($id_category, $active = true)
    {
        $query = new DbQuery();
        $query->select('*');
        $query->from('configurator_ral_color', 'col');
        $query->where('col.id_ral_category = ' . (int)$id_category);
        if ($active) {
            $query->where('col.active = 1');
        }
        $query->orderBy('col.position ASC');

        $result = Db::getInstance()->executeS($query);
        $colors = [];

        if ($result && is_array($result)) {
            foreach ($result as $row) {
                $color = new RalColor();
                $color->id = (int)$row['id_ral_color'];
                $color->id_ral_color = (int)$row['id_ral_color'];
                $color->id_ral_category = (int)$row['id_ral_category'];
                $color->ral_code = $row['ral_code'];
                $color->name = $row['name'];
                $color->hex = $row['hex'];
                $color->position = (int)$row['position'];
                $color->active = (int)$row['active'];
                $color->price_impact = (float)$row['price_impact'];
                $colors[] = $color;
            }
        }

        return $colors;
    }

    public static function getHigherPosition($id_category)
    {
        $sql = 'SELECT MAX(`position`) FROM `' . _DB_PREFIX_ . 'configurator_ral_color` WHERE `id_ral_category` = ' . (int)$id_category;
        return (int)Db::getInstance()->getValue($sql);
    }

    public function add($autodate = true, $null_values = false)
    {
        if (!$this->position) {
            $this->position = self::getHigherPosition($this->id_ral_category) + 1;
        }
        return parent::add($autodate, $null_values);
    }
}

