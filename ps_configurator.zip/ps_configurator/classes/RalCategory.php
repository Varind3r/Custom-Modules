<?php
/**
 * RAL Category ObjectModel
 */

class RalCategory extends ObjectModel
{
    public $id_ral_category;
    public $name;
    public $position;
    public $active;
    public $price_impact;

    public static $definition = [
        'table' => 'configurator_ral_category',
        'primary' => 'id_ral_category',
        'fields' => [
            'name' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'required' => true, 'size' => 255],
            'position' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'],
            'active' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'price_impact' => ['type' => self::TYPE_FLOAT, 'validate' => 'isPrice'],
        ],
    ];

    public static function getAllCategories($active = true)
    {
        $query = new DbQuery();
        $query->select('*');
        $query->from('configurator_ral_category', 'c');
        if ($active) {
            $query->where('c.active = 1');
        }
        $query->orderBy('c.position ASC');

        $result = Db::getInstance()->executeS($query);
        $categories = [];

        if ($result && is_array($result)) {
            foreach ($result as $row) {
                $category = new RalCategory();
                $category->id = (int)$row['id_ral_category'];
                $category->id_ral_category = (int)$row['id_ral_category'];
                $category->name = $row['name'];
                $category->position = (int)$row['position'];
                $category->active = (int)$row['active'];
                $category->price_impact = (float)$row['price_impact'];
                $categories[] = $category;
            }
        }

        return $categories;
    }

    public function getColors($active = true)
    {
        return RalColor::getColorsByCategory($this->id_ral_category, $active);
    }
}

