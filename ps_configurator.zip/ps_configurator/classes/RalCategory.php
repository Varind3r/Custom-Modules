<?php
/**
 * RAL Category ObjectModel
 */

class RalCategory extends ObjectModel
{
    public $id_ral_category;
    public $name;
    public $position;
    public $active;
    public $price_impact;

    public static $definition = [
        'table' => 'ps_configurator_ral_category',
        'primary' => 'id_ral_category',
        'fields' => [
            'name' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'required' => true, 'size' => 255],
            'position' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'],
            'active' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'price_impact' => ['type' => self::TYPE_FLOAT, 'validate' => 'isPrice'],
        ],
    ];

    public static function getAllCategories($active = true)
    {
        $query = new DbQuery();
        $query->select('*');
        $query->from('ps_configurator_ral_category');
        if ($active) {
            $query->where('active = 1');
        }
        $query->orderBy('position ASC');

        $result = Db::getInstance()->executeS($query);
        $categories = [];

        if ($result) {
            foreach ($result as $row) {
                $categories[] = new RalCategory($row['id_ral_category']);
            }
        }

        return $categories;
    }

    public function getColors($active = true)
    {
        return RalColor::getColorsByCategory($this->id_ral_category, $active);
    }
}

