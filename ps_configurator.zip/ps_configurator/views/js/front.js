document.addEventListener("DOMContentLoaded", function () {
  const configContainer = document.getElementById("ps-configurator");
  if (!configContainer) return;

  const ajaxUrl = configContainer.dataset.ajaxUrl;
  const currentConfiguratorId = parseInt(configContainer.dataset.configuratorId) || 0;
  const advancedRulesRaw = configContainer.dataset.advancedRules || "[]";
  let advancedRules = [];
  try {
    advancedRules = JSON.parse(advancedRulesRaw);
    // Filter rules to only include rules for the current configurator
    advancedRules = advancedRules.filter((rule) => {
      return parseInt(rule.id_configurator) === currentConfiguratorId;
    });
  } catch (e) {
    console.error("Error parsing advanced rules:", e);
  }

  const steps = configContainer.querySelectorAll(".config-step");
  
  // Get all step IDs for the current configurator to validate rule references
  const currentConfiguratorStepIds = Array.from(steps).map(step => parseInt(step.dataset.id));
  
  const prevBtn = document.getElementById("prev-step");
  const nextBtn = document.getElementById("next-step");
  const cartBtn = document.getElementById("config-add-to-cart"); // Might be missing now
  // Progress bar removed per user request
  const progressBar = null;

  // Find price display: sidebar or main product price
  let priceDisplay = document.getElementById("live-config-price");
  if (!priceDisplay) {
    // Fallback to standard PrestaShop 1.7 product price selectors
    priceDisplay =
      document.querySelector('.current-price span[itemprop="price"]') ||
      document.querySelector(".current-price span") ||
      document.querySelector(".product-price");
  }

  const summaryList = configContainer.querySelector(".summary-list");
  const emptyMsg = configContainer.querySelector(".empty-msg");

  let currentStepIndex = 0;
  let state = {
    selections: {}, // {stepId: {optionId: {label, valueKey}}}
    dimensions: {}, // {key: {value: X, label: Y}}
    totalPrice: 0,
  };

  function updateUI() {
    // Evaluate Visibility FIRST (must be called before accessing currentStep)
    // This ensures steps are properly shown/hidden based on current selections
    evaluateStepVisibility();
    
    // Update step menu items visibility to match step visibility
    configContainer.querySelectorAll(".step-menu-item").forEach((menuItem) => {
      const stepId = menuItem.dataset.stepId;
      const step = Array.from(steps).find((s) => s.dataset.id === stepId);
      if (step) {
        if (step.dataset.hidden === "true") {
          menuItem.style.display = "none";
        } else {
          menuItem.style.display = "";
        }
      }
    });

    // Ensure currentStepIndex is valid and points to a visible step
    if (
      currentStepIndex >= steps.length ||
      (steps[currentStepIndex] &&
        steps[currentStepIndex].dataset.hidden === "true")
    ) {
      // Find first visible step
      for (let i = 0; i < steps.length; i++) {
        if (steps[i].dataset.hidden !== "true") {
          currentStepIndex = i;
          break;
        }
      }
    }

    const currentStep = steps[currentStepIndex];
    if (!currentStep) {
      console.error("No visible step found");
      return;
    }
    const currentStepId = currentStep.dataset.id;

    steps.forEach((step, index) => {
      // Only show step if it's the current step AND not hidden by conditional logic
      if (index === currentStepIndex && step.dataset.hidden !== "true") {
        step.classList.remove("d-none");
      } else {
        step.classList.add("d-none");
      }
    });

    // Update Sidebar
    configContainer.querySelectorAll(".step-menu-item").forEach((item) => {
      if (item.dataset.stepId === currentStepId) {
        item.classList.add("active");
      } else {
        item.classList.remove("active");
      }

      // Hide menu item if step is hidden
      const targetStep = Array.from(steps).find(
        (s) => s.dataset.id === item.dataset.stepId,
      );
      if (targetStep && targetStep.dataset.hidden === "true") {
        item.classList.add("d-none");
      } else {
        item.classList.remove("d-none");
      }
    });

    // Progress bar removed per user request

    // Update buttons
    if (currentStepIndex === 0 || !hasVisiblePrevStep()) {
      if (prevBtn) prevBtn.classList.add("d-none");
    } else {
      if (prevBtn) prevBtn.classList.remove("d-none");
    }

    if (!hasVisibleNextStep()) {
      if (nextBtn) nextBtn.classList.add("d-none");
      if (cartBtn) cartBtn.classList.remove("d-none");
    } else {
      if (nextBtn) nextBtn.classList.remove("d-none");
      if (cartBtn) cartBtn.classList.add("d-none");
    }

    renderSummary();
    calculatePrice();
    applyOptionFiltering();
  }

  // Sidebar navigation click
  configContainer.querySelectorAll(".step-menu-item").forEach((item) => {
    item.addEventListener("click", () => {
      const stepId = item.dataset.stepId;
      const targetIndex = Array.from(steps).findIndex(
        (s) => s.dataset.id === stepId,
      );
      if (targetIndex !== -1 && steps[targetIndex].dataset.hidden !== "true") {
        currentStepIndex = targetIndex;
        updateUI();
      }
    });
  });

  function evaluateStepVisibility() {
    steps.forEach((step) => {
      const stepId = step.dataset.id;
      const dependsOnStepId = step.dataset.dependsOn;
      
      // --- 1. First check Simple Dependencies (from dataset) ---
      let isVisibleBySimple = true;

      // If dependency exists on Step fields
      if (
        dependsOnStepId &&
        dependsOnStepId != "0" &&
        dependsOnStepId !== "0" &&
        dependsOnStepId !== ""
      ) {
      const triggerValuesStr = step.dataset.triggerValues || "";
      const triggerValues = triggerValuesStr
        .split(",")
        .map((v) => v.trim())
        .filter((v) => v !== "");
      
        if (triggerValues.length > 0) {
          const condition = (step.dataset.condition || "ANY").toUpperCase();
          const prevStepSelections = getSelectionsForStep(dependsOnStepId);
          const normalizedSelected = getNormalizedValues(prevStepSelections);
          const normalizedTriggers = triggerValues.map((v) =>
            v.toLowerCase().trim(),
          );

          isVisibleBySimple = checkCondition(
            condition,
            normalizedTriggers,
            normalizedSelected,
          );
        }
      }

      // --- 2. Check Advanced Rules (from Configurator Rules Admin) ---
      let isVisibleByAdvanced = true;
      const relevantAdvancedRules = advancedRules.filter(
        (r) => parseInt(r.id_step_target) === parseInt(stepId),
      );

      if (relevantAdvancedRules.length > 0) {
        // If there are advanced rules, they take precedence or act as additional filters
        // Here we'll treat them as: if ANY advanced rule for this step is met, it's visible
        isVisibleByAdvanced = relevantAdvancedRules.some((rule) => {
          let ruleData = {};
          try {
            ruleData =
              typeof rule.rule_data === "string"
                ? JSON.parse(rule.rule_data)
                : rule.rule_data;
          } catch (e) {
            return true;
          }

          if (!ruleData || !ruleData.rules || ruleData.rules.length === 0)
            return true;

          const results = ruleData.rules.map((subRule) => {
            // Verify that the referenced step belongs to the current configurator
            if (!currentConfiguratorStepIds.includes(parseInt(subRule.step_id))) {
              // Step doesn't belong to this configurator, skip this rule
              return false;
            }
            
            const stepSels = getSelectionsForStep(subRule.step_id);
            const selectedKeys = Object.values(stepSels).map(
              (s) => s.valueKey || "",
            );
            const normalizedSelected = selectedKeys.map((v) =>
              v.toLowerCase().trim(),
            );
            const normalizedTriggers = (subRule.values || []).map((v) =>
              v.toLowerCase().trim(),
            );

            const match = normalizedTriggers.some((t) =>
              normalizedSelected.includes(t),
            );
            return subRule.op === "NOT_IN" ? !match : match;
          });

          if (ruleData.op === "OR") {
            return results.some((r) => r);
          } else {
            return results.every((r) => r);
          }
        });
      }

      // Final Visibility
      const isVisible = isVisibleBySimple && isVisibleByAdvanced;

      // Update visibility
      if (!isVisible) {
        step.dataset.hidden = "true";
        step.classList.add("d-none");
      } else {
        step.dataset.hidden = "false";
        step.classList.remove("d-none");
      }
    });
  }

  // Helper to get selections for a step ID (supports both ID and Position)
  function getSelectionsForStep(stepIdOrPos) {
    if (!stepIdOrPos || stepIdOrPos === "0" || stepIdOrPos === 0) {
      return {};
    }
    
    const id = parseInt(stepIdOrPos);
    if (isNaN(id)) {
      return {};
    }
    
    // First, try to find the step element to get its actual ID
    let actualStepId = null;
    steps.forEach((s) => {
      const stepId = parseInt(s.dataset.id);
      const stepPos = Array.from(steps).indexOf(s) + 1;
      // Match by actual step ID or by position
      if (stepId === id || stepPos === id) {
        actualStepId = String(s.dataset.id);
      }
    });
    
    // If we found a step, try to get selections by its ID
    if (actualStepId) {
      if (state.selections[actualStepId]) {
        return state.selections[actualStepId];
      }
      // Also try numeric version
      if (state.selections[parseInt(actualStepId)]) {
        return state.selections[parseInt(actualStepId)];
      }
    }
    
    // Fallback: try direct lookup by the provided ID (string and numeric)
    if (state.selections[id]) {
      return state.selections[id];
    }
    if (state.selections[String(id)]) {
      return state.selections[String(id)];
    }
    
    return {};
  }

  function getNormalizedValues(selections) {
    const labels = Object.values(selections).map((s) => s.label || "");
    const keys = Object.values(selections).map((s) => s.valueKey || "");

    // Add base labels without RAL codes (e.g., "Custom RAL (RAL 4003)" -> "Custom RAL")
    const cleanedLabels = labels.map((label) => {
      return label
        .replace(/\s*\(RAL\s*\d+\)/gi, "")
        .replace(/\s*\(\d+\)/g, "")
        .trim();
    });

    return [...labels, ...keys, ...cleanedLabels]
      .filter((v) => v !== "")
      .map((v) => v.toLowerCase().trim());
  }

  function checkCondition(condition, triggers, selected) {
    if (condition === "ANY") {
      return triggers.some((t) =>
        selected.some((s) => s === t || s.includes(t) || t.includes(s)),
      );
    } else if (condition === "ALL") {
      return triggers.every((t) =>
        selected.some((s) => s === t || s.includes(t) || t.includes(s)),
      );
    } else if (condition === "NONE") {
      return !triggers.some((t) =>
        selected.some((s) => s === t || s.includes(t) || t.includes(s)),
      );
      }
    return true;
  }

  function hasVisibleNextStep() {
    for (let i = currentStepIndex + 1; i < steps.length; i++) {
      if (steps[i].dataset.hidden !== "true") return true;
    }
    return false;
  }

  function hasVisiblePrevStep() {
    for (let i = currentStepIndex - 1; i >= 0; i--) {
      if (steps[i].dataset.hidden !== "true") return true;
    }
    return false;
  }

  function applyOptionFiltering() {
    // Hide/Show specific options based on selected IDs (show_options/hide_options logic)
    const allSelectedIds = [];
    Object.values(state.selections).forEach((sel) => {
      allSelectedIds.push(...Object.keys(sel));
    });

    configContainer.querySelectorAll(".option-wrapper").forEach((wrapper) => {
      const showOnlyIfSelected = wrapper.dataset.showOptions
        ? wrapper.dataset.showOptions.split(",")
        : [];
      const hideIfSelected = wrapper.dataset.hideOptions
        ? wrapper.dataset.hideOptions.split(",")
        : [];

      let hidden = false;
      if (showOnlyIfSelected.length > 0) {
        hidden = !showOnlyIfSelected.some((id) => allSelectedIds.includes(id));
      }
      if (
        hideIfSelected.length > 0 &&
        hideIfSelected.some((id) => allSelectedIds.includes(id))
      ) {
        hidden = true;
      }

      if (hidden) {
        wrapper.classList.add("d-none");
      } else {
        wrapper.classList.remove("d-none");
      }
    });
  }

  function renderSummary() {
    summaryList.innerHTML = "";
    let hasSelections = false;

    Object.values(state.selections).forEach((stepSelections) => {
      Object.values(stepSelections).forEach((sel) => {
        hasSelections = true;
        const li = document.createElement("li");
        li.className = "summary-item";

        let priceHtml = "";
        if (sel.price > 0) {
          priceHtml = `<span class="badge badge-info ml-2">+${sel.price}</span>`;
        }

        // Check if this is a RAL color selection (has hex property)
        let colorSwatch = "";
        if (sel.hex) {
          colorSwatch = `<span class="ral-swatch-summary" style="display: inline-block; width: 20px; height: 20px; background-color: ${sel.hex}; border: 1px solid #ddd; border-radius: 3px; margin-right: 8px; vertical-align: middle;"></span>`;
        }

        li.innerHTML = `
                    <i class="material-icons">${sel.hex ? 'palette' : 'check_circle'}</i> 
                    <div class="option-info">
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="font-weight-bold">${colorSwatch}${sel.label}</span>
                            ${priceHtml}
                        </div>
                    </div>
                `;
        summaryList.appendChild(li);
      });
    });

    Object.values(state.dimensions).forEach((dim) => {
      if (dim.value > 0) {
        hasSelections = true;

        let priceHtml = "";
        let calculatedPrice = 0;

        if (dim.priceType === "fixed") {
          calculatedPrice = dim.priceValue;
        } else if (dim.priceType === "per_unit") {
          calculatedPrice = dim.value * dim.priceValue;
        }

        if (calculatedPrice > 0) {
          const displayPrice = parseFloat(calculatedPrice.toFixed(2));
          priceHtml = `<span class="badge badge-info ml-2">+${displayPrice}</span>`;
        } else if (dim.priceType === "percentage" && dim.priceValue > 0) {
          priceHtml = `<span class="badge badge-info ml-2">+${dim.priceValue}%</span>`;
        }

        const li = document.createElement("li");
        li.className = "summary-item";
        li.innerHTML = `
                    <i class="material-icons">straighten</i> 
                    <div class="option-info">
                        <div class="d-flex justify-content-between align-items-center">
                            <span><span class="font-weight-bold">${dim.label}</span>: ${dim.rawValue}${dim.unit}</span>
                            ${priceHtml}
                        </div>
                    </div>
                `;
        summaryList.appendChild(li);
      }
    });

    if (hasSelections) {
      emptyMsg.classList.add("d-none");
    } else {
      emptyMsg.classList.remove("d-none");
    }
  }

  // Helper function to get product ID from multiple sources
  function getProductId() {
    let id = 0;

    // 1. PrestaShop page object (PS 1.7.6+)
    if (
      typeof prestashop !== "undefined" &&
      prestashop.page &&
      prestashop.page.id_product
    ) {
      id = prestashop.page.id_product;
    }

    // 2. Container data attribute
    if (!id && configContainer.closest(".product-container")) {
      id = configContainer.closest(".product-container").dataset.idProduct;
    }

    // 3. URL parameter
    if (!id) {
      const urlParams = new URLSearchParams(window.location.search);
      id = urlParams.get("id_product");
    }

    // 4. Product input field
    if (!id) {
      const input = document.querySelector('input[name="id_product"]');
      if (input) {
        id = input.value;
      }
    }

    // 5. Add to cart button data attribute
    if (!id) {
      const addBtn = document.querySelector(
        '.product-add-to-cart button[data-button-action="add-to-cart"]',
      );
      if (addBtn) {
        id = addBtn.getAttribute("data-id-product");
      }
    }

    return parseInt(id) || 0;
  }

  function calculatePrice() {
    const selectedOptionIds = [];
    // Only include selections that were actually made by the user (not auto-selected)
    Object.keys(state.selections).forEach((stepId) => {
      const stepSelections = state.selections[stepId];
      if (stepSelections && Object.keys(stepSelections).length > 0) {
        selectedOptionIds.push(...Object.keys(stepSelections));
      }
    });

    // Send full dimension data including price info
    const dimValues = {};
    Object.keys(state.dimensions).forEach((key) => {
      const dim = state.dimensions[key];
      dimValues[key] = {
        value: dim.value,
        rawValue: dim.rawValue,
        label: dim.label,
        unit: dim.unit,
        priceType: dim.priceType || "fixed",
        priceValue: dim.priceValue || 0,
      };
    });

    const formData = new FormData();
    formData.append("action", "calculate_price");
    const productId = getProductId();
    formData.append("id_product", productId);
    formData.append("selections", JSON.stringify(selectedOptionIds));
    formData.append("dimensions", JSON.stringify(dimValues));

    if (!productId) {
      console.warn("Product ID not found for price calculation");
      return;
    }

    fetch(ajaxUrl, {
      method: "POST",
      body: new URLSearchParams(formData),
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          // Update configurator specific total
          const configPriceDisplay =
            document.getElementById("live-config-price");
          if (configPriceDisplay) {
            configPriceDisplay.textContent = data.price_formatted;
            configPriceDisplay.classList.add("updated");
            setTimeout(
              () => configPriceDisplay.classList.remove("updated"),
              500,
            );
          }

          // Also try to update the main product price display if different
          if (priceDisplay && priceDisplay !== configPriceDisplay) {
            priceDisplay.textContent = data.price_formatted;
          }

          // Trigger custom event for other modules
          const priceEvent = new CustomEvent("configurator:priceUpdated", {
            detail: data,
          });
          document.dispatchEvent(priceEvent);
        }
      })
      .catch((err) => console.error("Price calculation error:", err));
  }

  // Step Navigation
  if (nextBtn) {
    nextBtn.addEventListener("click", () => {
      let nextIndex = -1;
      for (let i = currentStepIndex + 1; i < steps.length; i++) {
        if (steps[i].dataset.hidden !== "true") {
          nextIndex = i;
          break;
        }
      }
      if (nextIndex !== -1) {
        currentStepIndex = nextIndex;
        updateUI();
      }
    });
  }

  if (prevBtn) {
    prevBtn.addEventListener("click", () => {
      let prevIndex = -1;
      for (let i = currentStepIndex - 1; i >= 0; i--) {
        if (steps[i].dataset.hidden !== "true") {
          prevIndex = i;
          break;
        }
      }
      if (prevIndex !== -1) {
        currentStepIndex = prevIndex;
        updateUI();
      }
    });
  }

  // Option Selection
  // Option Selection
  configContainer.addEventListener("click", (e) => {
    // Don't process if clicking on RAL swatches or other nested elements
    if (e.target.closest(".ral-swatch-item") || e.target.closest(".ral-category-tab")) {
      return;
    }
    
    const optionCard = e.target.closest(".option-card");
    if (optionCard) {
      try {
        const step = optionCard.closest(".config-step");
        if (!step) {
          console.warn("Option card clicked but no step found");
          return;
        }
        
        const stepId = step.dataset.id;
        const optionId = optionCard.dataset.optionId;
        const label = optionCard.dataset.label;
        const valueKey = optionCard.dataset.valueKey;
        const price = parseFloat(optionCard.dataset.price) || 0;

        if (!stepId || !optionId) {
          console.warn("Missing stepId or optionId", { stepId, optionId });
          return;
        }

        // Handle RAL Interface Visibility
        const ralInterface = step.querySelector(".ral-interface-container");

      // FORCE SINGLE SELECT
      step
        .querySelectorAll(".option-card")
        .forEach((c) => c.classList.remove("selected"));
      state.selections[stepId] = {};

      if (optionCard.dataset.type === "ral_system") {
        // It is a RAL option - check conditional logic from step, not RAL interface
        const dependsOn = step.dataset.dependsOn;
        const triggerValues = step.dataset.triggerValues;
        const condition = step.dataset.condition || "ANY";

        let shouldShow = true;
        if (
          dependsOn &&
          dependsOn != "0" &&
          dependsOn !== "0" &&
          triggerValues &&
          triggerValues.trim() !== ""
        ) {
          const triggers = triggerValues
            .split(",")
            .map((v) => v.trim())
            .filter((v) => v !== "");

          // Find the dependent step
          let dependsOnStep = null;
          const dependsOnStepIdNum = parseInt(dependsOn);
          steps.forEach((s) => {
            if (parseInt(s.dataset.id) === dependsOnStepIdNum) {
              dependsOnStep = s;
            }
          });

          const prevStepSelections = dependsOnStep
            ? state.selections[dependsOnStep.dataset.id] ||
              state.selections[dependsOn] ||
              state.selections[dependsOnStepIdNum] ||
              {}
            : {};

          const selectedLabels = Object.values(prevStepSelections).map(
            (s) => s.label || "",
          );
          const selectedKeys = Object.values(prevStepSelections).map(
            (s) => s.valueKey || "",
          );

          // Also check base labels without RAL codes
          const allSelected = [
            ...selectedLabels,
            ...selectedKeys,
            ...selectedLabels.map((label) => {
              return label
                .replace(/\s*\(RAL\s*\d+\)/gi, "")
                .replace(/\s*\(\d+\)/g, "")
                .trim();
            }),
          ].filter((v) => v !== "");

          const normalizedTriggers = triggers.map((v) =>
            v.toLowerCase().trim(),
          );
          const normalizedSelected = allSelected.map((v) =>
            v.toLowerCase().trim(),
          );

          if (condition === "ANY") {
            shouldShow = normalizedTriggers.some((trigger) =>
              normalizedSelected.some(
                (selected) =>
                  selected === trigger ||
                  selected.includes(trigger) ||
                  trigger.includes(selected),
              ),
            );
          } else if (condition === "ALL") {
            shouldShow = normalizedTriggers.every((trigger) =>
              normalizedSelected.some(
                (selected) =>
                  selected === trigger ||
                  selected.includes(trigger) ||
                  trigger.includes(selected),
              ),
            );
          } else if (condition === "NONE") {
            shouldShow = !normalizedTriggers.some((trigger) =>
              normalizedSelected.some(
                (selected) =>
                  selected === trigger ||
                  selected.includes(trigger) ||
                  trigger.includes(selected),
              ),
            );
          }
        }

        if (shouldShow && ralInterface) {
          console.log('Showing RAL interface for option:', optionId);
          ralInterface.classList.remove("d-none");
          // Initialize grid if empty
          const grid = ralInterface.querySelector(".ral-colors-grid");
          const cats = ralInterface.querySelector(".ral-categories");
          console.log('RAL interface elements:', {
            hasGrid: !!grid,
            hasCats: !!cats,
            gridInnerHTML: grid ? grid.innerHTML.substring(0, 100) : 'null'
          });
          
          if (grid) {
            const gridContent = grid.innerHTML.trim();
            // Check if grid is empty or only contains HTML comments
            const isEmpty = gridContent === "" || gridContent === "<!-- Colors Grid -->";
            
            if (isEmpty) {
              console.log('Initializing RAL picker (grid is empty)');
              initializeRalPicker(ralInterface);
            } else {
              console.log('RAL picker already initialized, grid has content:', gridContent.substring(0, 100));
              // Update selected colors display if there are already selected colors
              setTimeout(() => {
                updateSelectedColorsDisplay(ralInterface, stepId, optionId);
              }, 100);
            }
          } else {
            console.error('Grid container not found in RAL interface');
          }
          // Scroll to it for better UX
          setTimeout(
            () =>
              ralInterface.scrollIntoView({
                behavior: "smooth",
                block: "start",
              }),
            100,
          );
        } else if (ralInterface) {
          console.log('Hiding RAL interface (shouldShow:', shouldShow, ')');
          ralInterface.classList.add("d-none");
        } else {
          console.warn('RAL interface not found for step:', stepId);
        }

        state.selections[stepId][optionId] = {
          label: label,
          valueKey: valueKey,
          price: price,
        };
        
        // Update selected colors display after adding the option to state
        if (shouldShow && ralInterface) {
          setTimeout(() => {
            updateSelectedColorsDisplay(ralInterface, stepId, optionId);
          }, 100);
        }
      } else {
        // Standard option
        if (ralInterface) ralInterface.classList.add("d-none");
        state.selections[stepId][optionId] = {
          label: label,
          valueKey: valueKey,
          price: price,
        };
      }

        optionCard.classList.add("selected");
        
        // CRITICAL: Re-evaluate step visibility after selection changes
        evaluateStepVisibility();
        
        updateUI();
      } catch (error) {
        console.error("Error processing option card selection:", error);
      }
    }
  });

  // Helper function to validate dimension/slider value
  function validateDimensionValue(input, config) {
    const min = parseFloat(config.min) || 0;
    const max = parseFloat(config.max) || 10000;
    const step = parseFloat(config.step) || 1;
    const value = parseFloat(input.value);
    
    const errors = [];
    
    // Check if value is numeric
    if (isNaN(value) || input.value === '' || input.value === null) {
      errors.push('Value must be a number');
    }
    
    // Check if value is within range
    if (!isNaN(value)) {
      if (value < min) {
        errors.push(`Value must be at least ${min}`);
      }
      if (value > max) {
        errors.push(`Value must not exceed ${max}`);
      }
      
      // Check if value matches step increment
      if (step > 0) {
        const remainder = (value - min) % step;
        if (Math.abs(remainder) > 0.0001 && Math.abs(remainder - step) > 0.0001) {
          errors.push(`Value must be in increments of ${step}`);
        }
      }
    }
    
    return {
      isValid: errors.length === 0,
      errors: errors,
      value: isNaN(value) ? null : value
    };
  }

  // Helper function to show validation error
  function showDimensionError(wrapper, message) {
    // Remove existing error message
    const existingError = wrapper.querySelector('.dimension-error');
    if (existingError) {
      existingError.remove();
    }
    
    // Remove error styling
    const input = wrapper.querySelector('.dimension-input, .range-slider-input');
    if (input) {
      input.classList.remove('is-invalid');
    }
    wrapper.classList.remove('has-error');
    
    if (message) {
      // Add error styling
      if (input) {
        input.classList.add('is-invalid');
      }
      wrapper.classList.add('has-error');
      
      // Create error message element
      const errorDiv = document.createElement('div');
      errorDiv.className = 'dimension-error text-danger small mt-1';
      errorDiv.style.color = '#dc3545';
      errorDiv.textContent = message;
      wrapper.appendChild(errorDiv);
    }
  }

  // Helper function to handle dimension input changes (used by both input and change events)
  function handleDimensionChange(input) {
    if (
      !input.classList.contains("dimension-input") &&
      !input.classList.contains("range-slider-input")
    ) {
      return;
    }

    const key = input.dataset.key;
    const label = input.dataset.label;
    
    if (!key) {
      console.warn("Dimension input missing data-key attribute");
      return;
    }
    
    // Get config from parent wrapper or dataset
    const wrapper = input.closest(".dimension-wrapper");
    if (!wrapper) {
      console.warn("Dimension input missing wrapper element");
      return;
    }

    let config = {};
    const configData = wrapper.dataset.config;
    if (configData) {
      try {
        config = JSON.parse(configData);
      } catch (e) {
        console.warn("Failed to parse config:", e);
      }
    }
    
    // Validate the input value
    const validation = validateDimensionValue(input, config);
    
    if (!validation.isValid) {
      // Show first error message
      showDimensionError(wrapper, validation.errors[0]);
      
      // For range sliders, clamp the value to valid range
      if (input.classList.contains("range-slider-input")) {
        const min = parseFloat(config.min) || 0;
        const max = parseFloat(config.max) || 10000;
        const clampedValue = Math.max(min, Math.min(max, parseFloat(input.value) || min));
        input.value = clampedValue;
        const display = wrapper.querySelector(".range-value-display");
        if (display) {
          display.textContent = clampedValue;
        }
      }
      
      // Don't update state with invalid value
      return;
    }
    
    // Clear error if validation passes
    showDimensionError(wrapper, null);
    
    // Read priceType and priceValue from input element data attributes first, then fallback to wrapper
    let priceType = input.dataset.priceType;
    let priceValue = parseFloat(input.dataset.priceValue);
    
    // If not found on input, try to get from wrapper's option data
    if (!priceType || isNaN(priceValue)) {
      const optionId = input.dataset.optionId;
      if (optionId && wrapper) {
        // Try to find the option card or get from wrapper's data attributes
        const optionCard = wrapper.querySelector(
          `[data-option-id="${optionId}"]`,
        );
        if (optionCard) {
          priceType = optionCard.dataset.priceType || priceType || "fixed";
          priceValue =
            parseFloat(optionCard.dataset.priceValue) || priceValue || 0;
        }
      }
    }
    
    // Final fallback
    priceType = priceType || "fixed";
    priceValue = isNaN(priceValue) ? 0 : priceValue;
    
    const unit = config.unit || "mm";
    const rawValue = validation.value;

    // Convert to meters for calculation
    let valueInMeters = rawValue;
    if (unit === "mm") valueInMeters /= 1000;
    if (unit === "cm") valueInMeters /= 100;
    // if unit is 'm', keep as is

    // Update state dimensions
    if (!state.dimensions[key]) {
      state.dimensions[key] = {};
    }
    state.dimensions[key] = {
      value: rawValue,
      label: label || key,
      priceType: priceType,
      priceValue: priceValue,
    };

    // CRITICAL: Re-evaluate step visibility after dimension change (in case steps depend on dimensions)
    evaluateStepVisibility();

    // Update display for range slider
    if (input.classList.contains("range-slider-input")) {
      const display = wrapper.querySelector(".range-value-display");
      if (display) {
        display.textContent = rawValue;
      }
    }

    state.dimensions[key] = {
      value: valueInMeters, // Store in meters for calculations
      rawValue: rawValue, // Keep original for display
      label: label,
      unit: unit,
      priceType: priceType,
      priceValue: priceValue,
    };
    updateUI();
  }

  // Dimension Inputs and Range Sliders with unit conversion and price calculation
  // Use both 'input' and 'change' events for better compatibility
  configContainer.addEventListener("input", (e) => {
    if (
      e.target.classList.contains("dimension-input") ||
      e.target.classList.contains("range-slider-input")
    ) {
      handleDimensionChange(e.target);
    }
  });

  // Also listen for 'change' event for range sliders (some browsers need this)
  configContainer.addEventListener("change", (e) => {
    if (e.target.classList.contains("range-slider-input")) {
      handleDimensionChange(e.target);
    }
  });

  // Add mousemove event for range sliders for better responsiveness while dragging
  configContainer.addEventListener("mousemove", (e) => {
    if (e.target.classList.contains("range-slider-input") && e.buttons === 1) {
      handleDimensionChange(e.target);
    }
  });

  // Initialize range slider displays on page load
  function initializeRangeSliderDisplays() {
    configContainer
      .querySelectorAll(".range-slider-input")
      .forEach((slider) => {
        const wrapper = slider.closest(".dimension-wrapper");
      if (wrapper) {
          const display = wrapper.querySelector(".range-value-display");
        if (display && slider.value !== undefined) {
          display.textContent = slider.value;
        }
      }
    });
  }

  // Initialize range slider displays
  initializeRangeSliderDisplays();

  // Expose Qty function
  window.updateConfigQty = function (change) {
    const qtyInput = document.getElementById("config-qty");
    if (qtyInput) {
      let val = parseInt(qtyInput.value) || 1;
      val += change;
      if (val < 1) val = 1;
      qtyInput.value = val;
    }
  };

  // File Upload Preview
  const fileInput = document.getElementById("config-custom-file");
  const dropzone = document.getElementById("config-file-dropzone");
  if (dropzone && fileInput) {
    dropzone.addEventListener("click", () => fileInput.click());
    fileInput.addEventListener("change", () => {
      if (fileInput.files.length > 0) {
        document.getElementById("file-preview-name").textContent =
          fileInput.files[0].name;
      }
    });
  }

  // Validate all dimensions before adding to cart
  function validateAllDimensions() {
    const errors = [];
    const dimensionInputs = configContainer.querySelectorAll('.dimension-input, .range-slider-input');
    
    dimensionInputs.forEach(input => {
      const wrapper = input.closest(".dimension-wrapper");
      if (!wrapper) return;
      
      let config = {};
      const configData = wrapper.dataset.config;
      if (configData) {
        try {
          config = JSON.parse(configData);
        } catch (e) {
          console.warn("Failed to parse config:", e);
        }
      }
      
      const validation = validateDimensionValue(input, config);
      if (!validation.isValid) {
        const label = input.dataset.label || 'Dimension';
        errors.push(`${label}: ${validation.errors[0]}`);
        showDimensionError(wrapper, validation.errors[0]);
      } else {
        showDimensionError(wrapper, null);
      }
    });
    
    return {
      isValid: errors.length === 0,
      errors: errors
    };
  }

  // Add To Cart Logic
  function handleAddToCart(e) {
    e.preventDefault();
    e.stopPropagation();

    const btn = e.currentTarget;
    const originalText = btn.innerHTML;

    // Validate all dimensions before proceeding
    const dimensionValidation = validateAllDimensions();
    if (!dimensionValidation.isValid) {
      alert('Please fix the following errors:\n\n' + dimensionValidation.errors.join('\n'));
      return;
    }

    // Get quantity
      let qty = 1;
    const qtyInput =
      document.getElementById("config-qty") ||
      document.getElementById("quantity_wanted");
    if (qtyInput) qty = parseInt(qtyInput.value) || 1;

    // Get comment
    const commentEl = document.getElementById("config-comment");
    const comment = commentEl ? commentEl.value : "";

    // Get product ID
    const productId = getProductId();
    if (!productId) {
      alert("Product ID not found. Please refresh the page.");
      return;
    }

    // Build form data
      const formData = new FormData();
      formData.append("action", "add_to_cart");
      formData.append("ajax", 1);
    formData.append("id_product", productId);
      formData.append("qty", qty);
      formData.append("comment", comment);
      formData.append("selections", JSON.stringify(state.selections || {}));
    formData.append("dimensions", JSON.stringify(state.dimensions || {}));

    // Add file if exists
      if (fileInput && fileInput.files.length > 0) {
        formData.append("custom_file", fileInput.files[0]);
      }

    // Show loading state
      btn.disabled = true;
    btn.innerHTML = '<i class="material-icons">hourglass_empty</i> Adding...';

    // Send request
      fetch(ajaxUrl, {
        method: "POST",
        body: formData,
      })
      .then(function (response) {
        return response.json();
      })
      .then(function (data) {
          btn.disabled = false;
          btn.innerHTML = originalText;

          if (data.success) {
          // Update cart count manually
          var cartCountEls = document.querySelectorAll(".cart-products-count");
          cartCountEls.forEach(function (el) {
            if (data.cart_count) {
              el.textContent = data.cart_count;
            }
          });

          // Refresh cart block via AJAX
          if (typeof prestashop !== "undefined" && prestashop.emit) {
            try {
            prestashop.emit("updateCart", {
                reason: {
                  idProduct: productId,
                  idProductAttribute: 0,
                  idCustomization: data.id_customization,
                  linkAction: "refresh-configurator",
                },
                resp: data,
              });
            } catch (e) {
              console.log("Cart event emit failed:", e);
            }
          }

          // Show standard popup if returned, otherwise redirect to cart
          if (
            data.modal &&
            typeof prestashop !== "undefined" &&
            prestashop.blockcart &&
            prestashop.blockcart.showModal
          ) {
            prestashop.blockcart.showModal(data.modal);
          } else if (data.redirect) {
            window.location.href = data.redirect;
          } else {
            showAddToCartSuccess(data.message || "Product added to cart!");
          }
        } else {
          alert(
            "Error: " +
              (data.errors || data.message || "Could not add to cart"),
          );
          }
        })
      .catch(function (error) {
        console.error("Add to cart failed:", error);
          btn.disabled = false;
          btn.innerHTML = originalText;
        // Check if it's a JSON parse error (which often happens on PHP errors)
        if (error.message && error.message.includes("is not valid JSON")) {
          alert(
            "Server Error: The request returned an invalid response. Please check logs.",
          );
        } else {
          alert("Network error. Please try again.");
        }
        });
  }

  // Simple success notification
  function showAddToCartSuccess(message) {
    var toast = document.createElement("div");
    toast.style.cssText =
      "position:fixed;top:20px;right:20px;background:#28a745;color:#fff;padding:15px 25px;border-radius:8px;z-index:99999;box-shadow:0 4px 15px rgba(0,0,0,0.2);font-size:16px;";
    toast.innerHTML =
      '<i class="material-icons" style="vertical-align:middle;margin-right:8px;">check_circle</i>' +
      message;
    document.body.appendChild(toast);

    setTimeout(function () {
      toast.style.transition = "opacity 0.5s";
      toast.style.opacity = "0";
      setTimeout(function () {
        toast.remove();
      }, 500);
    }, 3000);
  }

  // Event listener attachment
  function attachCartEventListeners() {
    // Module Button (Summary Step)
  const mainCartBtn = document.getElementById("config-add-to-cart-main");
    if (mainCartBtn && !mainCartBtn.hasAttribute("data-listener-attached")) {
    mainCartBtn.addEventListener("click", handleAddToCart);
      mainCartBtn.setAttribute("data-listener-attached", "true");
  }

    // Sidebar button
    const sideCartBtn = document.getElementById("config-add-to-cart");
    if (sideCartBtn && !sideCartBtn.hasAttribute("data-listener-attached")) {
      sideCartBtn.addEventListener("click", handleAddToCart);
      sideCartBtn.setAttribute("data-listener-attached", "true");
    }

    // Also attach to any button with config-add-to-cart class
    document.querySelectorAll(".config-add-to-cart").forEach((btn) => {
      if (!btn.hasAttribute("data-listener-attached")) {
        btn.addEventListener("click", handleAddToCart);
        btn.setAttribute("data-listener-attached", "true");
      }
    });

    // Handle PrestaShop's default add-to-cart button CAREFULLY
    const psAddToCartSelectors = [
      '.product-add-to-cart button[data-button-action="add-to-cart"]',
      ".add-to-cart:not(.config-add-to-cart)",
    ];

    psAddToCartSelectors.forEach((selector) => {
      document.querySelectorAll(selector).forEach((btn) => {
        if (
          !btn.id.includes("config") &&
          !btn.classList.contains("config-add-to-cart") &&
          !btn.hasAttribute("data-config-listener")
        ) {
          btn.addEventListener("click", function (e) {
            // Only intercept if we are on a configurator page
            if (document.getElementById("ps-configurator")) {
              e.preventDefault();
              e.stopPropagation();
              handleAddToCart(e);
            }
          });
          btn.setAttribute("data-config-listener", "true");
        }
      });
    });
  }

  // Initial attachment
  attachCartEventListeners();

  // --- RAL SYSTEM LOGIC ---
  const RAL_FAMILIES = {
    yellow: {
      label: "Jaunes",
      colors: [
        { code: "1000", hex: "#D6C68B" },
        { code: "1001", hex: "#D3B683" },
        { code: "1002", hex: "#D2AA6D" },
        { code: "1003", hex: "#F9A800" },
        { code: "1004", hex: "#E4A010" },
        { code: "1005", hex: "#CB8E16" },
        { code: "1006", hex: "#E1A100" },
        { code: "1007", hex: "#E88C00" },
        { code: "1011", hex: "#AD8B59" },
        { code: "1012", hex: "#DDD968" },
        { code: "1013", hex: "#EAE6CA" },
        { code: "1014", hex: "#E1CC4F" },
        { code: "1015", hex: "#E6D690" },
        { code: "1016", hex: "#EDFF21" },
        { code: "1017", hex: "#F5D033" },
        { code: "1018", hex: "#F8F32B" },
        { code: "1019", hex: "#A4957D" },
        { code: "1020", hex: "#A08F65" },
        { code: "1021", hex: "#F6B600" },
        { code: "1023", hex: "#F7B500" },
        { code: "1024", hex: "#BA8F4C" },
        { code: "1027", hex: "#A77F0E" },
        { code: "1028", hex: "#FFAB00" },
        { code: "1032", hex: "#E2A300" },
        { code: "1033", hex: "#F3752C" },
        { code: "1034", hex: "#E09E3F" },
        { code: "1037", hex: "#E88C00" },
      ],
    },
    orange: {
      label: "Oranges",
      colors: [
        { code: "2000", hex: "#ED6B28" },
        { code: "2001", hex: "#BE4E20" },
        { code: "2002", hex: "#CB3234" },
        { code: "2003", hex: "#FF7514" },
        { code: "2004", hex: "#F05620" },
        { code: "2008", hex: "#F3752C" },
        { code: "2009", hex: "#E8521C" },
        { code: "2010", hex: "#D84B20" },
        { code: "2011", hex: "#EC7C26" },
        { code: "2012", hex: "#E55137" },
      ],
    },
    red: {
      label: "Rouges",
      colors: [
        { code: "3000", hex: "#AF2B1E" },
        { code: "3001", hex: "#A52019" },
        { code: "3002", hex: "#9B111E" },
        { code: "3003", hex: "#900020" },
        { code: "3004", hex: "#75151E" },
        { code: "3005", hex: "#5E2129" },
        { code: "3007", hex: "#412227" },
        { code: "3009", hex: "#6D3F38" },
        { code: "3011", hex: "#7C2C28" },
        { code: "3013", hex: "#A12312" },
        { code: "3016", hex: "#B32D29" },
        { code: "3020", hex: "#CC0605" },
        { code: "3031", hex: "#AB2328" },
      ],
    },
    pink: {
      label: "Roses/Violets",
      colors: [
        { code: "4001", hex: "#8A5A83" },
        { code: "4002", hex: "#933D50" },
        { code: "4003", hex: "#D15887" },
        { code: "4004", hex: "#6B1C23" },
        { code: "4005", hex: "#7E6DA7" },
        { code: "4006", hex: "#9F338C" },
        { code: "4007", hex: "#4A192C" },
        { code: "4008", hex: "#904684" },
        { code: "4010", hex: "#D43075" },
      ],
    },
    blue: {
      label: "Bleus",
      colors: [
        { code: "5000", hex: "#354D73" },
        { code: "5001", hex: "#1F3438" },
        { code: "5002", hex: "#20214F" },
        { code: "5003", hex: "#1D1E33" },
        { code: "5004", hex: "#18171C" },
        { code: "5005", hex: "#1E2460" },
        { code: "5007", hex: "#3E5F8A" },
        { code: "5008", hex: "#26252D" },
        { code: "5009", hex: "#345271" },
        { code: "5010", hex: "#183980" },
        { code: "5011", hex: "#1D1E2C" },
        { code: "5012", hex: "#3886BC" },
        { code: "5013", hex: "#1E213D" },
        { code: "5014", hex: "#606E8C" },
        { code: "5015", hex: "#2973B8" },
        { code: "5017", hex: "#2F4F7F" },
        { code: "5018", hex: "#398E8B" },
        { code: "5019", hex: "#175676" },
        { code: "5020", hex: "#1D3338" },
        { code: "5021", hex: "#2D6B71" },
        { code: "5023", hex: "#487FA3" },
      ],
    },
    green: {
      label: "Verts",
      colors: [
        { code: "6000", hex: "#42755E" },
        { code: "6001", hex: "#346A38" },
        { code: "6002", hex: "#2D572C" },
        { code: "6003", hex: "#424632" },
        { code: "6004", hex: "#1F3A3D" },
        { code: "6005", hex: "#2F4538" },
        { code: "6009", hex: "#253529" },
        { code: "6010", hex: "#3F612D" },
        { code: "6011", hex: "#587246" },
        { code: "6016", hex: "#1D4536" },
        { code: "6018", hex: "#57A639" },
        { code: "6019", hex: "#B9CEAC" },
        { code: "6021", hex: "#8A9977" },
        { code: "6024", hex: "#358155" },
        { code: "6029", hex: "#20603D" },
      ],
    },
    grey: {
      label: "Gris",
      colors: [
        { code: "7000", hex: "#7E8B92" },
        { code: "7001", hex: "#8F999F" },
        { code: "7004", hex: "#9DA1AA" },
        { code: "7005", hex: "#6B6E6B" },
        { code: "7006", hex: "#756F61" },
        { code: "7011", hex: "#5D666E" },
        { code: "7012", hex: "#596163" },
        { code: "7015", hex: "#51565C" },
        { code: "7016", hex: "#3B3F42" },
        { code: "7021", hex: "#2E3234" },
        { code: "7022", hex: "#4D4A44" },
        { code: "7024", hex: "#474A51" },
        { code: "7030", hex: "#939388" },
        { code: "7032", hex: "#B8B799" },
        { code: "7035", hex: "#D7DBD5" },
        { code: "7037", hex: "#7D7F7E" },
        { code: "7040", hex: "#9DA1AA" },
        { code: "7042", hex: "#8F9695" },
        { code: "7043", hex: "#4E5452" },
        { code: "7044", hex: "#BDBDB2" },
      ],
    },
    brown: {
      label: "Bruns",
      colors: [
        { code: "8000", hex: "#826C42" },
        { code: "8001", hex: "#935F33" },
        { code: "8003", hex: "#734222" },
        { code: "8004", hex: "#88442D" },
        { code: "8007", hex: "#633A34" },
        { code: "8011", hex: "#59351F" },
        { code: "8014", hex: "#49392D" },
        { code: "8015", hex: "#5A2F2B" },
        { code: "8016", hex: "#4C2F27" },
        { code: "8017", hex: "#45322E" },
        { code: "8019", hex: "#3F3A3A" },
        { code: "8028", hex: "#4E3B31" },
      ],
    },
    white_black: {
      label: "Blancs/Noirs",
      colors: [
        { code: "9001", hex: "#FDF4E3" },
        { code: "9002", hex: "#E7EBDA" },
        { code: "9003", hex: "#F4F4F4" },
        { code: "9004", hex: "#282828" },
        { code: "9005", hex: "#0A0A0A" },
        { code: "9006", hex: "#A5A5A5" },
        { code: "9007", hex: "#8F8F8F" },
        { code: "9010", hex: "#F7F9EF" },
        { code: "9016", hex: "#F6F6F6" },
      ],
    },
  };

  const RAL_BAR_COLORS = {
    yellow: "#D6C68B",
    orange: "#ED6B28",
    red: "#AF2B1E",
    pink: "#D15887",
    blue: "#1E2460",
    green: "#346A38",
    grey: "#7E8B92",
    brown: "#734222",
    white_black: "#282828",
  };

  function initializeRalPicker(interfaceContainer) {
    if (!interfaceContainer) {
      console.error("initializeRalPicker: interfaceContainer is null");
      return;
    }
    
    const categories = interfaceContainer.querySelector(".ral-categories");
    const grid = interfaceContainer.querySelector(".ral-colors-grid");
    const optionId = interfaceContainer.dataset.optionId;

    console.log("initializeRalPicker called", {
      hasInterfaceContainer: !!interfaceContainer,
      hasCategories: !!categories,
      hasGrid: !!grid,
      optionId: optionId
    });

    if (!categories || !grid) {
      console.error("RAL picker elements not found", {
        categories: categories,
        grid: grid,
        interfaceContainer: interfaceContainer,
        html: interfaceContainer ? interfaceContainer.innerHTML.substring(0, 200) : 'null'
      });
      return;
    }

    // Clear containers
    categories.innerHTML = "";
    grid.innerHTML = "";

    // Check if there are custom colors configured for this option
    const customColorsData = configContainer ? configContainer.dataset.customColors : null;
    let customColors = [];
    
    if (customColorsData && optionId) {
      try {
        const allCustomColors = JSON.parse(customColorsData);
        const optionIdStr = String(optionId);
        const optionIdNum = parseInt(optionId);
        customColors = allCustomColors[optionIdStr] || allCustomColors[optionIdNum] || [];
        console.log('Found custom colors for option', optionId, ':', customColors.length, 'colors');
      } catch (e) {
        console.error("Error parsing custom colors:", e);
      }
    }

    // If custom colors are configured, filter RAL library to show only those colors
    if (customColors && customColors.length > 0) {
      console.log('Loading filtered RAL library (custom colors only)');
      loadRalLibraryForCustomColors(categories, grid, interfaceContainer, customColors);
    } else {
      console.log('No custom colors configured, loading full RAL library');
      loadRalLibraryFromDatabase(categories, grid, interfaceContainer);
    }
  }

  function loadRalLibraryForCustomColors(categoriesContainer, gridContainer, interfaceContainer, customColors) {
    const ajaxUrlValue = configContainer ? configContainer.dataset.ajaxUrl : null;
    if (!ajaxUrlValue) {
      console.error('AJAX URL not found');
      gridContainer.innerHTML = '<div class="text-center text-danger p-4">Error: AJAX URL not configured.</div>';
      return;
    }
    
    // Show loading message
    gridContainer.innerHTML = '<div class="text-center p-4"><i class="fa fa-spinner fa-spin"></i> Loading categories...</div>';
    
    const formData = new FormData();
    formData.append("action", "getRalLibrary");

    fetch(ajaxUrlValue, {
      method: "POST",
      body: new URLSearchParams(formData),
    })
      .then((response) => response.json())
      .then((data) => {
        console.log('RAL Library AJAX response for custom colors:', data);
        if (data && data.success && data.categories && data.categories.length > 0) {
          // Filter to show only categories/colors that match custom colors
          const filteredData = filterRalLibraryForCustomColors(data, customColors);
          displayRalCategoriesFirst(filteredData, categoriesContainer, gridContainer, interfaceContainer);
        } else {
          // Fallback: show custom colors without categories
          displayCustomColorsDirectly(customColors, categoriesContainer, gridContainer, interfaceContainer);
        }
      })
      .catch((error) => {
        console.error("Error loading RAL library:", error);
        // Fallback: show custom colors directly
        displayCustomColorsDirectly(customColors, categoriesContainer, gridContainer, interfaceContainer);
      });
  }

  function filterRalLibraryForCustomColors(ralLibraryData, customColors) {
    // Extract RAL codes from custom colors
    const customRalCodes = customColors.map(c => {
      // Extract code from color_code (e.g., "RAL 4003" -> "4003")
      const code = c.color_code ? c.color_code.replace(/^RAL\s+/i, "").trim() : null;
      return code;
    }).filter(c => c);

    console.log('Filtering RAL library for custom codes:', customRalCodes);

    const filteredCategories = [];
    const filteredColors = {};

    // Go through each category and check if it has any matching colors
    ralLibraryData.categories.forEach(cat => {
      const categoryColors = ralLibraryData.colors[cat.id] || [];
      const matchingColors = categoryColors.filter(color => {
        return customRalCodes.includes(color.code);
      });

      if (matchingColors.length > 0) {
        filteredCategories.push(cat);
        filteredColors[cat.id] = matchingColors;
      }
    });

    return {
      success: true,
      categories: filteredCategories,
      colors: filteredColors
    };
  }

  function displayCustomColorsDirectly(customColors, categoriesContainer, gridContainer, interfaceContainer) {
    // If we can't get categories, just show all custom colors in a simple grid
    console.log('Displaying custom colors directly:', customColors.length);
    
    categoriesContainer.innerHTML = "";
    gridContainer.innerHTML = "";

    const colorsGrid = document.createElement("div");
    colorsGrid.className = "d-flex flex-wrap";
    colorsGrid.style.gap = "10px";
    colorsGrid.style.justifyContent = "flex-start";

    customColors.forEach((color) => {
      const ralCode = color.color_code ? color.color_code.replace(/^RAL\s+/i, "").trim() : '';
      const hex = color.hex_code || "#000000";
      const name = color.color_name || '';

      const item = document.createElement("div");
      item.className = "ral-swatch-item text-center";
      item.style.cssText = `
        cursor: pointer;
        padding: 12px 16px;
        border: 2px solid #ddd;
        border-radius: 6px;
        background: white;
        transition: all 0.2s;
        min-width: 120px;
        flex: 0 0 auto;
      `;

      item.innerHTML = `
        <div class="ral-swatch-color" style="background-color: ${hex}; width: 100%; height: 60px; border-radius: 4px; border: 1px solid #ccc; margin-bottom: 8px;"></div>
        <div class="ral-swatch-code font-weight-bold" style="font-size: 14px; color: #333;">${color.color_code || 'RAL ' + ralCode}</div>
        ${name ? `<div class="ral-swatch-name text-muted" style="font-size: 11px; margin-top: 4px;">${name}</div>` : ''}
      `;

      item.addEventListener("click", function(e) {
        e.stopPropagation(); // Prevent event from bubbling to option card handler
        
        // Toggle selection
        const isSelected = this.classList.contains("selected");
        const step = interfaceContainer.closest(".config-step");
        const stepId = step ? step.dataset.id : null;
        const optionId = interfaceContainer.dataset.optionId;
        
        if (!stepId || !optionId) {
          console.warn("Missing stepId or optionId for custom RAL color selection");
          return;
        }
        
        if (isSelected) {
          this.classList.remove("selected");
          this.style.borderColor = "#ddd";
          this.style.borderWidth = "2px";
          
          const ralKey = `${optionId}_RAL_${ralCode}`;
          if (stepId && state.selections[stepId] && state.selections[stepId][ralKey]) {
            delete state.selections[stepId][ralKey];
            updateSelectedColorsDisplay(interfaceContainer, stepId, optionId);
            evaluateStepVisibility();
            updateUI();
          }
        } else {
          this.classList.add("selected");
          this.style.borderColor = "#28a745";
          this.style.borderWidth = "3px";
          
          // Try to find categoryId for custom colors
          const categoryId = findCategoryIdForRalCode(interfaceContainer, ralCode);
          processRalSelection(interfaceContainer, color.color_code || "RAL " + ralCode, hex, categoryId);
        }
      });

      colorsGrid.appendChild(item);
    });

    gridContainer.appendChild(colorsGrid);
  }

  function loadRalLibraryFromDatabase(categoriesContainer, gridContainer, interfaceContainer) {
    const ajaxUrlValue = configContainer ? configContainer.dataset.ajaxUrl : null;
    if (!ajaxUrlValue) {
      console.error('AJAX URL not found', { configContainer: configContainer });
      if (gridContainer) {
        gridContainer.innerHTML = '<div class="text-center text-danger p-4">Error: AJAX URL not configured.</div>';
      }
      return;
    }
    
    console.log('Loading RAL library from:', ajaxUrlValue);
    
    // Show loading message in grid
    if (gridContainer) {
      gridContainer.innerHTML = '<div class="text-center p-4"><i class="fa fa-spinner fa-spin"></i> Loading categories...</div>';
    }
    
    const formData = new FormData();
    formData.append("action", "getRalLibrary");

    fetch(ajaxUrlValue, {
      method: "POST",
      body: new URLSearchParams(formData),
    })
      .then((response) => {
        console.log('RAL Library fetch response status:', response.status);
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.text();
      })
      .then((text) => {
        console.log('RAL Library raw response:', text.substring(0, 500));
        let data;
        try {
          data = JSON.parse(text);
        } catch (e) {
          console.error('Failed to parse JSON response:', e, text);
          throw new Error('Invalid JSON response: ' + text.substring(0, 200));
        }
        console.log('RAL Library AJAX parsed data:', data);
        
        if (data && data.success && data.categories && data.categories.length > 0) {
          // Show categories FIRST, then colors when clicked
          displayRalCategoriesFirst(data, categoriesContainer, gridContainer, interfaceContainer);
        } else {
          console.warn('RAL Library response missing data:', {
            success: data.success,
            categoriesCount: data.categories ? data.categories.length : 0,
            hasColors: !!data.colors
          });
          if (categoriesContainer) {
            categoriesContainer.innerHTML = '<div class="text-center text-muted p-4">No RAL categories found.</div>';
          }
          if (gridContainer) {
            gridContainer.innerHTML = '<div class="text-center text-muted p-4">No RAL colors available. Please contact administrator.</div>';
          }
        }
      })
      .catch((error) => {
        console.error("Error loading RAL library:", error);
        if (categoriesContainer) {
          categoriesContainer.innerHTML = '<div class="text-center text-danger p-4">Error loading categories: ' + error.message + '</div>';
        }
        if (gridContainer) {
          gridContainer.innerHTML = '<div class="text-center text-danger p-4">Error loading RAL colors: ' + error.message + '. Please refresh the page.</div>';
        }
      });
  }

  function displayRalCategoriesFirst(data, categoriesContainer, gridContainer, interfaceContainer) {
    console.log('displayRalCategoriesFirst called', {
      hasData: !!data,
      hasCategoriesContainer: !!categoriesContainer,
      hasGridContainer: !!gridContainer,
      hasInterfaceContainer: !!interfaceContainer
    });
    
    const categories = data.categories || [];
    const colors = data.colors || {};

    console.log('Displaying categories first:', categories.length, 'categories');
    console.log('Categories data:', categories);
    console.log('Colors data:', colors);
    console.log('Colors keys:', Object.keys(colors));

    if (!categoriesContainer || !gridContainer) {
      console.error('Missing containers in displayRalCategoriesFirst', {
        categoriesContainer: categoriesContainer,
        gridContainer: gridContainer
      });
      return;
    }

    // Store categories and colors data in interfaceContainer for later use
    if (interfaceContainer) {
      try {
        interfaceContainer.dataset.ralCategories = JSON.stringify(categories);
        interfaceContainer.dataset.ralColors = JSON.stringify(colors);
      } catch (e) {
        console.error('Error storing RAL data:', e);
      }
    }

    // Clear containers
    categoriesContainer.innerHTML = "";
    gridContainer.innerHTML = "";

    if (categories.length === 0) {
      gridContainer.innerHTML = '<div class="text-center text-muted p-4">No RAL categories found.</div>';
      console.warn('No categories found in data');
      return;
    }

    // Create category tabs FIRST - show them immediately (same style as admin)
    const tabsWrapper = document.createElement("div");
    tabsWrapper.className = "d-flex flex-wrap justify-content-center mb-4";
    tabsWrapper.style.gap = "10px";
    tabsWrapper.style.borderBottom = "2px solid #ddd";
    tabsWrapper.style.paddingBottom = "15px";
    tabsWrapper.style.marginBottom = "20px";

    categories.forEach((cat, index) => {
      // Get first color from category for swatch display
      const categoryColors = colors[cat.id] || [];
      const firstColor = categoryColors.length > 0 ? categoryColors[0] : null;
      const categoryColorHex = firstColor ? firstColor.hex : '#cccccc';
      
      const tab = document.createElement("button");
      tab.type = "button";
      tab.className = "btn btn-sm ral-category-tab d-flex align-items-center";
      tab.dataset.categoryId = cat.id;
      
      // Create tab content with color swatch and name
      tab.innerHTML = `
        <span class="ral-category-swatch" style="
          display: inline-block;
          width: 30px;
          height: 30px;
          background-color: ${categoryColorHex};
          border: 2px solid #333;
          border-radius: 4px;
          margin-right: 8px;
          flex-shrink: 0;
        "></span>
        <span class="ral-category-name">${cat.name}</span>
      `;
      
      tab.style.cssText = `
        border-radius: 4px;
        padding: 8px 16px;
        border: 2px solid #ddd;
        background: ${index === 0 ? '#007bff' : '#f8f9fa'};
        color: ${index === 0 ? 'white' : '#333'};
        cursor: pointer;
        transition: all 0.2s;
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 8px;
      `;

      tab.addEventListener("mouseover", function() {
        if (!this.classList.contains("active")) {
          this.style.background = "#e9ecef";
          this.style.borderColor = "#007bff";
        }
      });
      tab.addEventListener("mouseout", function() {
        if (!this.classList.contains("active")) {
          this.style.background = "#f8f9fa";
          this.style.borderColor = "#ddd";
        }
      });

      tab.addEventListener("click", function(e) {
        e.preventDefault();
        e.stopPropagation();
        
        console.log('Category tab clicked:', cat.name, 'ID:', cat.id);
        console.log('Colors for this category:', colors[cat.id]);
        
        // Update active tab
        tabsWrapper.querySelectorAll(".ral-category-tab").forEach((t) => {
          t.classList.remove("active");
          t.style.background = "#f8f9fa";
          t.style.color = "#333";
          t.style.borderColor = "#ddd";
        });
        this.classList.add("active");
        this.style.background = "#007bff";
        this.style.color = "white";
        this.style.borderColor = "#007bff";

        // Load and show colors for this category - NO auto-select, user selects manually
        const categoryColors = colors[cat.id] || [];
        console.log(`Loading ${categoryColors.length} colors for category ${cat.name}`);
        loadCategoryColors(cat.id, categoryColors, gridContainer, interfaceContainer, false);
      });

      if (index === 0) {
        tab.classList.add("active");
        // Load first category colors immediately - NO auto-select
        setTimeout(() => {
          const firstCategoryColors = colors[cat.id] || [];
          console.log(`Loading first category (${cat.name}):`, firstCategoryColors.length, 'colors');
          loadCategoryColors(cat.id, firstCategoryColors, gridContainer, interfaceContainer, false);
        }, 100);
      }

      tabsWrapper.appendChild(tab);
    });

    categoriesContainer.appendChild(tabsWrapper);
  }

  function loadCategoryColors(categoryId, categoryColors, gridContainer, interfaceContainer, autoSelectAll = false) {
    console.log(`Loading colors for category ${categoryId}:`, categoryColors.length, 'colors', 'autoSelect:', autoSelectAll);
    
    gridContainer.innerHTML = "";

    if (categoryColors.length === 0) {
      gridContainer.innerHTML = '<div class="text-center text-muted p-4">No colors in this category.</div>';
      return;
    }

    // Create grid similar to reference site - simple RAL code display
    const colorsGrid = document.createElement("div");
    colorsGrid.className = "d-flex flex-wrap";
    colorsGrid.style.gap = "10px";
    colorsGrid.style.justifyContent = "flex-start";

    categoryColors.forEach((color) => {
      const item = document.createElement("div");
      item.className = "ral-swatch-item text-center";
      
      // Auto-select if requested
      const isSelected = autoSelectAll;
      if (isSelected) {
        item.classList.add("selected");
      }
      
      item.style.cssText = `
        cursor: pointer;
        padding: 12px 16px;
        border: ${isSelected ? '3px solid #28a745' : '2px solid #ddd'};
        border-radius: 6px;
        background: white;
        transition: all 0.2s;
        min-width: 120px;
        flex: 0 0 auto;
      `;

      item.innerHTML = `
        <div class="ral-swatch-color" style="background-color: ${color.hex}; width: 100%; height: 60px; border-radius: 4px; border: 1px solid #ccc; margin-bottom: 8px;"></div>
        <div class="ral-swatch-code font-weight-bold" style="font-size: 14px; color: #333;">RAL ${color.code}</div>
        ${color.name ? `<div class="ral-swatch-name text-muted" style="font-size: 11px; margin-top: 4px;">${color.name}</div>` : ''}
      `;

      item.addEventListener("mouseover", function() {
        if (!this.classList.contains("selected")) {
          this.style.borderColor = "#007bff";
          this.style.borderWidth = "2px";
          this.style.transform = "translateY(-2px)";
          this.style.boxShadow = "0 2px 8px rgba(0,123,255,0.3)";
        }
      });
      item.addEventListener("mouseout", function() {
        if (!this.classList.contains("selected")) {
          this.style.borderColor = "#ddd";
          this.style.borderWidth = "2px";
          this.style.transform = "translateY(0)";
          this.style.boxShadow = "none";
        }
      });
      item.addEventListener("click", function(e) {
        e.stopPropagation(); // Prevent event from bubbling to option card handler
        
        const step = interfaceContainer.closest(".config-step");
        const stepId = step ? step.dataset.id : null;
        const optionId = interfaceContainer.dataset.optionId;
        
        if (!stepId || !optionId) {
          console.warn("Missing stepId or optionId for RAL color selection");
          return;
        }
        
        // Single selection mode: Deselect all other colors first
        const allSwatches = gridContainer.querySelectorAll(".ral-swatch-item");
        allSwatches.forEach(swatch => {
          swatch.classList.remove("selected");
          swatch.style.borderColor = "#ddd";
          swatch.style.borderWidth = "2px";
        });
        
        // Clear previous selections for this option
        if (stepId && state.selections[stepId]) {
          Object.keys(state.selections[stepId]).forEach(key => {
            if (key.startsWith(`${optionId}_RAL_`)) {
              delete state.selections[stepId][key];
            }
          });
        }
        
        // Select this color
        this.classList.add("selected");
        this.style.borderColor = "#28a745";
        this.style.borderWidth = "3px";
        
        // Add to state and update input field - pass categoryId
        processRalSelection(interfaceContainer, "RAL " + color.code, color.hex, categoryId);
      });

        // Auto-select on load if requested
        if (autoSelectAll) {
          processRalSelection(interfaceContainer, "RAL " + color.code, color.hex, categoryId);
        }

      colorsGrid.appendChild(item);
    });

    gridContainer.appendChild(colorsGrid);
  }


  function processRalSelection(interfaceContainer, fullCode, hex, categoryId = null) {
    const optionId = interfaceContainer.dataset.optionId;
    const step = interfaceContainer.closest(".config-step");
    const stepId = step ? step.dataset.id : null;

    if (!stepId || !optionId) {
      console.warn("processRalSelection: Missing stepId or optionId", { stepId, optionId });
      return;
    }

    // Update state selections - Support multiple RAL colors
    if (!state.selections[stepId]) {
      state.selections[stepId] = {};
    }

    // Find the option card to get label and valueKey
    const optionCard = step.querySelector(`[data-option-id="${optionId}"]`);
    const baseLabel = optionCard ? (optionCard.dataset.label || "RAL Custom") : "RAL Custom";
    const baseValueKey = optionCard ? (optionCard.dataset.valueKey || "ral_custom") : "ral_custom";
    const price = optionCard ? (parseFloat(optionCard.dataset.price) || 0) : 0;
    
    // Extract RAL code (e.g., "RAL 4003" -> "4003")
    const ralCodeOnly = fullCode.replace(/^RAL\s+/i, "").trim();
    
    // Create unique key for this RAL color selection
    const ralKey = `${optionId}_RAL_${ralCodeOnly}`;
    
    // Get category name if categoryId is provided
    let categoryName = null;
    if (categoryId) {
      try {
        const categoriesData = interfaceContainer.dataset.ralCategories;
        if (categoriesData) {
          const categories = JSON.parse(categoriesData);
          const category = categories.find(cat => cat.id == categoryId);
          if (category) {
            categoryName = category.name;
          }
        }
      } catch (e) {
        console.warn("Error parsing categories:", e);
      }
    }
    
    // Add or update this RAL color selection
    state.selections[stepId][ralKey] = {
      label: `${baseLabel} - ${fullCode}`,
      valueKey: `${baseValueKey}_${ralCodeOnly}`,
      price: price,
      ralCode: fullCode,
      hex: hex,
      optionId: optionId,
      categoryId: categoryId,
      categoryName: categoryName,
    };
    
    // Mark option card as selected (if exists)
    if (optionCard) {
      optionCard.classList.add("selected");
    }

    // Update input field with RAL code (without "RAL " prefix)
    const input = interfaceContainer.querySelector(".ral-manual-input-field");
    if (input) {
      input.value = ralCodeOnly;
      console.log('Updated RAL input field with:', ralCodeOnly);
    }

    // Update selected colors display
    updateSelectedColorsDisplay(interfaceContainer, stepId, optionId);

    // CRITICAL: Re-evaluate step visibility after RAL selection
    evaluateStepVisibility();

    updateUI();
  }

  function findCategoryIdForRalCode(interfaceContainer, ralCode) {
    try {
      const categoriesData = interfaceContainer.dataset.ralCategories;
      const colorsData = interfaceContainer.dataset.ralColors;
      
      if (categoriesData && colorsData) {
        const categories = JSON.parse(categoriesData);
        const colors = JSON.parse(colorsData);
        
        // Search through all categories to find which one contains this RAL code
        for (const category of categories) {
          const categoryColors = colors[category.id] || [];
          const foundColor = categoryColors.find(c => c.code === ralCode);
          if (foundColor) {
            return category.id;
          }
        }
      }
    } catch (e) {
      console.warn("Error finding category for RAL code:", e);
    }
    return null;
  }

  function updateSelectedColorsDisplay(interfaceContainer, stepId, optionId) {
    if (!interfaceContainer || !stepId || !optionId) {
      return;
    }
    
    const selectedColorsWrapper = interfaceContainer.querySelector('.ral-selected-colors-wrapper');
    const selectedColorsContent = interfaceContainer.querySelector('.ral-selected-colors-content');
    
    if (!selectedColorsWrapper || !selectedColorsContent) {
      return;
    }

    // Get all selected RAL colors for this option
    const selectedColors = [];
    if (state.selections[stepId]) {
      Object.keys(state.selections[stepId]).forEach(key => {
        if (key.startsWith(`${optionId}_RAL_`)) {
          const selection = state.selections[stepId][key];
          if (selection.ralCode && selection.hex) {
            selectedColors.push(selection);
          }
        }
      });
    }

    if (selectedColors.length === 0) {
      selectedColorsWrapper.classList.add('d-none');
      return;
    }

    // Show the wrapper
    selectedColorsWrapper.classList.remove('d-none');

    // Group colors by category
    const colorsByCategory = {};
    selectedColors.forEach(color => {
      const categoryName = color.categoryName || 'Autre';
      if (!colorsByCategory[categoryName]) {
        colorsByCategory[categoryName] = [];
      }
      colorsByCategory[categoryName].push(color);
    });

    // Build HTML for selected colors grouped by category
    let html = '';
    Object.keys(colorsByCategory).forEach(categoryName => {
      const categoryColors = colorsByCategory[categoryName];
      html += `
        <div class="mb-3">
          <h6 class="font-weight-bold mb-2" style="font-size: 0.95em; color: #495057;">
            ${categoryName}
          </h6>
          <div class="d-flex flex-wrap" style="gap: 10px;">
      `;
      
      categoryColors.forEach(color => {
        html += `
          <div class="selected-ral-color-item d-flex align-items-center p-2 bg-white border rounded"
               style="border-color: #28a745 !important; border-width: 2px;">
            <span class="ral-color-swatch mr-2" 
                  style="display: inline-block; width: 30px; height: 30px; background-color: ${color.hex}; border: 1px solid #ccc; border-radius: 4px; flex-shrink: 0;"></span>
            <span class="ral-color-code font-weight-bold" style="font-size: 0.9em;">${color.ralCode}</span>
          </div>
        `;
      });
      
      html += `
          </div>
        </div>
      `;
    });

    selectedColorsContent.innerHTML = html;
  }

  // Implement RAL event handlers
  function attachRalEvents() {
    // Handle manual RAL code input
    document.addEventListener("input", function (e) {
      if (e.target.classList.contains("ral-manual-input-field")) {
        const input = e.target;
        let ralCode = input.value.trim().replace(/[^0-9]/g, ""); // Numbers only

        // Allow 4-digit RAL codes
        if (ralCode.length === 4) {
          const interfaceContainer = input.closest(".ral-interface-container");
          if (interfaceContainer) {
            // Try to find color in loaded RAL library or custom colors
            let foundColor = null;
            const grid = interfaceContainer.querySelector(".ral-colors-grid");
            
            if (grid) {
              // Search in visible color swatches
              const swatches = grid.querySelectorAll(".ral-swatch-item");
              swatches.forEach((swatch) => {
                const codeElement = swatch.querySelector(".ral-swatch-code");
                if (codeElement && codeElement.textContent.includes(ralCode)) {
                  foundColor = {
                    code: ralCode,
                    hex: swatch.querySelector(".ral-swatch-color").style.backgroundColor || "#000000"
                  };
                  swatch.click(); // Trigger click on the swatch
                }
              });
            }

            // If not found, still process the selection with the code
            if (!foundColor) {
              // Try to get hex from custom colors or use a default
              const customColorsData = configContainer.dataset.customColors || configContainer.getAttribute('data-custom-colors');
              let categoryId = null;
              
              // Try to find categoryId for this RAL code
              categoryId = findCategoryIdForRalCode(interfaceContainer, ralCode);
              
              if (customColorsData) {
                try {
                  const allCustomColors = JSON.parse(customColorsData);
                  const optionId = interfaceContainer.dataset.optionId;
                  const optionIdStr = String(optionId);
                  const optionIdNum = parseInt(optionId);
                  const customColors = allCustomColors[optionIdStr] || allCustomColors[optionIdNum] || [];
                  
                  const matchingColor = customColors.find(c => c.color_code === ralCode);
                  if (matchingColor) {
                    processRalSelection(interfaceContainer, "RAL " + ralCode, matchingColor.hex_code, categoryId);
                    return;
                  }
                } catch (e) {
                  console.error("Error parsing custom colors:", e);
                }
              }
              
              // Fallback: process with code only
              processRalSelection(interfaceContainer, "RAL " + ralCode, "#000000", categoryId);
            }
          }
        }
      }
    });

    // Highlight selected RAL in grid
    document.addEventListener("click", function (e) {
      if (e.target.closest(".ral-swatch-item")) {
        // Remove previous selection
        const grid = e.target.closest(".ral-colors-grid");
        if (grid) {
          grid.querySelectorAll(".ral-swatch-item").forEach((item) => {
            item.classList.remove("selected");
          });
        }
        // Add selection to clicked item
        e.target.closest(".ral-swatch-item").classList.add("selected");
      }
    });
  }

  attachRalEvents();

  // Initialize dimensions from default input values on page load
  // NOTE: We DON'T auto-add dimensions to state to avoid auto-selecting and adding prices
  // Dimensions will only be added when user actually changes the input
  function initializeDimensions() {
    // Just initialize the display values, but don't add to state.selections
    // This prevents auto-selection and price calculation
    configContainer
      .querySelectorAll(".dimension-input, .range-slider-input")
      .forEach((input) => {
        const wrapper = input.closest(".dimension-wrapper");
      if (wrapper) {
          const display = wrapper.querySelector(".range-value-display");
        if (display && input.value !== undefined) {
          display.textContent = input.value;
        }
      }
    });
  }

  // Initialize dimensions on page load
  initializeDimensions();

  // Initialize range slider displays after dimensions are initialized
  initializeRangeSliderDisplays();

  // Initial UI update - evaluate visibility and show first step
  updateUI();

  // Re-evaluate visibility after a short delay to ensure all data is loaded
  setTimeout(() => {
    evaluateStepVisibility();
    updateUI();
  }, 100);
});
