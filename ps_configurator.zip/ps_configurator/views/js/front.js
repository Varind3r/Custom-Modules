document.addEventListener('DOMContentLoaded', function () {
    const configContainer = document.getElementById('ps-configurator');
    if (!configContainer) return;

    const ajaxUrl = configContainer.dataset.ajaxUrl;
    const steps = configContainer.querySelectorAll('.config-step');
    const prevBtn = document.getElementById('prev-step');
    const nextBtn = document.getElementById('next-step');
    const cartBtn = document.getElementById('config-add-to-cart'); // Might be missing now
    const progressBar = document.getElementById('config-progress-bar');

    // Find price display: sidebar or main product price
    let priceDisplay = document.getElementById('live-config-price');
    if (!priceDisplay) {
        // Fallback to standard PrestaShop 1.7 product price selectors
        priceDisplay = document.querySelector('.current-price span[itemprop="price"]') ||
            document.querySelector('.current-price span') ||
            document.querySelector('.product-price');
    }

    const summaryList = configContainer.querySelector('.summary-list');
    const emptyMsg = configContainer.querySelector('.empty-msg');

    let currentStepIndex = 0;
    let state = {
        selections: {}, // {stepId: {optionId: {label, valueKey}}}
        dimensions: {}, // {key: {value: X, label: Y}}
        totalPrice: 0
    };

    function updateUI() {
        // Evaluate Visibility
        evaluateStepVisibility();

        const currentStep = steps[currentStepIndex];
        const currentStepId = currentStep.dataset.id;

        steps.forEach((step, index) => {
            if (index === currentStepIndex) {
                step.classList.remove('d-none');
            } else {
                step.classList.add('d-none');
            }
        });

        // Update Sidebar
        configContainer.querySelectorAll('.step-menu-item').forEach(item => {
            if (item.dataset.stepId === currentStepId) {
                item.classList.add('active');
            } else {
                item.classList.remove('active');
            }

            // Hide menu item if step is hidden
            const targetStep = Array.from(steps).find(s => s.dataset.id === item.dataset.stepId);
            if (targetStep && targetStep.dataset.hidden === "true") {
                item.classList.add('d-none');
            } else {
                item.classList.remove('d-none');
            }
        });

        // Update progress bar
        const visibleSteps = configContainer.querySelectorAll('.config-step:not([data-hidden="true"])');
        const currentStepOrder = Array.from(visibleSteps).indexOf(currentStep) + 1;
        const progress = (currentStepOrder / visibleSteps.length) * 100;
        if (progressBar) progressBar.style.width = progress + '%';

        // Update buttons
        if (currentStepIndex === 0 || !hasVisiblePrevStep()) {
            if (prevBtn) prevBtn.classList.add('d-none');
        } else {
            if (prevBtn) prevBtn.classList.remove('d-none');
        }

        if (!hasVisibleNextStep()) {
            if (nextBtn) nextBtn.classList.add('d-none');
            if (cartBtn) cartBtn.classList.remove('d-none');
        } else {
            if (nextBtn) nextBtn.classList.remove('d-none');
            if (cartBtn) cartBtn.classList.add('d-none');
        }

        renderSummary();
        calculatePrice();
        applyOptionFiltering();
    }

    // Sidebar navigation click
    configContainer.querySelectorAll('.step-menu-item').forEach((item) => {
        item.addEventListener('click', () => {
            const stepId = item.dataset.stepId;
            const targetIndex = Array.from(steps).findIndex(s => s.dataset.id === stepId);
            if (targetIndex !== -1 && steps[targetIndex].dataset.hidden !== "true") {
                currentStepIndex = targetIndex;
                updateUI();
            }
        });
    });

    function evaluateStepVisibility() {
        steps.forEach(step => {
            const dependsOnStepId = step.dataset.dependsOn;
            if (dependsOnStepId && dependsOnStepId != '0') {
                const triggerValues = step.dataset.triggerValues.split(',').map(v => v.trim()).filter(v => v !== "");
                const condition = step.dataset.condition || 'ANY'; // ANY, ALL, NONE

                const prevStepSelections = state.selections[dependsOnStepId] || {};
                const selectedLabels = Object.values(prevStepSelections).map(s => s.label);
                const selectedKeys = Object.values(prevStepSelections).map(s => s.valueKey);
                const allSelected = [...selectedLabels, ...selectedKeys];

                let isVisible = false;
                if (condition === 'ANY') {
                    isVisible = triggerValues.some(val => allSelected.includes(val));
                } else if (condition === 'ALL') {
                    isVisible = triggerValues.every(val => allSelected.includes(val));
                } else if (condition === 'NONE') {
                    isVisible = !triggerValues.some(val => allSelected.includes(val));
                }

                if (!isVisible) {
                    step.dataset.hidden = "true";
                    // If we are currently on a hidden step, jump
                    if (steps[currentStepIndex] === step) {
                        currentStepIndex++;
                    }
                } else {
                    step.dataset.hidden = "false";
                }
            } else {
                step.dataset.hidden = "false";
            }
        });
    }

    function hasVisibleNextStep() {
        for (let i = currentStepIndex + 1; i < steps.length; i++) {
            if (steps[i].dataset.hidden !== "true") return true;
        }
        return false;
    }

    function hasVisiblePrevStep() {
        for (let i = currentStepIndex - 1; i >= 0; i--) {
            if (steps[i].dataset.hidden !== "true") return true;
        }
        return false;
    }

    function applyOptionFiltering() {
        // Hide/Show specific options based on selected IDs (show_options/hide_options logic)
        const allSelectedIds = [];
        Object.values(state.selections).forEach(sel => {
            allSelectedIds.push(...Object.keys(sel));
        });

        configContainer.querySelectorAll('.option-wrapper').forEach(wrapper => {
            const showOnlyIfSelected = wrapper.dataset.showOptions ? wrapper.dataset.showOptions.split(',') : [];
            const hideIfSelected = wrapper.dataset.hideOptions ? wrapper.dataset.hideOptions.split(',') : [];

            let hidden = false;
            if (showOnlyIfSelected.length > 0) {
                hidden = !showOnlyIfSelected.some(id => allSelectedIds.includes(id));
            }
            if (hideIfSelected.length > 0 && hideIfSelected.some(id => allSelectedIds.includes(id))) {
                hidden = true;
            }

            if (hidden) {
                wrapper.classList.add('d-none');
            } else {
                wrapper.classList.remove('d-none');
            }
        });
    }

    function renderSummary() {
        summaryList.innerHTML = '';
        let hasSelections = false;

        Object.values(state.selections).forEach(stepSelections => {
            Object.values(stepSelections).forEach(sel => {
                hasSelections = true;
                const li = document.createElement('li');
                li.className = 'summary-item d-flex justify-content-between align-items-center';
                
                let priceHtml = '';
                if (sel.price > 0) {
                    // We don't have currency formatting here easily without duplication, 
                    // but we can at least show the number or just use the label if it's already there
                    priceHtml = `<span class="badge badge-info ml-2">+${sel.price}</span>`;
                }

                li.innerHTML = `
                    <div class="d-flex align-items-center">
                        <i class="material-icons text-success mr-2">check_circle</i> 
                        <span>${sel.label}</span>
                    </div>
                    ${priceHtml}
                `;
                summaryList.appendChild(li);
            });
        });

        Object.values(state.dimensions).forEach(dim => {
            if (dim.value > 0) {
                hasSelections = true;
                const li = document.createElement('li');
                li.className = 'summary-item';
                li.innerHTML = `<i class="material-icons">straighten</i> <span>${dim.label}: ${dim.value}</span>`;
                summaryList.appendChild(li);
            }
        });

        if (hasSelections) {
            emptyMsg.classList.add('d-none');
        } else {
            emptyMsg.classList.remove('d-none');
        }
    }

    function calculatePrice() {
        const selectedOptionIds = [];
        Object.keys(state.selections).forEach(stepId => {
            selectedOptionIds.push(...Object.keys(state.selections[stepId]));
        });

        const dimValues = {};
        Object.keys(state.dimensions).forEach(key => {
            dimValues[key] = state.dimensions[key].value;
        });

        const formData = new FormData();
        formData.append('action', 'calculate_price');
        formData.append('id_product', prestashop.cart.id_product || configContainer.closest('.product-container')?.dataset?.idProduct || '');
        formData.append('selections', JSON.stringify(selectedOptionIds));
        formData.append('dimensions', JSON.stringify(dimValues));

        fetch(ajaxUrl, {
            method: 'POST',
            body: new URLSearchParams(formData)
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    priceDisplay.textContent = data.price_formatted;
                }
            });
    }

    // Step Navigation
    nextBtn.addEventListener('click', () => {
        let nextIndex = -1;
        for (let i = currentStepIndex + 1; i < steps.length; i++) {
            if (steps[i].dataset.hidden !== "true") {
                nextIndex = i;
                break;
            }
        }
        if (nextIndex !== -1) {
            currentStepIndex = nextIndex;
            updateUI();
        }
    });

    prevBtn.addEventListener('click', () => {
        let prevIndex = -1;
        for (let i = currentStepIndex - 1; i >= 0; i--) {
            if (steps[i].dataset.hidden !== "true") {
                prevIndex = i;
                break;
            }
        }
        if (prevIndex !== -1) {
            currentStepIndex = prevIndex;
            updateUI();
        }
    });

    // Option Selection
    // Option Selection
    configContainer.addEventListener('click', (e) => {
        const optionCard = e.target.closest('.option-card');
        if (optionCard) {
            const step = optionCard.closest('.config-step');
            const stepId = step.dataset.id;
            const optionId = optionCard.dataset.optionId;
            const label = optionCard.dataset.label;
            const valueKey = optionCard.dataset.valueKey;
            const price = parseFloat(optionCard.dataset.price) || 0;
            
            // Handle RAL Interface Visibility
            const ralInterface = step.querySelector('.ral-interface-container');
            
            // FORCE SINGLE SELECT
            step.querySelectorAll('.option-card').forEach(c => c.classList.remove('selected'));
            state.selections[stepId] = {};

            if (optionCard.dataset.type === 'ral_system') {
                // It is a RAL option
                if (ralInterface) {
                    ralInterface.classList.remove('d-none');
                    // Initialize grid if empty
                    const grid = ralInterface.querySelector('.ral-colors-grid');
                    const cats = ralInterface.querySelector('.ral-categories');
                    if (grid && grid.innerHTML === '') {
                         initializeRalPicker(ralInterface);
                    }
                    // Scroll to it for better UX
                    setTimeout(() => ralInterface.scrollIntoView({behavior: 'smooth', block: 'start'}), 100);
                }
                
                state.selections[stepId][optionId] = { label: label, valueKey: valueKey, price: price };
                
            } else {
                // Standard option
                if (ralInterface) ralInterface.classList.add('d-none');
                state.selections[stepId][optionId] = { label: label, valueKey: valueKey, price: price };
            }

            optionCard.classList.add('selected');
            updateUI();
        }
    });

    // Dimension Inputs
    configContainer.addEventListener('input', (e) => {
        if (e.target.classList.contains('dimension-input')) {
            const key = e.target.dataset.key;
            const label = e.target.dataset.label;
            state.dimensions[key] = {
                value: e.target.value,
                label: label
            };
            updateUI();
        }
    });

    // Expose Qty function
    window.updateConfigQty = function (change) {
        const qtyInput = document.getElementById('config-qty');
        if (qtyInput) {
            let val = parseInt(qtyInput.value) || 1;
            val += change;
            if (val < 1) val = 1;
            qtyInput.value = val;
        }
    };

    // File Upload Preview
    const fileInput = document.getElementById('config-custom-file');
    const dropzone = document.getElementById('config-file-dropzone');
    if (dropzone && fileInput) {
        dropzone.addEventListener('click', () => fileInput.click());
        fileInput.addEventListener('change', () => {
            if (fileInput.files.length > 0) {
                document.getElementById('file-preview-name').textContent = fileInput.files[0].name;
            }
        });
    }

    // Add To Cart Logic
    function handleAddToCart(e) {
        // We prevent default immediately to handle via AJAX
        e.preventDefault();
        e.stopPropagation();

        const btn = e.currentTarget;
        const originalText = btn.innerHTML;

        try {
            let qty = 1;

            // Determine which quantity input to use based on the button clicked
            if (btn.id === 'config-add-to-cart-main') {
                const moduleQtyInput = document.getElementById('config-qty');
                if (moduleQtyInput) qty = moduleQtyInput.value;
            } else {
                const mainQtyInput = document.getElementById('quantity_wanted');
                if (mainQtyInput) qty = mainQtyInput.value;
            }

            const comment = document.getElementById('config-comment') ? document.getElementById('config-comment').value : '';

            // Collect Form Data
            const formData = new FormData();
            formData.append('action', 'add_to_cart');
            formData.append('ajax', 1);
            formData.append('qty', qty);
            formData.append('comment', comment);
            // Append selections
            formData.append('selections', JSON.stringify(state.selections || {}));
            formData.append('dimensions', JSON.stringify(state.dimensions || {}));
            formData.append('id_product', prestashop.cart.id_product || configContainer.closest('.product-container')?.dataset?.idProduct || 0);

            if (fileInput && fileInput.files.length > 0) {
                formData.append('custom_file', fileInput.files[0]);
            }

            // Add loading state
            btn.disabled = true;
            btn.innerHTML = '<i class="material-icons text-spin">refresh</i> ' + (btn.dataset.loadingText || 'Adding...');

            fetch(ajaxUrl, {
                method: 'POST',
                body: formData
            })
                .then(res => res.json())
                .then(data => {
                    btn.disabled = false;
                    btn.innerHTML = originalText;

                    if (data.success) {
                        prestashop.emit('updateCart', { reason: { linkAction: 'add-to-cart' } });
                    } else {
                        const errorMsg = data.errors || 'Error adding to cart';
                        alert(errorMsg);
                    }
                })
                .catch(err => {
                    console.error(err);
                    btn.disabled = false;
                    btn.innerHTML = originalText;
                    alert('An error occurred while adding to cart.');
                });

        } catch (error) {
            console.error('Configurator Error:', error);
            btn.disabled = false;
            btn.innerHTML = originalText;
            alert('Failed to process configuration.');
        }
    }

    // Attach to Module Button (Summary Step)
    const mainCartBtn = document.getElementById('config-add-to-cart-main');
    if (mainCartBtn) {
        mainCartBtn.addEventListener('click', handleAddToCart);
    }

    // Attach to Main Product Page Button
    // We try to find the standard PrestaShop add-to-cart button
    const productAddToCartBtn = document.querySelector('.product-add-to-cart .add-to-cart');
    if (productAddToCartBtn) {
        // Remove existing listeners by cloning (brute force) or just add ours and preventDefault
        // Adding ours with preventDefault is usually enough if it runs first or if we can stop propagation.
        // However, PrestaShop binds with jQuery usually.
        // We will try standard addEventListener. 
        productAddToCartBtn.addEventListener('click', handleAddToCart);

        // Also disable the button if configuration is not complete? 
        // For now, we let them click and maybe validate in handleAddToCart if needed, 
        // but currently there is no strict validation logic shown.
    }

    // --- RAL SYSTEM LOGIC ---
    const RAL_FAMILIES = {
        'yellow': {
            label: 'Jaunes',
            colors: [
                {code: '1000', hex: '#D6C68B'}, {code: '1001', hex: '#D3B683'}, {code: '1002', hex: '#D2AA6D'}, 
                {code: '1003', hex: '#F9A800'}, {code: '1004', hex: '#E4A010'}, {code: '1005', hex: '#CB8E16'},
                {code: '1006', hex: '#E1A100'}, {code: '1007', hex: '#E88C00'}, {code: '1011', hex: '#AD8B59'},
                {code: '1012', hex: '#DDD968'}, {code: '1013', hex: '#EAE6CA'}, {code: '1014', hex: '#E1CC4F'},
                {code: '1015', hex: '#E6D690'}, {code: '1016', hex: '#EDFF21'}, {code: '1017', hex: '#F5D033'},
                {code: '1018', hex: '#F8F32B'}, {code: '1019', hex: '#A4957D'}, {code: '1020', hex: '#A08F65'},
                {code: '1021', hex: '#F6B600'}, {code: '1023', hex: '#F7B500'}, {code: '1024', hex: '#BA8F4C'},
                {code: '1027', hex: '#A77F0E'}, {code: '1028', hex: '#FFAB00'}, {code: '1032', hex: '#E2A300'},
                {code: '1033', hex: '#F3752C'}, {code: '1034', hex: '#E09E3F'}, {code: '1037', hex: '#E88C00'}
            ]
        },
        'orange': {
            label: 'Oranges',
            colors: [
                {code: '2000', hex: '#ED6B28'}, {code: '2001', hex: '#BE4E20'}, {code: '2002', hex: '#CB3234'},
                {code: '2003', hex: '#FF7514'}, {code: '2004', hex: '#F05620'}, {code: '2008', hex: '#F3752C'},
                {code: '2009', hex: '#E8521C'}, {code: '2010', hex: '#D84B20'}, {code: '2011', hex: '#EC7C26'},
                {code: '2012', hex: '#E55137'}
            ]
        },
        'red': {
            label: 'Rouges',
            colors: [
                {code: '3000', hex: '#AF2B1E'}, {code: '3001', hex: '#A52019'}, {code: '3002', hex: '#9B111E'},
                {code: '3003', hex: '#900020'}, {code: '3004', hex: '#75151E'}, {code: '3005', hex: '#5E2129'},
                {code: '3007', hex: '#412227'}, {code: '3009', hex: '#6D3F38'}, {code: '3011', hex: '#7C2C28'},
                {code: '3013', hex: '#A12312'}, {code: '3016', hex: '#B32D29'}, {code: '3020', hex: '#CC0605'},
                {code: '3031', hex: '#AB2328'}
            ]
        },
        'pink': {
            label: 'Roses/Violets',
            colors: [
                {code: '4001', hex: '#8A5A83'}, {code: '4002', hex: '#933D50'}, {code: '4003', hex: '#D15887'},
                {code: '4004', hex: '#6B1C23'}, {code: '4005', hex: '#7E6DA7'}, {code: '4006', hex: '#9F338C'},
                {code: '4007', hex: '#4A192C'}, {code: '4008', hex: '#904684'}, {code: '4010', hex: '#D43075'}
            ]
        },
        'blue': {
            label: 'Bleus',
            colors: [
                {code: '5000', hex: '#354D73'}, {code: '5001', hex: '#1F3438'}, {code: '5002', hex: '#20214F'},
                {code: '5003', hex: '#1D1E33'}, {code: '5004', hex: '#18171C'}, {code: '5005', hex: '#1E2460'},
                {code: '5007', hex: '#3E5F8A'}, {code: '5008', hex: '#26252D'}, {code: '5009', hex: '#345271'},
                {code: '5010', hex: '#183980'}, {code: '5011', hex: '#1D1E2C'}, {code: '5012', hex: '#3886BC'},
                {code: '5013', hex: '#1E213D'}, {code: '5014', hex: '#606E8C'}, {code: '5015', hex: '#2973B8'},
                {code: '5017', hex: '#2F4F7F'}, {code: '5018', hex: '#398E8B'}, {code: '5019', hex: '#175676'},
                {code: '5020', hex: '#1D3338'}, {code: '5021', hex: '#2D6B71'}, {code: '5023', hex: '#487FA3'}
            ]
        },
        'green': {
            label: 'Verts',
            colors: [
                {code: '6000', hex: '#42755E'}, {code: '6001', hex: '#346A38'}, {code: '6002', hex: '#2D572C'},
                {code: '6003', hex: '#424632'}, {code: '6004', hex: '#1F3A3D'}, {code: '6005', hex: '#2F4538'},
                {code: '6009', hex: '#253529'}, {code: '6010', hex: '#3F612D'}, {code: '6011', hex: '#587246'},
                {code: '6016', hex: '#1D4536'}, {code: '6018', hex: '#57A639'}, {code: '6019', hex: '#B9CEAC'},
                {code: '6021', hex: '#8A9977'}, {code: '6024', hex: '#358155'}, {code: '6029', hex: '#20603D'}
            ]
        },
        'grey': {
            label: 'Gris',
            colors: [
                {code: '7000', hex: '#7E8B92'}, {code: '7001', hex: '#8F999F'}, {code: '7004', hex: '#9DA1AA'},
                {code: '7005', hex: '#6B6E6B'}, {code: '7006', hex: '#756F61'}, {code: '7011', hex: '#5D666E'},
                {code: '7012', hex: '#596163'}, {code: '7015', hex: '#51565C'}, {code: '7016', hex: '#3B3F42'},
                {code: '7021', hex: '#2E3234'}, {code: '7022', hex: '#4D4A44'}, {code: '7024', hex: '#474A51'},
                {code: '7030', hex: '#939388'}, {code: '7032', hex: '#B8B799'}, {code: '7035', hex: '#D7DBD5'},
                {code: '7037', hex: '#7D7F7E'}, {code: '7040', hex: '#9DA1AA'}, {code: '7042', hex: '#8F9695'},
                {code: '7043', hex: '#4E5452'}, {code: '7044', hex: '#BDBDB2'}
            ]
        },
        'brown': {
            label: 'Bruns',
            colors: [
                {code: '8000', hex: '#826C42'}, {code: '8001', hex: '#935F33'}, {code: '8003', hex: '#734222'},
                {code: '8004', hex: '#88442D'}, {code: '8007', hex: '#633A34'}, {code: '8011', hex: '#59351F'},
                {code: '8014', hex: '#49392D'}, {code: '8015', hex: '#5A2F2B'}, {code: '8016', hex: '#4C2F27'},
                {code: '8017', hex: '#45322E'}, {code: '8019', hex: '#3F3A3A'}, {code: '8028', hex: '#4E3B31'}
            ]
        },
        'white_black': {
            label: 'Blancs/Noirs',
            colors: [
                {code: '9001', hex: '#FDF4E3'}, {code: '9002', hex: '#E7EBDA'}, {code: '9003', hex: '#F4F4F4'},
                {code: '9004', hex: '#282828'}, {code: '9005', hex: '#0A0A0A'}, {code: '9006', hex: '#A5A5A5'},
                {code: '9007', hex: '#8F8F8F'}, {code: '9010', hex: '#F7F9EF'}, {code: '9016', hex: '#F6F6F6'}
            ]
        }
    };

    const RAL_BAR_COLORS = {
        'yellow': '#D6C68B', 'orange': '#ED6B28', 'red': '#AF2B1E', 'pink': '#D15887',
        'blue': '#1E2460', 'green': '#346A38', 'grey': '#7E8B92', 'brown': '#734222',
        'white_black': '#282828'
    };

    function initializeRalPicker(interfaceContainer) {
        const categories = interfaceContainer.querySelector('.ral-categories');
        const grid = interfaceContainer.querySelector('.ral-colors-grid');
        
        categories.innerHTML = ''; // Clear
        
        // Build Categories in a style to match design
        Object.keys(RAL_FAMILIES).forEach((key) => {
            const family = RAL_FAMILIES[key];
            const tab = document.createElement('div');
            tab.className = 'ral-cat-bar col-md-5 m-2 p-3 text-center text-white shadow-sm';
            tab.style.backgroundColor = RAL_BAR_COLORS[key] || '#333';
            tab.style.cursor = 'pointer';
            tab.style.fontWeight = 'bold';
            tab.style.borderRadius = '6px';
            tab.style.transition = 'transform 0.2s';
            tab.textContent = family.label;
            
            tab.onmouseover = () => tab.style.transform = 'scale(1.05)';
            tab.onmouseout = () => tab.style.transform = 'scale(1)';
            tab.onclick = () => loadRalGrid(grid, key, interfaceContainer);
            categories.appendChild(tab);
        });
        
        // Load first
        loadRalGrid(grid, 'yellow', interfaceContainer);
    }

    function loadRalGrid(grid, catKey, interfaceContainer) {
        grid.innerHTML = '';
        const family = RAL_FAMILIES[catKey];
        if (!family || !family.colors) return;
        const colors = family.colors;

        colors.forEach(col => {
            const item = document.createElement('div');
            item.className = 'ral-swatch-item d-inline-block m-2 text-center';
            item.style.cursor = 'pointer';
            item.innerHTML = `
                <div class="ral-swatch-color" style="background-color: ${col.hex}; width: 60px; height: 35px; border-radius: 4px; border: 1px solid #ccc;"></div>
                <div class="ral-swatch-code mt-1" style="font-size: 11px;">RAL ${col.code}</div>
            `;
            item.onclick = () => processRalSelection(interfaceContainer, 'RAL ' + col.code, col.hex);
            grid.appendChild(item);
        });
    }

    function processRalSelection(interfaceContainer, fullCode, hex) {
        const optionId = interfaceContainer.dataset.optionId;
        const step = interfaceContainer.closest('.config-step');
        const stepId = step.dataset.id;
        
        // Update input
        const input = interfaceContainer.querySelector('.ral-manual-input-field');
        if (input && document.activeElement !== input) {
            input.value = fullCode.replace('RAL ', '');
        }

        // Find the trigger card
        const card = step.querySelector(`.option-card[data-option-id="${optionId}"]`);
        if (!card) return;

        const baseLabel = card.dataset.label;
        const customLabel = `${baseLabel} (${fullCode})`;
        const valueKey = card.dataset.valueKey + '_' + fullCode.replace(/\s+/g, '');
        const price = parseFloat(card.dataset.price) || 0;

        state.selections[stepId] = {}; // Ensure single select
        state.selections[stepId][optionId] = { 
            label: customLabel, 
            valueKey: valueKey,
            price: price
        };
        
        updateUI();
    }

    attachRalEvents();

    updateUI();
});
