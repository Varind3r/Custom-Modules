# Conditional Logic & Step Types Guide

## 📋 Conditional Logic Fields

### 1. **Depends On Step** (`depends_on_step`)
**Purpose**: Makes this step visible only when a specific previous step has been completed.

**How it works**:
- Select which step this step depends on from the dropdown
- If set to "None", the step is always visible
- The step will only show when the selected dependency step has selections

**Example**:
- Step 1: "Choose Material" (PVC, Aluminum, Wood)
- Step 2: "Choose Color" → Depends On Step: Step 1
- Result: Color step only appears after Material is selected

---

### 2. **Trigger Values** (`depends_on_value` / `trigger_values`)
**Purpose**: Specifies which specific option values from the dependency step will trigger this step to show.

**How it works**:
- Enter comma-separated values (option labels or value keys)
- These values are matched against what the user selected in the dependency step
- Case-insensitive matching
- Supports partial matching (e.g., "PVC" matches "PVC White")

**Example**:
- Step 1: "Choose Material" with options: "PVC", "Aluminum", "Wood"
- Step 2: "Choose Color" → Depends On Step: Step 1, Trigger Values: "PVC, Aluminum"
- Result: Color step only shows if user selected PVC or Aluminum (not Wood)

**Format**: `PVC, Aluminum, Wood` (comma-separated, no quotes needed)

---

### 3. **Show Condition** (`show_condition`)
**Purpose**: Determines how trigger values are evaluated (ANY, ALL, or NONE).

**Options**:

#### **ANY** (Default)
- Step shows if **any** of the trigger values match
- Most common use case
- Example: If trigger values are "PVC, Aluminum" and user selects "PVC" → Step shows ✅

#### **ALL**
- Step shows only if **all** trigger values match
- Useful when multiple conditions must be met
- Example: If trigger values are "PVC, White" and user selects both "PVC" AND "White" → Step shows ✅
- If user only selects "PVC" → Step hidden ❌

#### **NONE**
- Step shows if **none** of the trigger values match
- Inverted logic - shows when specified values are NOT selected
- Example: If trigger values are "PVC, Aluminum" and user selects "Wood" → Step shows ✅
- If user selects "PVC" → Step hidden ❌

---

## 🔄 How Conditional Logic Works Together

The system evaluates visibility in this order:

1. **Check if `depends_on_step` is set**
   - If "None" → Step is always visible
   - If set → Continue to step 2

2. **Get selections from dependency step**
   - System looks at what user selected in the dependency step
   - Extracts option labels and value keys

3. **Match trigger values**
   - Compares `depends_on_value` (trigger values) with user selections
   - Uses `show_condition` (ANY/ALL/NONE) to determine match

4. **Update visibility**
   - If condition is met → Step shows
   - If condition not met → Step is hidden

**Real-time Updates**: Visibility is recalculated automatically when:
- User selects/deselects options
- User changes dimension values
- User selects RAL colors

---

## 📝 Step Types Explained

### 1. **Content Only** (`content`)
**Purpose**: Display information only, no user input required.

**Use Cases**:
- Welcome message
- Instructions
- Information about the product
- Terms and conditions

**Features**:
- No options needed
- Can have description/HTML content
- Always visible (unless conditional logic hides it)

---

### 2. **Choice** (`choice`)
**Purpose**: User selects ONE option from multiple choices.

**Use Cases**:
- Material selection (PVC, Aluminum, Wood)
- Style selection (Modern, Classic)
- Single color choice

**Features**:
- Radio button behavior (one selection only)
- Options can have images
- Options can have pricing
- Supports Visual Choice and RAL Color System

**Option Types Available**:
- **Visual Choice**: Image-based selection with cards
- **RAL Color System**: Color picker with RAL library
- **Toggle**: On/Off switch

---

### 3. **Multi Choice** (`multi_choice`)
**Purpose**: User can select MULTIPLE options.

**Use Cases**:
- Add-ons (Window locks, Screens, etc.)
- Features selection
- Multiple accessories

**Features**:
- Checkbox behavior (multiple selections)
- Each option can be selected independently
- Options can have pricing (prices add up)
- Supports Visual Choice and RAL Color System

**Option Types Available**:
- **Visual Choice**: Image-based selection with cards
- **RAL Color System**: Color picker with RAL library
- **Toggle**: On/Off switch

---

### 4. **Dimension** (`dimension`)
**Purpose**: User enters numeric measurements (width, height, length, etc.).

**Use Cases**:
- Window dimensions (width × height)
- Custom sizes
- Quantity input
- Any numeric value

**Features**:
- Number input field
- Can have min/max/step values
- Supports unit conversion (mm to meters)
- Price calculation based on dimensions (m, m², m³)
- Can have multiple dimension fields per step

**Option Types Available**:
- **Dimension**: Single number input
- **Range Slider**: Visual slider for numeric input

**Pricing**:
- **Per Unit**: Price per meter (m)
- **Per Area**: Price per square meter (m²)
- **Per Volume**: Price per cubic meter (m³)
- **Fixed**: Fixed price regardless of dimension
- **Percentage**: Percentage of base price
- **Formula**: Custom calculation formula

---

### 5. **Summary** (`summary`)
**Purpose**: Display a summary of all selections before checkout.

**Use Cases**:
- Review all selections
- Final confirmation
- Show total price breakdown

**Features**:
- Automatically populated with all previous selections
- Shows selected options, dimensions, colors
- Displays total price
- Usually the last step before "Add to Cart"

---

## 🎯 Complete Example: Window Configurator

### Step 1: Material (Choice)
- **Type**: Choice
- **Options**: PVC, Aluminum, Wood
- **Conditional Logic**: None (always visible)

### Step 2: Color (Choice)
- **Type**: Choice
- **Options**: White, Black, Brown (RAL colors)
- **Depends On Step**: Step 1 (Material)
- **Trigger Values**: PVC, Aluminum
- **Show Condition**: ANY
- **Result**: Color step only shows if Material is PVC or Aluminum

### Step 3: Dimensions (Dimension)
- **Type**: Dimension
- **Options**: Width (mm), Height (mm)
- **Depends On Step**: Step 1 (Material)
- **Trigger Values**: PVC, Aluminum, Wood
- **Show Condition**: ANY
- **Result**: Always visible (all materials need dimensions)

### Step 4: Add-ons (Multi Choice)
- **Type**: Multi Choice
- **Options**: Window Locks, Screens, Blinds
- **Depends On Step**: Step 2 (Color)
- **Trigger Values**: White, Black
- **Show Condition**: ANY
- **Result**: Add-ons only show for White or Black colors

### Step 5: Summary (Summary)
- **Type**: Summary
- **Conditional Logic**: None (always visible as last step)
- **Result**: Shows all selections and total price

---

## ✅ Verification Checklist

To verify conditional logic is working:

1. **Test Depends On Step**:
   - ✅ Step with dependency should be hidden initially
   - ✅ Step should appear when dependency step has selection
   - ✅ Step should hide if dependency selection is removed

2. **Test Trigger Values**:
   - ✅ Step shows when matching trigger value is selected
   - ✅ Step hides when non-matching value is selected
   - ✅ Multiple trigger values work correctly

3. **Test Show Condition**:
   - ✅ **ANY**: Shows if any trigger value matches
   - ✅ **ALL**: Shows only if all trigger values match
   - ✅ **NONE**: Shows if no trigger values match

4. **Test Real-time Updates**:
   - ✅ Visibility updates immediately when selection changes
   - ✅ Step navigation adjusts automatically
   - ✅ Hidden steps are skipped in navigation

---

## 🔧 Troubleshooting

### Step not showing when it should:
1. Check `depends_on_step` is set correctly
2. Verify `trigger_values` match option labels exactly (case-insensitive)
3. Check `show_condition` is set to correct value (ANY/ALL/NONE)
4. Ensure dependency step has selections
5. Check browser console for JavaScript errors

### Step showing when it shouldn't:
1. Verify `depends_on_step` is not set to "None"
2. Check `trigger_values` don't accidentally match
3. Verify `show_condition` logic (NONE might be inverted)

### Step type not working:
1. Ensure step has options (except Content and Summary types)
2. Check option type matches step type requirements
3. Verify JavaScript is loaded (check browser console)

---

**Last Updated**: Current Date
**Module Version**: 1.0.0

