# Testing Checklist

## Critical Tests

### 1. Module Installation
- [ ] Install module in PrestaShop
- [ ] Check database tables created (6 tables)
- [ ] Verify id_order field exists in configurator_selection table
- [ ] Check hooks registered in database

### 2. Autoloader Test
- [ ] Create configurator with RAL option
- [ ] Add custom colors to RAL option
- [ ] Save and reload - colors should persist
- [ ] If error "Class CustomColor not found" → autoloader broken

### 3. Order Integration Test
**Test Flow:**
1. [ ] Configure product on product page
2. [ ] Add to cart - check config saved with id_cart
3. [ ] Go to checkout
4. [ ] Complete order
5. [ ] Check order confirmation page - config should display
6. [ ] Go to "My Orders" - config should display
7. [ ] Go to Admin → Orders → View order - config should display
8. [ ] Check database - configurator_selection should have id_order set

**Expected Results:**
- Configuration visible on order confirmation ✅
- Configuration visible in customer order history ✅
- Configuration visible in admin order view ✅
- id_order field populated in database ✅

### 4. Price Types Test
- [ ] Create option with Fixed price - should work
- [ ] Create option with Percentage price - should work (NEW)
- [ ] Create option with Per Unit price - should work
- [ ] Create option with Formula price - should work
- [ ] All 4 types should appear in admin dropdown

### 5. Cart Display Test
- [ ] Add configured product to cart
- [ ] Go to cart page
- [ ] Verify configuration displays correctly
- [ ] Verify dimensions display correctly
- [ ] Verify price calculation shows

### 6. Duplicate Function Test
- [ ] Create configurator with steps, options, custom colors
- [ ] Click duplicate
- [ ] Verify all steps copied
- [ ] Verify all options copied
- [ ] Verify custom colors copied
- [ ] Verify step dependencies work
- [ ] Verify option dependencies work

### 7. JavaScript Test
- [ ] Open product page with configurator
- [ ] Check browser console - no errors
- [ ] Click Next/Previous buttons - should work
- [ ] Select options - should work
- [ ] Add to cart - should work

## Error Tests

### If Order Integration Fails:
- Check: Are hooks registered? (Admin → Modules → Configure)
- Check: Does id_order field exist? (phpMyAdmin)
- Check: Is hookActionValidateOrder being called? (Add logging)

### If CustomColor Fails:
- Check: Is CustomColor in autoloader? (ps_configurator.php line 16)
- Check: Does CustomColor.php exist? (classes/CustomColor.php)
- Check: Error message "Class CustomColor not found"?

### If Percentage Price Fails:
- Check: Is percentage in admin dropdown? (step_options.tpl)
- Check: Is percentage in price_types array? (AdminStepsController.php)
- Check: Does PriceCalculator handle percentage? (classes/PriceCalculator.php line 34)

## Quick Verification

**Run these SQL queries:**
```sql
-- Check id_order field exists
DESCRIBE ps_configurator_selection;

-- Check hooks registered
SELECT * FROM ps_hook_module WHERE id_module = [YOUR_MODULE_ID];

-- Check order linking works
SELECT id_cart, id_order, id_product FROM ps_configurator_selection WHERE id_order IS NOT NULL;
```

**Check files exist:**
- views/templates/front/order_confirmation.tpl ✅
- views/templates/front/order_detail.tpl ✅
- views/templates/admin/order_configuration.tpl ✅

## What Should Work

✅ Product configuration
✅ Cart display
✅ Price calculation (all 4 types)
✅ Order confirmation display
✅ Order history display
✅ Admin order view
✅ Custom colors
✅ Duplicate functionality
✅ Conditional logic

## What Might Break

⚠️ If PrestaShop version < 1.7 - hooks might not work
⚠️ If theme doesn't support hooks - templates won't display
⚠️ If database migration fails - id_order field missing

