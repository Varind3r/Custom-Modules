<?php
/**
 * Theme Content Helper Class
 * 
 * Helper class for easy access to theme content in templates
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class ThemeContentHelper
{
    /**
     * Get content for a specific page and field
     * 
     * @param string $page_identifier Page identifier (e.g., 'home', 'product')
     * @param string $field_key Field key (e.g., 'hero_title')
     * @param int|null $lang_id Language ID (optional)
     * @param int|null $shop_id Shop ID (optional)
     * @return string Content value
     */
    public static function get($page_identifier, $field_key, $lang_id = null, $shop_id = null)
    {
        $module = Module::getInstanceByName('themecontentmanager');
        if (!$module || !$module->active) {
            return '';
        }
        
        return $module->getContentValue($page_identifier, $field_key, $lang_id, $shop_id);
    }

    /**
     * Get all content for a specific page
     * 
     * @param string $page_identifier Page identifier
     * @param int|null $lang_id Language ID (optional)
     * @param int|null $shop_id Shop ID (optional)
     * @return array Array of content fields
     */
    public static function getAll($page_identifier, $lang_id = null, $shop_id = null)
    {
        $module = Module::getInstanceByName('themecontentmanager');
        if (!$module || !$module->active) {
            return array();
        }
        
        return $module->getAllPageContent($page_identifier, $lang_id, $shop_id);
    }

    /**
     * Check if content exists
     * 
     * @param string $page_identifier Page identifier
     * @param string $field_key Field key
     * @param int|null $lang_id Language ID (optional)
     * @param int|null $shop_id Shop ID (optional)
     * @return bool True if content exists
     */
    public static function exists($page_identifier, $field_key, $lang_id = null, $shop_id = null)
    {
        $content = self::get($page_identifier, $field_key, $lang_id, $shop_id);
        return !empty($content);
    }

    /**
     * Get content with default fallback
     * 
     * @param string $page_identifier Page identifier
     * @param string $field_key Field key
     * @param string $default Default value if content doesn't exist
     * @param int|null $lang_id Language ID (optional)
     * @param int|null $shop_id Shop ID (optional)
     * @return string Content value or default
     */
    public static function getWithDefault($page_identifier, $field_key, $default = '', $lang_id = null, $shop_id = null)
    {
        $content = self::get($page_identifier, $field_key, $lang_id, $shop_id);
        return !empty($content) ? $content : $default;
    }
}

