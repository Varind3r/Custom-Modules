# Theme Content Manager for PrestaShop

A comprehensive PrestaShop module that allows you to manage dynamic content for all pages through a theme options sidebar in the PrestaShop back office.

## Features

- ✅ **Theme Options Sidebar**: Easy-to-use sidebar interface in PrestaShop admin
- ✅ **Page-Specific Content**: Manage content for different pages (Home, Product, Category, Contact, etc.)
- ✅ **Multiple Field Types**: Support for Text, Textarea, HTML, Image URL, and URL fields
- ✅ **Multi-Language Support**: Content management for multiple languages
- ✅ **Multi-Shop Support**: Works with PrestaShop multi-shop functionality
- ✅ **Dynamic Template Integration**: Easy access to content in Smarty templates
- ✅ **Custom Fields**: Add custom fields for any page on the fly
- ✅ **Auto-Save**: Automatic saving with debounce for better UX
- ✅ **Image Preview**: Preview images directly in the admin panel

## Installation

1. **Copy the module** to your PrestaShop modules directory:
   ```
   /modules/themecontentmanager/
   ```

2. **Install the module**:
   - Go to PrestaShop Back Office
   - Navigate to Modules → Module Manager
   - Search for "Theme Content Manager"
   - Click "Install"

3. **Configure the module**:
   - After installation, click "Configure"
   - You'll be redirected to the Theme Options sidebar

## Usage

### Admin Interface

1. **Access Theme Options**:
   - Go to Modules → Module Manager
   - Find "Theme Content Manager"
   - Click "Configure"
   - You'll see the Theme Options sidebar

2. **Select a Page**:
   - Use the sidebar navigation to select a page (Home, Product, Category, etc.)

3. **Edit Content**:
   - Fill in the fields for the selected page
   - Content auto-saves after 1 second of inactivity
   - Or click "Save All Content" to save manually

4. **Add Custom Fields**:
   - Use the "Add Custom Field" section
   - Enter Field Key (e.g., `custom_banner`)
   - Enter Field Label (e.g., `Custom Banner`)
   - Select Field Type
   - Click the "+" button

### Using Content in Templates

#### Method 1: Using Helper Class (Recommended)

```php
<?php
// In PHP files
use ThemeContentHelper;

// Get single field
$heroTitle = ThemeContentHelper::get('home', 'hero_title');

// Get all content for a page
$homeContent = ThemeContentHelper::getAll('home');

// Get with default value
$title = ThemeContentHelper::getWithDefault('home', 'hero_title', 'Default Title');

// Check if content exists
if (ThemeContentHelper::exists('home', 'hero_title')) {
    // Content exists
}
```

#### Method 2: Using Module Instance

```php
<?php
// In PHP files
$module = Module::getInstanceByName('themecontentmanager');
$content = $module->getContentValue('home', 'hero_title');
$allContent = $module->getAllPageContent('home');
```

#### Method 3: In Smarty Templates

```smarty
{* Get content directly *}
{$theme_content.hero_title|escape:'html':'UTF-8'}

{* Using module helper *}
{assign var='hero_title' value=Module::getInstanceByName('themecontentmanager')->getContentValue('home', 'hero_title')}
{$hero_title|escape:'html':'UTF-8'}

{* Get all page content *}
{assign var='page_content' value=Module::getInstanceByName('themecontentmanager')->getAllPageContent('home')}
{foreach from=$page_content item=content key=key}
    <div class="field-{$key|escape:'html':'UTF-8'}">
        {if $content.type == 'html'}
            {$content.value nofilter}
        {else}
            {$content.value|escape:'html':'UTF-8'}
        {/if}
    </div>
{/foreach}
```

#### Method 4: Using Hooks

The module registers hooks for common pages. You can customize the hook templates in:
```
/views/templates/hook/
```

## Page Identifiers

Available page identifiers:
- `home` - Home page
- `product` - Product pages
- `category` - Category pages
- `contact` - Contact page
- `cms` - CMS pages
- `cart` - Shopping cart
- `checkout` - Checkout page
- `my-account` - My Account page
- `footer` - Footer area
- `header` - Header area

## Field Types

- **text**: Single line text input
- **textarea**: Multi-line text input
- **html**: Rich text editor (HTML content)
- **image**: Image URL input with preview
- **url**: URL input field

## Database Structure

The module creates a table `ps_theme_content` with the following structure:
- `id_content`: Primary key
- `page_identifier`: Page identifier (e.g., 'home', 'product')
- `field_key`: Field key (e.g., 'hero_title')
- `field_value`: Field value (content)
- `field_type`: Field type (text, textarea, html, image, url)
- `lang_id`: Language ID
- `shop_id`: Shop ID
- `active`: Active status (1 or 0)
- `date_add`: Creation date
- `date_upd`: Update date

## Customization

### Adding Custom Pages

Edit `controllers/admin/AdminThemeContentController.php` and add to `getAvailablePages()`:

```php
private function getAvailablePages()
{
    return array(
        // ... existing pages
        'custom-page' => $this->l('Custom Page'),
    );
}
```

### Adding Default Fields for Pages

Edit `controllers/admin/AdminThemeContentController.php` and add to `getPageFields()`:

```php
private function getPageFields($page_identifier)
{
    $fields = array(
        // ... existing fields
        'custom-page' => array(
            array('key' => 'custom_field', 'label' => 'Custom Field', 'type' => 'text'),
        ),
    );
    return isset($fields[$page_identifier]) ? $fields[$page_identifier] : array();
}
```

### Custom Hook Templates

Create custom templates in:
```
/views/templates/hook/
```

Example: `custom_page.tpl`

## Requirements

- PrestaShop 1.7.x or higher
- PHP 7.1 or higher
- MySQL 5.6 or higher

## Support

For issues, questions, or contributions, please contact the module author.

## License

This module is provided as-is. Modify and use according to your needs.

## Changelog

### Version 1.0.0
- Initial release
- Theme options sidebar
- Multi-language support
- Multi-shop support
- Custom fields support
- Auto-save functionality
- Image preview
- Template integration helpers

